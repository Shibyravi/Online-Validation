package driver;



import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;


public class DriverScript {
	public static Properties prop;
	public static String cell;
	private static DriverScript ds;

	public static Process  process;
	public static DriverScript getInstance(){
        if(ds == null){
            try {
            	ds = new DriverScript();
				//DriverScript.initialization();
			} catch (IOException e) {
				
				e.printStackTrace();
			} catch (Exception e) {
				
				e.printStackTrace();
			}
        }
        return ds;
    }
	public String getReportConfigPath(){
		String reportConfigPath = prop.getProperty("extentReportPath");
		if(reportConfigPath!= null) return reportConfigPath;
		else throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");		
	}
	
	protected DriverScript() throws IOException
	{
		//FunctionLibrary.launchPCOMM();
		prop = new Properties();
		FileInputStream fis = new FileInputStream("src//test//java//config//config.properties");
		prop.load(fis);
		try {
			DriverScript.initialization();
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}
	private static void initialization() throws Exception
	{
		Runtime rt =  Runtime.getRuntime();
		/*try {
				Process  p = rt.exec(KILL + "pcsws.exe");
				rt.exec(KILL + "pcscm.exe");
			} catch (IOException e) {
			
				e.printStackTrace();
			}*/
		//try {
		
		String[] s = new String[] {"pcsws.exe","tn3270.WS"};
		process = rt.exec(s); 
		
			//Thread.sleep(10000);
		//} 
		//catch (InterruptedException e) {
		
			//e.printStackTrace();
		//}
		String env = prop.getProperty("environment");
		if(env.equalsIgnoreCase("alpha"))
		{
			FunctionLibrary.loginPCOMM("CICSAAA1",prop);
		}
		else if (env.equalsIgnoreCase("bravo"))
		{
			FunctionLibrary.loginPCOMM("CICSBAB1",prop);
		}
	}	
		
		//Close all opened sessions of PCOM and open a fresh session

		////Codes to be deleted.. Testing purpose -INQUIRE
		//FunctionLibrary.changeDiv();
		//FunctionLibrary.InquireClaim("080566689", "", "OHO", "HO400","AUD",9,4,6,0,0,0);
		//FunctionLibrary.InquireClaim("080566689", "", "OHO", "HO409","AUD",9,4,6,0,0,0);
		//FunctionLibrary.InquireClaim("080566689", "", "OHO", "HO410","AUD",9,4,6,0,0,0);
		//FunctionLibrary.InquireClaim("090219638", "", "OEB", "HO409","AUD",9,4,6,0,0,0);
		//FunctionLibrary.InquireClaim("8896362700", "", "OEB", "CL209","CLAIM AUDIT",8,4,22,2,4,33);
		//FunctionLibrary.InquireClaim("8896362800", "", "OEB", "CL209","CLAIM AUDIT",8,4,22,2,4,33);
		//FunctionLibrary.InquireClaim("8896361200", "", "OEB", "CL201","AUDIT",8,4,13,2,4,24);
		//PRICER CODE
		//String cell = FunctionLibrary.getClaimValue("HO430", "", "", 3, 12, 16,5);
		//Interest
		//String cell = FunctionLibrary.getClaimValue("HO430", "", "", 10, 21, 40,0);
		//Det deny code
		//cell = FunctionLibrary.getClaimValue("HO400", "", "", 4, 11, 77,0);
		//Prov status
		//cell = FunctionLibrary.getClaimValue("HO409", "", "",8,10,15,1);
		//cell = FunctionLibrary.getClaimValue("CL201", "");
		//FunctionLibrary.getClaimValue("HO410", "", "",8,10,15,1);
	//	List al = (List) FunctionLibrary.getReviewClearDetails("CL209", "00647",6);
		//List al = FunctionLibrary.getReviewClearDetails("HO409", "00372",9);
		//Thread.sleep(2000);
	//	System.out.println("Done "+cell);
		
	}
	


