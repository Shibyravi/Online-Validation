package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class Physician_CL138 {
	public Field DeductibleFlag,SupplyPlanCode;
	public Screen ScreenName1;
	public Physician_CL138(){
		try {				
			SupplyPlanCode= Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("U").build()).describe(Field.class, new FieldDescription.Builder()
					.length(10).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(18)).build());
			
			
			
			DeductibleFlag=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("U").build()).describe(Field.class, new FieldDescription.Builder()
							.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(8).setColumn(28)).build());
			ScreenName1=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("U").size(new com.hp.lft.sdk.te.SizeProperty().setRowCount(24).setColumnCount(80)).build());
			
			
		} catch (GeneralLeanFtException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}


public void CL138_Inquire(String Supply_code, String screen) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary fl_inq_bpl = new FunctionLibrary();
		fl_inq_bpl.InquireServiceCode(Supply_code, screen, 4,4,18);
		
	}
	
	
	public String DeductibleFlagValidation() throws IOException, GeneralLeanFtException{
		
		String Deductible_Flag = null;
		FunctionLibrary fl_effec_date = new FunctionLibrary();
		Deductible_Flag = fl_effec_date.getClaimValue("CL140",DeductibleFlag,0,0);
		return Deductible_Flag;
		
		}
	


  
   }
   

	   
	   
   
