package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;
public class Physician_PS343 {
	public Field contract,anes_factor;
	public Screen main_screen;
    public Physician_PS343()
    {
    	try{
    		contract = Desktop.describe(Window.class, new WindowDescription.Builder()
    				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
    						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
    						.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(21)).build());
    		anes_factor=Desktop.describe(Window.class, new WindowDescription.Builder()
    				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
    						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
    						.length(8).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(23)).build());
    		main_screen=Desktop.describe(Window.class, new WindowDescription.Builder()
    				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
    				.label("UNI").build());
    	}
    	catch (GeneralLeanFtException e) {
            e.printStackTrace();
}
    }
    public void PS343_Inquire(String exp_contract, String screen) throws GeneralLeanFtException, InterruptedException, IOException
 	{
 		FunctionLibrary fl_inq = new FunctionLibrary();
 		fl_inq.InquireContract(exp_contract, "PS343");
 	}
  
    public String contract_val() throws IOException, GeneralLeanFtException
    {
                   String phy_contract = null;
                   FunctionLibrary fl_cont = new FunctionLibrary();
                   phy_contract = fl_cont.getClaimValue("PS343",contract,0,0);
                   return phy_contract;
    }
    public String anesfact_val() throws IOException, GeneralLeanFtException
    {
                   String phy_anes = null;
                   FunctionLibrary fl_cont = new FunctionLibrary();
                   phy_anes = fl_cont.getClaimValue("PS343",anes_factor,0,0);
                   return phy_anes;
    }
}
