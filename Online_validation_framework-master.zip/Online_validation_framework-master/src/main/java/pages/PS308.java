package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;
//
public class PS308 {
	public Field schedule, proc_code,base_fee,PTI,IND,SRC_IND,prov_Code1,prov_Code2,ScreenField,prov_Indent,fedTax_id;
	public Screen main_screen,ScreenNameA;
	FunctionLibrary funlib;
	public PS308() throws GeneralLeanFtException
	{
	//lj
		ScreenNameA=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNIT").build());
		
		PTI=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNIT").build()).describe(Field.class, new FieldDescription.Builder()
				.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(6).setColumn(64)).build());
		SRC_IND=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNIT").build()).describe(Field.class, new FieldDescription.Builder()
				.length(2).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(3).setColumn(64)).build());
		
		IND=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNIT").build()).describe(Field.class, new FieldDescription.Builder()
				.length(1).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(6).setColumn(78)).build());
		

		prov_Code1=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNIT").build()).describe(Field.class, new FieldDescription.Builder()
				.length(4).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(3).setColumn(17)).index(0).build());
		
		prov_Code2=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNIT").build()).describe(Field.class, new FieldDescription.Builder()
						.length(7).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(3).setColumn(24)).build());
		prov_Indent=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNIT").build()).describe(Field.class, new FieldDescription.Builder()
						.length(2).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(17)).build());
				
	funlib = new FunctionLibrary();
		
		ScreenField=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNIT").build()).describe(Field.class, new FieldDescription.Builder()
						.length(5).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(1).setColumn(4)).build());
		
		fedTax_id=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNIT").build()).describe(Field.class, new FieldDescription.Builder()
						.length(9).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(20).setColumn(13)).build());
	
	}

	public String Provider_Indent_val() throws IOException, GeneralLeanFtException
	{
		String Provider_Indent_val = null;
		Provider_Indent_val = funlib.getClaimValue("PS308",prov_Indent,0,0);
		return Provider_Indent_val;
	}
	public String PTI_val() throws IOException, GeneralLeanFtException
	{
		String pti = null;
		pti = funlib.getClaimValue("PS308",PTI,0,0);
		return pti;
	}
	
	public String IND_val() throws IOException, GeneralLeanFtException
	{
		String ind = null;
		ind = funlib.getClaimValue("PS308",IND,0,0);
		return ind;
	}
	public String SRC_IND_val() throws IOException, GeneralLeanFtException
	{
		String src_ind = null;
		src_ind = funlib.getClaimValue("PS308",SRC_IND,0,0);
		return src_ind;
	}
	
	public void  PS308_Inquire(String Prov_Code1,String Prov_Code2,String Screen) throws IOException, GeneralLeanFtException, InterruptedException
	{
		funlib.InquireProviderNo(Prov_Code1, Prov_Code2, Screen);
	}
	
	
	public void enter_NewScreen(String Screen) throws IOException, GeneralLeanFtException
	{
	ScreenField.setText(Screen);
		ScreenNameA.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);	

	}
	
	public String fed_Tax_val() throws IOException, GeneralLeanFtException
	{
		String pti = null;
		pti = funlib.getClaimValue("PS308",fedTax_id,0,0);
		return pti;
	}
	
}
