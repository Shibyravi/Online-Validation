package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class Provider_GI302 {

public Field select,provider,splitIndicator,ScreenField;
public Screen screen_GI302,cur_screen;

public Provider_GI302() throws GeneralLeanFtException
{
		select= Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(3)).build());
		screen_GI302=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build());
		provider=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(18).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(12)).build());
		cur_screen=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build());
		splitIndicator=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(90).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(17).setColumn(5)).build());
		ScreenField=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(1).setColumn(4)).build());
}
public void provider_inq(String prov_number,String screen) throws IOException, GeneralLeanFtException, InterruptedException
{
	
	FunctionLibrary fl_prov = new FunctionLibrary();
	
	fl_prov.InquireProvider(prov_number,"GI302",18,5,12);
	
}
public String Indicator_val() throws IOException, GeneralLeanFtException
{
	FunctionLibrary funlib = new FunctionLibrary();
	String indicator = null;
	indicator = funlib.getClaimValue("GI302",splitIndicator,74,77);
	return indicator;
}
public void enter_NewScreen(String Screen) throws IOException, GeneralLeanFtException
{
ScreenField.setText(Screen);
screen_GI302.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);	

}

}
