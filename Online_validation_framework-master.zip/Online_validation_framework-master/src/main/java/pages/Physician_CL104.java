package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class Physician_CL104 {
	public Field key,status,tempAudit;

	
	
	
	public Screen Screen;
	public Physician_CL104()
	{
		try {
			
		   Screen=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build());
		  
		 status= Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("screen33641").build()).describe(Field.class, new FieldDescription.Builder()
					.length(2).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(3).setColumn(38)).build());
		 
		tempAudit=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("screen33641").build()).describe(Field.class, new FieldDescription.Builder()
						.length(12).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(3).setColumn(14)).build()); 
		
		key=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("screen33641").build()).describe(Field.class, new FieldDescription.Builder()
						.length(43).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(23).setColumn(2)).build());
		}
		
		
		catch (GeneralLeanFtException e) {
			e.printStackTrace();
		}
}

	
	public String getStatus() throws IOException, GeneralLeanFtException, InterruptedException
	{
		Thread.sleep(800);
		String phy_key_Number = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_key_Number = fl_chk_val.getClaimValue("CL104",status,0,0);
		return phy_key_Number;
	}
	
	public String getKeyValue() throws IOException, GeneralLeanFtException
	{
		String phy_key_Number = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_key_Number = fl_chk_val.getClaimValue("CL104",key,11,26);
		return phy_key_Number;
	}
	
	public String gettempAudit() throws IOException, GeneralLeanFtException
	{
		String phy_key_Number = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_key_Number = fl_chk_val.getClaimValue("CL104",tempAudit,0,0);
		return phy_key_Number;
	}
}
