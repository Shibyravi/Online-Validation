package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class Physician_CL214 {
	public Field Additional_info_letter,AUDIT, sub_aud,Information_follow_up_letter, Enrolee_notification_letter;
	public Screen main_screen,ScreenNameA;
	FunctionLibrary funlib;
	public Physician_CL214() throws GeneralLeanFtException
	{
		
		ScreenNameA= Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build());
		funlib = new FunctionLibrary();
		
		Enrolee_notification_letter= Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(15).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(10).setColumn(65)).build());
		Information_follow_up_letter= Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(15).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(11).setColumn(65)).build());
		Additional_info_letter= Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(10).setColumn(25)).build());
		AUDIT=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(8).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(13)).build());
		sub_aud=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(2).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(24)).build());
	
	}
	public void CL214_Inquire(String phys_aud, String c_div) throws GeneralLeanFtException, InterruptedException, IOException
	{
		//FunctionLibrary fl_inq2 = new FunctionLibrary();
		String x=phys_aud.substring(0,8);
		String y=phys_aud.substring(8);
				
		AUDIT.setText(x);
		sub_aud.setText(y);
		ScreenNameA.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		Thread.sleep(1000);
		//fl_inq2.InquireClaim(phys_aud,  c_div, "CL214","AUDIT",8,4,13,2,4,24);
		//fl_inq.InquireClaim(phys_aud,  c_div, "CL201", "AUDIT",8,4,13,2,4,24);
	}
	public String Enrolee_notification_letter_val() throws IOException, GeneralLeanFtException
	{
		String ps_schedule = null;
		ps_schedule = funlib.getClaimValue("CL214",Enrolee_notification_letter,0,0);
		return ps_schedule;
	}
	
	public String Information_follow_up_letter_val() throws IOException, GeneralLeanFtException
	{
		String ps_schedule = null;
		ps_schedule = funlib.getClaimValue("CL214",Information_follow_up_letter,0,0);
		return ps_schedule;
	}
	public String Additional_info_letter_val() throws IOException, GeneralLeanFtException
	{
		String ps_schedule = null;
		ps_schedule = funlib.getClaimValue("CL214",Additional_info_letter,0,0);
		return ps_schedule;
	}

}
