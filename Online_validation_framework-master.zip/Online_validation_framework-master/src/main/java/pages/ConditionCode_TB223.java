package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;

import util.FunctionLibrary;

import com.hp.lft.sdk.te.*;

public class ConditionCode_TB223 {

	public Field cc_inq,cc;
	public Screen main_screen;
	public ConditionCode_TB223()
	{
		try {
			cc_inq = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder().label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(2).startPosition(4,36).build());
			cc= Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(2).startPosition(7,21).index(1).build());
			main_screen=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build());
		} catch (GeneralLeanFtException e) {
			e.printStackTrace();
		}
	}
	public String cc_val() throws IOException, GeneralLeanFtException
	{
		String cc_value = null;
		FunctionLibrary fl_cc_val = new FunctionLibrary();
		cc_value = fl_cc_val.getClaimValue("TB223",cc,0,0);
		return cc_value;
	}
	public void TB223_Inquire(String condition_code) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary fl_inq = new FunctionLibrary();
		fl_inq.InquireCode(condition_code, "TB223", 2,4,36);
	}
}	
