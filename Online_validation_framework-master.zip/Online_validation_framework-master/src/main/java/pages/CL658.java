package pages;

import java.io.IOException;

import org.testng.Assert;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class CL658 {
	
	public Field dme_cat,provider_stat,unitfee_val,limit_review;
	public Screen main_screen,ScreenNameA;
	
	public CL658()
	{
		try{
			dme_cat=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(49)).build());
			
			provider_stat=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(10).setColumn(17)).build());
			unitfee_val=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(10).setColumn(19)).build());
			
			limit_review=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
					.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(10).setColumn(44)).build());
			
			
			ScreenNameA= Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build());
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	public void enter_dme_cat(String Screen) throws IOException, GeneralLeanFtException, InterruptedException
	{
		
		FunctionLibrary funlib = new FunctionLibrary();
		String dme_val=null;
		CL657 cl657_screen= new CL657();
		Thread.sleep(500);
		
		funlib.navigateToDiv(Screen);
	if(Screen.equals("CL657")){
		Thread.sleep(1000);
		dme_val=cl657_screen.dme_cat();
		System.out.println("The vlaue of DME in screen CL657:"+dme_val);
	}
		funlib.navigateToDiv("CL658");
		if(Screen.equalsIgnoreCase("CL658")){
		dme_cat.setText(dme_val);
		ScreenNameA.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		System.out.println("The value of dme in CL658 is:"+dme_val);
		System.out.println("value for dme entered");
	}
	}
	
	public void enter_dme_cat(String Screen,String Screen1,String AuditNumber,String Div) throws IOException, GeneralLeanFtException, InterruptedException
	{
		
		FunctionLibrary funlib = new FunctionLibrary();
		String dme_val=null;
		CL657 cl657_screen= new CL657();
		Thread.sleep(500);
		
		funlib.navigateToDiv(Screen);
	if(Screen.equals("CL657")){
		Thread.sleep(1000);
		cl657_screen.enter_proccode("CL201", AuditNumber, Div);
		Thread.sleep(1000);
		dme_val=cl657_screen.dme_cat();
		System.out.println("The vlaue of DME in screen CL657:"+dme_val);
	}
		funlib.navigateToDiv(Screen1);
		if(Screen1.equalsIgnoreCase("CL658")){
		dme_cat.setText(dme_val);
		ScreenNameA.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		System.out.println("The value of dme in CL658 is:"+dme_val);
		System.out.println("value for dme entered");
	}
	}
	 

	public String get_prov_code() throws IOException, GeneralLeanFtException
	{
		String phy_prov_code = null;
		FunctionLibrary fl_proc_val = new FunctionLibrary();
		phy_prov_code = fl_proc_val.getClaimValue("CL658",provider_stat,0,0);
		return phy_prov_code;
	}
	
	public String get_unit_fee() throws IOException, GeneralLeanFtException
	{
		String unitfee = null;
		FunctionLibrary fl_unit_val = new FunctionLibrary();
		unitfee = fl_unit_val.getClaimValue("CL658",unitfee_val,0,0);
		return unitfee;
	}
	
	public String get_limit_rev() throws IOException, GeneralLeanFtException
	{
		String limitrev = null;
		FunctionLibrary fl_review_val = new FunctionLibrary();
		limitrev = fl_review_val.getClaimValue("CL658",limit_review,0,0);
		return limitrev;
	}
	public void press_enter() throws IOException, GeneralLeanFtException
	{
	
	    ScreenNameA.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	}
	}
