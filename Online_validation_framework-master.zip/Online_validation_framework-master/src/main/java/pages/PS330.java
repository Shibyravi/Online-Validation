package pages;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.temporal.ChronoUnit;
import java.util.Date;

import org.junit.Assert;

import com.cucumber.listener.Reporter;
import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import stepDefinition.Medica;
import util.FunctionLibrary;

public class PS330 {
	public Field prov1,prov2,msg,ScreenNo;
	public Screen screen;
	FunctionLibrary funlib;
	public static String ContractNumber=null;
	public PS330() throws GeneralLeanFtException
	{
		//lj
		screen=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UN").build());

		prov1=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UN").build()).describe(Field.class, new FieldDescription.Builder()
								.length(4).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(13)).build());

		prov2=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UN").build()).describe(Field.class, new FieldDescription.Builder()
								.length(7).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(21)).build());

		msg=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UN").build()).describe(Field.class, new FieldDescription.Builder()
								.length(79).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(23).setColumn(2)).build());
		ScreenNo=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UN").build()).describe(Field.class, new FieldDescription.Builder()
						.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(1).setColumn(3)).build());
	
	}

	/*public void validateContractNo() throws IOException, GeneralLeanFtException, ParseException, InterruptedException
	{
        Thread.sleep(500);
		String panelId=	null;
		String ExpDate=null;
		String contractNo=null;
		String status="fail";
		int i;
		boolean flag=false;
		Field panel,expDate,contract;
		String Msg=null;
		Thread.sleep(800);
		//Msg=funlib.getClaimValue("PS330", msg, 0, 0);
		Msg=msg.getText();
		System.out.println("Msg is: "+Msg);
		outerloop:
		do{

			for (i = 9; i <=18; i+=3) {



				panel=Desktop.describe(Window.class, new WindowDescription.Builder()
						.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UN").build()).describe(Field.class, new FieldDescription.Builder()
										.length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(i).setColumn(7)).build());

				expDate=Desktop.describe(Window.class, new WindowDescription.Builder()
						.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UN").build()).describe(Field.class, new FieldDescription.Builder()
										.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(i).setColumn(35)).build());

				contract=Desktop.describe(Window.class, new WindowDescription.Builder()
						.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UN").build()).describe(Field.class, new FieldDescription.Builder()
										.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(i).setColumn(52)).build());



				 panelId=	panel.getText();
				 ExpDate=expDate.getText();
				 contractNo=contract.getText();




				String reqPanel=Medica.panel_no;
				String reqContract=Medica.cont_No;

				//for required expired date
				if (panelId.equalsIgnoreCase(reqPanel)) 
				{


					if (ExpDate.equalsIgnoreCase("")||ExpDate.equalsIgnoreCase(null)) {
						System.out.println("Expired date is not there:pass");
						status="pass";
						
					}

					else{

						Date d=new Date();
						SimpleDateFormat format1 = new SimpleDateFormat("MMddyy");
						String n=format1.format(d);	
						System.out.println(n);
						SimpleDateFormat sdf = new SimpleDateFormat("MMddyy");
						Date date1 = sdf.parse(n);
						System.out.println("date 1 is :"+ date1);
						Date date2 = sdf.parse(ExpDate);
						System.out.println("date 2 is :"+ date2);


						long daysBetween = ChronoUnit.DAYS.between(date1.toInstant(), date2.toInstant());
						System.out.println("Days Difference between Frm_Date and Thru_Date is" +daysBetween);

						String temp=String.valueOf(daysBetween);
						if (!temp.contains("-")) {
							System.out.println("expiration date is not expired:pass");
							status="pass";
						}

						else{
							System.out.println("expiration date is expired:fail");
							status="fail";
						}


					}		


				}	

				//condition for required panel no and expire date should not expired
				if(panelId.equalsIgnoreCase(reqPanel)||(status.equalsIgnoreCase("pass")))
				{
					System.out.println("Required panel no found with not expired date");
					if(contractNo.equalsIgnoreCase(reqContract))
					{
						System.out.println("Contract Number Matched:pass");
						flag=true;
					}
					else{
						System.out.println("Contract no does not match:fail ");
					}
					break outerloop;
				}


			}

			screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			Thread.sleep(800);
		}while(!Msg.contains("NO PANEL RECORDS"));

		System.out.println("No More records found");
		Assert.assertTrue(flag);
		System.out.println("Contract Verified");	
		Reporter.addStepLog("Contract Number Matched: "+contractNo);

	}
*/



	public void enter_providerNo1() throws IOException, GeneralLeanFtException
	{
		String Prov1=Medica.PROV_NO1;
		prov1.setText(Prov1);

	}
	public void enter_providerNo2() throws IOException, GeneralLeanFtException
	{
		String Prov2=Medica.PROV_NO2;
		prov2.setText(Prov2);
		screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);	

	}
	
	public void enterScreen(String screenNo) throws IOException, GeneralLeanFtException, InterruptedException
	{
        ScreenNo.setText(screenNo);
        Thread.sleep(800);
    	screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);	

	}
	// method is used for verifying or fetching the contract no from screen PS330 corresponding to required panel number and expiration date
	public void validateContractNo(String operation) throws IOException, GeneralLeanFtException, ParseException, InterruptedException
	{
        Thread.sleep(500);
		String panelId=	null;
		String ExpDate=null;
		String contractNo=null;
		String status="fail";
		int i;
		boolean flag=false;
		Field panel,expDate,contract;
		String Msg=null;
		Thread.sleep(800);
		Msg=msg.getText();
		System.out.println("Msg is: "+Msg);
		outerloop:
		do{

			for (i = 9; i <=18; i+=3) {



				panel=Desktop.describe(Window.class, new WindowDescription.Builder()
						.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UN").build()).describe(Field.class, new FieldDescription.Builder()
										.length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(i).setColumn(7)).build());

				expDate=Desktop.describe(Window.class, new WindowDescription.Builder()
						.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UN").build()).describe(Field.class, new FieldDescription.Builder()
										.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(i).setColumn(35)).build());

				contract=Desktop.describe(Window.class, new WindowDescription.Builder()
						.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UN").build()).describe(Field.class, new FieldDescription.Builder()
										.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(i).setColumn(52)).build());



				 panelId=	panel.getText();
				 ExpDate=expDate.getText();
				 contractNo=contract.getText();




				String reqPanel=Medica.panel_no;
				String reqContract=Medica.cont_No;

				//for required expired date
				if (panelId.equalsIgnoreCase(reqPanel)) 
				{


					if (ExpDate.equalsIgnoreCase("")||ExpDate.equalsIgnoreCase(null)) {
						System.out.println("Expired date is not there:pass");
						status="pass";
						
					}

					else{

						Date d=new Date();
						SimpleDateFormat format1 = new SimpleDateFormat("MMddyy");
						String n=format1.format(d);	
						System.out.println(n);
						SimpleDateFormat sdf = new SimpleDateFormat("MMddyy");
						Date date1 = sdf.parse(n);
						System.out.println("date 1 is :"+ date1);
						Date date2 = sdf.parse(ExpDate);
						System.out.println("date 2 is :"+ date2);


						long daysBetween = ChronoUnit.DAYS.between(date1.toInstant(), date2.toInstant());
						System.out.println("Days Difference between Frm_Date and Thru_Date is" +daysBetween);

						String temp=String.valueOf(daysBetween);
						if (!temp.contains("-")) {
							System.out.println("expiration date is not expired:pass");
							status="pass";
						}

						else{
							System.out.println("expiration date is expired:fail");
							status="fail";
						}


					}		


				}	

				//condition for required panel no and expire date should not expired
				if(panelId.equalsIgnoreCase(reqPanel)||(status.equalsIgnoreCase("pass")))
				{
					System.out.println("Required panel no found with not expired date");
					
			if	(operation.equalsIgnoreCase("validate"))	
			{
			
					if(contractNo.equalsIgnoreCase(reqContract))
					{
						System.out.println("Contract Number Matched:pass");
						flag=true;
					}
					else{
						System.out.println("Contract no does not match:fail ");
					}
					break outerloop;
			}
			
			else if (operation.equalsIgnoreCase("fetch")) {
				ContractNumber=contractNo;
				flag=true;
				break outerloop;
			}

				}
			}

			screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			Thread.sleep(800);
		}while(!Msg.contains("NO PANEL RECORDS"));

		System.out.println("No More records found");
		Assert.assertTrue(flag);
		System.out.println("Contract Verified");	
		Reporter.addStepLog("Contract Number Matched: "+contractNo);

	}

	

}
