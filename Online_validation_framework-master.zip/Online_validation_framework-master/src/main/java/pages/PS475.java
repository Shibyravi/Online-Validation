package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class PS475 {
	public Field schedule, proc_code,base_fee;
	public Screen main_screen,ScreenNameA;
	FunctionLibrary funlib;
	public PS475() throws GeneralLeanFtException
	{
		schedule= Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNITED").build()).describe(Field.class, new FieldDescription.Builder()
				.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(3).setColumn(14)).build());
		proc_code= Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNITED").build()).describe(Field.class, new FieldDescription.Builder()
						.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(3).setColumn(36)).build());
		base_fee= Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNITED").build()).describe(Field.class, new FieldDescription.Builder()
						.length(11).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(37)).build());
		ScreenNameA= Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.cursorPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(3).setColumn(41)).build());
		funlib = new FunctionLibrary();
	
	}
	public void PS475_Inquire(String div,String schd,String cpt,String screen) throws GeneralLeanFtException, InterruptedException, IOException
	{
		
		funlib.InquireFeeMax(div,schd,cpt,screen);
		
	}
	public String schedule_val() throws IOException, GeneralLeanFtException
	{
		String ps_schedule = null;
		ps_schedule = funlib.getClaimValue("PS475",schedule,0,0);
		return ps_schedule;
	}
	
	public String proc_code_val() throws IOException, GeneralLeanFtException
	{
		String ps_proc_code = null;
		ps_proc_code = funlib.getClaimValue("PS475",proc_code,0,0);
		return ps_proc_code;
	}
	public String base_fee_val() throws IOException, GeneralLeanFtException
	{
		String ps_base_fee = null;
		ps_base_fee = funlib.getClaimValue("PS475",base_fee,0,0);
		return ps_base_fee;
	}
	

}
