
package pages;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.temporal.ChronoUnit;
import java.util.Date;

import org.testng.Assert;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import stepDefinition.Gatekeeper;
import stepDefinition.Medica;
import util.FunctionLibrary;

public class PS303 {
	public Field provider1,provider2,msg,caregrp,ScreenName;
	public Screen Screen;
	FunctionLibrary funlib;

	public PS303() throws GeneralLeanFtException
	{
		///updated
	//lj
		Screen=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UN").build());
		provider1=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UN").build()).describe(Field.class, new FieldDescription.Builder()
						.length(4).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(21)).build());
		
		provider2=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UN").build()).describe(Field.class, new FieldDescription.Builder()
						.length(7).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(28)).build());
	
		msg=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UN").build()).describe(Field.class, new FieldDescription.Builder()
						.length(79).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(23).setColumn(2)).build());
		
caregrp=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UN").build()).describe(Field.class, new FieldDescription.Builder()
						.length(4).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(8).setColumn(4)).build());
		ScreenName=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UN").build()).describe(Field.class, new FieldDescription.Builder()
						.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(1).setColumn(3)).build());
	Screen=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UN").build());
	}

	
	/*	public void enter_providerNo1() throws IOException, GeneralLeanFtException
	{
	
		String Prov1=Gatekeeper.Ref_no1;
		provider1.setText(Prov1);
	}
	public void enter_providerNo2() throws IOException, GeneralLeanFtException
	{
		String Prov2=Gatekeeper.Ref_no2;
		provider2.setText(Prov2);
		Screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);	
	}*/

	public void enter_providerNo1() throws IOException, GeneralLeanFtException
	{
		String Prov1=Gatekeeper.Ref_no1;
		provider1.setText(Prov1);

	}
	public void enter_providerNo2() throws IOException, GeneralLeanFtException
	{
		String Prov2=Gatekeeper.Ref_no2;
		provider2.setText(Prov2);
		Screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);	

}
	public void provider_inq(String provider_number1,String provider_number2,String screen) throws IOException, GeneralLeanFtException, InterruptedException
	{
		FunctionLibrary fl_mem = new FunctionLibrary();
		
		fl_mem.InquireProviderNumber(provider_number1,provider_number2,"PS303");
		
	
	}

	public String caregrp_val() throws IOException, GeneralLeanFtException, InterruptedException
	{
		String care=null;
		FunctionLibrary fl_claim = new FunctionLibrary();
		care = fl_claim.getClaimValue("PS303",caregrp,0,0);
		return care;
		
	}
	
	
	
	public String validate_GatekeeperOrNot() throws IOException, GeneralLeanFtException, ParseException, InterruptedException
	{	 String status="fail";
		String Msg=null;
		String  ExpDate=null;

		Field expDate;
		Msg=msg.getText();
		if (Msg.contains("NO RECORDS FOUND")) {
			System.out.println("No details found: Not Gatekeeper provider");
			status="fail";
		}
		else{
			outerloop:
				do{
					for (int i = 8; i <=20; i=+2) {
						
					
					expDate=Desktop.describe(Window.class, new WindowDescription.Builder()
							.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
									.label("UN").build()).describe(Field.class, new FieldDescription.Builder()
									.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(i).setColumn(54)).build());
					
				ExpDate=expDate.getText();
				

				if (ExpDate.equalsIgnoreCase("")||ExpDate.equalsIgnoreCase(null)) {
					System.out.println("Expired date is not there:pass");
					System.out.println("Gatekeeper provider");
					status="pass";
					break outerloop;
					
				}
				else{
				Date d=new Date();
				SimpleDateFormat format1 = new SimpleDateFormat("MMddyy");
				String n=format1.format(d);	
				System.out.println(n);
				SimpleDateFormat sdf = new SimpleDateFormat("MMddyy");
				Date date1 = sdf.parse(n);
				System.out.println("date 1 is :"+ date1);
				Date date2 = sdf.parse(ExpDate);
				System.out.println("date 2 is :"+ date2);


				long daysBetween = ChronoUnit.DAYS.between(date1.toInstant(), date2.toInstant());
				System.out.println("Days Difference between Frm_Date and Thru_Date is" +daysBetween);

				String temp=String.valueOf(daysBetween);
				if (!temp.contains("-")) {
					System.out.println("expiration date is not expired:pass");
					System.out.println("gatekeeper provider");
					status="pass";
					break outerloop;
				}

				else{
					System.out.println("expiration date is expired:fail");
					status="fail";
				}


			}	
					}
					
					Screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
					Thread.sleep(800);
		}while(!Msg.contains("NO MORE RECORDS"));
	
		}		
		return status;
	}
	
	public void enter_NewScreen(String screen) throws IOException, GeneralLeanFtException
	{
	ScreenName.setText(screen);
	Screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);	

	}
	


}
//=======
