package pages;

import java.io.IOException;


import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

//import bsh.ParseException;
import util.FunctionLibrary;
public class Member_GI101 {
	
	public Field select,Group,Sec_Key,Type,Primery_Key,Eff_Date,Expiry_Date;
	public Screen SCREEN;
	public Member_GI101() throws GeneralLeanFtException
	{
		SCREEN=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder().label("UNI").build());
		select=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).attachedText("field323").isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(3)).id(323).build());
		Sec_Key=Desktop.describe(Window.class, new WindowDescription()).describe(Screen.class, new ScreenDescription()).describe(Field.class, new FieldDescription.Builder()
				.attachedText("field353").startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(33)).visible(true).id(353).build());
		Type=Desktop.describe(Window.class, new WindowDescription()).describe(Screen.class, new ScreenDescription()).describe(Field.class, new FieldDescription.Builder()
				.attachedText("field373").startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(53)).visible(true).id(373).build());
		Eff_Date=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(75).startPosition(9,6).index(0).build());
		Primery_Key=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").id(13496).size(new com.hp.lft.sdk.te.SizeProperty().setRowCount(24).setColumnCount(80)).build()).describe(Field.class, new FieldDescription.Builder()
				.length(18).attachedText("field332").isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(12)).build());
		Expiry_Date=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(75).startPosition(9,6).build());
	}
	
	
	public String ExpiryDate_val() throws IOException, GeneralLeanFtException
	{
		String mem_ExpDate = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		mem_ExpDate = fl_chk_val.getClaimValue("GI101",Expiry_Date,57,63);
		return mem_ExpDate;
	}
	
	public String EffDate_val() throws IOException, GeneralLeanFtException
	{
		String mem_EffDate = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		mem_EffDate = fl_chk_val.getClaimValue("GI101",Eff_Date,50,56);
		return mem_EffDate;
	}
	
	public String PrimaryKey() throws IOException, GeneralLeanFtException
	{
		String mem_PrimaryKey = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		mem_PrimaryKey = fl_chk_val.getClaimValue("GI101",Primery_Key,0,0);
		return mem_PrimaryKey;
	}
	
	public String Select_val() throws IOException, GeneralLeanFtException
	{
		String mem_select = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		mem_select = fl_chk_val.getClaimValue("GI101",select,0,0);
		return mem_select;
	}
	
	public String Group_val() throws IOException, GeneralLeanFtException
	{
		String mem_group = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		mem_group = fl_chk_val.getClaimValue("GI101",Group,0,0);
		return mem_group;
	}
	
	public String SecKey_val() throws IOException, GeneralLeanFtException
	{
		String mem_seckey = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		mem_seckey = fl_chk_val.getClaimValue("GI101",Sec_Key,0,0);
		return mem_seckey;
	}
	
	public String Type_val() throws IOException, GeneralLeanFtException
	{
		String mem_type = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		mem_type = fl_chk_val.getClaimValue("GI101",Type,0,0);
		return mem_type;
	}
	
	public void Validate_Date() throws IOException, GeneralLeanFtException,  java.text.ParseException
	{
	String ABC=null;
		Physician_CL201 phy_screen1 = new Physician_CL201();
		FunctionLibrary fl = new FunctionLibrary();
		
		ABC = phy_screen1.from_val();
		String DEF=EffDate_val();
		
		fl.DateComparision(ABC, DEF);
	
		}
	public void GI101_Inquire(String Member_ID) throws GeneralLeanFtException, InterruptedException, IOException
	{
	FunctionLibrary fl_inq = new FunctionLibrary();
	fl_inq.InquireCode(Member_ID, "GI101", 2,4,36);
	}
	
	
}
