package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class FeeMax_TB822 {
	
	public Field dos,providerType,pos,cpt,calcType,feemaxfactor,icp,cur_screen,anesFatcor;
	public Screen phy_screen,main_screen;
	
	public FeeMax_TB822()
	{
		try{
			dos=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("U").build()).describe(Field.class, new FieldDescription.Builder()
					.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(10)).build());
			providerType=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("U").build()).describe(Field.class, new FieldDescription.Builder()
							.length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(35)).build());
			pos=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("U").build()).describe(Field.class, new FieldDescription.Builder()
							.length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(24)).build());
			icp=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("U").build()).describe(Field.class, new FieldDescription.Builder()
							.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(16)).build());
			cpt=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("U").build()).describe(Field.class, new FieldDescription.Builder()
							.length(7).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(20)).build());
			main_screen=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("U").build());
			cur_screen=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("U").build()).describe(Field.class, new FieldDescription.Builder()
							.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(1).setColumn(3)).build());
			calcType=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("U").build()).describe(Field.class, new FieldDescription.Builder()
							.length(147).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(21).setColumn(2)).build());
			feemaxfactor=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("U").build()).describe(Field.class, new FieldDescription.Builder()
							.length(147).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(21).setColumn(2)).build());
			anesFatcor=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("U").build()).describe(Field.class, new FieldDescription.Builder()
							.length(147).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(21).setColumn(2)).build());
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	public String dos_val() throws IOException, GeneralLeanFtException
	{
		String dateService = null;
		FunctionLibrary fl_date = new FunctionLibrary();
		dateService = fl_date.getClaimValue("TB822",dos,0,0);
		return dateService;
	}
	public String provType_val() throws IOException, GeneralLeanFtException
	{
		String provType = null;
		FunctionLibrary fl_prov = new FunctionLibrary();
		provType = fl_prov.getClaimValue("TB822",providerType,0,0);
		return provType;
    }
	public String pos_val() throws IOException, GeneralLeanFtException
	{
		String place = null;
		FunctionLibrary fl_pos = new FunctionLibrary();
		place = fl_pos.getClaimValue("TB822",pos,0,0);
		return place;
    }
	public String icp_val() throws IOException, GeneralLeanFtException
	{
		String icp_constant = null;
		FunctionLibrary fl_icp = new FunctionLibrary();
		icp_constant = fl_icp.getClaimValue("TB822",icp,0,0);
		return icp_constant;
    }
	public String cpt_val() throws IOException, GeneralLeanFtException
	{
		String code= null;
		FunctionLibrary fl_cpt = new FunctionLibrary();
		code = fl_cpt.getClaimValue("TB822",cpt,0,0);
		return code;
    }
	public String calcType_val() throws IOException, GeneralLeanFtException
	{
		String calc= null;
		FunctionLibrary fl_calc = new FunctionLibrary();
		calc = fl_calc.getClaimValue("TB822",calcType,0,0);
		calc=calc.substring(11,13);
		return calc;
    }
	public String feemax_val() throws IOException, GeneralLeanFtException
	{
		String feeFac= null;
		FunctionLibrary fl_feemax = new FunctionLibrary();
		feeFac = fl_feemax.getClaimValue("TB822",feemaxfactor,0,0);
		feeFac=feeFac.substring(33,38);
		return feeFac;
    }
	public String anesfact_val() throws IOException, GeneralLeanFtException
	{
		String anesFac= null;
		FunctionLibrary fl_feemax = new FunctionLibrary();
		anesFac = fl_feemax.getClaimValue("TB822",anesFatcor,0,0);
		
		if(anesFac.endsWith(":")){
			System.out.println("Not found Anes Factor in TB822");
		}
		else{
		anesFac=anesFac.substring(69,71);
		}
		return anesFac;
    }
	public void TB822_Inquire(String dos,String pos,String provType,String icp,String cpt) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary fl_inq = new FunctionLibrary();
		fl_inq.InquireFeeCode(dos,pos,provType,icp,cpt);
	}
}
