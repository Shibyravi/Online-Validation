package pages;

import java.io.IOException;
import com.hp.lft.sdk.*;
import com.hp.lft.sdk.te.*;

import util.FunctionLibrary;

public class Physician_CL140 {
	public Field benefitNumber,benefitName,effectiveDate,expireDate;
	public Screen ScreenName1;
	public Physician_CL140(){
		try {				
			benefitNumber= Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(18)).build());
			
			benefitName=Desktop.describe(Window.class, new WindowDescription()).describe(Screen.class, new ScreenDescription()).describe(Field.class, new FieldDescription.Builder()
					.length(13).attachedText("BENEFIT NAME").startPosition(5,25).index(2).build());
			effectiveDate=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(7).setColumn(18)).build());
			expireDate=Desktop.describe(Window.class, new WindowDescription()).describe(Screen.class, new ScreenDescription()).describe(Field.class, new FieldDescription.Builder()
					.length(15).attachedText("EXPIRE DATE").startPosition(9,2).index(0).build());
			ScreenName1=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.cursorPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(23)).label("UNI").build());
			 
		} catch (GeneralLeanFtException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}


public void CL140_Inquire(String bpl_code, String screen) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary fl_inq_bpl = new FunctionLibrary();
		fl_inq_bpl.InquireBenefitNumber(bpl_code,screen,5,5,18);
		
	}
	
	
	public String effectiveDateValidation() throws IOException, GeneralLeanFtException{
		
		String effec_date = null;
		FunctionLibrary fl_effec_date = new FunctionLibrary();
		effec_date = fl_effec_date.getClaimValue("CL140",effectiveDate,0,0);
		return effec_date;
		
		}
	
   public String expiryDateValidation(Field expire_date) throws IOException, GeneralLeanFtException{
	   
	   String exp_date = null;
		FunctionLibrary fl_to_date = new FunctionLibrary();
		exp_date = fl_to_date.getClaimValue("CL140",expireDate,0,0);
		return exp_date;
		
		}
 /*  public void validationDate(String from,String thru) throws IOException, ParseException{
	  
	   FunctionLibrary fl_valid_date = new FunctionLibrary();
	   fl_valid_date.DateComparision("effectiveDate","expireDate");
	  
	   
   }*/
  
   }
   

	   
	   
   
