package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class CL657{
	
	private static final String Auditnumber = null;
	private static final String Div = null;
	public Field procedure_code,dme_category;
	public Screen main_screen,ScreenNameA,cur_Screen;
	
	public CL657()
	{
		try{
			procedure_code=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(31)).build());
			dme_category=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(17)).build());
			cur_Screen=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build());
			ScreenNameA= Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNITE").build());
			
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	public void enter_proccode(String Screen,String Audit_Number,String Div) throws IOException, GeneralLeanFtException, InterruptedException
	{
		Physician_CL201 phy=new Physician_CL201();
		Thread.sleep(500);
		String procedureCode=null;
		FunctionLibrary fun=new FunctionLibrary();
		fun.navigateToDiv(Screen);
		Thread.sleep(1000);
		phy.CL201_Inquire(Audit_Number,Div);
		procedureCode=phy.proc1_val();
		Thread.sleep(500);
		System.out.println("ProcCode:"+procedureCode);
		fun.navigateToDiv("CL657");
		Thread.sleep(500);
		procedure_code.setText(procedureCode);
		System.out.println("value for procedure entered");
		cur_Screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		Thread.sleep(500);
		
		}
	
	
	
	public String dme_cat() throws IOException, GeneralLeanFtException, InterruptedException
	{
		
		String dme_cat = null;
		FunctionLibrary fl_dmeval = new FunctionLibrary();
		dme_cat = fl_dmeval.getClaimValue("CL657",dme_category,0,0);
		return dme_cat;
	}

	public void press_enter() throws IOException, GeneralLeanFtException
	{
	
	    ScreenNameA.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	}
	}
