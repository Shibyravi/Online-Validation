
package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class Hospital_HO430 {
	public Field audit,sys_drg,man_drg,pp_flag,prc_flg,drg_hos_num,drg_amt,drg_payor_id,pp_letter,interest,pp_discount,provider1,provider2;
	public Hospital_HO430() 
	{
	
		try {
			audit = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().attachedText("AUD").length(9).startPosition(4,6).build());
			sys_drg = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(5).startPosition(10,10).build());
			man_drg = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(5).startPosition(9,10).build());
			prc_flg = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(3).startPosition(12,16).build());
			drg_hos_num = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(9,53).build());
			drg_amt = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(10,48).build());
			drg_payor_id = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(2).startPosition(9,79).build());
			pp_letter = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(8).startPosition(21,20).build());
			interest = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(10).startPosition(21,40).build());
			pp_discount = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(15).startPosition(21,65).build());
		
			provider1 =Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(4).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(6).setColumn(11)).build());
			provider2=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(7).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(6).setColumn(16)).build());
			pp_flag = Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build())
					.describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build())
					.describe(Field.class, new FieldDescription.Builder()
						.length(2)
						.startPosition(new com.hp.lft.sdk.te.PositionProperty().setColumn(26).setRow(8)).build());
		}
		catch (GeneralLeanFtException e) {
			e.printStackTrace();
		}
	}
	public void HO430_Inquire(String hos_aud, String c_div) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary fl_inq2 = new FunctionLibrary();
		fl_inq2.InquireClaim(hos_aud,  c_div, "HO430","AUD",9,4,6,0,0,0);
		
	}
	public String sys_drg_val() throws IOException, GeneralLeanFtException
	{
		String system_drg = null;
		FunctionLibrary fl_sys_drg_val = new FunctionLibrary();
		system_drg = fl_sys_drg_val.getClaimValue("HO430",sys_drg,0,0);
		return system_drg;
	}
	public String man_drg_val() throws IOException, GeneralLeanFtException
	{
		String manual_drg = null;
		FunctionLibrary fl_man_drg_val = new FunctionLibrary();
		manual_drg = fl_man_drg_val.getClaimValue("HO430",man_drg,0,0);
		return manual_drg;
	}
	public String prc_flg_val() throws IOException, GeneralLeanFtException
	{
		String prc_flag = null;
		FunctionLibrary fl_prc_flg_val = new FunctionLibrary();
		prc_flag = fl_prc_flg_val.getClaimValue("HO430",prc_flg,0,0);
		return prc_flag;
	}
	public String drg_hos_num_val() throws IOException, GeneralLeanFtException
	{
		String drg_hos = null;
		FunctionLibrary fl_drg_hos_num = new FunctionLibrary();
		drg_hos = fl_drg_hos_num.getClaimValue("HO430",drg_hos_num,0,0);
		return drg_hos;
	}
	public String drg_amt_val() throws IOException, GeneralLeanFtException
	{
		String drg_amount = null;
		FunctionLibrary fl_drg_amt_val = new FunctionLibrary();
		drg_amount = fl_drg_amt_val.getClaimValue("HO430",drg_amt,0,0);
		return drg_amount;
	}
	public String drg_payor_val() throws IOException, GeneralLeanFtException
	{
		String drg_payor = null;
		FunctionLibrary fl_drg_payor_val = new FunctionLibrary();
		drg_payor = fl_drg_payor_val.getClaimValue("HO430",drg_payor_id,0,0);
		return drg_payor;
	}
	public String pp_letter_val() throws IOException, GeneralLeanFtException
	{
		String pp_ltr = null;
		FunctionLibrary fl_pp_letter_val = new FunctionLibrary();
		pp_ltr = fl_pp_letter_val.getClaimValue("HO430",pp_letter,0,0);
		return pp_ltr;
	}
	
	public String pp_flag_val() throws IOException, GeneralLeanFtException
	{
		String pp_ltr = null;
		FunctionLibrary fl_pp_letter_val = new FunctionLibrary();
		pp_ltr = fl_pp_letter_val.getClaimValue("HO430",pp_flag,0,0);
		return pp_ltr;
	}
	public String interest_val() throws IOException, GeneralLeanFtException
	{
		String hos_interest = null;
		FunctionLibrary fl_interest_val = new FunctionLibrary();
		hos_interest = fl_interest_val.getClaimValue("HO430",interest,0,0);
		return hos_interest;
	}
	public String pp_discount() throws IOException, GeneralLeanFtException
	{
		String hos_pp_disc = null;
		FunctionLibrary fl_pp_discount_val = new FunctionLibrary();
		hos_pp_disc = fl_pp_discount_val.getClaimValue("HO430",pp_discount,0,0);
		return hos_pp_disc;
	}

	//shalu
	public String prov_type_val_new() throws IOException, GeneralLeanFtException
	{
		String provtype1 = null;
		String provtype2 = null;
		String provtype=null;
		FunctionLibrary fl_prov = new FunctionLibrary();
		provtype1 = fl_prov.getClaimValue("HO430",provider1,0,0);
		provtype2 = fl_prov.getClaimValue("HO430",provider2,0,0);
		provtype=provtype1+"-"+provtype2;
		System.out.println("prov type is: "+provtype);
		return provtype;
	}

}
