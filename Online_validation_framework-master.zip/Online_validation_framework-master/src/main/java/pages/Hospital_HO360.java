package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class Hospital_HO360 {

	public Field select,key,status,member,type,fieldclear;
	public Screen Screen;
	public Hospital_HO360()
	{
	
	try {
		select=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(3)).build());
		key=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(16).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(14)).build());
	   status=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(2).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(10).setColumn(75)).build());
	
	   Screen=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build());
	  
	 
	}
	
	
	catch (GeneralLeanFtException e) {
		e.printStackTrace();
	}
	
}

	
	public void enter_Select(String UFI) throws IOException, GeneralLeanFtException
	{
		select.setText(UFI);
		Screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);	

	}
	
	public void enter_Key(String Key) throws IOException, GeneralLeanFtException
	{
		key.setText(Key);
		Screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);	

	}
	
	public String getStatus() throws IOException, GeneralLeanFtException
	{
		String phy_status = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_status = fl_chk_val.getClaimValue("HO360",status,0,0);
		return phy_status;
	}
	
}
