package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;
public class Physician_CL160 {

    public Field Inq_MemNum, Level, Code, Member_Amount,mem_sub1,mem_sub2;
	
	public Screen cur_screen,phy_screen,main_screen;
	public Physician_CL160()
	{
		try {
	   Inq_MemNum=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(5).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(26)).build());
	   Level=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(1).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(16)).build());
	   Member_Amount=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(10).attachedText("8(protected)").isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(36)).build());
	   main_screen=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build());
	   mem_sub1= Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(9).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(34)).build());
	   mem_sub2= Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(2).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(46)).build());
		}

	
		
		catch (GeneralLeanFtException e) {
			e.printStackTrace();
		}
		
	}
	public void CL160_Inquire(String Mem_Num, String mem_sub1, String mem_sub2, String screen, String Level) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary fl_inq = new FunctionLibrary();
		fl_inq.InquireMemberNumber(Mem_Num, mem_sub1, mem_sub2, "CL160", 5, 4, 22);
		Thread.sleep(1000);
		Physician_CL160 phy_mem = new Physician_CL160();
		phy_mem.Level.setText(Level);
		phy_mem.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		
		
	}
	
	public String actual_member_fee_val() throws IOException, GeneralLeanFtException
	{
		String actual_member_fee_val = null;
		FunctionLibrary fl_par_status = new FunctionLibrary();
		actual_member_fee_val = fl_par_status.getClaimValue("CL160",Member_Amount,0,0);
		return actual_member_fee_val;
	}
	
	
}


