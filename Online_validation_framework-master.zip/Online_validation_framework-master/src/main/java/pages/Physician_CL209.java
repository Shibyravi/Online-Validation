package pages;

import java.io.IOException;
import java.util.List;

import com.hp.lft.sdk.*;
import com.hp.lft.sdk.te.*;

import util.FunctionLibrary;

public class Physician_CL209 {
	
	public Field audit,subaudit,clr_user_code,review_number,revField1,rev_field2,User_Code1,User_Code2,Init_status,revField5,User_Code5,User_Code8,revField8, rev_field1,rev_field3,rev_field4;
	public Screen screenName;
	FunctionLibrary fl_inq1 = new FunctionLibrary();
		
	public Physician_CL209()
	{
		try {
			screenName=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build());
			audit = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().attachedText("CLAIM AUDIT").length(8).startPosition(4,22).index(0).build());
			subaudit =  Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().attachedText("CLAIM AUDIT").length(2).startPosition(4,33).index(0).build());
revField1=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(7).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(8).setColumn(7)).build());
Init_status=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
		.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(2).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(8).setColumn(22)).build());			
rev_field2 =Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(7).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(7)).build());
			User_Code1=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(8).setColumn(15)).build());
			User_Code2=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(15)).build());
			Init_status=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(2).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(8).setColumn(22)).build());
			revField5=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(7).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(10).setColumn(7)).build());
			review_number=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(7).startPosition(12,7).build());
			clr_user_code=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(6).startPosition(12,15).build());
			screenName=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.cursorPosition(1,11).label("UNI").build());
			
			User_Code5=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(10).setColumn(15)).build());
			
			revField8=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
					.length(7).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(11).setColumn(47)).build());
			User_Code8=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
					.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(11).setColumn(55)).build());
			rev_field1=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
					.length(7).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(8).setColumn(7)).build());
			rev_field3=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
					.length(7).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(7)).build());
			rev_field4=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(7).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(47)).build());
		}
		catch (GeneralLeanFtException e) {
			e.printStackTrace();
		}
	}
	
	
	public List review_val(String required_review) throws IOException, GeneralLeanFtException, InterruptedException
	{
		
		FunctionLibrary fl_inq1 = new FunctionLibrary();
		//fl_review_val.InquireClaim(phys_aud,  c_div, "CL209","CLAIM AUDIT",8,4,22,2,4,33);
		//String phy_rev = null;
		List claim_clear_details = fl_inq1.getReviewClearDetails("CL209",required_review,6);
		return claim_clear_details;
	}
	public void CL209_Inquire(String phys_aud, String c_div) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary fl_inq2 = new FunctionLibrary();
		fl_inq2.InquireClaim(phys_aud,  c_div, "CL209","CLAIM AUDIT",8,4,22,2,4,33);
		//fl_inq.InquireClaim(phys_aud,  c_div, "CL201", "AUDIT",8,4,13,2,4,24);
	}
	public List status_val(String required_status) throws IOException, GeneralLeanFtException, InterruptedException
	{
		List status_clear_details = fl_inq1.getINITCODE("CL209", required_status, 2);
		fl_inq1.takeScreenshot("CL209","CL209_MaxFreq");
		return status_clear_details;
	}
//	public String GetRev_Code1() throws IOException, GeneralLeanFtException
//	{
//		String phy_GetRev_Code1 = null;
//		FunctionLibrary fl_chk_val = new FunctionLibrary();
//		phy_GetRev_Code1 = fl_chk_val.getClaimValue("CL209",revField1,0,0);
//		return phy_GetRev_Code1;
//	}
	public String GetRev_Code2() throws IOException, GeneralLeanFtException
	{
		String phy_GetRev_Code2 = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_GetRev_Code2 = fl_chk_val.getClaimValue("CL209",rev_field2,0,0);
		return phy_GetRev_Code2;
	}
	
	
	public String GetRev_Code1() throws IOException, GeneralLeanFtException
	{
	String phy_GetRev_Code1 = null;
	FunctionLibrary fl_chk_val = new FunctionLibrary();
	phy_GetRev_Code1 = fl_chk_val.getClaimValue("CL209",rev_field1,0,0);
	return phy_GetRev_Code1;
	}
	
	public String GetRev_Code3() throws IOException, GeneralLeanFtException
	{
	String phy_GetRev_Code3 = null;
	FunctionLibrary fl_chk_val = new FunctionLibrary();
	phy_GetRev_Code3 = fl_chk_val.getClaimValue("CL209",rev_field3,0,0);
	return phy_GetRev_Code3;
	}

	public String GetRev_Code4() throws IOException, GeneralLeanFtException
	{
	String phy_GetRev_Code4 = null;
	
	FunctionLibrary fl_chk_val = new FunctionLibrary();
	phy_GetRev_Code4 = fl_chk_val.getClaimValue("CL209",rev_field4,0,0);
	return phy_GetRev_Code4;
	}
	public String GetRev_Code5() throws IOException, GeneralLeanFtException
	{
		String phy_GetRev_Code5 = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_GetRev_Code5 = fl_chk_val.getClaimValue("CL209",revField5,0,0);
		return phy_GetRev_Code5;
	}
	public String GetRev_Code8() throws IOException, GeneralLeanFtException
	{
		String phy_GetRev_Code8 = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_GetRev_Code8 = fl_chk_val.getClaimValue("CL209",revField8,0,0);
		return phy_GetRev_Code8;
	}
	public String Getuser_Code1() throws IOException, GeneralLeanFtException
	{
		String phy_GetUser_Code1 = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_GetUser_Code1 = fl_chk_val.getClaimValue("CL209",User_Code1,0,0);
		return phy_GetUser_Code1;
	}
	public String Getuser_Code2() throws IOException, GeneralLeanFtException
	{
		String phy_GetUser_Code2 = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_GetUser_Code2 = fl_chk_val.getClaimValue("CL209",User_Code2,0,0);
		return phy_GetUser_Code2;
	}
	public String Getuser_Code5() throws IOException, GeneralLeanFtException
	{
		String phy_GetUser_Code5 = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_GetUser_Code5 = fl_chk_val.getClaimValue("CL209",User_Code5,0,0);
		return phy_GetUser_Code5;
	}
	public String Getuser_Code8() throws IOException, GeneralLeanFtException
	{
		String phy_GetUser_Code8 = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_GetUser_Code8 = fl_chk_val.getClaimValue("CL209",User_Code8,0,0);
		return phy_GetUser_Code8;
	}
	/*public void CL209_Inquire(String phys_aud, String c_div) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary fl_inq2 = new FunctionLibrary();
		fl_inq2.InquireClaim(phys_aud,  c_div, "CL209","CLAIM AUDIT",8,4,22,2,4,33);
		//fl_inq.InquireClaim(phys_aud,  c_div, "CL201", "AUDIT",8,4,13,2,4,24);
	}*/
}
