package pages;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.*;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class Hospital_HO400 {
	//updated
	public Field audit,header_deny_code,paid_date,post_date,chk_num,mbr_num,prov,grp,sub,dep,prov_type,prov_num,rev_code1,rev_code2,pos,from_date,NOTIF_DAYS,dlm_flaG,ERC_FLAG;
	public Field rev_code3,rev_code4,units1,units2,units3,units4,svc1,svc2,svc3,svc4,dos1,dos2,dos3,dos4,cpt1,cpt2,cpt3,cpt4,cpt4_mod2,cpt4_mod3,cpt4_mod4,bpl_num,thru_date;
	public Field cpt1_mod1,cpt1_mod2,cpt1_mod3,cpt1_mod4,cpt2_mod1,cpt2_mod2,cpt2_mod3,cpt2_mod4,cpt3_mod1,cpt3_mod2,cpt3_mod3,cpt3_mod4,cpt4_mod1,From_date,Cause_Deny,Review_Code;

	public Field claimed1,ScreenField,CLOSED_CLAIM_MESSAGE,rec_date,claimed2,claimed3,claimed4,det_rsn1,det_rsn2,det_rsn3,det_rsn4,copay1,copay2,copay3,copay4,ded1,ded2,ded3,ded4;
	public Field disc1,total_copay,disc2,disc3,disc4,receive_date,payable1,payable2,payable3,payable4,dslw1,dslw2,dslw3,dslw4,msg,review_status,notif,reserve1,reserve2,reserve3,reserve4,res_pc1,res_pc2,res_pc3,res_pc4,limited_svc,notif_no,reviewCode;

	public Screen hos_mainscreen,cur_screen;
	FunctionLibrary funlib;
	public Hospital_HO400() throws GeneralLeanFtException
	{
	    cur_screen=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build());
		hos_mainscreen = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build());
		receive_date=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(42)).build());
		audit = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().attachedText("AUD").length(9).startPosition(4,6).build());
		header_deny_code =	Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(4).startPosition(7,77).build());
		paid_date = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(6,42).build());
		post_date = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(6, 56).build());
		chk_num = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(8).startPosition(7, 54).build());
		pos = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(2).startPosition(8, 78).build());
		grp = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(5).startPosition(5, 11).build());
		sub = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(9).startPosition(5, 17).build());
		dep = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(2).startPosition(5,27).build());
		prov_type = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(4).startPosition(6, 11).build());
		prov_num = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(13).startPosition(6,16).build());
		rev_code1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(5).startPosition(11,6).build());
		rev_code2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(5).startPosition(12,6).build());
		rev_code3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(5).startPosition(13,6).build());
		rev_code4 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(5).startPosition(14,6).build());
		units1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(11,12).build());
		units2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(12,12).build());
		units3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(13,12).build());
		units4 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(14,12).build());
		svc1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(7).startPosition(11,23).build());
		svc2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(7).startPosition(12,23).build());
		svc3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(7).startPosition(13,23).build());
		svc4 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(7).startPosition(14,23).build());
		dos1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(7).startPosition(11,31).build());
		dos2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(7).startPosition(12,31).build());
		dos3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(7).startPosition(13,31).build());
		dos4 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(7).startPosition(14,31).build());
		cpt1=cpt1_mod1=cpt1_mod2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(13).startPosition(11,39).build());
		cpt2=cpt2_mod1=cpt2_mod2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(13).startPosition(12,39).build());
		cpt3=cpt3_mod1=cpt3_mod2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(13).startPosition(13,39).build());
		cpt4=cpt4_mod1=cpt4_mod2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(13).startPosition(14,39).build());
		claimed1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(11,53).build());
		claimed2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(12,53).build());
		claimed3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(13,53).build());
		claimed4 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(14,53).build());
		det_rsn1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(4).startPosition(11,77).build());
		det_rsn2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(4).startPosition(12,77).build());
		det_rsn3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(4).startPosition(13,77).build());
		det_rsn4 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(4).startPosition(14,77).build());
		copay1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(10).startPosition(16,2).build());
		copay2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(10).startPosition(17,2).build());
		copay3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(10).startPosition(18,2).build());
		copay4 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(10).startPosition(19,2).build());
		ded1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(16,24).build());
		ded2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(17,24).build());
		ded3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(18,24).build());
		ded4 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(19,24).build());
		disc1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(12).startPosition(16,56).build());
		disc2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(12).startPosition(17,56).build());
		disc3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(12).startPosition(18,56).build());
		disc4 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(12).startPosition(19,56).build());
		payable1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(16,69).build());
		payable2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(17,69).build());
		payable3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(18,69).build());
		payable4 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(19,69).build());
		dslw1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(11,65).build());
		dslw2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(12,65).build());
		dslw3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(13,65).build());
		dslw4 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(14,65).build());
		msg = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(79).startPosition(23,2).build());
		bpl_num=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder().label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(6).startPosition(6,74).build());
		from_date=Desktop.describe(Window.class, new WindowDescription.Builder()
		.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(6).startPosition(4,56).build());
		thru_date=Desktop.describe(Window.class, new WindowDescription.Builder()
		.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(6).startPosition(5,56).build());
		rec_date= Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(42)).build());
		review_status=Desktop.describe(Window.class, new WindowDescription.Builder()
		.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(20).setColumn(21)).build());
		notif=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(2).startPosition(8,22).build());

notif_no=Desktop.describe(Window.class, new WindowDescription.Builder()

				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(9).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(8).setColumn(12)).build());
		funlib = new FunctionLibrary();	
				From_date=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(56)).build());
		Cause_Deny=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(4).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(7).setColumn(77)).build());
		Review_Code=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(20).setColumn(12)).build());
		reserve1 =Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(10).startPosition(16,39).build());
		reserve2=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(10).startPosition(17,39).build());
		reserve3=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(10).startPosition(18,39).build());
		reserve4=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(10).startPosition(19,39).build());
		res_pc1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(5).startPosition(16,50).build());
		res_pc2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(5).startPosition(17,50).build());
		res_pc3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(5).startPosition(18,50).build());
		res_pc4 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(5).startPosition(19,50).build());
		limited_svc=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(11).setColumn(19)).build());

		CLOSED_CLAIM_MESSAGE= Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(79).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(23).setColumn(2)).build());
		ScreenField=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(1).setColumn(3)).build());
						NOTIF_DAYS=Desktop.describe(Window.class, new WindowDescription.Builder()

				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(8).setColumn(38)).build());
		reviewCode=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(8).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(24).setColumn(66)).build());
NOTIF_DAYS=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(8).setColumn(38)).build());
		dlm_flaG=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(1).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(22).setColumn(73)).build());
		total_copay=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(10).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(18).setColumn(2)).build());
		ERC_FLAG=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(3).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(22).setColumn(79)).build());	}
	public String ERC_FLAG_val() throws IOException, GeneralLeanFtException
	{
		String hos_ERC_FLAG_val = null;
		FunctionLibrary fl_hdr_deny_val = new FunctionLibrary();
		hos_ERC_FLAG_val = fl_hdr_deny_val.getClaimValue("HO400",ERC_FLAG,0,0);
		return hos_ERC_FLAG_val;
		
	}
	
	public void enter_NewScreen(String Screen) throws IOException, GeneralLeanFtException
	{
	ScreenField.setText(Screen);
	cur_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER); 

	}
public String total_Copay_val() throws IOException, GeneralLeanFtException
	{
		String hos_total_Copay_val = null;
		FunctionLibrary fl_hdr_deny_val = new FunctionLibrary();
		hos_total_Copay_val = fl_hdr_deny_val.getClaimValue("HO400",total_copay,0,0);
		return hos_total_Copay_val;
		
	}
	public void HO400_Inquire(String hos_aud, String c_div) throws GeneralLeanFtException, InterruptedException, IOException
	{
		//FunctionLibrary fl_inq = new FunctionLibrary();
		funlib.InquireClaim(hos_aud,  c_div, "HO400", "AUD",9,4,6,0,0,0);
	}
	
	public String dlm_flag_val() throws IOException, GeneralLeanFtException
	{
		String hos_dlm_flag_val = null;
		FunctionLibrary fl_hdr_deny_val = new FunctionLibrary();
		hos_dlm_flag_val = fl_hdr_deny_val.getClaimValue("HO400",dlm_flaG,0,0);
		return hos_dlm_flag_val;
		
	}
	
public String Review_Code_val() throws IOException, GeneralLeanFtException
	{
		String hos_Review_Code_val = null;
		FunctionLibrary fl_hdr_deny_val = new FunctionLibrary();
		hos_Review_Code_val = fl_hdr_deny_val.getClaimValue("HO400",Review_Code,0,0);
		return hos_Review_Code_val;
		
	}

public String closed_claim_message_val() throws IOException, GeneralLeanFtException
{
	String closed = null;
	FunctionLibrary fl_tot_allowed = new FunctionLibrary();
	closed = fl_tot_allowed.getClaimValue("HO400",CLOSED_CLAIM_MESSAGE,0,11).trim();
	return closed;
}

public String Receive_date_val() throws IOException, GeneralLeanFtException
{
	String hos_Review_Code_val = null;
	FunctionLibrary fl_hdr_deny_val = new FunctionLibrary();
	hos_Review_Code_val = fl_hdr_deny_val.getClaimValue("HO400",receive_date,0,0);
	return hos_Review_Code_val;
	
}
public String rec_date_val() throws IOException, GeneralLeanFtException
{
	String hos_Review_Code_val = null;
	FunctionLibrary fl_hdr_deny_val = new FunctionLibrary();
	hos_Review_Code_val = fl_hdr_deny_val.getClaimValue("HO400",rec_date,0,0);
	return hos_Review_Code_val;
	
}

FunctionLibrary fl_hdr_deny_val = new FunctionLibrary();

public String unit_val(String required_unit) throws IOException, GeneralLeanFtException, InterruptedException
{
	FunctionLibrary fl_inq1 = new FunctionLibrary();
	 
	 String claim_clear_details = fl_inq1.AddUnits("HO400", required_unit, 6);
	 
	return claim_clear_details;
}

	
	public String From_Date_val() throws IOException, GeneralLeanFtException
	{
		String hos_From_Date_val = null;
		FunctionLibrary fl_hdr_deny_val = new FunctionLibrary();
		hos_From_Date_val = fl_hdr_deny_val.getClaimValue("HO400",From_date,0,0);
		return hos_From_Date_val;
	}
	
	public String Cause_Deny_val() throws IOException, GeneralLeanFtException
	{
		String hos_Cause_Deny_val = null;
		FunctionLibrary fl_hdr_deny_val = new FunctionLibrary();
		hos_Cause_Deny_val = fl_hdr_deny_val.getClaimValue("HO400",Cause_Deny,76,80);
		return hos_Cause_Deny_val;
	}
	
	public void HO410_Inquire(String audit_number, String div) throws GeneralLeanFtException, InterruptedException, IOException {
		// TODO Auto-generated method stub
		FunctionLibrary fl_inq = new FunctionLibrary();
		fl_inq.InquireClaim(audit_number,  div, "HO410", "AUD",9,4,6,0,0,0);
	}
	public String hos_audit_val() throws IOException, GeneralLeanFtException
	{
		String hos_audit = null;
		//FunctionLibrary fl_audit_val = new FunctionLibrary();
		hos_audit = funlib.getClaimValue("HO400",audit,0,0);
		return hos_audit;
	}

	
	public String hdr_deny_val() throws IOException, GeneralLeanFtException
	{
		String hos_hdr_deny_code = null;
		FunctionLibrary funlib = new FunctionLibrary();
		hos_hdr_deny_code = funlib.getClaimValue("HO400",header_deny_code,0,0);
		return hos_hdr_deny_code;
	}
	public boolean msg_val() throws IOException, GeneralLeanFtException
	{
		boolean hos_msg = false;
		//FunctionLibrary fl_msg_val = new FunctionLibrary();
		hos_msg = funlib.checkHistoryClaim("HO400");
		return hos_msg;
	}
	public String hos_msg_val() throws IOException, GeneralLeanFtException
	{
		String hos_claim_msg = null;
		//FunctionLibrary fl_msg_val = new FunctionLibrary();
		hos_claim_msg = funlib.getClaimValue("HO400",msg,0,0);
		return hos_claim_msg;
	}
	
	public String chk_val() throws IOException, GeneralLeanFtException
	{
		String hos_chk = null;
		//FunctionLibrary fl_chk_val = new FunctionLibrary();
		hos_chk = funlib.getClaimValue("HO400",chk_num,0,0);
		return hos_chk;
	}
	public String paid_date_val() throws IOException, GeneralLeanFtException
	{
		String hos_paid_date = null;
		//FunctionLibrary fl_paid_date_val = new FunctionLibrary();
		hos_paid_date = funlib.getClaimValue("HO400",paid_date,0,0);
		return hos_paid_date;
	}
	public String reserve1_val() throws IOException, GeneralLeanFtException
	{
		String res1 = null;
		res1 = funlib.getClaimValue("HO400",reserve1,0,0);
		return res1;
	}
	public String reserve2_val() throws IOException, GeneralLeanFtException
	{
		String res2 = null;
		res2 = funlib.getClaimValue("HO400",reserve2,0,0);
		return res2;
	}
	public String reserve3_val() throws IOException, GeneralLeanFtException
	{
		String res3 = null;
		res3 = funlib.getClaimValue("HO400",reserve3,0,0);
		return res3;
	}
	public String reserve4_val() throws IOException, GeneralLeanFtException
	{
		String res4 = null;
		res4 = funlib.getClaimValue("HO400",reserve4,0,0);
		return res4;
	}
	public String res_pc1_val() throws IOException, GeneralLeanFtException
	{
		String respc1 = null;
		respc1 = funlib.getClaimValue("HO400",res_pc1,0,0);
		return respc1;
	}
	public String res_pc2_val() throws IOException, GeneralLeanFtException
	{
		String respc2 = null;
		respc2 = funlib.getClaimValue("HO400",res_pc2,0,0);
		return respc2;
	}
	public String res_pc3_val() throws IOException, GeneralLeanFtException
	{
		String respc3 = null;
		respc3 = funlib.getClaimValue("HO400",res_pc3,0,0);
		return respc3;
	}
	public String res_pc4_val() throws IOException, GeneralLeanFtException
	{
		String respc4 = null;
		respc4 = funlib.getClaimValue("HO400",res_pc4,0,0);
		return respc4;
	}
	
	public String post_date_val() throws IOException, GeneralLeanFtException
	{
		String hos_post_date = null;
		//FunctionLibrary fl_post_date_val = new FunctionLibrary();
		hos_post_date = funlib.getClaimValue("HO400",post_date,0,0);
		return hos_post_date;
	}
	public String member_val() throws IOException, GeneralLeanFtException
	{
		String mem = null;
		//FunctionLibrary fl_member_val = new FunctionLibrary();
		mem = funlib.getClaimValue("HO400",grp,0,0).concat(funlib.getClaimValue("HO400",sub,0,0)).concat(funlib.getClaimValue("HO400",dep,0,0));
		return mem;
	}
	public String pos_val() throws IOException, GeneralLeanFtException
	{
		String hos_pos = null;
		//FunctionLibrary fl_pos_val = new FunctionLibrary();
		hos_pos = funlib.getClaimValue("HO400",pos,0,0);
		return hos_pos;
	}
	public String prov_type_val() throws IOException, GeneralLeanFtException
	{
		String prv_type = null;
		//FunctionLibrary fl_prov_type_val = new FunctionLibrary();
		prv_type = funlib.getClaimValue("HO400",prov_type,0,0);
		return prv_type;
	}
	public String prov_num_val() throws IOException, GeneralLeanFtException
	{
		String prv_num = null;
		FunctionLibrary fl_prov_num_val = new FunctionLibrary();
		prv_num = fl_prov_num_val.getClaimValue("HO400",prov_num,0,0);
		return prv_num;
	}
	public String prov_val() throws IOException, GeneralLeanFtException
	{
		String prov = null;
		//FunctionLibrary fl_prov_val = new FunctionLibrary();
		prov = funlib.getClaimValue("HO400",prov_type,0,0).concat(funlib.getClaimValue("HO400",prov_num,0,0));
		return prov;
	}
	public String rev_code1_val() throws IOException, GeneralLeanFtException
	{
		String rev = null;
		//FunctionLibrary fl_rev_code1_val = new FunctionLibrary();
		rev = funlib.getClaimValue("HO400",rev_code1,0,0);
		return rev;
	}
	public String rev_code2_val() throws IOException, GeneralLeanFtException
	{
		String rev = null;
		//FunctionLibrary fl_rev_code2_val = new FunctionLibrary();
		rev = funlib.getClaimValue("HO400",rev_code2,0,0);
		return rev;
	}
	public String rev_code3_val() throws IOException, GeneralLeanFtException
	{
		String rev = null;
		//FunctionLibrary fl_rev_code3_val = new FunctionLibrary();
		rev = funlib.getClaimValue("HO400",rev_code3,0,0);
		return rev;
	}
	public String rev_code4_val() throws IOException, GeneralLeanFtException
	{
		String rev = null;
		//FunctionLibrary fl_rev_code4_val = new FunctionLibrary();
		rev = funlib.getClaimValue("HO400",rev_code4,0,0);
		return rev;
	}
	public String units1_val() throws IOException, GeneralLeanFtException
	{
		String units = null;
		//FunctionLibrary fl_units1_val = new FunctionLibrary();
		units = funlib.getClaimValue("HO400",units1,0,0);
		return units;
	}
	public String units2_val() throws IOException, GeneralLeanFtException
	{
		String units = null;
		//FunctionLibrary fl_units2_val = new FunctionLibrary();
		units = funlib.getClaimValue("HO400",units2,0,0);
		return units;
	}
	public String units3_val() throws IOException, GeneralLeanFtException
	{
		String units = null;
		//FunctionLibrary fl_units3_val = new FunctionLibrary();
		units = funlib.getClaimValue("HO400",units3,0,0);
		return units;
	}
	public String units4_val() throws IOException, GeneralLeanFtException
	{
		String units = null;
		//FunctionLibrary fl_units4_val = new FunctionLibrary();
		units = funlib.getClaimValue("HO400",units4,0,0);
		return units;
	}
	public String svc1_val() throws IOException, GeneralLeanFtException
	{
		String svc_code = null;
		//FunctionLibrary fl_svc1_val = new FunctionLibrary();
		svc_code = funlib.getClaimValue("HO400",svc1,0,0);
		return svc_code;
	}
	public String svc2_val() throws IOException, GeneralLeanFtException
	{
		String svc_code = null;
		//FunctionLibrary fl_svc2_val = new FunctionLibrary();
		svc_code = funlib.getClaimValue("HO400",svc2,0,0);
		return svc_code;
	}
	public String svc3_val() throws IOException, GeneralLeanFtException
	{
		String svc_code = null;
		//FunctionLibrary fl_svc3_val = new FunctionLibrary();
		svc_code = funlib.getClaimValue("HO400",svc3,0,0);
		return svc_code;
	}
	public String svc4_val() throws IOException, GeneralLeanFtException
	{
		String svc_code = null;
		//FunctionLibrary fl_svc4_val = new FunctionLibrary();
		svc_code = funlib.getClaimValue("HO400",svc4,0,0);
		return svc_code;
	}
	public String dos1_val() throws IOException, GeneralLeanFtException
	{
		String dos = null;
		//FunctionLibrary fl_dos1_val = new FunctionLibrary();
		dos = funlib.getClaimValue("HO400",dos1,0,0);
		return dos;
	}
	public String dos2_val() throws IOException, GeneralLeanFtException
	{
		String dos = null;
		//FunctionLibrary fl_dos2_val = new FunctionLibrary();
		dos = funlib.getClaimValue("HO400",dos2,0,0);
		return dos;
	}

public String NOTIFDAYS_val() throws IOException, GeneralLeanFtException

	{
		String NOTIFDAY = null;
		//FunctionLibrary fl_dos2_val = new FunctionLibrary();
		NOTIFDAY = funlib.getClaimValue("HO400",NOTIF_DAYS,0,0);
		return NOTIFDAY;
	}

	public String dos3_val() throws IOException, GeneralLeanFtException
	{
		String dos = null;
		//FunctionLibrary fl_dos3_val = new FunctionLibrary();
		dos = funlib.getClaimValue("HO400",dos3,0,0);
		return dos;
	}
	public String dos4_val() throws IOException, GeneralLeanFtException
	{
		String dos = null;
		//FunctionLibrary fl_dos4_val = new FunctionLibrary();
		dos = funlib.getClaimValue("HO400",dos4,0,0);
		return dos;
	}
	public String claimed1_val() throws IOException, GeneralLeanFtException
	{
		String claimed = null;
		//FunctionLibrary fl_claimed1_val = new FunctionLibrary();
		claimed = funlib.getClaimValue("HO400",claimed1,0,0);
		return claimed;
	}
	public String claimed2_val() throws IOException, GeneralLeanFtException
	{
		String claimed = null;
		//FunctionLibrary fl_claimed2_val = new FunctionLibrary();
		claimed = funlib.getClaimValue("HO400",claimed2,0,0);
		return claimed;
	}
	public String claimed3_val() throws IOException, GeneralLeanFtException
	{
		String claimed = null;
		//FunctionLibrary fl_claimed3_val = new FunctionLibrary();
		claimed = funlib.getClaimValue("HO400",claimed3,0,0);
		return claimed;
	}
	public String claimed4_val() throws IOException, GeneralLeanFtException
	{
		String claimed = null;
		//FunctionLibrary fl_claimed4_val = new FunctionLibrary();
		claimed = funlib.getClaimValue("HO400",claimed4,0,0);
		return claimed;
	}
	public String det_deny1_val() throws IOException, GeneralLeanFtException
	{
		String det_deny = null;
		//FunctionLibrary fl_det_deny1_val = new FunctionLibrary();
		det_deny = funlib.getClaimValue("HO400",det_rsn1,0,0);
		return det_deny;
	}
	public String det_deny2_val() throws IOException, GeneralLeanFtException
	{
		String det_deny = null;
		//FunctionLibrary fl_det_deny2_val = new FunctionLibrary();
		det_deny = funlib.getClaimValue("HO400",det_rsn2,0,0);
		return det_deny;
	}
	public String det_deny3_val() throws IOException, GeneralLeanFtException
	{
		String det_deny = null;
		//FunctionLibrary fl_det_deny3_val = new FunctionLibrary();
		det_deny = funlib.getClaimValue("HO400",det_rsn3,0,0);
		return det_deny;
	}
	public String det_deny4_val() throws IOException, GeneralLeanFtException
	{
		String det_deny = null;
		//FunctionLibrary fl_det_deny4_val = new FunctionLibrary();
		det_deny = funlib.getClaimValue("HO400",det_rsn4,0,0);
		return det_deny;
	}
	public String copay1_val() throws IOException, GeneralLeanFtException
	{
		String hos_copay = null;
		//FunctionLibrary fl_copay1_val = new FunctionLibrary();
		hos_copay = funlib.getClaimValue("HO400",copay1,0,0);
		return hos_copay;
	}
	public String copay2_val() throws IOException, GeneralLeanFtException
	{
		String hos_copay = null;
		//FunctionLibrary fl_copay2_val = new FunctionLibrary();
		hos_copay = funlib.getClaimValue("HO400",copay2,0,0);
		return hos_copay;
	}
	public String copay3_val() throws IOException, GeneralLeanFtException
	{
		String hos_copay = null;
		//FunctionLibrary fl_copay3_val = new FunctionLibrary();
		hos_copay = funlib.getClaimValue("HO400",copay3,0,0);
		return hos_copay;
	}
	public String copay4_val() throws IOException, GeneralLeanFtException
	{
		String hos_copay = null;
		//FunctionLibrary fl_copay4_val = new FunctionLibrary();
		hos_copay = funlib.getClaimValue("HO400",copay4,0,0);
		return hos_copay;
	}
	public String ded1_val() throws IOException, GeneralLeanFtException
	{
		String hos_ded = null;
		//FunctionLibrary fl_ded1_val = new FunctionLibrary();
		hos_ded = funlib.getClaimValue("HO400",ded1,0,0);
		return hos_ded;
	}
	public String ded2_val() throws IOException, GeneralLeanFtException
	{
		String hos_ded = null;
		//FunctionLibrary fl_ded2_val = new FunctionLibrary();
		hos_ded = funlib.getClaimValue("HO400",ded2,0,0);
		return hos_ded;
	}
	public String ded3_val() throws IOException, GeneralLeanFtException
	{
		String hos_ded = null;
		//FunctionLibrary fl_ded3_val = new FunctionLibrary();
		hos_ded = funlib.getClaimValue("HO400",ded3,0,0);
		return hos_ded;
	}
	public String ded4_val() throws IOException, GeneralLeanFtException
	{
		String hos_ded = null;
		//FunctionLibrary fl_ded4_val = new FunctionLibrary();
		hos_ded = funlib.getClaimValue("HO400",ded4,0,0);
		return hos_ded;
	}
	public String disc1_val() throws IOException, GeneralLeanFtException
	{
		String hos_disc = null;
		//FunctionLibrary fl_disc1_val = new FunctionLibrary();
		hos_disc = funlib.getClaimValue("HO400",disc1,0,0);
		return hos_disc;
	}
	public String disc2_val() throws IOException, GeneralLeanFtException
	{
		String hos_disc = null;
		//FunctionLibrary fl_disc2_val = new FunctionLibrary();
		hos_disc = funlib.getClaimValue("HO400",disc2,0,0);
		return hos_disc;
	}
	public String disc3_val() throws IOException, GeneralLeanFtException
	{
		String hos_disc = null;
		//FunctionLibrary fl_disc3_val = new FunctionLibrary();
		hos_disc = funlib.getClaimValue("HO400",disc3,0,0);
		return hos_disc;
	}
	public String disc4_val() throws IOException, GeneralLeanFtException
	{
		String hos_disc = null;
		//FunctionLibrary fl_disc4_val = new FunctionLibrary();
		hos_disc = funlib.getClaimValue("HO400",disc4,0,0);
		return hos_disc;
	}
	public String payable1_val() throws IOException, GeneralLeanFtException
	{
		String hos_payable = null;
		//FunctionLibrary fl_payable1_val = new FunctionLibrary();
		hos_payable = funlib.getClaimValue("HO400",payable1,0,0);
		return hos_payable;
	}
	public String payable2_val() throws IOException, GeneralLeanFtException
	{
		String hos_payable = null;
		//FunctionLibrary fl_payable2_val = new FunctionLibrary();
		hos_payable = funlib.getClaimValue("HO400",payable2,0,0);
		return hos_payable;
	}
	public String payable3_val() throws IOException, GeneralLeanFtException
	{
		String hos_payable = null;
		//FunctionLibrary fl_payable3_val = new FunctionLibrary();
		hos_payable = funlib.getClaimValue("HO400",payable3,0,0);
		return hos_payable;
	}
	public String payable4_val() throws IOException, GeneralLeanFtException
	{
		String hos_payable = null;
	//	FunctionLibrary fl_payable4_val = new FunctionLibrary();
		hos_payable = funlib.getClaimValue("HO400",payable4,0,0);
		return hos_payable;
	}
	public String disallow1_val() throws IOException, GeneralLeanFtException
	{
		String hos_disallow = null;
		//FunctionLibrary fl_disallow1_val = new FunctionLibrary();
		hos_disallow = funlib.getClaimValue("HO400",dslw1,0,0);
		return hos_disallow;
	}
	public String disallow2_val() throws IOException, GeneralLeanFtException
	{
		String hos_disallow = null;
		//FunctionLibrary fl_disallow2_val = new FunctionLibrary();
		hos_disallow = funlib.getClaimValue("HO400",dslw2,0,0);
		return hos_disallow;
	}
	public String disallow3_val() throws IOException, GeneralLeanFtException
	{
		String hos_disallow = null;
		//FunctionLibrary fl_disallow3_val = new FunctionLibrary();
		hos_disallow = funlib.getClaimValue("HO400",dslw3,0,0);
		return hos_disallow;
	}
	public String disallow4_val() throws IOException, GeneralLeanFtException
	{
		String hos_disallow = null;
		//FunctionLibrary fl_disallow4_val = new FunctionLibrary();
		hos_disallow = funlib.getClaimValue("HO400",dslw4,0,0);
		return hos_disallow;
	}
	public String cpt1_val() throws IOException, GeneralLeanFtException
	{
		String cpt_code = null;
		//FunctionLibrary fl_cpt1_val = new FunctionLibrary();
		cpt_code = funlib.getClaimValue("HO400",cpt1,0,5);
		return cpt_code;
	}
	public String cpt2_val() throws IOException, GeneralLeanFtException
	{
		String cpt_code = null;
		//FunctionLibrary fl_cpt2_val = new FunctionLibrary();
		cpt_code = funlib.getClaimValue("HO400",cpt2,0,5);
		return cpt_code;
	}
	public String cpt3_val() throws IOException, GeneralLeanFtException
	{
		String cpt_code = null;
		//FunctionLibrary fl_cpt3_val = new FunctionLibrary();
		cpt_code = funlib.getClaimValue("HO400",cpt3,0,5);
		return cpt_code;
	}
	public String cpt4_val() throws IOException, GeneralLeanFtException
	{
		String cpt_code = null;
		//FunctionLibrary fl_cpt4_val = new FunctionLibrary();
		cpt_code = funlib.getClaimValue("HO400",cpt4,0,5);
		return cpt_code;
	}
	public String cpt1_mod1_val() throws IOException, GeneralLeanFtException
	{
		String mod_code = null;
		//FunctionLibrary fl_cpt1_mod1_val = new FunctionLibrary();
		mod_code = funlib.getClaimValue("HO400",cpt1_mod1,6,8);
		return mod_code;
	}
	public String cpt1_mod2_val() throws IOException, GeneralLeanFtException
	{
		String mod_code = null;
		
		mod_code = funlib.getClaimValue("HO400",cpt1_mod2,8,10);
		return mod_code;
	}
	public String cpt2_mod1_val() throws IOException, GeneralLeanFtException
	{
		String mod_code = null;
		//FunctionLibrary fl_cpt2_mod1_val = new FunctionLibrary();
		mod_code = funlib.getClaimValue("HO400",cpt2_mod1,6,8);
		return mod_code;
	}
	public String cpt2_mod2_val() throws IOException, GeneralLeanFtException
	{
		String mod_code = null;
		//FunctionLibrary fl_cpt2_mod2_val = new FunctionLibrary();
		mod_code = funlib.getClaimValue("HO400",cpt2_mod2,8,10);
		return mod_code;
	}
	public String cpt3_mod1_val() throws IOException, GeneralLeanFtException
	{
		String mod_code = null;
		//FunctionLibrary fl_cpt3_mod1_val = new FunctionLibrary();
		mod_code = funlib.getClaimValue("HO400",cpt3_mod1,6,8);
		return mod_code;
	}
	public String cpt3_mod2_val() throws IOException, GeneralLeanFtException
	{
		String mod_code = null;
		//FunctionLibrary fl_cpt2_mod2_val = new FunctionLibrary();
		mod_code = funlib.getClaimValue("HO400",cpt3_mod2,8,10);
		return mod_code;
	}
	public String cpt4_mod1_val() throws IOException, GeneralLeanFtException
	{
		String mod_code = null;
		//FunctionLibrary fl_cpt4_mod1_val = new FunctionLibrary();
		mod_code = funlib.getClaimValue("HO400",cpt4_mod1,6,8);
		return mod_code;
	}
	public String cpt4_mod2_val() throws IOException, GeneralLeanFtException
	{
		String mod_code = null;
		//FunctionLibrary fl_cpt4_mod2_val = new FunctionLibrary();
		mod_code = funlib.getClaimValue("HO400",cpt4_mod2,8,10);
		return mod_code;
	}
	public String from_date() throws IOException, GeneralLeanFtException
	{
		String fromdate = null;
		FunctionLibrary fl_from_date = new FunctionLibrary();
		fromdate = fl_from_date.getClaimValue("HO400",from_date,0,0);
		return fromdate;
	}
	public String thru_date() throws IOException, GeneralLeanFtException
	{
		String thrudate = null;
		FunctionLibrary fl_thru_date = new FunctionLibrary();
		thrudate = fl_thru_date.getClaimValue("HO400",thru_date,0,0);
		return thrudate;
	}
		public String bpl_num() throws IOException, GeneralLeanFtException
	{
		String exp_bpl = null;
		FunctionLibrary fl_bpl_num = new FunctionLibrary();
		exp_bpl = fl_bpl_num.getClaimValue("HO400",bpl_num,0,0);
		return exp_bpl;
	}
	public String review_status() throws IOException, GeneralLeanFtException
	{
		String exp_review = null;
		FunctionLibrary fl_review_num = new FunctionLibrary();
		exp_review = fl_review_num.getClaimValue("HO400",review_status,0,0);
		return exp_review;
	}

	public String notif_num() throws IOException, GeneralLeanFtException
	{
		String hos_notification_num = null;
		FunctionLibrary fl_notif_num = new FunctionLibrary();
		hos_notification_num = fl_notif_num.getClaimValue("HO400",notif,0,0);
		return hos_notification_num;
	}
	public String limited_SVC_code() throws IOException, GeneralLeanFtException
	{
		String hos_lim_svc = null;
		FunctionLibrary fl_svc_num = new FunctionLibrary();
		hos_lim_svc = fl_svc_num.getClaimValue("HO400",limited_svc,0,0);
		return hos_lim_svc;
	}
	public String rsn_num() throws IOException, GeneralLeanFtException
	{
		String hos_rsn_num = null;
		FunctionLibrary fl_rsn_num = new FunctionLibrary();
		hos_rsn_num = fl_rsn_num.getClaimValue("HO400",det_rsn1,0,0);
		return hos_rsn_num;
	}
//}
	

	public String get_notif_num() throws IOException, GeneralLeanFtException
	{
		String hos_notification_num = null;
		FunctionLibrary fl_notif_num = new FunctionLibrary();
		hos_notification_num = fl_notif_num.getClaimValue("HO400",notif_no,0,0);
		return hos_notification_num;
	}
	public String get_rev_code() throws IOException, GeneralLeanFtException
	{
		String hos_rev_num = null;
		FunctionLibrary fl_rev_code = new FunctionLibrary();
		hos_rev_num = fl_rev_code.getClaimValue("HO400",reviewCode,0,0);
		return hos_rev_num;
	}
}
