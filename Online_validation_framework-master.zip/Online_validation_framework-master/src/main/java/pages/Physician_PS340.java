package pages;

import java.io.IOException;
import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class Physician_PS340 {
               
               public Field contract, FR_pricing,flat_rate,def_fee_src,paymentType,alt_table,NDB_MKTNo,editCode,feeSchedule;
               public Screen cur_screen;
               public Physician_PS340()
               {
                              try {
                                             cur_screen=Desktop.describe(Window.class, new WindowDescription.Builder()
                                                                           .shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
                                                                           .label("UNI").build());
                                             contract = Desktop.describe(Window.class, new WindowDescription.Builder()
                                                                           .shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
                                                                                                         .label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
                                                                                                         .length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(3).setColumn(13)).build());
                                             FR_pricing = Desktop.describe(Window.class, new WindowDescription.Builder()
                                                                           .shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
                                                                           .label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
                                                                           .length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(79)).build());
                                             editCode=Desktop.describe(Window.class, new WindowDescription.Builder()
                                            			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
                                            			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
                                            			.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(47)).build());
                                             
                                             feeSchedule=Desktop.describe(Window.class, new WindowDescription.Builder()
                                            			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
                                            					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
                                            					.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(47)).build());
                                             
                                             flat_rate = Desktop.describe(Window.class, new WindowDescription.Builder()
                                                                           .shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
                                                                           .label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
                                                                           .length(8).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(12).setColumn(72)).build());
                                             def_fee_src= Desktop.describe(Window.class, new WindowDescription.Builder()
                                                                           .shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
                                                                           .label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
                                                                           .length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(8).setColumn(19)).build());
                                             paymentType=   Desktop.describe(Window.class, new WindowDescription.Builder()
                                          			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
                                          			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
                                          			.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(19)).build());
                                             
                                             //shalu
                                             
                              alt_table=Desktop.describe(Window.class, new WindowDescription.Builder()
                          			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
                          					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
                          					.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(19).setColumn(19)).build());
                              
//Shivi for Anesthesia

NDB_MKTNo= Desktop.describe(Window.class, new WindowDescription.Builder()
                                         			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
                                         			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
                                         			.length(7).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(6).setColumn(19)).build());
                                            		                                 
                          
                              } 
                              
                              catch (GeneralLeanFtException e) {
                                             e.printStackTrace();
                              }
               }
                  public void PS340_Inquire(String exp_contract, String screen) throws GeneralLeanFtException, InterruptedException, IOException
             	{
             		FunctionLibrary fl_inq = new FunctionLibrary();
             		fl_inq.InquireContract(exp_contract, "PS340");
             	}
              
               
public String contract_val() throws IOException, GeneralLeanFtException
               {
                              String cont = null;
                              FunctionLibrary fl_cont = new FunctionLibrary();
                              cont = fl_cont.getClaimValue("PS340",contract,0,0);
                              return cont;
               }

public String def_fee_src_val() throws IOException, GeneralLeanFtException
{
               String def = null;
               FunctionLibrary fl_tot_allowed = new FunctionLibrary();
               def = fl_tot_allowed.getClaimValue("PS340",def_fee_src,0,0);
               return def;
}

public String FR_pricing_val() throws IOException, GeneralLeanFtException
{
               String fr = null;
               FunctionLibrary fl_tot_allowed = new FunctionLibrary();
               fr = fl_tot_allowed.getClaimValue("PS340",FR_pricing,0,0);
               return fr;
}
public String flat_rate_val() throws IOException, GeneralLeanFtException
{
               String rate = null;
               FunctionLibrary fl_tot_allowed = new FunctionLibrary();
               rate = fl_tot_allowed.getClaimValue("PS340",flat_rate,0,0);
               return rate;
}
public String payment_val() throws IOException, GeneralLeanFtException
{
               String pay = null;
               FunctionLibrary fl_payment = new FunctionLibrary();
               pay = fl_payment.getClaimValue("PS340",paymentType,0,0);
               return pay;
}

//shalu
public String alt_table_val() throws IOException, GeneralLeanFtException
{
               String Alt_Table = null;
               FunctionLibrary fl_cont = new FunctionLibrary();
               Alt_Table = fl_cont.getClaimValue("PS340",alt_table,0,0);
               return Alt_Table;
}

//Shivi for Anesthesia

public String ndb_mkt_val() throws IOException, GeneralLeanFtException 
{ 
               String ndb = null; 
               FunctionLibrary fl_cont = new FunctionLibrary(); 
               ndb = fl_cont.getClaimValue("PS340",NDB_MKTNo,0,0); 
               return ndb; 
} 
//Shivi for FeeSchedule Demo
public String editCode_val() throws IOException, GeneralLeanFtException 
{ 
               String edit_code = null; 
               FunctionLibrary fl_code = new FunctionLibrary(); 
               edit_code = fl_code.getClaimValue("PS340",editCode,0,0); 
               return edit_code; 
} 
public String feeSch_val() throws IOException, GeneralLeanFtException 
{ 
               String feeSch = null; 
               FunctionLibrary fl_shc = new FunctionLibrary(); 
               feeSch = fl_shc.getClaimValue("PS340",feeSchedule,0,0); 
               return feeSch; 
} 
}