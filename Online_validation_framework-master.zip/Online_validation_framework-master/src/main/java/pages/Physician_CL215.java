package pages;

import java.io.IOException;
import java.util.List;

import com.hp.lft.sdk.*;
import com.hp.lft.sdk.te.*;

import util.FunctionLibrary;

public class Physician_CL215 {
	
	public Field audit,Claim_Type,DOS,Claimed_Amount,subaudit;
	public Screen SCREEN;
	public Physician_CL215()
	{
		try {
			SCREEN=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder().label("UNI").build());
			audit=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(9).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(17)).build());
			subaudit=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(2).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(32)).build());
			Claim_Type=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(50)).build());
			DOS=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(14).setColumn(6)).build());
			Claimed_Amount=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(12).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(14).setColumn(41)).build());
		}
		
		catch (GeneralLeanFtException e) {
			e.printStackTrace();
		}

}
	
	public void CL215_Inquire(String phys_aud, String c_div) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary fl_inq = new FunctionLibrary();
		fl_inq.InquireClaim(phys_aud,  c_div, "CL215", "audit",11,4,17,2,4,32);
		Physician_CL215 phy2 = new Physician_CL215();
		phy2.Claim_Type.setText("P");
		Thread.sleep(2000);
		phy2.SCREEN.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);

	
	
		
	}
	public String Getaudit_Num() throws IOException, GeneralLeanFtException
	{
		String phy_Getaudit_Number = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_Getaudit_Number = fl_chk_val.getClaimValue("CL215",audit,0,0);
		return phy_Getaudit_Number;
	}
	
	public String Getsubaudit_Num() throws IOException, GeneralLeanFtException
	{
		String phy_Getsubaudit_Number = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_Getsubaudit_Number = fl_chk_val.getClaimValue("CL215",subaudit,0,0);
		return phy_Getsubaudit_Number;
	}
	
	public String GetClaim_type() throws IOException, GeneralLeanFtException
	{
		String phy_GetClaim_type = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_GetClaim_type = fl_chk_val.getClaimValue("CL215",Claim_Type,0,0);
		return phy_GetClaim_type;
	}
	
	public String GetDOS() throws IOException, GeneralLeanFtException
	{
		String phy_Get_DOS = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_Get_DOS = fl_chk_val.getClaimValue("CL215",DOS, 0, 0);
		return phy_Get_DOS;
	}
//	public String GetRev_Code1() throws IOException, GeneralLeanFtException
//	{
//		String phy_GetRev_Code1 = null;
//		FunctionLibrary fl_chk_val = new FunctionLibrary();
//		phy_GetRev_Code1 = fl_chk_val.getClaimValue("CL209",revField1,0,0);
//		return phy_GetRev_Code1;
//	}
	
	public String GetClaimed_AMOUNT() throws IOException, GeneralLeanFtException
	{
		String phy_Claimed_AMOUNT = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_Claimed_AMOUNT = fl_chk_val.getClaimValue("CL215",Claimed_Amount,0,0);
		return phy_Claimed_AMOUNT;
	}
}