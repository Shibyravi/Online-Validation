package pages;

import java.io.IOException;
import java.util.List;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class Member_GI325 {

public Field MemberId,audit_number,status,member_inq,mem_sub1,memb_sub2;
public Screen screen_GI;

public Member_GI325() throws GeneralLeanFtException
{
		MemberId= Desktop.describe(Window.class, new WindowDescription.Builder()
		.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
		.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
		.length(18).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(13)).build());
		
		screen_GI=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build());
		audit_number=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(11).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(6)).build());
		status=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(2).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(27)).build());
}

//public void GI325_Inquire(String member_ID) throws GeneralLeanFtException {
//	// TODO Auto-generated method stub
//	FunctionLibrary fl_mem = new FunctionLibrary();
//	fl_mem.InquireMemberId(member_ID,"GI325",18,5,31);
//}

public void member_inq(String mem_number,String screen) throws IOException, GeneralLeanFtException, InterruptedException
{
	
	FunctionLibrary fl_mem = new FunctionLibrary();
	
	fl_mem.InquireMember(mem_number,"GI325",18,5,13);
	
}


public String audit_num() throws IOException, GeneralLeanFtException
{
	String aud_num= null;
	FunctionLibrary fl_lsvc = new FunctionLibrary();
	aud_num = fl_lsvc.getClaimValue("GI325",audit_number,0,0);
	return aud_num;
}
public String status_val() throws IOException, GeneralLeanFtException
{
	String stat_val= null;
	FunctionLibrary fl_lsvc = new FunctionLibrary();
	stat_val = fl_lsvc.getClaimValue("GI325",status,0,0);
	return stat_val;
}

public List getReviewClearDetails(String aud_num) throws GeneralLeanFtException, InterruptedException {
	// TODO Auto-generated method stub
	FunctionLibrary fl_inq1 = new FunctionLibrary();
	List status_clear_details = fl_inq1.getMemberDetailStatus("GI325",aud_num ,11);
	return status_clear_details;

}



}