package pages;

import java.io.IOException;


import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;
public class Provider_EP120 {
	
	public Field Group,EFF_date,End_Date;
	public Screen SCREEN;
	
	public Provider_EP120() throws GeneralLeanFtException
	{
		SCREEN=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder().label("UNITE").build());
		Group=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNITE").build()).describe(Field.class, new FieldDescription.Builder()
						.length(5).startPosition(4,23).build());
		EFF_date=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder().build()).describe(Field.class, new FieldDescription.Builder()
						.length(6).startPosition(4,38).build());
		End_Date=Desktop.describe(Window.class, new WindowDescription()).describe(Screen.class, new ScreenDescription()).describe(Field.class, new FieldDescription.Builder()
				.text("END").startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(67)).visible(true).id(307).build());
	}
	public String Group_val() throws IOException, GeneralLeanFtException
	{
		String prov_group = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		prov_group = fl_chk_val.getClaimValue("GI101",Group,0,0);
		return prov_group;
	}
	
	public String EFFective_date() throws IOException, GeneralLeanFtException
	{
		//String prov_eff = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		 String prov_eff = fl_chk_val.getClaimValue("EP120",EFF_date,0,0);
		return prov_eff;
	}
	
	public String EndDate_val() throws IOException, GeneralLeanFtException
	{
		String prov_EndDate = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		prov_EndDate = fl_chk_val.getClaimValue("GI101",End_Date,0,0);
		return prov_EndDate;
	}
	
	public void EP120_Inquire(String Group_ID) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary fl_inq = new FunctionLibrary();
	fl_inq.InquireCode(Group_ID,"EP120",5,4,23);
	

	
	}

}
