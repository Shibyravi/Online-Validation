package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class AuthNotification_TB309 {
	
	public Field logic_code,self_referral,ancillary_option;
	public Screen screenname;
	
	public AuthNotification_TB309(){
		try{
			logic_code=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
					.length(4).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(32)).build());
		self_referral=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(12).setColumn(50)).build());
		ancillary_option=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(2).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(17).setColumn(34)).build());
		screenname=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build());
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void TB309_Inquire(String logic,String screen) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary funlib = new FunctionLibrary();
		funlib.InquireLogic(logic, "TB309");
		
	}

	public String logic_val() throws IOException, GeneralLeanFtException
	{
		String phy_logic = null;
		FunctionLibrary fl_schd1_val = new FunctionLibrary();
		phy_logic = fl_schd1_val.getClaimValue("TB309",logic_code,0,0);
		return phy_logic;
	}
	public String self_referral() throws IOException, GeneralLeanFtException
	{
		String phy_refer = null;
		FunctionLibrary fl_refer_val = new FunctionLibrary();
		phy_refer = fl_refer_val.getClaimValue("TB309",self_referral,0,0);
		return phy_refer;
	}
	public String ancillary_val() throws IOException, GeneralLeanFtException
	{
		String phy_anc = null;
		FunctionLibrary fl_anc_val = new FunctionLibrary();
		phy_anc = fl_anc_val.getClaimValue("TB309",ancillary_option,0,0);
		return phy_anc;
	}
}
