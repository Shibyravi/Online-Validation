package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import stepDefinition.Medica;
import util.FunctionLibrary;

public class Physician_CL300 {
	public Field asOfdate,group,member,memNo,carrier;
	
	public Screen screen;
	
	public Physician_CL300()
	{
		try {
	     asOfdate=		Desktop.describe(Window.class, new WindowDescription.Builder()
	 			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
	 					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
	 					.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(3).setColumn(16)).build());
	     
	     group= Desktop.describe(Window.class, new WindowDescription.Builder()
	 			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
	 					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
	 					.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(10)).build());
	     
	    member=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(9).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(19)).build());
	    
memNo=Desktop.describe(Window.class, new WindowDescription.Builder()
		.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
		.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
		.length(2).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(32)).build());
	
carrier=Desktop.describe(Window.class, new WindowDescription.Builder()
		.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
		.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
		.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(10).setColumn(43)).build());

screen=Desktop.describe(Window.class, new WindowDescription.Builder()
		.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
		.label("UNI").build());
		
		}

	
		
		catch (GeneralLeanFtException e) {
			e.printStackTrace();
		}
	}
	
	//////////Methods for validating each of the field value in CL300//////////////
	
	public void enter_asOfdate(String date) throws IOException, GeneralLeanFtException
	{
		asOfdate.setText(date);

	}
	public void enter_group() throws IOException, GeneralLeanFtException
	{
		String Group=Medica.group;
		group.setText(Group);

	}
	
	public void enter_member() throws IOException, GeneralLeanFtException
	{
		String Member=Medica.memberNo;
		member.setText(Member);

	}
	
	public void enter_memNo() throws IOException, GeneralLeanFtException
	{
		String mNo=Medica.mNo;
		memNo.setText(mNo);
		screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);

	}
	
	public String get_carrier() throws IOException, GeneralLeanFtException
	{
		String Carrier = null;
		FunctionLibrary f1 = new FunctionLibrary();
		Carrier = f1.getClaimValue("CL300",carrier,0,0);
		return Carrier;
	}
}
