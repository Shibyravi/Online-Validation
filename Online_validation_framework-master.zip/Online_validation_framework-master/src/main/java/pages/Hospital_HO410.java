package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

//
public class Hospital_HO410 {

	public Field audit,par_status,cat_num,fin_prod,cat_sub_num,last_cat_num,last_catsub_num,contract_amt,claim_split,fed_tax_id,bill_type,ptnt_stat,admit_hr,disch_hr,comments,Override_Code,prov_panel,Mental_Health_Status,ref1,ref2,pcp1,pcp2;;

	public Hospital_HO410() 
	{
		try {
			//fjldj
			audit = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().attachedText("AUD").length(9).startPosition(4,6).build());
			cat_num = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(3).startPosition(7,15).build());
			last_cat_num = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(5).startPosition(7,51).build());
			cat_sub_num = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(3).startPosition(8,15).build());
			last_catsub_num = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(5).startPosition(8,51).build());
			contract_amt = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(12).startPosition(9,15).build());
			par_status = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(8).startPosition(10,15).build());
			claim_split = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(1).startPosition(12,15).build());
			fed_tax_id = claim_split = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(9).startPosition(14,15).build());
			bill_type =  Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(3).startPosition(10,46).build());
			comments =  Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(78).startPosition(22,2).build());
						
			ptnt_stat = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(2).startPosition(11,46).build());
			admit_hr = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(2).startPosition(12,46).build());
			disch_hr = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(2).startPosition(13,46).build());
			Override_Code=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(46)).build());
			fin_prod= Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(6).attachedText("00952(protected)").startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(11).setColumn(72)).build());
              
                 Mental_Health_Status=Desktop.describe(Window.class, new WindowDescription.Builder()
     .shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
     .label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
     .length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(6).setColumn(72)).build());
			prov_panel=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
					.length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(72)).build());
			
			
			//shalu
			
			ref1=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(4).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(42)).build());
			
			ref2=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(8).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(47)).build());
			pcp1=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(4).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(6).setColumn(42)).build());
			pcp2=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(8).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(6).setColumn(47)).build());
			
		} catch (GeneralLeanFtException e) {
			e.printStackTrace();
		}
	}
	public void HO410_Inquire(String hos_aud, String c_div) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary fl_inq2 = new FunctionLibrary();
		fl_inq2.InquireClaim(hos_aud,  c_div, "HO410","AUD",9,4,6,0,0,0);
		
	}
	public String hos_audit_val() throws IOException, GeneralLeanFtException
	{
		String hos_audit = null;
		FunctionLibrary fl_audit_val = new FunctionLibrary();
		hos_audit = fl_audit_val.getClaimValue("HO410",audit,0,0);
		return hos_audit;
	}
	public String hos_Medical_val() throws IOException, GeneralLeanFtException
	{
		String hos_Medical_Health_Status_val = null;
		FunctionLibrary fl_audit_val = new FunctionLibrary();
		hos_Medical_Health_Status_val = fl_audit_val.getClaimValue("HO410",Mental_Health_Status,0,0);
		return hos_Medical_Health_Status_val;
	}
	public String par_status_val() throws IOException, GeneralLeanFtException
	{
		String par_stat = null;
		FunctionLibrary fl_par_status_val = new FunctionLibrary();
		par_stat = fl_par_status_val.getClaimValue("HO410",par_status,0,0);
		return par_stat;
	}
	public String claim_split_val() throws IOException, GeneralLeanFtException
	{
		String clm_stat = null;
		FunctionLibrary fl_claim_split_val = new FunctionLibrary();
		clm_stat = fl_claim_split_val.getClaimValue("HO410",claim_split,0,0);
		return clm_stat;
	}
	
	public String fin_prod_val() throws IOException, GeneralLeanFtException
	{
		String clm_stat = null;
		FunctionLibrary fl_claim_split_val = new FunctionLibrary();
		clm_stat = fl_claim_split_val.getClaimValue("HO410",fin_prod,0,0).trim();
		return clm_stat;
	}
	public String fed_tax_id_val() throws IOException, GeneralLeanFtException
	{
		String tax_id = null;
		FunctionLibrary fl_fed_tax_id_val = new FunctionLibrary();
		tax_id = fl_fed_tax_id_val.getClaimValue("HO410",fed_tax_id,0,0);
		return tax_id;
	}
	public String bill_type_val() throws IOException, GeneralLeanFtException
	{
		String type_of_bill = null;
		FunctionLibrary fl_bill_type_val = new FunctionLibrary();
		type_of_bill = fl_bill_type_val.getClaimValue("HO410",bill_type,0,0);
		return type_of_bill;
	}
	public String ptnt_stat_val() throws IOException, GeneralLeanFtException
	{
		String disch_stat = null;
		FunctionLibrary fl_ptnt_stat_val = new FunctionLibrary();
		disch_stat = fl_ptnt_stat_val.getClaimValue("HO410",ptnt_stat,0,0);
		return disch_stat;
	}
	public String admit_hr_val() throws IOException, GeneralLeanFtException
	{
		String adm_hr = null;
		FunctionLibrary fl_admit_hr_val = new FunctionLibrary();
		adm_hr = fl_admit_hr_val.getClaimValue("HO410",admit_hr,0,0);
		return adm_hr;
	}
	public String disch_hr_val() throws IOException, GeneralLeanFtException
	{
		String discharge_hr = null;
		FunctionLibrary fl_disch_hr_val = new FunctionLibrary();
		discharge_hr = fl_disch_hr_val.getClaimValue("HO410",disch_hr,0,0);
		return discharge_hr;
	}
	public String category_number_val() throws IOException, GeneralLeanFtException
	{
		String cat_number = null;
		FunctionLibrary fl_category_numberr_val = new FunctionLibrary();
		cat_number = fl_category_numberr_val.getClaimValue("HO410",cat_num,0,0).concat(fl_category_numberr_val.getClaimValue("HO410",cat_sub_num,0,0));
		return cat_number;
	}
	public String last_category_number_val() throws IOException, GeneralLeanFtException
	{
		String cat_number = null;
		FunctionLibrary fl_category_numberr_val = new FunctionLibrary();
		cat_number = fl_category_numberr_val.getClaimValue("HO410",last_cat_num,0,0).concat(fl_category_numberr_val.getClaimValue("HO410",last_catsub_num,0,0));
		return cat_number;
	}
	
	public String comments_val() throws IOException, GeneralLeanFtException
	{
		String hos_comments = null;
		FunctionLibrary fl_comments_val = new FunctionLibrary();
		hos_comments = fl_comments_val.getClaimValue("HO410",comments,0,0);
		return hos_comments;
	}
	public String Contract_Amount_val() throws IOException, GeneralLeanFtException
	{
		String Contract_Amount = null;
		FunctionLibrary fl_par_status_val = new FunctionLibrary();
		Contract_Amount = fl_par_status_val.getClaimValue("HO410",contract_amt,0,0);
		return Contract_Amount;
	}
	
	public String OverrideCD_val() throws IOException, GeneralLeanFtException
	{
		String OverrideCD = null;
		FunctionLibrary fl_par_status_val = new FunctionLibrary();
		OverrideCD = fl_par_status_val.getClaimValue("HO410",Override_Code,0,0);
		return OverrideCD;
	}
	public String prov_panel_val() throws IOException, GeneralLeanFtException
	{
		String provpanel = null;
		FunctionLibrary fl_prov_val = new FunctionLibrary();
		provpanel = fl_prov_val.getClaimValue("HO410",prov_panel,0,0);
		return provpanel;
	}
	
	//shalu
	public String ref_prvdr_val() throws IOException, GeneralLeanFtException
	{
		String refp1 = null;
		String refp2 = null;
		String refP=null;
		FunctionLibrary fl_prov_val = new FunctionLibrary();
		refp1 = fl_prov_val.getClaimValue("HO410",ref1,0,0);
		System.out.println("ref1 is: "+refp1);
		refp2= fl_prov_val.getClaimValue("HO410",ref2,0,0);
		System.out.println("ref2 is: "+refp2);
		refP=refp1+refp2;
		System.out.println("ref provider is: "+refP);
		return refP;
	}

	public String pcp_prvdr_val() throws IOException, GeneralLeanFtException
	{
		String pcp_p1 = null;
		String pcp_p2 = null;
		String pcp_P=null;
		FunctionLibrary fl_prov_val = new FunctionLibrary();
		pcp_p1 = fl_prov_val.getClaimValue("HO410",pcp1,0,0);
		System.out.println("pcp1 is: "+pcp_p1);
		pcp_p2= fl_prov_val.getClaimValue("HO410",pcp2,0,0);
		System.out.println("pcp2 is: "+pcp_p2);
		pcp_P=pcp_p1+pcp_p2;
		System.out.println("pcp provider is: "+pcp_P);
		return pcp_P;
	}
	
}
