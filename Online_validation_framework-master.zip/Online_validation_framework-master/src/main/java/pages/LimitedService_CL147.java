package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class LimitedService_CL147
{
public Field member_inq,mem_sub1,memb_sub2,limited_svc,unit_count;
public Screen main_screen;
public LimitedService_CL147()
{
	try {
		member_inq = Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(15)).build());
		mem_sub1=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(9).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(25)).build());
		memb_sub2 =Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(2).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(39)).build());
		
		limited_svc= Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(15)).build());
		unit_count=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(4).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(14).setColumn(16)).build());
		main_screen=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build());
	} catch (GeneralLeanFtException e) {
		e.printStackTrace();
	}
}

public void member_inq(String mem_number,String member_number2,String member_number3,String screen) throws IOException, GeneralLeanFtException, InterruptedException
{
	FunctionLibrary fl_mem = new FunctionLibrary();
	
	fl_mem.InquireMemberNumber(mem_number,member_number2, member_number3,"CL147",5,4,15);
	
}


public void limitedServ_Inquire(String limit_svc_code) throws GeneralLeanFtException, InterruptedException, IOException
{
	FunctionLibrary fl_inq = new FunctionLibrary();
	fl_inq.InquireCode(limit_svc_code, "CL147", 9,4,25);
}

public String limited_svc_val() throws IOException, GeneralLeanFtException
{
	String limited_svc1= null;
	FunctionLibrary fl_lsvc = new FunctionLibrary();
	limited_svc1 = fl_lsvc.getClaimValue("CL147",limited_svc,0,0);
	return limited_svc1;
}
public String member_val() throws IOException, GeneralLeanFtException
{
	String member_val= null;
	FunctionLibrary fl_lsvc = new FunctionLibrary();
	member_val = fl_lsvc.getClaimValue("CL147",member_inq,0,0);
	return member_val;
}
public String unit_count_val() throws IOException, GeneralLeanFtException
{
	String unit_count_val= null;
	FunctionLibrary fl_lsvc = new FunctionLibrary();
	unit_count_val = fl_lsvc.getClaimValue("CL147",unit_count,0,0);
	return unit_count_val;
}
}