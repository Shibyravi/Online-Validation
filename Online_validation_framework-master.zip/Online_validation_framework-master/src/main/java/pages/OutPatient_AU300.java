package pages;

import java.io.IOException;


import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.*;

import util.FunctionLibrary;

public class OutPatient_AU300 {
	public Field member_number,member_num_sub,intake_num,notif_units;
	public Screen ScreenName2,main_screen;
	
	public OutPatient_AU300(){
		try {
			intake_num =Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(8).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(3).setColumn(13)).build());
			main_screen=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build());
		
			member_number = Desktop.describe(Window.class, new WindowDescription.Builder()
				.build()).describe(Screen.class, new ScreenDescription()).describe(Field.class, new FieldDescription.Builder()
						.length(5).attachedText("MEMBER NBR").startPosition(4,13).id(253).index(0).build());
		
			member_num_sub=Desktop.describe(Window.class, new WindowDescription.Builder()
				.build()).describe(Screen.class, new ScreenDescription()).describe(Field.class, new FieldDescription.Builder()
						.length(9).attachedText("MEMBER NBR").startPosition(4,21).id(261).index(1).build());
			ScreenName2= Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.cursorPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(3).setColumn(21)).label("UNI").build());
			notif_units = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(3).startPosition(11,25).index(0).build());
	}
		
		 
		
		catch (GeneralLeanFtException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
		public void AU300_Inquire(String intake_num, String screen) throws IOException, GeneralLeanFtException, InterruptedException{
		    
			FunctionLibrary fl_inquire = new FunctionLibrary();
			fl_inquire.InquireNotification(intake_num,screen,8,3,13);
			
	}
		public String intake_num() throws IOException, GeneralLeanFtException
		{
			String intake_num1 = null;
			FunctionLibrary fl_intake_val = new FunctionLibrary();
			intake_num1 = fl_intake_val.getClaimValue("AU300",intake_num,0,0);
			return intake_num1;
		}
		public String notif_units_val() throws IOException, GeneralLeanFtException
		{
			String n_units = null;
			FunctionLibrary fl_notif_units_val = new FunctionLibrary();
			n_units = fl_notif_units_val.getClaimValue("AU300",notif_units,0,0);
			return n_units;
		}
}