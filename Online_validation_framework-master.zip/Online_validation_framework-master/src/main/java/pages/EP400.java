package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import stepDefinition.Medica;
import util.FunctionLibrary;

public class EP400 {

	
	
	
	public Field group,subscriber,cob;
		public Screen screen;
	
	public EP400()
	{
		try {
	     group=		Desktop.describe(Window.class, new WindowDescription.Builder()
	 			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
	 					.label("UNITE").build()).describe(Field.class, new FieldDescription.Builder()
	 					.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(18)).build());
	     
	     screen= Desktop.describe(Window.class, new WindowDescription.Builder()
	 			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
	 					.label("UNITE").build());
	   
	     subscriber=Desktop.describe(Window.class, new WindowDescription.Builder()
	 			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
	 					.label("UNITE").build()).describe(Field.class, new FieldDescription.Builder()
	 					.length(9).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(18)).visible(true).build());
	    cob=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNITE").build()).describe(Field.class, new FieldDescription.Builder()
						.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(11).setColumn(14)).build()); 
	   
		}

	
	
		
		catch (GeneralLeanFtException e) {
			e.printStackTrace();
		}
	}
	
	
	
	public void enter_group() throws IOException, GeneralLeanFtException
	{
		String GroupNo=Medica.group;
		group.setText(GroupNo);

	}
	
	public void enter_subscriber() throws IOException, GeneralLeanFtException
	{
		String Subscriber=Medica.memberNo;
		subscriber.setText(Subscriber);
		screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	}
	
	public String get_cob() throws IOException, GeneralLeanFtException
	{
		String COB = null;
		FunctionLibrary f1 = new FunctionLibrary();
		COB = f1.getClaimValue("EP400",cob,0,0);
		return COB;
	}
}
