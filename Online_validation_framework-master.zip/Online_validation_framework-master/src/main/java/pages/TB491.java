package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class TB491 {
	
	public Field legal_id,fin_id,mem_Zip,med_Cap;
	public Screen main_screen,ScreenNameA;
	public static String cap=null;
	
	public TB491()
	{
		try{
			legal_id=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(25)).build());
			
			fin_id=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(43)).build());
			mem_Zip=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(37)).build());
			med_Cap=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(41)).build());
			ScreenNameA= Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build());
			main_screen=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build());
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	public void enter_legal_id(String Screen) throws IOException, GeneralLeanFtException, InterruptedException
	{
		
		FunctionLibrary funlib = new FunctionLibrary();
		funlib.navigateToDiv(Screen);
		Thread.sleep(500);
		String leg_val=null;
		leg_val=Physician_CL202.Legal_id;
		legal_id.setText(leg_val);
		System.out.println("value for legal id entered");
	}
	 

	public void enter_fin_id() throws IOException, GeneralLeanFtException
	{
		String fin_val=null;
		fin_val=Physician_CL202.Fin_id;
		fin_id.setText(fin_val);
		System.out.println("value for financial id entered");
	    ScreenNameA.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	}
	
	public String get_mem_zip() throws IOException, GeneralLeanFtException
	{
		String zip = null;
		FunctionLibrary fl_zip_val = new FunctionLibrary();
		zip = fl_zip_val.getClaimValue("TB491",mem_Zip,0,0);
		return zip;
	}
	
	public String get_med_cap() throws IOException, GeneralLeanFtException
	{
		String cap = null;
		FunctionLibrary fl_cap_val = new FunctionLibrary();
		cap = fl_cap_val.getClaimValue("TB491",med_Cap,0,0);
		return cap;
	}
	public void press_enter() throws IOException, GeneralLeanFtException
	{
	
	    ScreenNameA.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	}
	}
