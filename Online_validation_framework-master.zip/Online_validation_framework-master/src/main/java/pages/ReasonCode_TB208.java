package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class ReasonCode_TB208 {
	public Field reason_code,ClsCode,GovCl;
	public Screen main_screen,ScreenNameA;
	FunctionLibrary funlib;
	public ReasonCode_TB208() throws GeneralLeanFtException
	{
		reason_code=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(4).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(39)).build());
		ClsCode=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(10).setColumn(63)).build());
		GovCl=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(13).setColumn(47)).build());
		ScreenNameA= Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build());
		funlib = new FunctionLibrary();
	
	}
	public void PS475_Inquire(String div,String schd,String cpt,String screen) throws GeneralLeanFtException, InterruptedException, IOException
	{
		
		funlib.InquireFeeMax(div,schd,cpt,screen);
		
	}
	public String reason_code_val() throws IOException, GeneralLeanFtException
	{
		String rsn = null;
		rsn = funlib.getClaimValue("TB208",reason_code,0,0);
		return rsn;
	}

	public String ClsCode_val() throws IOException, GeneralLeanFtException
	{
		String cls = null;
		cls = funlib.getClaimValue("TB208",ClsCode,0,0);
		return cls;
	}
	public String GovCl_val() throws IOException, GeneralLeanFtException
	{
		String gov = null;
		gov = funlib.getClaimValue("TB208",GovCl,0,0);
		return gov;
	}
	
	
	

}
