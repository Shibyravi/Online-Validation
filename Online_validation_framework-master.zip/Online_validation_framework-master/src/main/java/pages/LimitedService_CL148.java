package pages;

import java.io.IOException;
import java.util.List;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class LimitedService_CL148 {
	
		public Field member_inq,mem_sub1,memb_sub2,limited_svc,benefit_number,unit_code;
		public Screen main_Screen;
		public LimitedService_CL148()
		{
			try {
				member_inq = Desktop.describe(Window.class, new WindowDescription.Builder()
						.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
								.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(15)).build());
				mem_sub1=Desktop.describe(Window.class, new WindowDescription.Builder()
						.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
								.length(9).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(25)).build());
				memb_sub2 =Desktop.describe(Window.class, new WindowDescription.Builder()
						.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
								.length(2).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(39)).build());
				
				limited_svc= Desktop.describe(Window.class, new WindowDescription.Builder()
						.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
								.length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(15)).build());
				unit_code=Desktop.describe(Window.class, new WindowDescription.Builder()
						.shortName("B").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
								.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(13).setColumn(13)).index(1).build());
				benefit_number=Desktop.describe(Window.class, new WindowDescription.Builder()
						.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
								.length(7).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(13).setColumn(49)).build());
				main_Screen=Desktop.describe(Window.class, new WindowDescription.Builder()
						.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UNI").build());
			} catch (GeneralLeanFtException e) {
				e.printStackTrace();
			}
		}
		
		
		public void member_inq(String mem_number,String member_number2,String member_number3,String screen) throws IOException, GeneralLeanFtException, InterruptedException
		{
			
			FunctionLibrary fl_mem = new FunctionLibrary();
			
			fl_mem.InquireMemberNumber(mem_number,member_number2, member_number3,"CL148",5,4,15);
			
		}


		public void limitedServ_Inquire(String limit_svc_code) throws GeneralLeanFtException, InterruptedException, IOException
		{
			FunctionLibrary fl_inq = new FunctionLibrary();
			fl_inq.InquireCode(limit_svc_code, "CL148", 9,4,25);
		}

		public String limited_svc_val() throws IOException, GeneralLeanFtException
		{
			String limited_svc1= null;
			FunctionLibrary fl_lsvc = new FunctionLibrary();
			limited_svc1 = fl_lsvc.getClaimValue("CL148",limited_svc,0,0);
			return limited_svc1;
		}
		public String member_val() throws IOException, GeneralLeanFtException
		{
			String member_val= null;
			FunctionLibrary fl_lsvc = new FunctionLibrary();
			member_val = fl_lsvc.getClaimValue("CL148",member_inq,0,0);
			return member_val;
		}
		public String unit_val() throws IOException, GeneralLeanFtException
		{
			String unit_val= null;
			FunctionLibrary fl_lsvc = new FunctionLibrary();
			unit_val = fl_lsvc.getClaimValue("CL148",unit_code,0,0);
			return unit_val;
		}
		public String benefit_number_val() throws IOException, GeneralLeanFtException
		{
			String benefit_val= null;
			FunctionLibrary fl_lsvc = new FunctionLibrary();
			benefit_val = fl_lsvc.getClaimValue("CL148",benefit_number,0,0);
			return benefit_val;
		}
		
		public List benefit_val(String required_benefit_num) throws IOException, GeneralLeanFtException, InterruptedException
		{
			
			FunctionLibrary fl_inq1 = new FunctionLibrary();
			//fl_review_val.InquireClaim(phys_aud,  c_div, "CL209","CLAIM AUDIT",8,4,22,2,4,33);
			//String phy_rev = null;
			List benefit_number_details = fl_inq1.getReviewClearDetails("CL148",required_benefit_num,7);
			return benefit_number_details;
		}
		
}