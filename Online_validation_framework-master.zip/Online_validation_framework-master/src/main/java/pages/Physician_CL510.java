package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class Physician_CL510 {

	
	public Field zipCode,proc_code,provider_type,modifier,percent,date,actual_fee;
	
	public Screen cur_screen,phy_screen,main_screen;
	
	public Physician_CL510()
	{
		try {
	     zipCode=		Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNITE").build()).describe(Field.class, new FieldDescription.Builder()
					.length(3).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(22)).build());
	     
	     phy_screen= Desktop.describe(Window.class, new WindowDescription.Builder()
	 			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
	 			.label("UNITE").build());
	     
	    proc_code= Desktop.describe(Window.class, new WindowDescription.Builder()
	 			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
	 			.label("UNITE").build()).describe(Field.class, new FieldDescription.Builder()
	 			.length(5).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(22)).build());
	    
		provider_type=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNITE").build()).describe(Field.class, new FieldDescription.Builder()
						.length(4).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(6).setColumn(22)).build());
		
		modifier=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNITE").build()).describe(Field.class, new FieldDescription.Builder()
						.length(2).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(7).setColumn(25)).build());
		
		percent=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNITE").build()).describe(Field.class, new FieldDescription.Builder()
				.length(2).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(8).setColumn(22)).build());
		
		date=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNITE").build()).describe(Field.class, new FieldDescription.Builder()
				.length(6).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(22)).build());
		
		actual_fee=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNITE").build()).describe(Field.class, new FieldDescription.Builder()
				.length(14).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(15).setColumn(41)).build());
		}

	
		
		catch (GeneralLeanFtException e) {
			e.printStackTrace();
		}
	}
	
	//////////Methods for validating each of the field value in CL510//////////////
	public void enter_zipcode(String zipcode) throws IOException, GeneralLeanFtException
	{
		zipCode.setText(zipcode);
		phy_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);

	}
	
	public void enter_proc_code(String proc_Code) throws IOException, GeneralLeanFtException
	{
		proc_code.setText(proc_Code);
		phy_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);	

	}
	
	public void enter_prov_type(String prov_Code) throws IOException, GeneralLeanFtException
	{
		provider_type.setText(prov_Code);
		phy_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);	

	}
	
	public void enter_modifier(String mod) throws IOException, GeneralLeanFtException
	{
		modifier.setText(mod);
		phy_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);	

	}
	
	public void enter_percentage(String percentage) throws IOException, GeneralLeanFtException
	{
		percent.setText(percentage);
		phy_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);	

	}
	
	public void enter_date(String fromDate) throws IOException, GeneralLeanFtException
	{
		date.setText(fromDate);
		phy_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);	

	}
	
	public String actual_fee_val() throws IOException, GeneralLeanFtException
	{
		String actualFee = null;
		FunctionLibrary fl_par_status = new FunctionLibrary();
		actualFee = fl_par_status.getClaimValue("CL510",actual_fee,0,0);
		return actualFee;
	}
}
