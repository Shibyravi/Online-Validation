package pages;

import java.io.IOException;
import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class Procedure_PCFM {
	
	public Field std_fee_max,from,command,proc_code,stdAnesMax;
	public Screen cur_screen,proc_screen,com_screen;
	public Procedure_PCFM()
	{
		try {
			cur_screen=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build());
			std_fee_max=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("COMMAND           P R O C E").build()).describe(Field.class, new FieldDescription.Builder()
							.length(8).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(6).setColumn(20)).build());
			from = Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("COMMAND           P R O C E").build()).describe(Field.class, new FieldDescription.Builder()
							.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(2).setColumn(20)).build());
			command =  Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("COMMAND           P R O C E").build()).describe(Field.class, new FieldDescription.Builder()
							.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(2).setColumn(3)).build());
			proc_code=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("COMMAND           P R O C E").build()).describe(Field.class, new FieldDescription.Builder()
					.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(20)).build());
			stdAnesMax=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("COMMAND           P R O C E").build()).describe(Field.class, new FieldDescription.Builder()
							.length(8).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(6).setColumn(52)).build());
			proc_screen=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("COMMAND           P R O C E").build());
			com_screen=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("COMMAND           P R O C E").build());
			
		} 
		
		catch (GeneralLeanFtException e) {
			e.printStackTrace();
		}
	}
	public String std_fee_max_val() throws IOException, GeneralLeanFtException
	{
		String stand_fee_max = null;
		FunctionLibrary fl_det_deny_code = new FunctionLibrary();
		String str = fl_det_deny_code.getClaimValue("PCFM",std_fee_max,0,0);
		if((str.equals("") || str == null))
		{
			System.out.println("Not found standard feemax value in PCFM");
		}
		else if(str.length()<=6){
			stand_fee_max=str;
		}
		else{
			stand_fee_max=str.substring(0,6);	
			}
		
		return stand_fee_max;
	}
	
	
	public String from_val() throws IOException, GeneralLeanFtException
	{
		String from_date = null;
		FunctionLibrary fl_det_deny_code = new FunctionLibrary();
		from_date = fl_det_deny_code.getClaimValue("CL201",from,0,0);
		return from_date;
	}
	public String proc_val() throws IOException, GeneralLeanFtException
	{
		String proc = null;
		FunctionLibrary fl_cpt_code = new FunctionLibrary();
		proc = fl_cpt_code.getClaimValue("CL201",proc_code,0,0);
		return proc;
	}
	
	public String command_val() throws IOException, GeneralLeanFtException
	{
		String comm = null;
		FunctionLibrary fl_det_deny_code = new FunctionLibrary();
		comm = fl_det_deny_code.getClaimValue("CL201",command,0,0);
		return comm;
	}
	
	public String stdAnes_val() throws IOException, GeneralLeanFtException
	{
		String anes;
		FunctionLibrary fl_stdAnes = new FunctionLibrary();
		anes = fl_stdAnes.getClaimValue("PCFM",stdAnesMax,0,0);
		return anes;
	}
	public void Procedure_PCFM_Inquire(String command,String from,String cpt) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary fl_inq = new FunctionLibrary();
		fl_inq.InquireProcCOde(command,from,cpt);
	}
	

	
}
