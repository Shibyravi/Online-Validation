package pages;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.temporal.ChronoUnit;
import java.util.Date;

import org.testng.Assert;

import com.cucumber.listener.Reporter;
import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import stepDefinition.Gatekeeper;
import stepDefinition.Medica;
import util.FunctionLibrary;
//
public class PS331 {
	public Field provider1,provider2,msg,ScreenName;
	public Screen Screen;
	FunctionLibrary funlib;
	public static String BN=null;

	public PS331() throws GeneralLeanFtException
	{
	//lj
		Screen=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNIT").build());
		provider1=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNIT").build()).describe(Field.class, new FieldDescription.Builder()
						.length(4).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(13)).build());
		
		provider2=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNIT").build()).describe(Field.class, new FieldDescription.Builder()
						.length(7).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(21)).build());
	
		msg=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UN").build()).describe(Field.class, new FieldDescription.Builder()
						.length(79).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(23).setColumn(2)).build());
		ScreenName=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNIT").build()).describe(Field.class, new FieldDescription.Builder()
						.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(1).setColumn(3)).build());
	}


	public void enter_providerNo1(String provider_type) throws IOException, GeneralLeanFtException
	{
		if(provider_type.equalsIgnoreCase("Pricare_Provider")){
			String Prov1=Medica.PROV_NO1;
			provider1.setText(Prov1);	
		}
		else if (provider_type.equalsIgnoreCase("Par_Provider")) {
			String Prov1=Gatekeeper.Ref_no1;
			provider1.setText(Prov1);	
		}
		
		else if (provider_type.equalsIgnoreCase("Non_Par_Provider")) {
			String Prov1=Gatekeeper.Ref_no1;
			provider1.setText(Prov1);	
		}
		
		else if (provider_type.equalsIgnoreCase("Reference_Provider")) {
			String Prov1=Gatekeeper.Ref_no1;
			provider1.setText(Prov1);	
		}
			
		else if (provider_type.equalsIgnoreCase("Billing_Provider")) {
			String Prov1=Gatekeeper.Ref_no1;
			provider1.setText(Prov1);	
		}
		}

	
	public void enter_providerNo2(String provider_type) throws IOException, GeneralLeanFtException
	{
		if(provider_type.equalsIgnoreCase("Pricare_Provider")){
			String Prov2=Medica.PROV_NO2;
			provider2.setText(Prov2);	
		}
		else if (provider_type.equalsIgnoreCase("Par_Provider")) {
			String Prov2=Gatekeeper.Ref_no2;
			provider2.setText(Prov2);	
		}
		
		else if (provider_type.equalsIgnoreCase("Non_Par_Provider")) {
			String Prov2=Gatekeeper.Ref_no2;
			provider2.setText(Prov2);	
		}
		else if (provider_type.equalsIgnoreCase("Reference_Provider")) {
			String Prov2=Gatekeeper.Ref_no2;
			provider2.setText(Prov2);	
		}
		else if (provider_type.equalsIgnoreCase("Billing_Provider")) {
			String Prov2=Gatekeeper.Ref_no2;
			provider2.setText(Prov2);	
		}
	}
	
	public void validatePCP(String Reqstatus,String ReqRole,String provider_type) throws IOException, GeneralLeanFtException, ParseException, InterruptedException
	{
		Thread.sleep(500);
		String panelId=	null;
		String ExpDate=null;
		String ProvStatus=null;
		String Role=null;
		String PCPNo=null;
		String status="fail";
		int i;
		boolean flag=false;
		Field panel,expDate,Prov_status,role,PCP;
		String Msg=null;
		Thread.sleep(900);
		Msg=Screen.getText();
		//Msg=msg.getText();
		//System.out.println("Msg is: "+Msg);
		Thread.sleep(600);
		outerloop:
			do{

				for (i = 8; i <=16; i+=4) {

					panel=Desktop.describe(Window.class, new WindowDescription.Builder()
							.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNIT").build()).describe(Field.class, new FieldDescription.Builder()
							.length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(i).setColumn(7)).build());

					expDate=Desktop.describe(Window.class, new WindowDescription.Builder()
							.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNIT").build()).describe(Field.class, new FieldDescription.Builder()
							.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(i).setColumn(38)).build());
				
					Prov_status=Desktop.describe(Window.class, new WindowDescription.Builder()
							.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNIT").build()).describe(Field.class, new FieldDescription.Builder()
							.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(i).setColumn(47)).build());
					role=Desktop.describe(Window.class, new WindowDescription.Builder()
							.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNIT").build()).describe(Field.class, new FieldDescription.Builder()
							.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(i).setColumn(53)).build());

					PCP=Desktop.describe(Window.class, new WindowDescription.Builder()
							.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
									.label("UNIT").build()).describe(Field.class, new FieldDescription.Builder()
											.length(11).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(i+1).setColumn(7)).build());


					panelId=panel.getText();
					ExpDate=expDate.getText();
					ProvStatus=Prov_status.getText();
					Role=role.getText();
					PCPNo=PCP.getText();

					String reqPanel=Medica.panel_no;
					
					//for required expired date
					if (panelId.equalsIgnoreCase(reqPanel)) 
					{
						if (ExpDate.equalsIgnoreCase("")||ExpDate.equalsIgnoreCase(null)) {
							System.out.println("Expired date is not there:pass");
							status="pass";
						}
						else{

							Date d=new Date();
							SimpleDateFormat format1 = new SimpleDateFormat("MMddyy");
							String n=format1.format(d);	
							System.out.println(n);
							SimpleDateFormat sdf = new SimpleDateFormat("MMddyy");
							Date date1 = sdf.parse(n);
							System.out.println("date 1 is :"+ date1);
							Date date2 = sdf.parse(ExpDate);
							System.out.println("date 2 is :"+ date2);
							long daysBetween = ChronoUnit.DAYS.between(date1.toInstant(), date2.toInstant());
							System.out.println("Days Difference between Frm_Date and Thru_Date is" +daysBetween);
							String temp=String.valueOf(daysBetween);
							if (!temp.contains("-")) {
								System.out.println("expiration date is not expired:pass");
								status="pass";
							}
							else{
								System.out.println("expiration date is expired:fail");
								status="fail";
							}
						}		

					}	

					//condition for required panel no and expire date should not expired
					if(panelId.equalsIgnoreCase(reqPanel)||(status.equalsIgnoreCase("pass")))
					{
						
						if(provider_type.equalsIgnoreCase("Pricare_Provider")){
						//verify satsus role and fetch PCP and verify it with Referene provider
						System.out.println("Required panel no found with not expired date");
                         Assert.assertEquals(ReqRole, Role);
                         System.out.println("Role verified");
                         Assert.assertEquals(Reqstatus, ProvStatus);
                         System.out.println("Provider status verified");
                         String ReqRefno=Gatekeeper.Ref_no;
                         ReqRefno=ReqRefno.replace("-", "");
                         Assert.assertEquals(PCPNo,ReqRefno);
                         System.out.println("Provider verified");
                         flag=true;
                         break outerloop;
						}
						
						 else if(provider_type.equalsIgnoreCase("Par_Provider")){
							System.out.println("Fetch the stat value, if P then benefit lvl should be 06 and if N then ben lvl should be 07");
							if (ProvStatus.equalsIgnoreCase("P")) {
								System.out.println("Benefit level should be 06");
								BN="06";
								  flag=true;
								 break outerloop;
							}
							else if (ProvStatus.equalsIgnoreCase("N")) {
								System.out.println("Benefit level should be 07");
								BN="07";
								  flag=true;
								 break outerloop;

							}
						   
						  }
						
						 else if(provider_type.equalsIgnoreCase("Billing_Provider")){
								System.out.println("Fetch the stat value, if P then benefit lvl should be 05");
								if (ProvStatus.equalsIgnoreCase("P")) {
									System.out.println("Benefit level should be 05");
									BN="05";
									  flag=true;
									 break outerloop;
								}
								else if (ProvStatus.equalsIgnoreCase("N")) {
									System.out.println("Status not P");
									  flag=false;
									 break outerloop;

								}
							   
							  }
						
						 else if(provider_type.equalsIgnoreCase("Non_Par_Provider")){
								System.out.println("Fetch the stat value, if N then benefit lvl should be 06 and if Y then ben lvl should be 07");
								if (ProvStatus.equalsIgnoreCase("P")) {
									System.out.println("Benefit level should be 06");
									BN="06";
									  flag=true;
									 break outerloop;
								}
								else if (ProvStatus.equalsIgnoreCase("N")) {
									System.out.println("Benefit level should be 07");
									BN="07";
									  flag=true;
									 break outerloop;

								}
							  }
						

						 else if(provider_type.equalsIgnoreCase("Reference_Provider")){
						//verify satsus role and fetch PCP and verify it with Referene provider
						System.out.println("Required panel no found with not expired date");
                         String cl202_pcp=Gatekeeper.pcp;
                         cl202_pcp=cl202_pcp.replace("-", "");
                         Assert.assertEquals(PCPNo,cl202_pcp);
                         System.out.println("PCP verified");
                         flag=true;
                         break outerloop;
						}
						
				}
			}

			Screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			
			Thread.sleep(800);
		}while(!Msg.contains("NO PANEL RECORDS"));

		System.out.println("No More records found");
		Assert.assertTrue(flag);
		System.out.println("Provider Verified with role and status");	
		Reporter.addStepLog("Provider Verified with role and status");

	}
	public void enter_NewScreen(String screen) throws IOException, GeneralLeanFtException
	{
	ScreenName.setText(screen);
	Screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);	

	}
	
}
