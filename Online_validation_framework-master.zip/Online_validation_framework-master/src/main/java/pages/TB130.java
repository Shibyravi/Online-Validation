package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class TB130 {
	
	public Field legal_id,fin_id,patientID;
	public Screen main_screen,ScreenNameA;
	
	public TB130()
	{
		try{
			legal_id=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNITE").build()).describe(Field.class, new FieldDescription.Builder()
							.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(44)).build());
			
			fin_id=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNITE").build()).describe(Field.class, new FieldDescription.Builder()
							.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(27)).build());
			patientID=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNITE").build()).describe(Field.class, new FieldDescription.Builder()
							.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(19).setColumn(46)).build());
			
			ScreenNameA= Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNITE").build());
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	public void enter_legal_id(String Screen) throws IOException, GeneralLeanFtException, InterruptedException
	{
		
		FunctionLibrary funlib = new FunctionLibrary();
		funlib.navigateToDiv(Screen);
		Thread.sleep(500);
		String leg_val=null;
		leg_val=Physician_CL202.Legal_id;
		legal_id.setText(leg_val);
		System.out.println("value for legal id entered");
	}
	public void enter_legalentity() throws IOException, GeneralLeanFtException, InterruptedException
	{
		
		String leg_val=null;
		leg_val=Physician_CL202.Legal_id;
		legal_id.setText(leg_val);
		System.out.println("value for legal id entered");
		ScreenNameA.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	}

	public void enter_fin_id() throws IOException, GeneralLeanFtException
	{
		String fin_val=null;
		fin_val=Physician_CL202.Fin_id;
		fin_id.setText(fin_val);
		System.out.println("value for financial id entered");
	    ScreenNameA.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	}
	public void enter_financial_id(String Screen) throws IOException, GeneralLeanFtException
	{
		FunctionLibrary funlib = new FunctionLibrary();
		funlib.navigateToDiv(Screen);
		String fin_val=null;
		fin_val=Physician_CL202.Fin_id;
		fin_id.setText(fin_val);
		System.out.println("value for financial id entered");
	}
	
	public String get_pat_id() throws IOException, GeneralLeanFtException
	{
		String pat_id = null;
		FunctionLibrary fl_pat= new FunctionLibrary();
		pat_id = fl_pat.getClaimValue("TB130",patientID,0,0);
		return pat_id;
	}
	public void press_enter() throws IOException, GeneralLeanFtException
	{
	
	    ScreenNameA.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	}
	}
