
package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.*;

import util.FunctionLibrary;

public class Physician_CL202 {
	
	public Field audit,subaudit,original_audit_number,par_status,date_posted,risk_type,recovery_flag,claim_Status,zip_code,Acn_Code,prov_panel,provider,pp_letter,claim_Type,outofarea,interest,chk_Returned,fin_id,legal_id,msg,dtl_lin1,dtl_lin2,org,claim_msg,calc_date,pcp;

	public static String Legal_id = null;
	public static String Fin_id = null;
public Screen SCREEN;
	public Physician_CL202() throws GeneralLeanFtException
	{
		
		SCREEN=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder().label("UNI").build());
		audit = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().attachedText("AUDIT").length(8).startPosition(4,13).index(0).build());
		subaudit = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().attachedText("AUDIT").length(2).startPosition(4,24).index(0).build());
		par_status = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(8).startPosition(7,46).index(0).build());
		date_posted = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(8,46).index(0).build());
		risk_type = Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(2).startPosition(12,71).index(0).build());
		recovery_flag = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(1).startPosition(9,27).index(0).build());
claim_Status=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(79).startPosition(23,2).build());
		Acn_Code=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(22).setColumn(2)).build());
		zip_code=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(15).setColumn(58)).build());
						
						prov_panel=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(9).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(71)).build());
	provider = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(12).startPosition(6,12).index(0).isProtected(true).build());
	pp_letter=					Desktop.describe(Window.class, new WindowDescription.Builder()
								.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
								.length(1).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(16).setColumn(30)).build());
	//shalu
	interest=Desktop.describe(Window.class, new WindowDescription.Builder()
			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
			.length(10).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(12).setColumn(21)).build());
	chk_Returned=Desktop.describe(Window.class, new WindowDescription.Builder()
			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
			.label("UNI").inputFieldCount(6).build()).describe(Field.class, new FieldDescription.Builder()
			.length(1).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(8).setColumn(71)).build());
	fin_id=Desktop.describe(Window.class, new WindowDescription.Builder()
			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
			.length(5).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(13).setColumn(12)).build());
		original_audit_number= Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(22).setColumn(69)).build());
legal_id=Desktop.describe(Window.class, new WindowDescription.Builder()
			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
			.length(5).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(14).setColumn(12)).build());
	
	msg = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(79).startPosition(23,2).index(0).build());
	
	dtl_lin1 = Desktop.describe(Window.class, new WindowDescription.Builder()
			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(1).startPosition(18,2).build());
	dtl_lin2 = Desktop.describe(Window.class, new WindowDescription.Builder()
			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
					.attachedText("2(protected)").isProtected(true).index(4).build());
	
	org=Desktop.describe(Window.class, new WindowDescription.Builder()
			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
			.length(3).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(28)).build());
	
	claim_msg=	Desktop.describe(Window.class, new WindowDescription.Builder()
			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
			.length(79).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(23).setColumn(2)).build());
	
	calc_date=Desktop.describe(Window.class, new WindowDescription.Builder()
			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
			.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(14).setColumn(46)).build());
	
	pcp=Desktop.describe(Window.class, new WindowDescription.Builder()
			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
			.length(12).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(18).setColumn(25)).build());
	claim_Type=Desktop.describe(Window.class, new WindowDescription.Builder()
			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
			.length(10).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(46)).build());
	outofarea=Desktop.describe(Window.class, new WindowDescription.Builder()
			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
			.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(11).setColumn(71)).build());
	}
	
	public void CL202_Inquire(String phys_aud, String c_div) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary fl_inq = new FunctionLibrary();
		fl_inq.InquireClaim(phys_aud,  c_div, "CL202", "AUDIT",8,4,13,2,4,24);
	}
	public String par_status_val() throws IOException, GeneralLeanFtException
	{
		String par_stat = null;
		FunctionLibrary fl_par_status = new FunctionLibrary();
		par_stat = fl_par_status.getClaimValue("CL202",par_status,0,0);
		return par_stat;
	}
	
	public String claim_status_val() throws IOException, GeneralLeanFtException
	{
		String claim_stat = null;
		FunctionLibrary fl_par_status = new FunctionLibrary();
		claim_stat = fl_par_status.getClaimValue("CL202",claim_Status,80,108);
		return claim_stat;
	}
	public String original_audit_val() throws IOException, GeneralLeanFtException
	{
		String claim_stat = null;
		FunctionLibrary fl_par_status = new FunctionLibrary();
		claim_stat = fl_par_status.getClaimValue("CL202",original_audit_number,0,0);
		return claim_stat;
	}
	
	public String interest_val() throws IOException, GeneralLeanFtException
	{
		String in = null;
		FunctionLibrary fl_par_status = new FunctionLibrary();
		in = fl_par_status.getClaimValue("CL202",interest,0,0);
		return in;
	}
	public String zip_Code() throws IOException, GeneralLeanFtException
	{
		String zip_cod = null;
		FunctionLibrary fl_par_status = new FunctionLibrary();
		zip_cod = fl_par_status.getClaimValue("CL202",zip_code,0,0);
		return zip_cod;
	}
	
	public String Acn_Code_val() throws IOException, GeneralLeanFtException
	{
		String Acn_CODE = null;
		FunctionLibrary fl_par_status = new FunctionLibrary();
		Acn_CODE = fl_par_status.getClaimValue("CL202",Acn_Code,0,0);
		return Acn_CODE;
	}
	public String date_posted_val() throws IOException, GeneralLeanFtException
	{
		String posted_date = null;
		FunctionLibrary fl_date_posted = new FunctionLibrary();
		posted_date = fl_date_posted.getClaimValue("CL202",date_posted,0,0);
		return posted_date;
	}
	public String rec_flag_val() throws IOException, GeneralLeanFtException
	{
		String rec_flag = null;
		FunctionLibrary fl_rec_flag_val = new FunctionLibrary();
		rec_flag = fl_rec_flag_val.getClaimValue("CL202",recovery_flag,0,0);
		return rec_flag;
	}
	public String risk_type_val() throws IOException, GeneralLeanFtException
	{
		String risk = null;
		FunctionLibrary fl_risk_type = new FunctionLibrary();
		risk = fl_risk_type.getClaimValue("CL202",risk_type,0,0);
		return risk;
	}
	public String prov_panel_val() throws IOException, GeneralLeanFtException
	{
		String panel = null;
		FunctionLibrary fl_panel_val = new FunctionLibrary();
		panel = fl_panel_val.getClaimValue("CL202",prov_panel,0,0);
		return panel;
	}
	public void CL202_Inquire(String Audit_number) throws GeneralLeanFtException, InterruptedException, IOException
	{
	FunctionLibrary fl_inq = new FunctionLibrary();
	fl_inq.InquireCode(Audit_number, "CL202", 8,4,13);
	}
	//shalu
	public String prov_type_val_new() throws IOException, GeneralLeanFtException
	{
		String provtype = null;
		FunctionLibrary fl_prov = new FunctionLibrary();
		provtype = fl_prov.getClaimValue("CL202",provider,0,0);
		return provtype;
	}
	//shalu
	public String get_pp_letter() throws IOException, GeneralLeanFtException
	{
		String provtype = null;
		FunctionLibrary fl_prov = new FunctionLibrary();
		provtype = fl_prov.getClaimValue("CL202",pp_letter,0,0);
		return provtype;
	}
	//Shivi
//shalu
	public String get_interest() throws IOException, GeneralLeanFtException
	{
		String Interest = null;
		FunctionLibrary fl_prov = new FunctionLibrary();
		Interest = fl_prov.getClaimValue("CL202",interest,0,0);
		return Interest;
	}
	
	public String get_chk_Returned_value() throws IOException, GeneralLeanFtException
	{
		String CHK_Returned = null;
		FunctionLibrary fl_prov = new FunctionLibrary();
		CHK_Returned = fl_prov.getClaimValue("CL202",chk_Returned,0,0);
		return CHK_Returned;
	}
	
	public String get_fin_id_value() throws IOException, GeneralLeanFtException
	{
		
		FunctionLibrary fl_prov = new FunctionLibrary();
		Fin_id = fl_prov.getClaimValue("CL202",fin_id,0,0);
		return Fin_id;
	}
	
	public String get_legal_id_value() throws IOException, GeneralLeanFtException
	{
	
		FunctionLibrary fl_prov = new FunctionLibrary();
		Legal_id = fl_prov.getClaimValue("CL202",legal_id,0,0);
		return Legal_id;
	}
	public String claim_type_val() throws IOException, GeneralLeanFtException
	{
		String claim_val = null;
		FunctionLibrary fl_claim = new FunctionLibrary();
		claim_val= fl_claim.getClaimValue("CL202",claim_Type,0,0);
		return claim_val;
	}
	public String outofarea_val() throws IOException, GeneralLeanFtException
	{
		String areaval = null;
		FunctionLibrary fl_area = new FunctionLibrary();
		areaval = fl_area.getClaimValue("CL202",outofarea,0,0);
		return areaval;
	}
	
	public String claim_msg_val() throws IOException, GeneralLeanFtException
	{
		String phy_clm_msg = null;
		String msg_stat = null;
		FunctionLibrary fl_claim_msg_val = new FunctionLibrary();
		phy_clm_msg = fl_claim_msg_val.getClaimValue("CL202",msg,0,0);
		if (phy_clm_msg.length()<20)
		{
			 msg_stat = phy_clm_msg.substring(0, 11);
		}
		else
		{	
			 msg_stat = phy_clm_msg.substring(0, 21);
		}	
		return msg_stat;
	}
	
	public String dtl_lin2_val() throws IOException, GeneralLeanFtException
	{
		String phy_dtl_lin2 = null;
		FunctionLibrary fl_dtl_lin2 = new FunctionLibrary();
		phy_dtl_lin2 = fl_dtl_lin2.getClaimValue("CL201",dtl_lin2,0,0);
		return phy_dtl_lin2;
	}
	
	public String org_val() throws IOException, GeneralLeanFtException
	{
		String ORG = null;
		FunctionLibrary f1 = new FunctionLibrary();
		ORG = f1.getClaimValue("CL202",org,0,0);
		return ORG;
	
}
	
	public String claim_msg() throws IOException, GeneralLeanFtException
	{
		String org = null;
		FunctionLibrary f1 = new FunctionLibrary();
		org = f1.getClaimValue("CL201",claim_msg,41,67);
		return org;
	
}
	
	public String calc_date() throws IOException, GeneralLeanFtException
	{
		String org = null;
		FunctionLibrary f1 = new FunctionLibrary();
		org = f1.getClaimValue("CL202",calc_date,0,0);
		return org;
	
}
	
	public String get_pcp() throws IOException, GeneralLeanFtException
	{
		String Interest = null;
		FunctionLibrary fl_prov = new FunctionLibrary();
		Interest = fl_prov.getClaimValue("CL202",pcp,0,0);
		return Interest;
	}
}
