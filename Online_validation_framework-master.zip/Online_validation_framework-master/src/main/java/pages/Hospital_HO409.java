package pages;
//
import java.io.IOException;
import java.util.List;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class Hospital_HO409 {
	

	public Field audit,review_number,Review_Num3,User_Code3,Review_Num_One,User_Code_One,Review_Num_Two,User_Code_Two,Review_Num_Five,User_Code_Five;
	private static final Field Review_Num1 = null;
	public Hospital_HO409()
	{
		
		try {
			audit = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().attachedText("AUD").length(9).startPosition(4,6).build());
			review_number=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
					.length(7).startPosition(8,47).build());
Review_Num3= Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(7).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(7)).build());
			User_Code3= Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(9).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(15)).build());
			Review_Num_One=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(7).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(8).setColumn(7)).build());
			User_Code_One=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(9).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(8).setColumn(15)).build());
			Review_Num_Two=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(7).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(8).setColumn(47)).build());
			User_Code_Two=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(9).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(8).setColumn(55)).build());
			
			Review_Num_Five=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(7).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(10).setColumn(7)).build());
			User_Code_Five=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(9).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(10).setColumn(15)).build());
		}
		catch (GeneralLeanFtException e) {
			e.printStackTrace();
		}
	}
	
	public List review_val(String required_review) throws IOException, GeneralLeanFtException, InterruptedException
	{
		
		FunctionLibrary fl_inq1 = new FunctionLibrary();
		List claim_clear_details = fl_inq1.getReviewClearDetails("HO409",required_review,9);
		return claim_clear_details;
	}
	public void HO409_Inquire(String hos_aud, String c_div) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary fl_inq2 = new FunctionLibrary();
		fl_inq2.InquireClaim(hos_aud,  c_div, "HO409","AUD",9,4,6,0,0,0);
		
	}
	public String GetReview_Num() throws IOException, GeneralLeanFtException
	{
		String hos_GetReview_Num = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		hos_GetReview_Num = fl_chk_val.getClaimValue("HO409",Review_Num3,0,0);
		return hos_GetReview_Num;
	}
	
	public String GetUser_Code() throws IOException, GeneralLeanFtException
	{
		String hos_GetUser_Code = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		hos_GetUser_Code = fl_chk_val.getClaimValue("HO409",User_Code3,0,0);
		return hos_GetUser_Code;
	}
	
	public String GetReview_Num_One() throws IOException, GeneralLeanFtException
	{
		String hos_GetReview_Num1 = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		hos_GetReview_Num1 = fl_chk_val.getClaimValue("HO409",Review_Num_One,0,0);
		return hos_GetReview_Num1;
	}
	
	public String GetUser_Code_One() throws IOException, GeneralLeanFtException
	{
		String hos_GetUser_Code1 = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		hos_GetUser_Code1 = fl_chk_val.getClaimValue("HO409",User_Code_One,0,0);
		return hos_GetUser_Code1;
	}
	
	public String GetReview_Num_Two() throws IOException, GeneralLeanFtException
	{
		String hos_GetReview_Num_Two = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		hos_GetReview_Num_Two = fl_chk_val.getClaimValue("HO409",Review_Num_Two,0,0);
		return hos_GetReview_Num_Two;
	}
	
	public String GetUser_Code_Two() throws IOException, GeneralLeanFtException
	{
		String hos_GetUser_Code_Two = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		hos_GetUser_Code_Two = fl_chk_val.getClaimValue("HO409",User_Code_Two,0,0);
		return hos_GetUser_Code_Two;
	}
	
	public String GetReview_Num_Five() throws IOException, GeneralLeanFtException
	{
		String hos_GetReview_Num_Five = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		hos_GetReview_Num_Five = fl_chk_val.getClaimValue("HO409",Review_Num_Five,0,0);
		return hos_GetReview_Num_Five;
	}
	
	public String GetUser_Code_Five() throws IOException, GeneralLeanFtException
	{
		String hos_GetUser_Code_Five = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		hos_GetUser_Code_Five = fl_chk_val.getClaimValue("HO409",User_Code_Five,0,0);
		return hos_GetUser_Code_Five;
	}

}
