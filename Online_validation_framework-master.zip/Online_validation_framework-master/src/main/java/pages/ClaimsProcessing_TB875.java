package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class ClaimsProcessing_TB875 {
	
	public Field days,exp_mdy,bypass;
	public Screen screenname;
	
	public ClaimsProcessing_TB875(){
		try{
					screenname=Desktop.describe(Window.class, new WindowDescription.Builder()
							.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
									.label("U").build());
					days=Desktop.describe(Window.class, new WindowDescription.Builder()
							.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
									.label("U").build()).describe(Field.class, new FieldDescription.Builder()
									.length(4).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(14)).build());
					exp_mdy=Desktop.describe(Window.class, new WindowDescription.Builder()
							.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
									.label("U").build()).describe(Field.class, new FieldDescription.Builder()
									.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(6).setColumn(74)).build());
					bypass=Desktop.describe(Window.class, new WindowDescription.Builder()
							.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
									.label("U").build()).describe(Field.class, new FieldDescription.Builder()
									.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(20).setColumn(45)).build());
		
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void TB309_Inquire(String logic,String screen) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary funlib = new FunctionLibrary();
		funlib.InquireLogic(logic, "TB875");
		
	}

	public String days_val() throws IOException, GeneralLeanFtException
	{
		String phy_logic = null;
		FunctionLibrary fl_schd1_val = new FunctionLibrary();
		phy_logic = fl_schd1_val.getClaimValue("TB875",days,0,0);
		return phy_logic;
	}
	
	public String exp_mdy_val() throws IOException, GeneralLeanFtException
	{
		String phy_logic = null;
		FunctionLibrary fl_schd1_val = new FunctionLibrary();
		phy_logic = fl_schd1_val.getClaimValue("TB875",exp_mdy,0,0);
		return phy_logic;
	}
	public String bypass_val() throws IOException, GeneralLeanFtException
	{
		String phy_logic = null;
		FunctionLibrary fl_schd1_val = new FunctionLibrary();
		phy_logic = fl_schd1_val.getClaimValue("TB875",bypass,0,0);
		return phy_logic;
	}
	
}
