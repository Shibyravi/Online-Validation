package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class Member_GI301  {

public Field select,MemberId,splitindicator;
public Screen screen_GI301;

public Member_GI301() throws GeneralLeanFtException
{
		select= Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(3)).build());
		screen_GI301=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build());
		MemberId=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(18).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(12)).build());
		splitindicator=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(15).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(18).setColumn(54)).build());
}
public void member_inq(String mem_number,String screen) throws IOException, GeneralLeanFtException, InterruptedException
{
	
	FunctionLibrary fl_mem = new FunctionLibrary();
	
	fl_mem.InquireMember(mem_number,"GI301",18,5,13);
	
}
public String Indicator_val() throws IOException, GeneralLeanFtException
{
	FunctionLibrary funlib = new FunctionLibrary();
	String indicator = null;
	indicator = funlib.getClaimValue("GI301",splitindicator,0,0);
	return indicator;
}
}