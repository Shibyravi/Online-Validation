package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class Hospital_HO440 {
	public Field audit,catnbr,feeschd,calcrate,c_grp,proc_code,proc_code1,proc_code2,catnbr1,feeschd1,calcrate1,c_grp1,catnbr2,feeschd2,calcrate2,c_grp2,catnbr3,feeschd3,calcrate3,c_grp3,proc_code3,con_amt1,con_amt2,con_amt3,con_amt;
	public Screen main_screen;
	FunctionLibrary funlib;
	public Hospital_HO440() throws GeneralLeanFtException
	{
		audit = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(9).startPosition(4,6).build());
		catnbr = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(6).startPosition(10,2).build());
		feeschd = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(9).startPosition(10,15).index(0).build());
		calcrate = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(10,37).index(0).build());
		c_grp = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(4).startPosition(10,56).index(0).build());
		proc_code = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(10,25).build());
		proc_code1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(11,25).build());
		proc_code2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(12,25).build());
		catnbr1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(6).startPosition(11,2).build());
		feeschd1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(9).startPosition(11,15).index(0).build());
		calcrate1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(11,37).index(0).build());
		c_grp1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(4).startPosition(11,56).index(0).build());
		catnbr2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(12,2).build());
		feeschd2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(9).startPosition(12,15).index(0).build());
		calcrate2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(12,37).index(0).build());
		c_grp2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(4).startPosition(12,56).index(0).build());
		catnbr3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(13,2).build());
		feeschd3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(9).startPosition(13,15).index(0).build());
		calcrate3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(13,37).index(0).build());
		c_grp3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(4).startPosition(13,56).index(0).build());
		proc_code3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(13,25).build());
		main_screen = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build());
		con_amt = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(19).startPosition(10,61).index(0).build());
		con_amt1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(19).startPosition(11,61).index(0).build());
		con_amt2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(19).startPosition(12,61).index(0).build());
		con_amt3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(19).startPosition(13,61).index(0).build());
		funlib = new FunctionLibrary();
	
	}
	public void HO440_Inquire(String hos_aud, String c_div) throws GeneralLeanFtException, InterruptedException, IOException
	{
		//FunctionLibrary fl_inq2 = new FunctionLibrary();
		//fl_inq2.InquireClaim(hos_aud,  c_div, "HO440","AUD",9,4,6,0,0,0);
		funlib.InquireClaim(hos_aud,  c_div, "HO440","AUD",9,4,6,0,0,0);
		
	}
	public String catnbr_val() throws IOException, GeneralLeanFtException
	{
		String cat_num = null;
		//FunctionLibrary fl_catnbr_val = new FunctionLibrary();
		cat_num = funlib.getClaimValue("HO440",catnbr,0,0).trim();
		return cat_num;
	}
	public String conamt_val() throws IOException, GeneralLeanFtException
	{
		String amt = null;
		amt = funlib.getClaimValue("HO440",con_amt,0,0).trim();
		return amt;
	}
	public String conamt1_val() throws IOException, GeneralLeanFtException
	{
		String amt = null;
		//FunctionLibrary fl_catnbr_val = new FunctionLibrary();
		amt = funlib.getClaimValue("HO440",con_amt1,0,0).trim();
		return amt;
	}
	public String conamt2_val() throws IOException, GeneralLeanFtException
	{
		String amt = null;
		//FunctionLibrary fl_catnbr_val = new FunctionLibrary();
		amt = funlib.getClaimValue("HO440",con_amt2,0,0).trim();
		return amt;
	}
	public String conamt3_val() throws IOException, GeneralLeanFtException
	{
		String amt = null;
		//FunctionLibrary fl_catnbr_val = new FunctionLibrary();
		amt = funlib.getClaimValue("HO440",con_amt3,0,0).trim();
		return amt;
	}
	public String feeschd_val() throws IOException, GeneralLeanFtException
	{
		String fee_schd = null;
		//FunctionLibrary fl_feeschd_val = new FunctionLibrary();
		fee_schd = funlib.getClaimValue("HO440",feeschd,0,0).trim();
		return fee_schd;
	}
	public String calcrate_val() throws IOException, GeneralLeanFtException
	{
		String calc_rate = null;
		//FunctionLibrary fl_calcrate_val = new FunctionLibrary();
		calc_rate = funlib.getClaimValue("HO440",calcrate,0,0);
		return calc_rate;
	}
	public String c_grp_val() throws IOException, GeneralLeanFtException
	{
		String cgrp = null;
		//FunctionLibrary fl_c_grp_val = new FunctionLibrary();
		cgrp = funlib.getClaimValue("HO440",c_grp,0,0).trim();
		return cgrp;
	}
	public String catnbr1_val() throws IOException, GeneralLeanFtException
	{
		String cat_num = null;
		//FunctionLibrary fl_catnbr_val = new FunctionLibrary();
		cat_num = funlib.getClaimValue("HO440",catnbr1,0,0).trim();
		return cat_num;
	}
	public String feeschd1_val() throws IOException, GeneralLeanFtException
	{
		String fee_schd = null;
		//FunctionLibrary fl_feeschd_val = new FunctionLibrary();
		fee_schd = funlib.getClaimValue("HO440",feeschd1,0,0).trim();
		return fee_schd;
	}
	public String calcrate1_val() throws IOException, GeneralLeanFtException
	{
		String calc_rate = null;
		//FunctionLibrary funlib = new FunctionLibrary();
		calc_rate = funlib.getClaimValue("HO440",calcrate1,0,0);
		return calc_rate;
	}
	public String c_grp1_val() throws IOException, GeneralLeanFtException
	{
		String cgrp = null;
		//FunctionLibrary fl_c_grp_val = new FunctionLibrary();
		cgrp = funlib.getClaimValue("HO440",c_grp1,0,0).trim();
		return cgrp;
	}
	public String catnbr2_val() throws IOException, GeneralLeanFtException
	{
		String cat_num = null;
		//FunctionLibrary fl_catnbr_val = new FunctionLibrary();
		cat_num = funlib.getClaimValue("HO440",catnbr2,0,0).trim();
		return cat_num;
	}
	public String feeschd2_val() throws IOException, GeneralLeanFtException
	{
		String fee_schd = null;
		//FunctionLibrary fl_feeschd_val = new FunctionLibrary();
		fee_schd = funlib.getClaimValue("HO440",feeschd2,0,0).trim();
		return fee_schd;
	}
	public String calcrate2_val() throws IOException, GeneralLeanFtException
	{
		String calc_rate = null;
		//FunctionLibrary fl_calcrate_val = new FunctionLibrary();
		calc_rate = funlib.getClaimValue("HO440",calcrate2,0,0);
		return calc_rate;
	}
	public String c_grp2_val() throws IOException, GeneralLeanFtException
	{
		String cgrp = null;
		//FunctionLibrary fl_c_grp_val = new FunctionLibrary();
		cgrp = funlib.getClaimValue("HO440",c_grp2,0,0).trim();
		return cgrp;
	}
	public String proc_code1_val() throws IOException, GeneralLeanFtException
	{
		String cpt = null;
		//FunctionLibrary fl_c_grp_val = new FunctionLibrary();
		cpt = funlib.getClaimValue("HO440",proc_code1,0,0).trim();
		return cpt;
	}
	public String proc_code2_val() throws IOException, GeneralLeanFtException
	{
		String cpt = null;
		//FunctionLibrary fl_c_grp_val = new FunctionLibrary();
		cpt = funlib.getClaimValue("HO440",proc_code2,0,0).trim();
		return cpt;
	}
	public String proc_code_val() throws IOException, GeneralLeanFtException
	{
		String cpt = null;
		//FunctionLibrary fl_c_grp_val = new FunctionLibrary();
		cpt = funlib.getClaimValue("HO440",proc_code,0,0).trim();
		return cpt;
	}
	public String catnbr3_val() throws IOException, GeneralLeanFtException
	{
		String cat_num = null;
		//FunctionLibrary fl_catnbr_val = new FunctionLibrary();
		cat_num = funlib.getClaimValue("HO440",catnbr3,0,0).trim();
		return cat_num;
	}
	public String feeschd3_val() throws IOException, GeneralLeanFtException
	{
		String fee_schd = null;
		//FunctionLibrary fl_feeschd_val = new FunctionLibrary();
		fee_schd = funlib.getClaimValue("HO440",feeschd3,0,0).trim();
		return fee_schd;
	}
	public String calcrate3_val() throws IOException, GeneralLeanFtException
	{
		String calc_rate = null;
		//FunctionLibrary fl_calcrate_val = new FunctionLibrary();
		calc_rate = funlib.getClaimValue("HO440",calcrate3,0,0);
		return calc_rate;
	}
	public String c_grp3_val() throws IOException, GeneralLeanFtException
	{
		String cgrp = null;
		//FunctionLibrary fl_c_grp_val = new FunctionLibrary();
		cgrp = funlib.getClaimValue("HO440",c_grp3,0,0).trim();
		return cgrp;
	}
	public String proc_code3_val() throws IOException, GeneralLeanFtException
	{
		String cpt = null;
		//FunctionLibrary fl_c_grp_val = new FunctionLibrary();
		cpt = funlib.getClaimValue("HO440",proc_code3,0,0).trim();
		return cpt;
	}
	

}
