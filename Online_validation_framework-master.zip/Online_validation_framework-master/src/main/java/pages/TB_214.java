package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import stepDefinition.Medica;
import util.FunctionLibrary;

public class TB_214 {
	
	//

	public Field site,cob;
		public Screen screen;
	
	public TB_214()
	{
		try {
	   site=		Desktop.describe(Window.class, new WindowDescription.Builder()
	 			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
	 					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
	 					.length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(26)).build());
	     
	     screen= Desktop.describe(Window.class, new WindowDescription.Builder()
	 			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
	 					.label("UNI").build());
	   
	cob=Desktop.describe(Window.class, new WindowDescription.Builder()
			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
			.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(7).setColumn(75)).build());
	   
		}

	
	
		
		catch (GeneralLeanFtException e) {
			e.printStackTrace();
		}
	}
	
	
	
	public void enter_site(String Site) throws IOException, GeneralLeanFtException
	{
		
		site.setText(Site);
		screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);

	}
	
	
	
	public String get_cob() throws IOException, GeneralLeanFtException
	{
		String COB = null;
		FunctionLibrary f1 = new FunctionLibrary();
		COB = f1.getClaimValue("TB214",cob,0,0);
		return COB;
	}
}
