package pages;

import java.io.IOException;

import org.testng.Assert;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;

import util.FunctionLibrary;

import com.hp.lft.sdk.te.*;
public class ConditionCode_TB455 {
	
	public Field review_inq,allowed_days;
	public Screen main_screen;
	FunctionLibrary fl_cc_val = new FunctionLibrary();
	
	public ConditionCode_TB455(){
		try {
			review_inq = Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNITE").build()).describe(Field.class, new FieldDescription.Builder()
							.length(5).attachedText("START INQUIRY AT REVIEW CODE").startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(33)).build());
			allowed_days=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNITE").build()).describe(Field.class, new FieldDescription.Builder()
							.length(2).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(10).setColumn(15)).build()); 
			main_screen=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNITE").build());
		} catch (GeneralLeanFtException e) {
			e.printStackTrace();
		}
	}
	public String review_val() throws IOException, GeneralLeanFtException
	{
		String review_value = null;
		FunctionLibrary fl_cc_val = new FunctionLibrary();
		review_value = fl_cc_val.getClaimValue("TB455",review_inq,0,0);
		return review_value;
	}
	
	public String Allowed_days_val() throws IOException, GeneralLeanFtException
	{
		String con_Allowed_Days_val = null;
		FunctionLibrary fl_cc_val = new FunctionLibrary();
		con_Allowed_Days_val = fl_cc_val.getClaimValue("TB455", allowed_days,0,0);
		return con_Allowed_Days_val;
		

	}
	public void TB455_Inquire(String condition_code) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary fl_inq = new FunctionLibrary();
		fl_inq.InquireCode(condition_code, "TB455", 5,4,33);
	}
}
