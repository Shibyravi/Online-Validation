package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class Physician_CL360 {
	public Field select,key,status,member,type,fieldclear,
	//shalu
   statusNo,serialNo,recordNo;
	//shalu
	public static String serialNumber = null;
	
	
	public Screen Screen;
	public Physician_CL360()
	{
		try {
			select=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(3)).build());
			key=Desktop.describe(Window.class, new WindowDescription.Builder()
							.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
									.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
									.length(16).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(14)).build());
		   status=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(2).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(10).setColumn(9)).build());
		 member=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(18).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(22)).build());
		   Screen=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build());
		   type=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(35)).build());
		 fieldclear= Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
					.length(77).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(8).setColumn(4)).build());
		 
		 //shalu
		 statusNo=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(2).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(10).setColumn(12)).build());
		 
		 serialNo=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
					.length(19).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(9).setColumn(2)).build());
		 
		 recordNo=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(2).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(24).setColumn(16)).build());
		 
		}
		
		
		catch (GeneralLeanFtException e) {
			e.printStackTrace();
		}
}
	public void CL360_Inquire(String key1,String Div,String screen) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary funlib = new FunctionLibrary();
		funlib.InquireKey(key1,Div,"CL360");
		
	}
	
	public String getKey_num() throws IOException, GeneralLeanFtException
	{
		String phy_key_Number = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_key_Number = fl_chk_val.getClaimValue("CL360",key,0,0);
		return phy_key_Number;
	}
	
	public String getStatus() throws IOException, GeneralLeanFtException
	{
		String phy_status = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_status = fl_chk_val.getClaimValue("CL360",status,0,0);
		return phy_status;
	}
	
	public String getfieldclear() throws IOException, GeneralLeanFtException
	{
		String phy_clear = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_clear = fl_chk_val.getClaimValue("CL360",fieldclear,0,0);
		return phy_clear;
	}
	
	public String getType() throws IOException, GeneralLeanFtException
	{
		String phy_type = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_type = fl_chk_val.getClaimValue("CL360",type,0,0);
		return phy_type;
	}
	
	public String getdependentCode() throws IOException, GeneralLeanFtException
	{
		String phy_dependent_code = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_dependent_code = fl_chk_val.getClaimValue("CL360",member,0,0);
		String dep_code=phy_dependent_code.substring(16,18);
		return dep_code;
	}
	
	public void enter_Select(String UFI) throws IOException, GeneralLeanFtException
	{
		select.setText(UFI);
		Screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);	

	}
	
	public void enter_Key(String Key) throws IOException, GeneralLeanFtException
	{
		key.setText(Key);
		Screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);	

	}
	
	//shalu
	public String getStatusNo() throws IOException, GeneralLeanFtException
	{
		String phy_status = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_status = fl_chk_val.getClaimValue("CL360",statusNo,0,0);
		return phy_status;
	}
	
	public String getSerialNo() throws IOException, GeneralLeanFtException
	{
		String str[]=null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		serialNumber = fl_chk_val.getClaimValue("CL360",serialNo,0,0);
		str= serialNumber.split("\\.");
		serialNumber=str[0];
		return serialNumber;
	}
	
	public void enter_RecordNo() throws IOException, GeneralLeanFtException
	{
		recordNo.setText(serialNumber);
		Screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);	

	}
}
