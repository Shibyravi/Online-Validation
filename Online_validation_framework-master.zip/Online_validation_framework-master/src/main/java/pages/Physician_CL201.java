
package pages;

import java.io.IOException;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import util.FunctionLibrary;

public class Physician_CL201 {
///updated	
//
	
	public Field Dlm_Flag,member,phy_aud,phy_subaud,chk,svc1,svc2,schd1,schd2,msg,claimed1,claimed2,disallow1,disallow2,ded1,ded2,pos,proc_code1_mod1,proc_code1_mod2,proc_code1_mod3,proc_code1_mod4,proc_code2_mod1,proc_code2_mod2,proc_code2_mod3,proc_code2_mod4,closed_claim,
	TOTAL_CLAIMED,TOTAL_ALLOWED,ERC_FLAG,org,CHK,claim_msg,paid,contractNo,source;
	public Field provider,page,header_deny_code,proc_code1,proc_code2,rsn1,rsn2,to_dos1,to_dos2,fr_dos1,fr_dos2,copay1,copay2,disc1,disc2,allowed1,allowed2,newProc_code2,newProc_code1,fromdate,percent,contract,invalid_audit_error;
	public Field tot_billed,tot_allowed,from,thru,paid_date,RSN_CODE,pos2,tot_disallow,tot_copay,notification_number,adj_msg,lim_svc1,dtl_lin1,dtl_lin2,rcvd_date,Diag1,bpl,clm_status,lim_svc2,Fee_max,LValue,pcnt,last_record,unit,feemax1,feemax2,review_code,ref_prov	;
	public Screen cur_screen,phy_screen,main_screen;
	
	public Physician_CL201()
	{
		try {
			cur_screen=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build());
			clm_status = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(3).startPosition(4,29).build());
			rcvd_date = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(4,40).index(1).build());
			from =  Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(4,59).index(1).build());
			thru =  Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(5,59).index(1).build());
			phy_aud = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().attachedText("AUDIT").length(8).startPosition(4,13).build());
			member = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(18).startPosition(5,12).build());
			provider = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(12).startPosition(6,12).index(0).isProtected(true).build());
			phy_subaud = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(2).startPosition(4,24).build());
			header_deny_code = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(5).startPosition(7,77).index(0).build());
			chk = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(8).startPosition(7,49).index(1).build());
			proc_code1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(15).startPosition(12,19).index(0).build());
			proc_code2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(15).startPosition(14,19).index(0).build());
			proc_code1_mod1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(15).startPosition(12,19).index(0).build());
			proc_code2_mod1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(15).startPosition(14,19).index(0).build());
			proc_code1_mod2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(15).startPosition(12,19).index(0).build());
			proc_code2_mod2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(15).startPosition(14,19).index(0).build());
			proc_code1_mod3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(15).startPosition(12,19).index(0).build());
			proc_code2_mod3 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(15).startPosition(14,19).index(0).build());
			proc_code1_mod4 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(15).startPosition(12,19).index(0).build());
			proc_code2_mod4 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(15).startPosition(14,19).index(0).build());
			rsn1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(40).startPosition(18,31).build());
			rsn2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(40).startPosition(19,31).build());
			svc1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(13,20).index(0).build());
			svc2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(15,20).index(0).build());
			schd1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(4).startPosition(13,32).index(0).build());
			schd2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(4).startPosition(15,32).index(0).build());
			msg = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(79).startPosition(23,2).index(0).build());
			to_dos1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(13,9).index(0).build());
			to_dos2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(15,9).index(0).build());
			fr_dos1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(18,4).index(0).build());
			fr_dos2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(6).startPosition(19,4).index(0).build());
			claimed1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(9).startPosition(18,11).index(0).build());
			claimed2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(9).startPosition(19,11).index(0).build());
			disallow1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(9).startPosition(18,21).index(0).build());
			disallow2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(9).startPosition(19,21).index(0).build());
			copay1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(40).startPosition(18,31).build());
			copay2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(40).startPosition(19,31).build());
			ded1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(40).startPosition(18,31).build());
			ded2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(40).startPosition(19,31).build());
			disc1 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(40).startPosition(18,31).build());
			disc2 = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(40).startPosition(19,31).build());
			pos = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(2).startPosition(12,78).build());
			pos2 =Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(2).startPosition(14,78).build());
			allowed1=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(9).startPosition(18,72).build());
			allowed2=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(9).startPosition(19,72).build());
			tot_disallow=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(13).startPosition(20,21).index(0).build());
			tot_copay = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(46).startPosition(20,35).build());
notification_number=Desktop.describe(Window.class, new WindowDescription.Builder()
							.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(11).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(7).setColumn(31)).build());
					
			 adj_msg=Desktop.describe(Window.class, new WindowDescription.Builder()
						.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(3).startPosition(4,29).build());
			tot_allowed =Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(46).startPosition(20,35).build());			
			pcnt =Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(13).setColumn(44)).build());
			
			phy_screen=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build());
			paid_date= Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(6).setColumn(59)).build());
			lim_svc1= Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(3).startPosition(13,53).build());
			lim_svc2= Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(3).startPosition(14,53).build());
			tot_billed=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(11).startPosition(20,9).build());
			tot_allowed=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(46).startPosition(20,35).build());
			dtl_lin1 = Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(1).startPosition(18,2).build());
			dtl_lin2 = Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(1).startPosition(19,2).build());
							
			closed_claim= Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(79).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(23).setColumn(2)).build());
			
			tot_disallow=Desktop.describe(Window.class, new WindowDescription.Builder()
										.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
										.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(13).startPosition(20,21).index(0).build());
										
								//total copay
								 tot_copay = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
										.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(46).startPosition(20,35).build());
								 
								 adj_msg=Desktop.describe(Window.class, new WindowDescription.Builder()
											.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
													.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(3).startPosition(4,29).build());
								tot_allowed =Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
									.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(46).startPosition(20,35).build());			
						
								
								main_screen=Desktop.describe(Window.class, new WindowDescription.Builder()
										.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
												.label("UNI").build());
								lim_svc1= Desktop.describe(Window.class, new WindowDescription.Builder()
										.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
												.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(3).startPosition(13,53).build());
					
			
			Diag1=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				    .label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(7).startPosition(9,13).build());
		RSN_CODE=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(40).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(18).setColumn(31)).build());


		Fee_max=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(11).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(12).setColumn(51)).build());
		LValue=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(1).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(12).setColumn(63)).build());
		unit=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(12).setColumn(47)).build());
		feemax1=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
					.length(11).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(12).setColumn(51)).build());

	newProc_code2=	Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(15).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(14).setColumn(19)).build());
	
	newProc_code1=Desktop.describe(Window.class, new WindowDescription.Builder()
			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
			.length(15).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(12).setColumn(19)).build());
	
feemax2=	Desktop.describe(Window.class, new WindowDescription.Builder()
			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
			.length(11).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(14).setColumn(51)).build());
page= Desktop.describe(Window.class, new WindowDescription.Builder()
		.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
		.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
		.length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(29)).build());


fromdate=Desktop.describe(Window.class, new WindowDescription.Builder()
		.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
		.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
		.length(6).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(59)).build());

percent=Desktop.describe(Window.class, new WindowDescription.Builder()
		.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
		.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
		.length(5).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(13).setColumn(42)).build());
review_code=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(7).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(24).setColumn(67)).build());
source= Desktop.describe(Window.class, new WindowDescription.Builder()
		.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
		        .label("UNI").build()).describe(Field.class, new FieldDescription.Builder().length(3).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(5).setColumn(78)).build());
 //shalu
		org=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(3).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(4).setColumn(29)).build());
contract=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(12).setColumn(72)).build());		
	TOTAL_CLAIMED=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(11).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(20).setColumn(9)).build());
		Dlm_Flag=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(2).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(22).setColumn(72)).build());
				ERC_FLAG=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(2).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(22).setColumn(79)).build());
		CHK=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(8).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(7).setColumn(49)).build());
		
	claim_msg=	Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.length(79).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(23).setColumn(2)).build());
	
	
	paid=Desktop.describe(Window.class, new WindowDescription.Builder()
			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
			.length(6).isProtected(true).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(6).setColumn(59)).build());
	
	contractNo=Desktop.describe(Window.class, new WindowDescription.Builder()
			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
			.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(12).setColumn(72)).build());

//Shivi for Anesthesia

			//Shivi for Anesthesia

			invalid_audit_error=Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
									.length(79).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(23).setColumn(2)).build());


	ref_prov=Desktop.describe(Window.class, new WindowDescription.Builder()
			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
			.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
			.length(12).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(7).setColumn(11)).build());
		//}
		
		}
		
		catch (GeneralLeanFtException e) {
			e.printStackTrace();
		}
	}
	
	//////////Methods for validating each of the field value in CL201//////////////
	
	public String ERC_FLAG_val() throws IOException, GeneralLeanFtException
	{
		String phy_ERC_FLAG = null;
		FunctionLibrary fl_tot_allowed = new FunctionLibrary();
		phy_ERC_FLAG = fl_tot_allowed.getClaimValue("CL201",ERC_FLAG,0,0);
		return phy_ERC_FLAG;
	}
	public String tot_allowed_val() throws IOException, GeneralLeanFtException
	{
		String phy_tot_allowed = null;
		FunctionLibrary fl_tot_allowed = new FunctionLibrary();
		phy_tot_allowed = fl_tot_allowed.getClaimValue("CL201",tot_allowed,38,45).trim();
		return phy_tot_allowed;
	}
	
	public String DLM_FLAG_val() throws IOException, GeneralLeanFtException
	{
		String phy_DLM_FLAG = null;
		FunctionLibrary fl_tot_allowed = new FunctionLibrary();
		phy_DLM_FLAG = fl_tot_allowed.getClaimValue("CL201",Dlm_Flag,0,0);
		return phy_DLM_FLAG;
	}
	public String tot_claimed_val() throws IOException, GeneralLeanFtException
	{
		String phy_tot_claimed = null;
		FunctionLibrary fl_tot_allowed = new FunctionLibrary();
		phy_tot_claimed = fl_tot_allowed.getClaimValue("CL201",TOTAL_CLAIMED,74,80);
		return phy_tot_claimed;
	}
	public String closed_claim_val() throws IOException, GeneralLeanFtException
	{
		String closed = null;
		FunctionLibrary fl_tot_allowed = new FunctionLibrary();
		closed = fl_tot_allowed.getClaimValue("CL201",closed_claim,38,72).trim();
		return closed;
	}
	public String phy_aud_val() throws IOException, GeneralLeanFtException
	{
		String phy_aud_num = null;
		FunctionLibrary fl_aud_val = new FunctionLibrary();
		phy_aud_num = fl_aud_val.getClaimValue("CL201",phy_aud,0,0);
		return phy_aud_num;
    }
public String fee_max_val() throws IOException, GeneralLeanFtException
{
	String phy_fee_max= null;
	FunctionLibrary fl_tot_allowed = new FunctionLibrary();
	phy_fee_max = fl_tot_allowed.getClaimValue("CL201",Fee_max,0,0);
	return phy_fee_max;
	}
	
	public String dtl_lin1_val() throws IOException, GeneralLeanFtException
	{
		String phy_dtl_lin1 = null;
		FunctionLibrary fl_dtl_lin1 = new FunctionLibrary();
		phy_dtl_lin1 = fl_dtl_lin1.getClaimValue("CL201",dtl_lin1,0,0);
		return phy_dtl_lin1;
	}
	
	public String pcnt_val() throws IOException, GeneralLeanFtException
	{
		String pcnt_value = null;
		FunctionLibrary fl_pcn = new FunctionLibrary();
		pcnt_value = fl_pcn.getClaimValue("CL201",pcnt,0,0);
		return pcnt_value;
	}
	public String paid_date_val() throws IOException, GeneralLeanFtException
	{
		String pd = null;
		FunctionLibrary fl_dtl_lin1 = new FunctionLibrary();
		pd = fl_dtl_lin1.getClaimValue("CL201",paid_date,0,0);
		return pd;
	}
	public String clm_sts_Val() throws IOException, GeneralLeanFtException
	{
		String phy_dtl_lin1 = null;
		FunctionLibrary fl_dtl_lin1 = new FunctionLibrary();
		phy_dtl_lin1 = fl_dtl_lin1.getClaimValue("CL201",clm_status,0,0);
		return phy_dtl_lin1;
	}
	
	public String unit_Val() throws IOException, GeneralLeanFtException
	{
		String uni = null;
		FunctionLibrary fl_dtl_lin1 = new FunctionLibrary();
		uni = fl_dtl_lin1.getClaimValue("CL201",unit,0,0);
		return uni;
	}
	public String source_Val() throws IOException, GeneralLeanFtException
	{
		String uni = null;
		FunctionLibrary fl_dtl_lin1 = new FunctionLibrary();
		uni = fl_dtl_lin1.getClaimValue("CL201",source,0,0);
		return uni;
	}
	public String l_Val() throws IOException, GeneralLeanFtException
	{
		String l_value = null;
		FunctionLibrary fl_dtl_lin1 = new FunctionLibrary();
		l_value = fl_dtl_lin1.getClaimValue("CL201",LValue,0,0);
		return l_value;
	}
	public String dtl_lin2_val() throws IOException, GeneralLeanFtException
	{
		String phy_dtl_lin2 = null;
		FunctionLibrary fl_dtl_lin2 = new FunctionLibrary();
		phy_dtl_lin2 = fl_dtl_lin2.getClaimValue("CL201",dtl_lin2,0,0);
		return phy_dtl_lin2;
	}
	
public String lim_svc1_val() throws IOException, GeneralLeanFtException
	{
		String phy_lim_svc1 = null;
		FunctionLibrary fl_lim_svc1 = new FunctionLibrary();
		phy_lim_svc1 = fl_lim_svc1.getClaimValue("CL201",lim_svc1,0,0);
		return phy_lim_svc1;
	}
	
	public String lim_svc2_val() throws IOException, GeneralLeanFtException
	{
		String phy_lim_svc2 = null;
		FunctionLibrary fl_lim_svc2 = new FunctionLibrary();
		phy_lim_svc2 = fl_lim_svc2.getClaimValue("CL201",lim_svc2,0,0);
		return phy_lim_svc2;
	}
	public String pos_val() throws IOException, GeneralLeanFtException
	{
		String phy_pos = null;
		FunctionLibrary fl_pos = new FunctionLibrary();
		phy_pos = fl_pos.getClaimValue("CL201",pos,0,0);
		return phy_pos;
	}
		public String rsn_code() throws IOException, GeneralLeanFtException
	{
		String phy_rsncode = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_rsncode = fl_chk_val.getClaimValue("CL201",RSN_CODE,0,0);
		return phy_rsncode;
	}
	
	public String pos2_val() throws IOException, GeneralLeanFtException
	{
		String phy_pos = null;
		FunctionLibrary fl_pos = new FunctionLibrary();
		phy_pos = fl_pos.getClaimValue("CL201",pos2,0,0);
		return phy_pos;
	}
	public String chk_val() throws IOException, GeneralLeanFtException
	{
		String phy_chk = null;
		FunctionLibrary fl_chk_val = new FunctionLibrary();
		phy_chk = fl_chk_val.getClaimValue("CL201",chk,0,0);
		return phy_chk;
	}
	public String svc1_val() throws IOException, GeneralLeanFtException
	{
		String phy_svc1 = null;
		FunctionLibrary fl_svc1_val = new FunctionLibrary();
		phy_svc1 = fl_svc1_val.getClaimValue("CL201",svc1,0,0);
		return phy_svc1;
	}
	public String claim_msg_val() throws IOException, GeneralLeanFtException
	{
		String phy_clm_msg = null;
		String msg_stat = null;
		FunctionLibrary fl_claim_msg_val = new FunctionLibrary();
		phy_clm_msg = fl_claim_msg_val.getClaimValue("CL201",msg,0,0);
		if (phy_clm_msg.length()<20)
		{
			 msg_stat = phy_clm_msg.substring(0, 11);
		}
		else
		{	
			 msg_stat = phy_clm_msg.substring(0, 21);
		}	
		return msg_stat;
	}
	public String svc2_val() throws IOException, GeneralLeanFtException
	{
		String phy_svc2 = null;
		FunctionLibrary fl_svc2_val = new FunctionLibrary();
		phy_svc2 = fl_svc2_val.getClaimValue("CL201",svc2,0,0);
		
		return phy_svc2;
	}
	public String schd1_val() throws IOException, GeneralLeanFtException
	{
		String phy_schd1 = null;
		FunctionLibrary fl_schd1_val = new FunctionLibrary();
		phy_schd1 = fl_schd1_val.getClaimValue("CL201",schd1,0,0);
		return phy_schd1;
	}
	public String schd2_val() throws IOException, GeneralLeanFtException
	{
		String phy_schd2 = null;
		FunctionLibrary fl_svc2_val = new FunctionLibrary();
		phy_schd2 = fl_svc2_val.getClaimValue("CL201",svc2,0,0);
		return phy_schd2;
	}
	public String claimed1_val() throws IOException, GeneralLeanFtException
	{
		String phy_claimed1 = null;
		FunctionLibrary fl_claimed1_val = new FunctionLibrary();
		phy_claimed1 = fl_claimed1_val.getClaimValue("CL201",claimed1,0,0);
		return phy_claimed1;
	}
	public String claimed2_val() throws IOException, GeneralLeanFtException
	{
		String phy_claimed2_val = null;
		FunctionLibrary fl_claimed2_val = new FunctionLibrary();
		phy_claimed2_val = fl_claimed2_val.getClaimValue("CL201",claimed2,0,0);
		return phy_claimed2_val;
	}
	public String adj_msg_Val() throws IOException, GeneralLeanFtException
	{
			String phy_adj_msg = null;
			FunctionLibrary fl_adj_msg = new FunctionLibrary();
			phy_adj_msg = fl_adj_msg.getClaimValue("CL201",adj_msg,0,0);
			return phy_adj_msg;
			
	}
	public String disallow1_val() throws IOException, GeneralLeanFtException
	{
		String phy_disallow1 = null;
		FunctionLibrary fl_disallow1_val = new FunctionLibrary();
		phy_disallow1 = fl_disallow1_val.getClaimValue("CL201",disallow1,0,0);
		return phy_disallow1;
	}
	public String disallow2_val() throws IOException, GeneralLeanFtException
	{
		String phy_disallow2_val = null;
		FunctionLibrary fl_disallow2_val = new FunctionLibrary();
		phy_disallow2_val = fl_disallow2_val.getClaimValue("CL201",disallow2,0,0);
		return phy_disallow2_val;
	}
	
	public String page_val() throws IOException, GeneralLeanFtException
	{
		String pg = null;
		FunctionLibrary fl_disallow2_val = new FunctionLibrary();
		pg = fl_disallow2_val.getClaimValue("CL201",page,0,0);
		return pg;
	}
	
	public String to_dos1_val() throws IOException, GeneralLeanFtException
	{
		String phy_to_dos1 = null;
		FunctionLibrary fl_to_dos1_val = new FunctionLibrary();
		phy_to_dos1 = fl_to_dos1_val.getClaimValue("CL201",to_dos1,0,0);
		return phy_to_dos1;
	}
	public String to_dos2_val() throws IOException, GeneralLeanFtException
	{
		String phy_to_dos2 = null;
		FunctionLibrary fl_to_dos2_val = new FunctionLibrary();
		phy_to_dos2 = fl_to_dos2_val.getClaimValue("CL201",to_dos2,0,0);
		return phy_to_dos2;
	}
	public String frm_dos1_val() throws IOException, GeneralLeanFtException
	{
		String phy_frm_dos1 = null;
		FunctionLibrary fl_frm_dos1_val = new FunctionLibrary();
		phy_frm_dos1 = fl_frm_dos1_val.getClaimValue("CL201",fr_dos1,0,0);
		return phy_frm_dos1;
	}
	public String frm_dos2_val() throws IOException, GeneralLeanFtException
	{
		String phy_frm_dos2 = null;
		FunctionLibrary fl_frm_dos2_val = new FunctionLibrary();
		phy_frm_dos2 = fl_frm_dos2_val.getClaimValue("CL201",fr_dos2,0,0);
		
		return phy_frm_dos2;
	}
	
	
	public String hdr_deny_val() throws IOException, GeneralLeanFtException
	{
		String phy_hdr_deny_code = null;
		FunctionLibrary fl_hdr_deny_val = new FunctionLibrary();
		phy_hdr_deny_code = fl_hdr_deny_val.getClaimValue("CL201",header_deny_code,0,0);
		return phy_hdr_deny_code;
	}
	
	public String proc1_val() throws IOException, GeneralLeanFtException
	{
		String cpt_code = null;
		FunctionLibrary a = new FunctionLibrary();
		cpt_code = a.getClaimValue("CL201",proc_code1,0,5);
		return cpt_code;
	}
	public String proc1_mod1_val() throws IOException, GeneralLeanFtException
	{
		String mod1 = null;
		FunctionLibrary fl_proc1_mod1_val = new FunctionLibrary();
		mod1 = fl_proc1_mod1_val.getClaimValue("CL201",proc_code1_mod1,5,7);
		if(mod1.length()>2)
		{
			mod1="No modifier";
		}
		return mod1;
	}
	
	public String proc1_mod2_val() throws IOException, GeneralLeanFtException
	{
		String mod2 = null;
		FunctionLibrary fl_proc1_mod2_val = new FunctionLibrary();
		mod2 = fl_proc1_mod2_val.getClaimValue("CL201",proc_code1_mod2,7,9);
		if(mod2.length()>2)
		{
			mod2="No modifier";
		}
		return mod2;
	}
	
	public String proc1_mod3_val() throws IOException, GeneralLeanFtException
	{
		String mod3 = null;
		FunctionLibrary fl_proc1_mod3_val = new FunctionLibrary();
		mod3 = fl_proc1_mod3_val.getClaimValue("CL201",proc_code1_mod3,11,13);
		if(mod3.length()>2)
		{
			mod3="No modifier";
		}
		return mod3;
	}
	public String proc1_mod3_val1() throws IOException, GeneralLeanFtException
	{
		String mod3 = null;
		FunctionLibrary fl_proc1_mod3_val = new FunctionLibrary();
		mod3 = fl_proc1_mod3_val.getClaimValue("CL201",proc_code1_mod3,5,7);
		if(mod3.length()>2)
		{
			mod3="No modifier";
		}
		return mod3;
	}
	public String proc1_mod4_val() throws IOException, GeneralLeanFtException
	{
		String mod4 = null;
		FunctionLibrary fl_proc1_mod4_val = new FunctionLibrary();
		mod4 = fl_proc1_mod4_val.getClaimValue("CL201",proc_code1_mod4,13,15);
		if(mod4.length()>2)
		{
			mod4="No modifier";
		}
		return mod4;
	}
	public String proc2_mod1_val() throws IOException, GeneralLeanFtException
	{
		String mod1 = null;
		FunctionLibrary fl_proc2_mod1_val = new FunctionLibrary();
		mod1 = fl_proc2_mod1_val.getClaimValue("CL201",proc_code2_mod1,5,7);
		if(mod1.length()>2)
		{
			mod1="No modifier";
		}
		return mod1;
	}
	
	public String proc2_mod2_val() throws IOException, GeneralLeanFtException
	{
		String mod2 = null;
		FunctionLibrary fl_proc2_mod2_val = new FunctionLibrary();
		mod2 = fl_proc2_mod2_val.getClaimValue("CL201",proc_code2_mod2,7,9);
		if(mod2.length()>2)
		{
			mod2="No modifier";
		}
		return mod2;
	}
	
	public String proc2_mod3_val() throws IOException, GeneralLeanFtException
	{
		String mod3 = null;
		FunctionLibrary fl_proc2_mod3_val = new FunctionLibrary();
		mod3 = fl_proc2_mod3_val.getClaimValue("CL201",proc_code2_mod3,11,13);
		if(mod3.length()>2)
		{
			mod3="No modifier";
		}
		return mod3;
	}
	public String proc2_mod4_val() throws IOException, GeneralLeanFtException
	{
		String mod4 = null;
		FunctionLibrary fl_proc2_mod4_val = new FunctionLibrary();
		mod4 = fl_proc2_mod4_val.getClaimValue("CL201",proc_code2_mod4,13,15);
if(mod4.length()>2)
		{
			mod4="No modifier";
		}
		return mod4;
	}
	public String proc2_mod4_val1() throws IOException, GeneralLeanFtException
	{
		String mod4 = null;
		FunctionLibrary fl_proc2_mod4_val = new FunctionLibrary();
		mod4 = fl_proc2_mod4_val.getClaimValue("CL201",proc_code2_mod4,5,7);
		if(mod4.length()>2)
		{
			mod4="No modifier";
		}
		return mod4;
	}
	public String proc2_val() throws IOException, GeneralLeanFtException
	{
		String cpt_code = null;
		FunctionLibrary a = new FunctionLibrary();
		cpt_code = a.getClaimValue("CL201",proc_code2,0,5);
		return cpt_code;
	}
	public void CL201_Inquire(String phys_aud, String c_div) throws GeneralLeanFtException, InterruptedException, IOException
	{
		FunctionLibrary fl_inq = new FunctionLibrary();
		fl_inq.InquireClaim(phys_aud,  c_div, "CL201", "AUDIT",8,4,13,2,4,24);
	}
	public String det1_deny_val() throws IOException, GeneralLeanFtException
	{
		String det_deny_code = null;
		FunctionLibrary fl_det_deny_code = new FunctionLibrary();
		det_deny_code = fl_det_deny_code.getClaimValue("CL201",rsn1,0,4);
		return det_deny_code;
	}
	public String det2_deny_val() throws IOException, GeneralLeanFtException
	{
		String det_deny_code = null;
		FunctionLibrary fl_det_deny_code = new FunctionLibrary();
		det_deny_code = fl_det_deny_code.getClaimValue("CL201",rsn2,0,4);
		return det_deny_code;
	}
	 
	public String mem_val() throws IOException, GeneralLeanFtException
	{
		String subscriber = null;
		FunctionLibrary fl_mem = new FunctionLibrary();
		subscriber = fl_mem.getClaimValue("CL201",member,0,0);
		return subscriber;
	}
 
	public String prov_val() throws IOException, GeneralLeanFtException
	{
		String provider = null;
		FunctionLibrary fl_prov = new FunctionLibrary();
		provider = fl_prov.getClaimValue("CL201",member,0,0);
		return provider;
	}
	public String prov_val1() throws IOException, GeneralLeanFtException
	{
		String provnum = null;
		FunctionLibrary fl_prov = new FunctionLibrary();
		provnum = fl_prov.getClaimValue("CL201",provider,0,0);
		return provnum;
	}
	public String prov_type_val() throws IOException, GeneralLeanFtException
	{
		String provtype = null;
		FunctionLibrary fl_prov = new FunctionLibrary();
		provtype = fl_prov.getClaimValue("CL201",provider,0,0);
		if (provtype.length()>=4)
		{
			provtype = provtype.substring(2, 4);
		}
		return provtype;
	}
	public String copay1_val() throws IOException, GeneralLeanFtException
	{
		String phy_copay1 = null;
		FunctionLibrary fl_copay1_val = new FunctionLibrary();
		phy_copay1 = fl_copay1_val.getClaimValue("CL201",copay1,0,4);
		return phy_copay1;
	}
	public String copay2_val() throws IOException, GeneralLeanFtException
	{
		String phy_copay2 = null;
		FunctionLibrary fl_copay2_val = new FunctionLibrary();
		phy_copay2 = fl_copay2_val.getClaimValue("CL201",copay2,0,4);
		return phy_copay2;
	}	
	public String ded1_val() throws IOException, GeneralLeanFtException
	{
		String phy_ded1 = null;
		FunctionLibrary fl_ded1_val = new FunctionLibrary();
		phy_ded1 = fl_ded1_val.getClaimValue("CL201",ded1,0,4);
		return phy_ded1;
	}
	public String ded2_val() throws IOException, GeneralLeanFtException
	{
		String phy_ded2 = null;
		FunctionLibrary fl_ded2_val = new FunctionLibrary();
		phy_ded2 = fl_ded2_val.getClaimValue("CL201",ded2,0,4);
		return phy_ded2;
	}
	public String disc1_val() throws IOException, GeneralLeanFtException
	{
		String phy_disc1 = null;
		FunctionLibrary fl_disc1_val = new FunctionLibrary();
		phy_disc1 = fl_disc1_val.getClaimValue("CL201",disc1,33,39);
		return phy_disc1;
	}
	public String disc2_val() throws IOException, GeneralLeanFtException
	{
		String phy_disc2 = null;
		FunctionLibrary fl_disc2_val = new FunctionLibrary();
		phy_disc2 = fl_disc2_val.getClaimValue("CL201",disc2,33,39);
		return phy_disc2;
	}
	public boolean msg_val() throws IOException, GeneralLeanFtException
	{
		boolean phy_msg = false;
		FunctionLibrary fl_msg_val = new FunctionLibrary();
		phy_msg = fl_msg_val.checkHistoryClaim("CL201");
		return phy_msg;
	}
	public String allowed1_val() throws IOException, GeneralLeanFtException
	{
		String phy_allowed1 = null;
		FunctionLibrary fl_claimed1_val = new FunctionLibrary();
		phy_allowed1 = fl_claimed1_val.getClaimValue("CL201",allowed1,0,0);
		return phy_allowed1;
	}
	public String allowed2_val() throws IOException, GeneralLeanFtException
	{
		String phy_allowed2 = null;
		FunctionLibrary fl_claimed2_val = new FunctionLibrary();
		phy_allowed2 = fl_claimed2_val.getClaimValue("CL201",allowed2,0,0);
		return phy_allowed2;
	}
	
public String tot_disallow_Val() throws IOException, GeneralLeanFtException
	{
		String phy_tot_disallow = null;
		FunctionLibrary fl_tot_disallow = new FunctionLibrary();
		phy_tot_disallow = fl_tot_disallow.getClaimValue("CL201",tot_disallow,0,0);
		return phy_tot_disallow;
	
	}
	
	/*public String tot_allowed_val() throws IOException, GeneralLeanFtException
	{
		String total_allowed = null;
		FunctionLibrary fl_tot_allowed_val = new FunctionLibrary();
		total_allowed = fl_tot_allowed_val.getClaimValue("CL201",tot_allowed,40,46);
		return total_allowed;
		}*/
	public String from_val() throws IOException, GeneralLeanFtException
	{
		String phy_fromDate= null;
		FunctionLibrary fl_from_val = new FunctionLibrary();
		phy_fromDate =  fl_from_val.getClaimValue("CL201",from,0,0);
		return phy_fromDate;
	}
	
	public String thru_val() throws IOException, GeneralLeanFtException
	{
		String phy_thruDate= null;
		FunctionLibrary fl_thru_val = new FunctionLibrary();
		phy_thruDate =  fl_thru_val.getClaimValue("CL201",thru,0,0);
		return phy_thruDate;
	}
	public String rcvd_date() throws GeneralLeanFtException, IOException{
		String phy_rcvd_date= null;
		FunctionLibrary fl_rcvd_date = new FunctionLibrary();
		phy_rcvd_date =  fl_rcvd_date.getClaimValue("CL201",rcvd_date,0,0);
		return phy_rcvd_date;
		
		
	}
	public String notif_num() throws IOException, GeneralLeanFtException
	{
		String phy_notification_num = null;
		FunctionLibrary fl_notif_num = new FunctionLibrary();
		phy_notification_num = fl_notif_num.getClaimValue("CL201",notification_number,0,0);
		return phy_notification_num;
	}
	public String bpl_val() throws IOException, GeneralLeanFtException
	{
		String phy_bpl = null;
		FunctionLibrary fl_bpl_val = new FunctionLibrary();
		phy_bpl = fl_bpl_val.getClaimValue("CL201",bpl,0,0);
		return phy_bpl;
	}
	public String tot_billed_val() throws IOException, GeneralLeanFtException
	{
		String total_billed = null;
		FunctionLibrary fl_tot_billed_val = new FunctionLibrary();
		total_billed = fl_tot_billed_val.getClaimValue("CL201",tot_billed,0,0);
		return total_billed;
	}
	public String tot_copay_Val() throws IOException, GeneralLeanFtException
		{
			String phy_tot_copay = null;
			FunctionLibrary fl_tot_copay = new FunctionLibrary();
			phy_tot_copay = fl_tot_copay.getClaimValue("CL201",tot_copay,3,8);
			return phy_tot_copay;
		
		}
	
	public String Diag1_val() throws IOException, GeneralLeanFtException
	{
		String phy_diag1 = null;
		FunctionLibrary fl_diag1_val = new FunctionLibrary();
		phy_diag1 = fl_diag1_val.getClaimValue("CL201",Diag1,0,0);
		return phy_diag1;
	}
	/*	public String from_val() throws IOException, GeneralLeanFtException
	{
	String phy_fromDate= null;
	FunctionLibrary fl_from_val = new FunctionLibrary();
	phy_fromDate =  fl_from_val.getClaimValue("CL201",from,0,0);
	return phy_fromDate;
	}

	public String thru_val() throws IOException, GeneralLeanFtException
	{
	String phy_thruDate= null;
	FunctionLibrary fl_thru_val = new FunctionLibrary();
	phy_thruDate =  fl_thru_val.getClaimValue("CL201",thru,0,0);
	return phy_thruDate;
	} */
	
	public String unitfee_val() throws IOException, GeneralLeanFtException
	{
		String phy_unit_fee = null;
		FunctionLibrary fl_unitfee_val = new FunctionLibrary();
		phy_unit_fee = fl_unitfee_val.getClaimValue("CL201",unit,0,0);
		return phy_unit_fee;
	}
	public String fetching_last_record() throws IOException, GeneralLeanFtException
	{
		String last_rec = null;
		FunctionLibrary fl_diag1_val = new FunctionLibrary();
		last_rec = fl_diag1_val.getClaimValue("CL201",last_record,2,12);
		return last_rec;
	
	}
	public String feemax_val_1() throws IOException, GeneralLeanFtException
	{
		String fee_max = null;
		FunctionLibrary fl_feemax = new FunctionLibrary();
		fee_max = fl_feemax.getClaimValue("CL201",feemax1,0,0);
		return fee_max;
	
}
	public String new_proc2_val() throws IOException, GeneralLeanFtException
	{
		String cpt_code = null;
		FunctionLibrary a = new FunctionLibrary();
		cpt_code = a.getClaimValue("CL201",newProc_code2,0,7);
		return cpt_code;
	}
	public String reviewUserCode() throws IOException, GeneralLeanFtException
	{
		String rev_usr_code = null;
		FunctionLibrary fl_review_val = new FunctionLibrary();
		rev_usr_code = fl_review_val.getClaimValue("CL201",review_code,0,0);
		return rev_usr_code;
		}
	
public String source_value() throws IOException, GeneralLeanFtException
	{
		String source_code = null;
		FunctionLibrary fl_source_val = new FunctionLibrary();
		source_code = fl_source_val.getClaimValue("CL201",source,78,81);
		return source_code;
	}
	public String new_proc1_val() throws IOException, GeneralLeanFtException
	{
		String cpt_code = null;
		FunctionLibrary a = new FunctionLibrary();
		cpt_code = a.getClaimValue("CL201",newProc_code1,0,7);
		return cpt_code;
	}
	
	public String feemax_val_2() throws IOException, GeneralLeanFtException
	{
		String fee_max = null;
		FunctionLibrary fl_feemax = new FunctionLibrary();
		fee_max = fl_feemax.getClaimValue("CL201",feemax2,0,0);
		return fee_max;
	
}
	public String prov_type_val_new() throws IOException, GeneralLeanFtException
	{
		String provtype = null;
		FunctionLibrary fl_prov = new FunctionLibrary();
		provtype = fl_prov.getClaimValue("CL201",provider,0,0);
		if (provtype.length()>=4)
		{
			provtype = provtype.substring(0, 4);
		}
		return provtype;
	}
	
public String fromdate_val() throws IOException, GeneralLeanFtException
	{
		String fromdat = null;
		FunctionLibrary fl_date = new FunctionLibrary();
		fromdat = fl_date.getClaimValue("CL201",fromdate,0,0);
		
		return fromdat;

	
}
	public String percent_val() throws IOException, GeneralLeanFtException
	{
		String fee_max = null;
		FunctionLibrary fl_feemax = new FunctionLibrary();
		fee_max = fl_feemax.getClaimValue("CL201",pcnt,0,0);
		return fee_max;
	
}
	public String contract_val() throws IOException, GeneralLeanFtException
	{	String cont = null;
		FunctionLibrary fl_contract = new FunctionLibrary();
		cont = fl_contract.getClaimValue("CL201",contract,0,0);
		return cont;
	
}	//shalu
	public String org_val() throws IOException, GeneralLeanFtException
	{
		String ORG = null;
		FunctionLibrary f1 = new FunctionLibrary();
		ORG = f1.getClaimValue("CL201",org,0,0);
		return ORG;
	
}
	
	public String CHK_val() throws IOException, GeneralLeanFtException
	{
		String org = null;
		FunctionLibrary f1 = new FunctionLibrary();
		org = f1.getClaimValue("CL201",CHK,0,0);
		return org;
	
}
	
	public String claim_msg() throws IOException, GeneralLeanFtException
	{
		String org = null;
		FunctionLibrary f1 = new FunctionLibrary();
		org = f1.getClaimValue("CL201",claim_msg,41,67);
		return org;
	
}
	
	public String paid_val() throws IOException, GeneralLeanFtException
	{
		String org = null;
		FunctionLibrary f1 = new FunctionLibrary();
		org = f1.getClaimValue("CL201",paid,0,0);
		return org;
	
}
	
	public String getContract_No() throws IOException, GeneralLeanFtException
	{
		String contr = null;
		FunctionLibrary f1 = new FunctionLibrary();
		contr = f1.getClaimValue("CL201",contractNo,0,0);
		return contr;
	
}
public String invalid_audit_error_val() throws IOException, GeneralLeanFtException
	{
		String invalid_audit_error1= null;
		FunctionLibrary fl_tot_allowed = new FunctionLibrary();
		invalid_audit_error1 = fl_tot_allowed.getClaimValue("CL201",invalid_audit_error,0,0).trim();
		return invalid_audit_error1;
	}

	
	public String getRefProv_No() throws IOException, GeneralLeanFtException
	{
		String contr = null;
		FunctionLibrary f1 = new FunctionLibrary();
		contr = f1.getClaimValue("CL201",ref_prov,0,0);
		return contr;
	
}
	public void press_enter() throws IOException, GeneralLeanFtException
	{
	
	    main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	}
	
}

