package util;

import java.io.IOException;

import driver.DriverScript;

public class Constants extends DriverScript {
	public static String dbuser = prop.getProperty("username");
	public static String passwd = prop.getProperty("password");
	public static String reg = prop.getProperty("Region");

	protected Constants() throws IOException {
		//super();
		// TODO Auto-generated constructor stub
	}

	
}
