
package util;

import java.awt.image.RenderedImage;
import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.imageio.ImageIO;
import org.junit.Assert;
import org.testng.AssertJUnit;

import com.hp.lft.sdk.Description;
import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.ModifiableSDKConfiguration;
import com.hp.lft.sdk.SDK;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import cucumber.api.Scenario;
import cucumber.api.java.After;
//import bsh.ParseException;
import driver.DriverScript;
import pages.AuthNotification_TB309;
import pages.CL657;
import pages.ConditionCode_TB223;
import pages.ConditionCode_TB455;
import pages.FeeMax_TB822;
import pages.Hospital_HO400;
import pages.Hospital_HO409;
import pages.Hospital_HO410;
import pages.Hospital_HO430;
import pages.LimitedService_CL147;
import pages.LimitedService_CL148;
import pages.Member_GI101;
import pages.Member_GI301;
import pages.Member_GI325;
import pages.OutPatient_AU300;
import pages.PS303;
import pages.PS308;
import pages.PS330;
import pages.PS475;
import pages.Physician_CL140;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL209;
import pages.Physician_CL215;
import pages.Physician_CL360;
import pages.Physician_CL510;
import pages.Provider_EP120;
import pages.Physician_PS340;
import pages.Physician_PS343;
import pages.Procedure_PCFM;
import pages.Provider_GI302;
import stepDefinition.AdjudiproStepDefinition;

public class FunctionLibrary {
	private static FunctionLibrary fl;
	public Field field;
	public static Screen screen;
	public static Screen login;
	public static Screen change_site;
	public static Field site;
	public static Screen phy_claim_inq,hos_claim_inq,cosmos_menu,service_detail_inq,TB470_Screen,CL657_Screen;
	public Field msg,menu,memb;
	public Field aud;
	public Field sub_aud;
	public String main_audit;
	public String sub_audit,cellvalue;
	public Field f1;
	public static Process  process;
	public static Object objScreen;
	public static String member_Inq,member_sub1,member_sub2;
	public FunctionLibrary() {
		//super();
		/*
		Runtime rt =  Runtime.getRuntime();
		try {
				Process  p = rt.exec(KILL + "pcsws.exe");
				rt.exec(KILL + "pcscm.exe");
			} catch (IOException e) {
			
				e.printStackTrace();
			}
		try {
		Thread.sleep(9000);
		String[] s = new String[] {"pcsws.exe","tn3270.WS"};
		process = rt.exec(s); 
		
			Thread.sleep(20000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

    public static FunctionLibrary getInstance(){
        if(fl == null){
            try {
				fl = new FunctionLibrary();
				//DriverScript.initialization();
			}catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        return fl;
    }
    
	public static void launchPCOMM() throws IOException, InterruptedException
	{
		//final String KILL = "taskkill /F /IM ";
/*		Runtime rt =  Runtime.getRuntime();
		try {
				Process  p = rt.exec(KILL + "pcsws.exe");
				rt.exec(KILL + "pcscm.exe");
			} catch (IOException e) {
			
				e.printStackTrace();
			}

		Thread.sleep(9000);
		String[] s = new String[] {"pcsws.exe","tn3270.WS"};
		process = rt.exec(s); 
		Thread.sleep(20000);*/
		
	}
public static void xmit() throws GeneralLeanFtException, InterruptedException{
		
		screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		Thread.sleep(1500);
		
	}
	public static void loginPCOMM(String reg,Properties prop) throws Exception
	{
		//DriverScript.getInstance();
		//Properties prop = DriverScript.prop;
		ModifiableSDKConfiguration config = new ModifiableSDKConfiguration();
		config.setServerAddress(new URI("ws://localhost:5095"));
		SDK.init(config);
		screen = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder().label("screen5288").build());
		if(!screen.exists())
		{
			Thread.sleep(1000);
		}
		Field field = screen.describe(Field.class, new FieldDescription.Builder().attachedText("field161").isProtected(false).build());
		field.setText(reg);
		screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		Thread.sleep(1500);
		login =Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder().label("Si").build());
		Field userid = login.describe(Field.class, new FieldDescription.Builder().attachedText("Userid").isProtected(false).build());
		userid.setText(prop.getProperty("username"));
		login.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		Thread.sleep(1500);
		Field passwd = login.describe(Field.class, new FieldDescription.Builder().attachedText("Password").isProtected(false).build());
		passwd.setText(prop.getProperty("password"));
		Thread.sleep(1500);
		login.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		Field kos = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("screen7198").build()).describe(Field.class, new FieldDescription.Builder()
				.attachedText("field1").isProtected(false).build());
		kos.setText("KOS");
		Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("screen7198").build()).sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		Thread.sleep(1000);
	/*	Screen sys_menu = Desktop.describe(Window.class, new WindowDescription.Builder()
    			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
    			.label("Unit").build());
		Field begin = sys_menu.describe(Field.class, new FieldDescription.Builder()
    			.attachedText("field347").isProtected(false).build());
		begin.setText("CS010");
		sys_menu.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		Thread.sleep(2000); */
	}
	
	public static void changeSite() throws GeneralLeanFtException, InterruptedException
	{
		Field present_field = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.attachedText("field3").build());
		if(present_field.exists(2))
		{
			Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
					.attachedText("field3").build()).setText("CS010");
			Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		}
		else
		{
			Thread.sleep(1000);
			FunctionLibrary.changeDiv();
		}
		
	}
	
	
	public static void changeDiv() throws GeneralLeanFtException, InterruptedException
	{
		Screen sys_menu = Desktop.describe(Window.class, new WindowDescription.Builder()
    			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
    			.label("Unit").build());
		Field begin = sys_menu.describe(Field.class, new FieldDescription.Builder()
    			.attachedText("field347").isProtected(false).build());
		begin.setText("CS010");
		sys_menu.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		Thread.sleep(500);
		change_site = Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("Unite").build());
		site = change_site .describe(Field.class, new FieldDescription.Builder()
				.attachedText("New Site").isProtected(false).build());
	}
	
	public static void navigateToDiv(String screenname) throws GeneralLeanFtException, InterruptedException
	{
		
		Field cur_field = Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
				.attachedText("field3").isProtected(false).build());
		
		if(cur_field.exists(2))
		{
			String cur_screen_name = Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
					.attachedText("field3").isProtected(false).build()).getText();
			Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
					.attachedText("field3").isProtected(false).build()).setText(screenname);
			if(!cur_screen_name.equalsIgnoreCase(screenname))
			{
				Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			}
		}
		else if(Desktop.describe(Window.class, new WindowDescription.Builder() 
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder() 
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder() 
						.attachedText("field4").build()).exists(2))
		{
			Desktop.describe(Window.class, new WindowDescription.Builder() 
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder() 
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder() 
					.attachedText("field4").build()).setText(screenname); 
			Desktop.describe(Window.class, new WindowDescription.Builder() 
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder() 
					.label("UNI").build()).sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER); 
		}
		else if(Desktop.describe(Window.class, new WindowDescription.Builder() .shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder() 
				.label("UNITE").build()).describe(Field.class, new FieldDescription.Builder() .attachedText("field3").isProtected(false).build()).exists(3))
		{ 
			Desktop.describe(Window.class, new WindowDescription.Builder() .shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder() 
			.label("UNITE").build()).describe(Field.class, new FieldDescription.Builder() .attachedText("field3").isProtected(false).build()).setText(screenname);
			Desktop.describe(Window.class, new WindowDescription.Builder() .shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder() 
				.label("UNITE").build()).sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER); 
		} 
	
	}
	public static Physician_CL209 getObject1(){
		Physician_CL209 p = new Physician_CL209();
		return p;
		
	}
	public static Hospital_HO409 getObject3(){
		Hospital_HO409 p = new Hospital_HO409();
		return p;
	}
	public static Hospital_HO400 getObject4(){
		Hospital_HO400 p=null;
		try {
			
			p = new Hospital_HO400();
		} catch (GeneralLeanFtException e) {
			e.printStackTrace();
		}
		return p;
	}
	public static Hospital_HO410 getObjec5(){
		
		Hospital_HO410 p = new Hospital_HO410();
		return p;
	}	
public static Hospital_HO430 getObjec6(){
		
	Hospital_HO430 p = new Hospital_HO430();
		return p;
	}
	public static Physician_CL201 getObject(){
		Physician_CL201 p = new Physician_CL201();
		return p;
		
	}
	public static Physician_CL140 getObject7(){
		Physician_CL140 p = new Physician_CL140();
		return p;
	}
	public static Provider_EP120 getObjectP() throws GeneralLeanFtException{
		Provider_EP120 pE120 = new Provider_EP120();
		return pE120;
		
	}
	
	public static Member_GI101 getObject12() throws GeneralLeanFtException{
		Member_GI101 pr = new Member_GI101();
		return pr;
		
	}
	public static PS308 getObjectPS308() throws GeneralLeanFtException{
		PS308 pr = new PS308();
		return pr;
		
	}
	public static Physician_CL202 getObject2() throws GeneralLeanFtException{
		Physician_CL202 p = new Physician_CL202();
		return p;
		
	}
	public static OutPatient_AU300 getObject8() throws GeneralLeanFtException{
		OutPatient_AU300 out= new OutPatient_AU300();
		return out;
				
	}
	public static Physician_CL215 getObject215() throws GeneralLeanFtException{
		Physician_CL215 p = new Physician_CL215();
		return p;	}
public static LimitedService_CL147 getObject9() throws GeneralLeanFtException{
		LimitedService_CL147 lsvc= new LimitedService_CL147();
		return lsvc;
}
	public static LimitedService_CL148 getObject10() throws GeneralLeanFtException{
		LimitedService_CL148 ls1= new LimitedService_CL148();
		return ls1;
				
	}
		public static Member_GI325 getObject11() throws GeneralLeanFtException{
		Member_GI325 lmt_svc2= new Member_GI325();
		return lmt_svc2;
				
	}
		public static Physician_CL360 getObject13() throws GeneralLeanFtException{
			Physician_CL360 phy_stat= new Physician_CL360();
			return phy_stat;
					
		}
	public static Physician_PS340 getObject14() throws GeneralLeanFtException{
			Physician_PS340 phy_contract= new Physician_PS340();
			return phy_contract;
					
		}
		public static AuthNotification_TB309 getObject15() throws GeneralLeanFtException{
			AuthNotification_TB309 phy_logic = new AuthNotification_TB309();
			return phy_logic;
					
		}
		
public static Member_GI301 getObject16() throws GeneralLeanFtException{
			Member_GI301 mem_num = new Member_GI301();
			return mem_num;
					
		}
		public static Provider_GI302 getObject17() throws GeneralLeanFtException{
			Provider_GI302 prov_num = new Provider_GI302();
			return prov_num;
					
		}
//Shivi for Anesthesia
		public static FeeMax_TB822 getObject18() throws GeneralLeanFtException{
			FeeMax_TB822 ftb=new FeeMax_TB822();
			return ftb;
					
		}
		public static PS303 getObject19() throws GeneralLeanFtException{
			 PS303 ps=new PS303();
			return ps;
					
		}
		
/*The below method is for Inquiring contract in PS340 screen
		Created by Shivi(sjaisw20)*/
		public void InquireContract(String phy_contract,String screenname) throws InterruptedException, GeneralLeanFtException{
			Physician_PS340 p5 = FunctionLibrary.getObject14();
			if(screenname.equalsIgnoreCase("PS340"))
			{ 
				Physician_PS340 phy_con= new Physician_PS340();
				try 
				{
					Thread.sleep(1000);
					phy_con.contract.setText(phy_contract);
					System.out.println("The contract number in PS340 is:"+phy_contract);
					phy_con.cur_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
				}
				catch (GeneralLeanFtException e) {
					e.printStackTrace();
				}
			}
				else if(screenname.equalsIgnoreCase("PS343"))
				{ 
					Physician_PS343 phy_con= new Physician_PS343();
					try 
					{
						Thread.sleep(1000);
						phy_con.contract.setText(phy_contract);
						System.out.println("The contract number is:"+phy_contract);
						phy_con.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
					}
					catch (GeneralLeanFtException e) {
						e.printStackTrace();
					}
					
			}
		
		}
		
		/*The below method is for Inquiring provider number in PS303 screen
		Created by Shivi(sjaisw20)*/
		public void InquireProviderNumber(String prov1,String prov2,String screenname) throws InterruptedException, GeneralLeanFtException{
			PS303 ps = FunctionLibrary.getObject19();
			if(screenname.equalsIgnoreCase("PS303"))
			{ 
				 PS303 ps1=new PS303();
				try 
				{
					Thread.sleep(1000);
					ps1.provider1.setText(prov1);
					ps1.provider2.setText(prov2);
					ps1.Screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
					Thread.sleep(1000);
				}
				
				
				catch (GeneralLeanFtException e) {
					e.printStackTrace();
				}
			}
		
		}
		
		
		
		/*The below method is for Inquiring Logic in TB309
		Created by Shivi(sjaisw20)*/
		public void InquireLogic(String exp_logic,String screen) throws InterruptedException, GeneralLeanFtException{
			AuthNotification_TB309 p6 = FunctionLibrary.getObject15();
			if(screen.equalsIgnoreCase("TB309"))
			{ 
				AuthNotification_TB309 phy_logic = new AuthNotification_TB309();
				try 
				{
					Thread.sleep(1000);
					phy_logic.logic_code.setText(exp_logic);
					System.out.println("The logic code is:"+exp_logic);
					phy_logic.screenname.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
				}
				catch (GeneralLeanFtException e) {
					e.printStackTrace();
				}
			}
		}
		
		/*The below method is for Inquiring key
		Created by Shivi(sjaisw20)*/
		/*public void InquireKey(String key1,String Div,String screenname) throws InterruptedException, GeneralLeanFtException{
			Physician_CL360 p4 = FunctionLibrary.getObject13();
			if(screenname.equalsIgnoreCase("CL360"))
			{ 
				Physician_CL360 phy_stat= new Physician_CL360();
				site.setText(Div);
				change_site.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
				Thread.sleep(1000);
				Screen cosmos_menu = Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("Unite").build());
				Field menu = cosmos_menu.describe(Field.class, new FieldDescription.Builder().attachedText("field3").isProtected(false).build());
				menu.setText(screenname);
				cosmos_menu.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
				Thread.sleep(1000); */
		/*The below method is for Inquiring key
		Created by Shivi(sjaisw20)*/
		public void InquireKey(String key1,String Div,String screenname) throws InterruptedException, GeneralLeanFtException{
			Physician_CL360 p4 = FunctionLibrary.getObject13();
			if(screenname.equalsIgnoreCase("CL360"))
			{ 
				Physician_CL360 phy_stat= new Physician_CL360();
	site.setText(Div);
				change_site.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
				Thread.sleep(1000);
				Screen cosmos_menu = Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("Unite").build());
				Field menu = cosmos_menu.describe(Field.class, new FieldDescription.Builder().attachedText("field3").isProtected(false).build());
				menu.setText(screenname);
				cosmos_menu.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
				Thread.sleep(1000);
				try 
				{
					Thread.sleep(1000);
					phy_stat.key.setText(key1);
                    phy_stat.Screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
				}
				catch (GeneralLeanFtException e) {
					e.printStackTrace();
				}
			}
		}
	
	public void InquireCode(String input,String screenname,int len,int start_row,int start_col) throws GeneralLeanFtException ,InterruptedException
	{
		if(screenname.equalsIgnoreCase("TB223"))
		{ 
			ConditionCode_TB223 cc_tb223 = new ConditionCode_TB223();
			try 
			{
				Thread.sleep(1000);
				cc_tb223.cc_inq.setText(input);
				cc_tb223.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
}
			catch (GeneralLeanFtException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(screenname.equalsIgnoreCase("TB455"))
		{ 
			ConditionCode_TB455 cc_tb455 = new ConditionCode_TB455();
			try 
			{
				Thread.sleep(1000);
				cc_tb455.review_inq.setText(input);
				cc_tb455.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			}
			catch (GeneralLeanFtException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}	
		else if(screenname.equalsIgnoreCase("GI101"))
		{	
			//create obj for gi101
			Member_GI101 memobj=null;
			try {
				memobj = new Member_GI101();
			} catch (GeneralLeanFtException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				memobj.select.setText("NUMBER");
				memobj.Primery_Key.setText(input);
				memobj.SCREEN.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			} catch (GeneralLeanFtException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		else if(screenname.equalsIgnoreCase("EP120"))
		{
			Provider_EP120 prov_screenp1 = new Provider_EP120();
			//prov_screenp1.Group.setText(Member_ID);
			prov_screenp1.Group.setText(input);
			prov_screenp1.SCREEN.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		
		}
		else if(screenname.equalsIgnoreCase("CL202"))
		{
			Physician_CL202 prov_screenp1 = new Physician_CL202();
			//prov_screenp1.Group.setText(Member_ID);
			prov_screenp1.audit.setText(input);
			prov_screenp1.SCREEN.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		
		}

		/*if(screenname.equalsIgnoreCase("TB223"))
		{	
			ConditionCode_TB223 cc_tb223 = new ConditionCode_TB223();
			try {
				Thread.sleep(1000);
				cc_tb223.cc_inq.setText(input);
				cc_tb223.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			} catch (GeneralLeanFtException e) {
			e.printStackTrace();
			}
		}*/
		else if(screenname.equalsIgnoreCase("AU300"))
		{
			OutPatient_AU300 authAU300_obj = new OutPatient_AU300();
			
			try {
				Thread.sleep((1000));
				authAU300_obj.intake_num.setText(input);
				authAU300_obj.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			} catch (GeneralLeanFtException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
else if(screenname.equalsIgnoreCase("CL147")){
			LimitedService_CL147 lsvc= new LimitedService_CL147();
			Thread.sleep(1000);
			try {
				Thread.sleep(1000);
				lsvc.limited_svc.setText(input);
				lsvc.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			} catch (GeneralLeanFtException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
else if(screenname.equalsIgnoreCase("CL148")){
		LimitedService_CL148 lsvc1= new LimitedService_CL148();
			Thread.sleep(1000);
			try {
				Thread.sleep(1000);
				lsvc1.limited_svc.setText(input);
				lsvc1.main_Screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			} catch (GeneralLeanFtException e) {
			e.printStackTrace();
			}
}
	}
	
	/*These below two methods are for Inquiring Notification and Benefit Number
	Created by Shivi(sjaisw20)*/
	public void InquireNotification(String intake_numb,String ScreenName2,int a_len, int a_startrow,int a_startcol) throws GeneralLeanFtException, InterruptedException{
		OutPatient_AU300 out= FunctionLibrary.getObject8();
		out.intake_num.setText(intake_numb);
		out.ScreenName2.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		Thread.sleep(1000);
	}
	
	
	public void InquireBenefitNumber(String ben_Number,String ScreenName1,int a_len, int a_startrow,int a_startcol) throws GeneralLeanFtException, InterruptedException{
		Physician_CL140 p4 = FunctionLibrary.getObject7();
		p4.benefitNumber.setText(ben_Number);
		p4.ScreenName1.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		Thread.sleep(1000);
	}
	public void InquireMember(String memberId, String screen,int a_len, int a_startrow,int a_startcol) throws GeneralLeanFtException, InterruptedException {
		// TODO Auto-generated method stub {
		// TODO Auto-generated method stub
if(screen.equals("GI325")){
		Member_GI325 lmt_svc2= FunctionLibrary.getObject11();
		lmt_svc2.MemberId.setText(memberId);
	    lmt_svc2.screen_GI.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		}
		else if(screen.equals("GI301")){
	    Member_GI301 mem_inq= FunctionLibrary.getObject16();
	    Thread.sleep(1000);
	    mem_inq.select.setText("NUMBER");
	    mem_inq.MemberId.setText(memberId);
	    mem_inq.screen_GI301.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	}
}

	
public void InquireProvider(String prov_Number,String Screen,int a_len, int a_startrow,int a_startcol) throws GeneralLeanFtException, InterruptedException{
		Provider_GI302 p5 = FunctionLibrary.getObject17();
		Thread.sleep(1000);
		p5.select.setText("NUMBER");
		p5.provider.setText(prov_Number);
		p5.screen_GI302.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		Thread.sleep(1000);
	}
	
	
	public void InquireMemberNumber(String mem_Number,String mbr_sub1,String mbr_sub2,String ScreenName1,int a_len, int a_startrow,int a_startcol) throws GeneralLeanFtException, InterruptedException{
		
/*	String member_ID=mem_Number.concat(mem_sub1);
		String Member_Value=member_ID.concat(mem_sub2);
		System.out.println("The member value is:"+Member_Value);//right value!!
*/		if(ScreenName1.equals("CL147")){	
		LimitedService_CL147 lmt_svc= FunctionLibrary.getObject9();
		
		lmt_svc.member_inq.setText(mem_Number);
		lmt_svc.mem_sub1.setText(mbr_sub1);
		lmt_svc.memb_sub2.setText(mbr_sub2);
		
		Thread.sleep(1000);
	}
			else if(ScreenName1.equals("CL148")){
				LimitedService_CL148 lmt_svc1= FunctionLibrary.getObject10();
				lmt_svc1.member_inq.setText(mem_Number);
				lmt_svc1.mem_sub1.setText(mbr_sub1);
				lmt_svc1.memb_sub2.setText(mbr_sub2);
				Thread.sleep(1000);
			}
			else if(ScreenName1.equals("GI325")){
				Member_GI325 mb= FunctionLibrary.getObject11();
				mb.member_inq.setText(mem_Number);
				mb.mem_sub1.setText(mbr_sub1);
				mb.memb_sub2.setText(mbr_sub2);
				mb.screen_GI.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
				Thread.sleep(1000);
			}
			
	}
	
	
	public  void InquireClaim(String audit,String cur_div,String screenname,String aText,int a_len, int a_startrow,int a_startcol,int s_len,int s_startrow,int s_startcol) throws GeneralLeanFtException, InterruptedException
	{
		 boolean cur_screen = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder().label("Unite").build()).exists(2);
		 Physician_CL201 pl = FunctionLibrary.getObject();
		 Physician_CL209 p2 = FunctionLibrary.getObject1();
		 Physician_CL202 p3 = FunctionLibrary.getObject2();
		 Physician_CL215 p4 = FunctionLibrary.getObject215();
		 Physician_PS340 p5= FunctionLibrary.getObject14();
		// Physician_CL201 pl = FunctionLibrary.getObject();
		 
		if (cur_screen)
		{	
			String main_audit=null;
			site.setText(cur_div);
			change_site.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			Thread.sleep(1000);
			Screen cosmos_menu = Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
				.label("Unite").build());
			Field menu = cosmos_menu.describe(Field.class, new FieldDescription.Builder().attachedText("field3").isProtected(false).build());
			menu.setText(screenname);
			cosmos_menu.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			Thread.sleep(1000);
		}
		if((screenname.equalsIgnoreCase("CL201")) || (screenname.equalsIgnoreCase("CL202")) || (screenname.equalsIgnoreCase("CL209"))|| (screenname.equalsIgnoreCase("CL215")|| (screenname.equalsIgnoreCase("CL214"))))  
		{
			
			phy_claim_inq = Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build());
			msg = phy_claim_inq.describe(Field.class, new FieldDescription.Builder()
						.startPosition(23,2).length(79).isProtected(true).build());
			if(screenname.equals("CL201"))
			{
				aud = pl.phy_aud;
				sub_aud = pl.phy_subaud;
			}
			else if(screenname.equals("CL209"))
			{
				aud = p2.audit;
				/*aud = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().attachedText("CLAIM AUDIT").length(9).startPosition(4,22).index(0).build());*/
				sub_aud = p2.subaudit;
				
			}
			else if(screenname.equals("CL202"))
			{
				aud = p3.audit;
				/*aud = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().attachedText("CLAIM AUDIT").length(9).startPosition(4,22).index(0).build());*/
				sub_aud = p3.subaudit;
				
			}
			else if(screenname.equals("CL215"))
			{
				aud = p4.audit;
				/*aud = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().attachedText("CLAIM AUDIT").length(9).startPosition(4,22).index(0).build());*/
				
				sub_aud = p4.subaudit;
//				
			}
				//Field aud = phy_claim_inq .describe(Field.class, new FieldDescription.Builder().attachedText("AUDIT").isProtected(false).index(0).build());
			//aud = phy_claim_inq .describe(Field.class, new FieldDescription.Builder().attachedText(aText).length(a_len).startPosition(a_startrow,a_startcol).build());
			
			//aud = Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					//.label("UNI").build()).describe(Field.class, new FieldDescription.Builder().attachedText("AUDIT").length(8).startPosition(4,13).build());
			//sub_aud = phy_claim_inq .describe(Field.class, new FieldDescription.Builder().attachedText(aText).length(s_len).startPosition(s_startrow,s_startcol).build());
					
			if (audit.length() == 10)
			{
				main_audit = audit.substring(0, 8);
				sub_audit = audit.substring(8, 10);
			}
			else if (audit.length() == 8)
			{
				main_audit = audit.substring(0, 7);
				sub_audit = "00";
			}
			else if (audit.length() == 11)
			{
				main_audit = audit.substring(0, 9);
				sub_audit = audit.substring(9, 11);
			}
			
			aud.setText(main_audit);
			phy_claim_inq.sendTEKeys(com.hp.lft.sdk.te.Keys.TAB);
			Thread.sleep(500);
			sub_aud.setText(sub_audit);
			phy_claim_inq.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			Thread.sleep(500);
				
		}
		else if((screenname.equalsIgnoreCase("HO400")) || (screenname.equalsIgnoreCase("HO409")) || (screenname.equalsIgnoreCase("HO410")) || (screenname.equalsIgnoreCase("HO430")) || (screenname.equalsIgnoreCase("HO440")))
		{
		//	menu.setText(screenname);
			//cosmos_menu.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			//Thread.sleep(1000);
			hos_claim_inq = Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build());
			
			aud =hos_claim_inq.describe(Field.class, new FieldDescription.Builder()
					.attachedText(aText).length(a_len).startPosition(a_startrow,a_startcol).build());
			
			aud.setText(audit);
			
			hos_claim_inq.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		}
	}
	public  String getClaimValue(String screenname,Field fieldname,int start, int end ) throws GeneralLeanFtException
	{
		if((screenname.equalsIgnoreCase("CL201")) || (screenname.equalsIgnoreCase("CL202")) || (screenname.equalsIgnoreCase("CL209")) || (screenname.equalsIgnoreCase("CL140")) ||(screenname.equalsIgnoreCase("CL147")) ||(screenname.equalsIgnoreCase("CL148")) || (screenname.equalsIgnoreCase("CL360"))||(screenname.equalsIgnoreCase("CL510")) ||(screenname.equalsIgnoreCase("TB208"))|| (screenname.equalsIgnoreCase("PS340")) || (screenname.equalsIgnoreCase("TB309")) || (screenname.equalsIgnoreCase("TB201"))|| (screenname.equalsIgnoreCase("TB875")) || (screenname.equalsIgnoreCase("PS308"))|| (screenname.equalsIgnoreCase("CL104")) ||(screenname.equalsIgnoreCase("TB214"))||(screenname.equalsIgnoreCase("EP400"))||(screenname.equalsIgnoreCase("CL300"))||(screenname.equalsIgnoreCase("PS330")) || (screenname.equalsIgnoreCase("TB822")) || (screenname.equalsIgnoreCase("PCFM")) ||  (screenname.equalsIgnoreCase("PS343")) || (screenname.equalsIgnoreCase("PS303")) || (screenname.equalsIgnoreCase("TB130"))||(screenname.equalsIgnoreCase("TB491")) || (screenname.equalsIgnoreCase("CL657")) || (screenname.equalsIgnoreCase("CL658")) || (screenname.equalsIgnoreCase("GI302")) ||  (screenname.equalsIgnoreCase("GI301")))
		{
			if(screenname.equalsIgnoreCase("CL201"))
			{
				Physician_CL201 pl = FunctionLibrary.getObject();
//if( fieldname.getText().equals(pl.copay1.getText()) || fieldname.getText().equals(pl.copay2.getText()) ||fieldname.getText().equals(pl.ded1.getText())||fieldname.getText().equals(pl.ded2.getText())||fieldname.getText().equals(pl.rsn1.getText())||fieldname.getText().equals(pl.rsn2.getText())||fieldname.getText().equals(pl.proc_code1.getText()) || fieldname.getText().equals(pl.proc_code2.getText())||fieldname.getText().equals(pl.proc_code1_mod1.getText())||fieldname.getText().equals(pl.disc1.getText()) || fieldname.getText().equals(pl.proc_code1_mod2.getText())||fieldname.getText().equals(pl.proc_code1_mod2.getText())||fieldname.getText().equals(pl.proc_code1_mod3.getText())||fieldname.getText().equals(pl.proc_code1_mod4.getText())||fieldname.getText().equals(pl.proc_code2_mod1.getText())||fieldname.getText().equals(pl.proc_code2_mod2.getText())||fieldname.getText().equals(pl.proc_code2_mod3.getText())||fieldname.getText().equals(pl.proc_code2_mod4.getText())||fieldname.getText().equals(pl.disc2.getText()))
				if(fieldname.getText().equals(pl.proc_code1.getText()) || fieldname.getText().equals(pl.proc_code2.getText()) || fieldname.getText().equals(pl.tot_allowed.getText()))
				{	
					int len_proc = fieldname.getText().length();
					if(len_proc >5 || len_proc<5)
					{	
						cellvalue = fieldname.getText().substring(start,end).trim();	
						System.out.println(cellvalue);
					}
					else if(len_proc==5 || len_proc==4)
					{
						cellvalue = fieldname.getText().trim();
					}
					else 
					{
						//cellvalue ="No modifier";
						cellvalue ="";
					}
				}
				else if( fieldname.getText().equals(pl.closed_claim.getText())){
					cellvalue = fieldname.getText().substring(start).trim();	
				}
					
				
				else if(fieldname.getText().equals(pl.copay1.getText()) || fieldname.getText().equals(pl.disc1.getText()) ||fieldname.getText().equals(pl.copay2.getText()) ||fieldname.getText().equals(pl.ded1.getText())||fieldname.getText().equals(pl.ded2.getText())||fieldname.getText().equals(pl.rsn1.getText())||fieldname.getText().equals(pl.rsn2.getText())||fieldname.getText().equals(pl.disc2.getText()))
				{
					cellvalue = fieldname.getText().substring(start,end).trim();	
					System.out.println(cellvalue);
				}
				else if(fieldname.getText().equals(pl.proc_code1_mod1.getText())|| fieldname.getText().equals(pl.proc_code1_mod2.getText())||fieldname.getText().equals(pl.proc_code1_mod3.getText())||fieldname.getText().equals(pl.proc_code1_mod4.getText())||fieldname.getText().equals(pl.proc_code2_mod1.getText())||fieldname.getText().equals(pl.proc_code2_mod2.getText())||fieldname.getText().equals(pl.proc_code2_mod3.getText())||fieldname.getText().equals(pl.proc_code2_mod4.getText()))
				{
					int len_proc = fieldname.getText().length();
					if(len_proc >5)
					{	
						cellvalue = fieldname.getText().substring(start,end).trim();	
						System.out.println(cellvalue);
					}
					else if(len_proc==5)
					{
						cellvalue = "No modifier";
					}
					else 
					{
						cellvalue ="No modifier";
					}
				}
				else
				{
					cellvalue = fieldname.getText().trim();
				}
			}	
			else
			{
				cellvalue = fieldname.getText().trim();
			}
}
else if((screenname.equalsIgnoreCase("CL215")))
		{
			if(screenname.equalsIgnoreCase("CL215"))
			{
				Physician_CL215 Pr1 = FunctionLibrary.getObject215();
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				if(fieldname.getText().equals(Pr1.DOS.getText()))
				{	
					int len_proc = fieldname.getText().length();
					if(len_proc >6)
					{	
						cellvalue = fieldname.getText().substring(start,end);	
						System.out.println(cellvalue);
					}
					else if(len_proc==6)
					{
						cellvalue = fieldname.getText().trim();
					}
					else 
					{
						cellvalue ="No modifier";
					}
				}
				else if(fieldname.getText().equals(Pr1.DOS.getText()))
				{
					cellvalue = fieldname.getText().substring(start,end).trim();	
					System.out.println(cellvalue);
				}
				else if(fieldname.getText().equals(Pr1.DOS.getText()))
				{
					int len_proc = fieldname.getText().length();
					if(len_proc >6)
					{	
						cellvalue = fieldname.getText().substring(start,end).trim();	
						System.out.println(cellvalue);
					}
					else if(len_proc==6)
					{
						cellvalue = "No modifier";
					}
					else 
					{
						cellvalue ="No modifier";
					}
				}
				else
				{
					cellvalue = fieldname.getText().trim();
				}
			}	
			else
			{
				cellvalue = fieldname.getText().trim();
				
			}
			System.out.println(cellvalue);
		}
		

				else if((screenname.equalsIgnoreCase("EP120")))
		{
			if(screenname.equalsIgnoreCase("EP120"))
			{
				Provider_EP120 EP1 = FunctionLibrary.getObjectP();
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				if(fieldname.getText().equals(EP1.EFF_date.getText()))
				{	
					int len_proc = fieldname.getText().length();
					if(len_proc >6)
					{	
						cellvalue = fieldname.getText().substring(start,end);	
						System.out.println(cellvalue);
					}
					else if(len_proc==6)
					{
						cellvalue = fieldname.getText().trim();
					}
					else 
					{
						cellvalue ="No modifier";
					}
				}
				else if(fieldname.getText().equals(EP1.EFF_date.getText()))
				{
					cellvalue = fieldname.getText().substring(start,end).trim();	
					System.out.println(cellvalue);
				}
				else if(fieldname.getText().equals(EP1.EFF_date.getText()))
				{
					int len_proc = fieldname.getText().length();
					if(len_proc >6)
					{	
						cellvalue = fieldname.getText().substring(start,end).trim();	
						System.out.println(cellvalue);
					}
					else if(len_proc==6)
					{
						cellvalue = "No modifier";
					}
					else 
					{
						cellvalue ="No modifier";
					}
				}
				else
				{
					cellvalue = fieldname.getText().trim();
				}
			}	
			else
			{
				cellvalue = fieldname.getText().trim();
				
			}
			System.out.println(cellvalue);
		}
		
				else if((screenname.equalsIgnoreCase("GI101")))
				{
					if(screenname.equalsIgnoreCase("GI101"))
					{
						Member_GI101 Pr1 = FunctionLibrary.getObject12();
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						if(fieldname.getText().equals(Pr1.Eff_Date.getText()))
						{	
							int len_proc = fieldname.getText().length();
							if(len_proc >6)
							{	
								cellvalue = fieldname.getText().substring(start,end);	
								System.out.println(cellvalue);
							}
							else if(len_proc==6)
							{
								cellvalue = fieldname.getText().trim();
							}
							else 
							{
								cellvalue ="No modifier";
							}
						}
						else if(fieldname.getText().equals(Pr1.Eff_Date.getText()))
						{
							cellvalue = fieldname.getText().substring(start,end).trim();	
							System.out.println(cellvalue);
						}
						else if(fieldname.getText().equals(Pr1.Eff_Date.getText()))
						{
							int len_proc = fieldname.getText().length();
							if(len_proc >6)
							{	
								cellvalue = fieldname.getText().substring(start,end).trim();	
								System.out.println(cellvalue);
							}
							else if(len_proc==6)
							{
								cellvalue = "No modifier";
							}
							else 
							{
								cellvalue ="No modifier";
							}
						}
						else
						{
							cellvalue = fieldname.getText().trim();
						}
					}	
					else
					{
						cellvalue = fieldname.getText().trim();
						
					}
					System.out.println(cellvalue);
				}
		
		
		else if((screenname.equalsIgnoreCase("HO400")) || (screenname.equalsIgnoreCase("HO409")) || (screenname.equalsIgnoreCase("HO410")) || (screenname.equalsIgnoreCase("HO430")) ||(screenname.equalsIgnoreCase("HO440"))  )
		{
			boolean hasValue = false;
			
			String fname = fieldname.getText();
			//cellvalue = hos_claim_inq.describe(Field.class, new FieldDescription.Builder().length(a_len).startPosition(a_startrow,a_startcol).index(ind).build()).getText().trim();
			if(screenname.equalsIgnoreCase("HO400"))
			{
				//String fname = fieldname.getText();
				Hospital_HO400 hl = FunctionLibrary.getObject4();
				if(fname.equals(hl.cpt1_mod1.getText() != null) || (fname.equals(hl.cpt1_mod2.getText() !=null))){
					hasValue=true;
					try {
						Thread.sleep(1500);
					} catch (InterruptedException e) {
					
						e.printStackTrace();
					}
				}
				else if (fname.equals(hl.Cause_Deny.getText() != null) || (fname.equals(hl.Cause_Deny.getText() !=null))){
					hasValue=true;
					try {
						Thread.sleep(1500);
					} catch (InterruptedException e) {
					
						e.printStackTrace();
					}
				}
				else if (fname.equals(hl.cpt2_mod1.getText() != null) || (fname.equals(hl.cpt2_mod2.getText() !=null))){
					hasValue=true;
					try {
						Thread.sleep(1500);
					} catch (InterruptedException e) {
					
						e.printStackTrace();
					}
				}
				else if(fname.equals(hl.cpt3_mod1.getText() != null) || (fname.equals(hl.cpt3_mod2.getText() !=null))){
					hasValue=true;
					try {
						Thread.sleep(1500);
					} catch (InterruptedException e) {
					
						e.printStackTrace();
					}
				}
				else if(fname.equals(hl.cpt4_mod1.getText() != null) || (fname.equals(hl.cpt4_mod2.getText() !=null))){
					hasValue=true;
					try {
						Thread.sleep(1500);
					} catch (InterruptedException e) {
					
						e.printStackTrace();
					}
				}
			}	
			if(hasValue){
				try {
					Thread.sleep(1500);
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
				cellvalue = fieldname.getText().substring(start,end).trim();	
				System.out.println(cellvalue);
			}
			else
			{cellvalue = fieldname.getText().trim();
				try {
					Thread.sleep(1500);
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
				cellvalue = fieldname.getText().trim();
			}
			//}	
			//else
			//{
				//cellvalue = fieldname.getText().trim();
			//}
		
		}
		return cellvalue;
	}
	
	
	
	/*This below method is for getting member status detail
	Created by Shivi(sjaisw20)*/
public List getMemberDetailStatus(String screenname, String Audit_number,int len ) throws InterruptedException, GeneralLeanFtException{
		
		Screen rev_screen = null;
		Field audnum;
		Field status1;
		
		int audit_found = 0;
		String act_audit_num = null,act_status= null;
		if(screenname.equalsIgnoreCase("HO409"))
		{
			rev_screen = hos_claim_inq;
		}
		else if(screenname.equalsIgnoreCase("CL209"))
		{
			rev_screen = phy_claim_inq;
		}
		else if (screenname.equalsIgnoreCase("GI325"))
		{
			rev_screen= service_detail_inq;
		}
		
		for(int aud=9;aud<=22;aud++)
		{	
			Thread.sleep(1000);
			audnum = rev_screen.describe(Field.class, new FieldDescription.Builder()
					.length(11).isProtected(true).startPosition(aud,6).build());
			act_audit_num = audnum.getText();
			if(act_audit_num.equals(""))
			{	
				break;
			}	
			if(Audit_number.equalsIgnoreCase(act_audit_num) )
			{
				
				Thread.sleep(1000);
				audit_found = 1;
				Field stat =rev_screen.describe(Field.class, new FieldDescription.Builder()
							.length(len).isProtected(true).startPosition(aud,27).build());
				act_status=stat.getText();
				break;
			}
		}
		
		if (audit_found ==0)
		{	
			for(int aud=9;aud<=22;aud++)
			{	
				Thread.sleep(1000);
				audnum=rev_screen.describe(Field.class, new FieldDescription.Builder()
						.length(11).isProtected(true).startPosition(aud,6).build());
				act_audit_num = audnum.getText();
				if(act_audit_num.equals(""))
				{
					break;
				}	
				
				if(Audit_number.equalsIgnoreCase(act_audit_num))
				{
					Thread.sleep(1000);
					audit_found = 1;
					Field stat =rev_screen.describe(Field.class, new FieldDescription.Builder()
							.length(len).isProtected(true).startPosition(aud,27).index(1).build());
					act_status=stat.getText();
					break;
				}
				
			}}
		Thread.sleep(1000);
		//req_rev = String.valueOf(review_found);
		ArrayList<String> list = new ArrayList();
		if(audit_found==0)
		{
			
			list.add("Audit Number not found");
			list.add("User status not found");
		}
		else
		{	
			
			list.add(act_audit_num);
			list.add(act_status);
		}	
		return list;
		
	}

	
	
	
	
	
	public  List getReviewClearDetails(String screenname,String review,int len) throws GeneralLeanFtException, InterruptedException
	{
		Screen rev_screen = null;
		Field reviewnum;
		int review_found = 0;
		String act_usr_code = null,act_rev_code = null,req_rev = null;
		if(screenname.equalsIgnoreCase("HO409"))
		{
			rev_screen = hos_claim_inq;
		}
		else if(screenname.equalsIgnoreCase("CL209"))
		{
			rev_screen = phy_claim_inq;
		}

		
		for(int rev=8;rev<=22;rev++)
		{	
			Thread.sleep(1000);
			reviewnum = rev_screen.describe(Field.class, new FieldDescription.Builder()
				.length(7).startPosition(rev, 7).isProtected(true).build());
			act_rev_code = reviewnum.getText();
			if(act_rev_code.equals(""))
			{	
				break;
			}	
			if(review.equalsIgnoreCase(act_rev_code) )
			{
				Thread.sleep(1000);
				review_found = 1;
				Field usr_code =rev_screen.describe(Field.class, new FieldDescription.Builder()
					.startPosition(rev,15).length(len).isProtected(true).index(0).build());
				act_usr_code=usr_code.getText();
				break;
			}
		}
		if (review_found ==0)
		{	
			for(int rev=8;rev<=22;rev++)
			{	
				Thread.sleep(1000);
				reviewnum=rev_screen.describe(Field.class, new FieldDescription.Builder()
					.length(7).startPosition(rev, 47).isProtected(true).build());
				act_rev_code = reviewnum.getText();
				if(act_rev_code.equals(""))
				{
					break;
				}	
				if(review.equalsIgnoreCase(act_rev_code))
				{
					Thread.sleep(1000);
					review_found = 1;
					Field usr_code =rev_screen.describe(Field.class, new FieldDescription.Builder()
							.startPosition(rev,55).length(len).isProtected(true).index(0).build());
					act_usr_code=usr_code.getText();
					break;
				}
				
			}
			
		}
		Thread.sleep(1000);
		//req_rev = String.valueOf(review_found);
		ArrayList<String> list = new ArrayList();
		if(review_found==0)
		{
			
			list.add("Review not found");
			list.add("User code not found");
		}
		else
		{	
			
			list.add(act_rev_code);
			list.add(act_usr_code);
		}	
		return list;
		
	}
	
	/*public List AddUnits(String screenname,String units,int len) throws InterruptedException, GeneralLeanFtException, IOException {

		Screen rev_screen = null;
		Hospital_HO400 H4=new Hospital_HO400();
		Field unitnum;
		int unit_found = 0;
		String act_usr_code = null,act_rev_code = null,req_rev = null;
		int previous=0,sum,next;
		if(screenname.equalsIgnoreCase("HO400"))
		{
			rev_screen = hos_claim_inq;
		}
		for(int UNITFOUND=11;UNITFOUND<=14;UNITFOUND++)
		{	
			Thread.sleep(1000);
			unitnum = rev_screen.describe(Field.class, new FieldDescription.Builder().length(6).startPosition(UNITFOUND, 12).isProtected(true).build());
			act_rev_code = unitnum.getText();
			next = Integer.parseInt(act_rev_code);
		    sum=previous+next;
			previous=next;
			previous=sum;
			System.out.println("Sum is " +previous);
			if(  (!(H4.hos_msg_val().contains("NO MORE DETAILS"))) & (UNITFOUND==14)  ) {
				H4.hos_mainscreen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
				Thread.sleep(1000);
				for(UNITFOUND=11;UNITFOUND<=14;UNITFOUND++)
				{	
					Thread.sleep(1000);
					unitnum = rev_screen.describe(Field.class, new FieldDescription.Builder().length(6).startPosition(UNITFOUND, 12).isProtected(true).build());
					act_rev_code = unitnum.getText();
					next = Integer.parseInt(act_rev_code);
				    sum=previous+next;
					previous=next;
					previous=sum;
					System.out.println("Sum is " +previous);
				if(act_rev_code.equals("  "))
				{	
					System.out.println("Total Units are" +previous);
					break;
				}
				break;
			}
				
		}
		
		}
			
		
		ArrayList<String> list = new ArrayList<>();
//		if(units.equalsIgnoreCase(act_rev_code))
//		{
//			
//			list.add("Units found");
//			
//		}
//		else
//		{	
			
			list.add(act_rev_code);
			
		//}	
		
		for (String string : list) {
			System.out.println("each ele"+string);
		}
		return list;		
		
	}
	
*/
	public boolean checkHistoryClaim(String screenname)
	{
		boolean auditPresent = false;
		if((screenname.equalsIgnoreCase("CL201")) || (screenname.equalsIgnoreCase("CL202")) || (screenname.equalsIgnoreCase("CL209")))
		{
			Physician_CL201 phy_obj = new  Physician_CL201();
			try {
				if((!phy_obj.msg.getText().equalsIgnoreCase("UNABLE TO FIND;")) && (!phy_obj.msg.getText().equalsIgnoreCase("INVALID AUDIT NBR;")) )
				{
					auditPresent = true;
					Thread.sleep(1000);
				}
			} catch (GeneralLeanFtException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			
		}
if((screenname.equalsIgnoreCase("CL201")) || (screenname.equalsIgnoreCase("CL202")) || (screenname.equalsIgnoreCase("CL209")))
		{
			Physician_CL201 phy_obj = new  Physician_CL201();
			try {
				if((!phy_obj.msg.getText().equalsIgnoreCase("UNABLE TO FIND;")) && (!phy_obj.msg.getText().equalsIgnoreCase("INVALID AUDIT NBR;")) )
				{
					auditPresent = true;
					Thread.sleep(1000);
				}
			} catch (GeneralLeanFtException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			
		}
		else if((screenname.equalsIgnoreCase("HO400")) || (screenname.equalsIgnoreCase("HO409")) || (screenname.equalsIgnoreCase("HO410")) || (screenname.equalsIgnoreCase("HO430")) )
		{
			try {
				Hospital_HO400 hos_obj = new  Hospital_HO400();
				if(!hos_obj.msg.getText().equalsIgnoreCase("AUDIT NBR DOES NOT EXIST;"))
				{
					auditPresent = true;
					Thread.sleep(1000);
				}
			} catch (GeneralLeanFtException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			
		}
		return auditPresent;
		
	}
	
	
	public static String DB2Validation(String Field,String Region,String  Tablename,String keyfield,String keyvalue ) throws SQLException {
		String url1="jdbc:db2://GWYA8002:50002/DB0T";
		//String user="TSUKTN3";
		//String password="BAL13BAL";
		String user= Constants.dbuser;
		String password=Constants.passwd;
		String columnValue=null;
		Connection connection = null;
		try {
			//Load class into memory
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			//Establish connection
			connection = DriverManager.getConnection(url1, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{

			if(connection!=null){
				//System.out.println("Connected successfully.");
				Statement stmt1 = connection.createStatement();
				ResultSet rs1 = stmt1.executeQuery("select "+Field+ " from "+ Region+"."+Tablename+" where "+keyfield+"="+keyvalue);
				ResultSetMetaData rsmd=rs1.getMetaData();
				int colnum1=rsmd.getColumnCount();
				//System.out.println(colnum1);
				while(rs1.next()){
					for(int i =1;i<=colnum1;i++){

						columnValue = rs1.getString(i);


						//System.out.print(rsmd.getColumnName(i)+"                :"+columnValue);

						//System.out.println("");
					}


				}}
		}return columnValue;
		

	}
	


/*	public void DB2Validation(String url, String Field,String Region,String  Tablename,String keyfield,String keyvalue,String keyfield1,String keyvalue1 ) throws SQLException {

		String url1="jdbc:db2://GWYA8002:50002/DB0T";
		//String user=prop.getProperty("username");
		//String password=prop.getProperty("password");
		Connection connection = null;
		try {
			//Load class into memory
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			//Establish connection
			connection = DriverManager.getConnection(url1, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{

			if(connection!=null){
				System.out.println("Connected successfully.");
				Statement stmt1 = connection.createStatement();
				ResultSet rs1 = stmt1.executeQuery("select "+Field+ " from "+ "D9331C"+Region+"."+Tablename+" where "+keyfield+"="+keyvalue+" and "+keyfield1+"=\'"+keyvalue1+"\'");

				ResultSetMetaData rsmd=rs1.getMetaData();
				int colnum1=rsmd.getColumnCount();
				System.out.println(colnum1);
				while(rs1.next()){
					for(int i =1;i<=colnum1;i++){

						String columnValue = rs1.getString(i);


					}
				}}
		}
		try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}*/
	/*public void DB2Validation(String url, String Field,String Region,String  Tablename,String keyfield,String keyvalue,String keyfield1,String keyvalue1,String keyfield2,String keyvalue2,String keyfield3,String keyvalue3 ) throws SQLException {

		String url1="jdbc:db2://GWYA8002:50002/DB0T";
		String user="TSUKTN3";
		String password="BAL13BAL";
		Connection connection = null;
		try {
			//Load class into memory
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			//Establish connection
			connection = DriverManager.getConnection(url1, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{

			if(connection!=null){
				System.out.println("Connected successfully.");
				java.sql.Statement stmt1 = connection.createStatement();
				ResultSet rs1 = stmt1.executeQuery("select "+Field+ " from "+ "D9331CO"+Region+"."+Tablename+" where "+keyfield+"="+keyvalue+","+keyfield1+"="+keyvalue1+","+keyfield2+"="+keyvalue2+","+keyfield3+"="+keyvalue3);

				ResultSetMetaData rsmd=rs1.getMetaData();
				int colnum1=rsmd.getColumnCount();
				System.out.println(colnum1);
				while(rs1.next()){
					for(int i =1;i<=colnum1;i++){

						String columnValue = rs1.getString(i);


					}
				}}
		}
		try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}*/
	public static String DB2Validation(String Field,String Region,String  Tablename,String keyfield,String keyvalue1,String keyfield1,String keyvalue) throws SQLException {
		String columnValue=null;
		String url1="jdbc:db2://GWYA8002:50002/DB0T";
		String user= Constants.dbuser;
		String password=Constants.passwd;
		Connection connection = null;
		//String columnValue = null;
		try {
			//Load class into memory
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			//Establish connection
			connection = DriverManager.getConnection(url1, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{

			if(connection!=null){
				System.out.println("Connected successfully.");
				System.out.println("select "+Field+ " from "+ Region+"."+Tablename+" where "+keyfield+"='"+keyvalue1+"' AND "+keyfield1+"="+keyvalue);
				Statement stmt1 = connection.createStatement();
			ResultSet rs1 = stmt1.executeQuery("select "+Field+ " from "+ Region+"."+Tablename+" where "+keyfield+"='"+keyvalue1+"' AND "+keyfield1+"='"+keyvalue+"'");
			
				ResultSetMetaData rsmd=rs1.getMetaData();
				int colnum1=rsmd.getColumnCount();
				System.out.println(colnum1);
				while(rs1.next()){
					for(int i =1;i<=colnum1;i++){

						columnValue = rs1.getString(i);


					}
				}}
		}
		try {
			connection.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return columnValue;
	}


	public static String DB2Validation(String Field,String Region,String Tablename,String keyfield,String keyvalue,String keyfield1,String keyvalue1,String keyfield2,String keyvalue2) throws SQLException {

		String url1="jdbc:db2://GWYA8002:50002/DB0T";
		
		String user= Constants.dbuser;
		String password=Constants.passwd;
		Connection connection = null;
		String columnValue = null;
		try {
			//Load class into memory
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			//Establish connection
			connection = DriverManager.getConnection(url1, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{

			if(connection!=null){
				System.out.println("Connected successfully.");
				Statement stmt1 = connection.createStatement();
			
				//ResultSet rs1 = stmt1.executeQuery("select "+Field+ " from "+ "D9331CO"+Region+"."+Tablename+" where "+keyfield+"="+keyvalue+","+keyfield1+"="+keyvalue1+","+keyfield2+"="+keyvalue2+","+keyfield3+"="+keyvalue3+","+keyfield4+"="+keyvalue4);
				ResultSet rs1 = stmt1.executeQuery("select "+Field+ " from "+Region+"."+Tablename+" where "+keyfield+"="+keyvalue+" and "+keyfield1+"="+keyvalue1+" and "+keyfield2+"="+keyvalue2);
              
				ResultSetMetaData rsmd=rs1.getMetaData();
				int colnum1=rsmd.getColumnCount();
				System.out.println(colnum1);
				while(rs1.next()){
					for(int i =1;i<=colnum1;i++){

						 columnValue = rs1.getString(i);
						System.out.println("The result of query is:"+columnValue);	

}
				}}
		}
		try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return columnValue;

	}

public static String DB2Validation(String Field,String Region,String Tablename,String keyfield,String keyvalue,int keyfield1,String keyvalue1,String keyfield2,int keyvalue2) throws SQLException {
		//String Field,String Region,String  Tablename,String keyfield,String keyvalue,String keyfield1,String keyvalue1,

	String url1="jdbc:db2://GWYA8002:50002/DB0T";
	//String user=prop.getProperty("username");
	//String password=prop.getProperty("password");
	String user= Constants.dbuser;
	String password=Constants.passwd;
	Connection connection = null;
	String columnValue = null;
	try {
		//Load class into memory
		Class.forName("com.ibm.db2.jcc.DB2Driver");
		//Establish connection
		connection = DriverManager.getConnection(url1, user, password);
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	finally{

		if(connection!=null){
			System.out.println("Connected successfully.");
			Statement stmt1 = connection.createStatement();
			
			ResultSet rs1 = stmt1.executeQuery("select "+Field+ " from "+Region+"."+Tablename+" where "+keyfield+"="+keyvalue+" and "+keyfield1+"="+keyvalue1+" and "+keyfield2+"="+keyvalue2);
                                                
					

			ResultSetMetaData rsmd=rs1.getMetaData();
			int colnum1=rsmd.getColumnCount();
			System.out.println(colnum1);
			while(rs1.next()){
				for(int i =1;i<=colnum1;i++){

					columnValue = rs1.getString(i);
					 
					}
				}}
		}



		try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
return columnValue;
	}
	
	public static List DB2_return_mutliple_values(String Field,String Region,String  Tablename,String keyfield,String keyvalue,String keyfield1,String keyfield2,String keyfield3) throws SQLException {
		String columnValue=null;
		String url1="jdbc:db2://GWYA8002:50002/DB0T";
		String user= Constants.dbuser;
		String password=Constants.passwd;
		Connection connection = null;
		ArrayList<String> dbvalues= new ArrayList<String>();
		try {
			//Load class into memory
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			//Establish connection
			connection = DriverManager.getConnection(url1, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{

			if(connection!=null){
				System.out.println("Connected successfully.");
				Statement stmt1 = connection.createStatement();
				ResultSet rs1 = stmt1.executeQuery("select "+Field+","+keyfield1+","+keyfield2+","+keyfield3+ " from "+ Region+"."+Tablename+" where "+keyfield+"="+keyvalue);

				ResultSetMetaData rsmd=rs1.getMetaData();
				int colnum1=rsmd.getColumnCount();
				System.out.println(colnum1);
				while(rs1.next()){
					for(int i =1;i<=colnum1;i++){

						columnValue = rs1.getString(i);
						dbvalues.add(columnValue);


					}
				}}
		}
		try {
			connection.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dbvalues;
	}

	public static List DB2_return_three_values(String Field,String Region,String  Tablename,String keyfield1,String keyfield2,String inp_key1,String inp_val1,String inp_key2,String inp_val2,String inp_key3,String inp_val3,String inp_key4,String inp_val4) throws SQLException {
													// kfield1, db, tablename, i_field1, i_value1, kfield2, kfield3, i_field1, i_value1, i_field2, i_value2, i_field3, i_value3, i_field4, i_value4);
		String columnValue=null;
		//String keyval="keyvalue";
		String url1="jdbc:db2://GWYA8002:50002/DB0T";
		String user= Constants.dbuser;
		String password=Constants.passwd;
		Connection connection = null;
		ArrayList<String> dbvalues= new ArrayList<String>();
		try {
			//Load class into memory
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			//Establish connection
			connection = DriverManager.getConnection(url1, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{

			if(connection!=null){
				System.out.println("Connected successfully.");
				Statement stmt1 = connection.createStatement();
				System.out.println("select "+Field+","+keyfield1+","+keyfield2+ " from "+ Region+"."+Tablename+" where "  +inp_key1+ "='"+inp_val1+ "' and " +inp_key2+ "="+inp_val2+ " and " +inp_key3+ "="+inp_val3+ " and " +inp_key4+ "='"+inp_val4+"' FETCH FIRST ROW ONLY");
				ResultSet rs1 = stmt1.executeQuery("select "+Field+","+keyfield1+","+keyfield2+ " from "+ Region+"."+Tablename+" where "  +inp_key1+ "='"+inp_val1+ "' and " +inp_key2+ "="+inp_val2+ " and " +inp_key3+ "="+inp_val3+ " and " +inp_key4+ "='"+inp_val4+"' FETCH FIRST ROW ONLY");

				ResultSetMetaData rsmd=rs1.getMetaData();
				int colnum1=rsmd.getColumnCount();
				System.out.println(colnum1);
				while(rs1.next()){
					for(int i =1;i<=colnum1;i++){

						columnValue = rs1.getString(i);
						dbvalues.add(columnValue);


					}
				}}
		}
		try {
			connection.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dbvalues;
	}
	
	public static List DB2_return_one_value(String Field, String Region, String Tablename, 
			String inp_key1, String inp_val1, String inp_key2, String inp_val2, String inp_key3,
			String inp_val3, String inp_key4, String inp_val4,String inp_key5, String inp_val5) throws SQLException {
		// kfield1, db, tablename, i_field1, i_value1, kfield2, kfield3,
		// i_field1, i_value1, i_field2, i_value2, i_field3, i_value3, i_field4,
		// i_value4);
		String columnValue = null;
		// String keyval="keyvalue";
		String url1 = "jdbc:db2://GWYA8002:50002/DB0T";
		String user = Constants.dbuser;
		String password = Constants.passwd;
		Connection connection = null;
		ArrayList<String> dbvalues = new ArrayList<String>();
		try {
			// Load class into memory
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			// Establish connection
			connection = DriverManager.getConnection(url1, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			if (connection != null) {
				System.out.println("Connected successfully.");
				Statement stmt1 = connection.createStatement();
				System.out.println("select " + Field +   " from " + Region + "."
						+ Tablename + " where " + inp_key1 + "='" + inp_val1 + "' and " + inp_key2 + "=" + inp_val2
						+ " and " + inp_key3 + "=" + inp_val3 + " and " + inp_key4 + "='" + inp_val4 
						+ "' and " + inp_key5 + "=" + inp_val5 +" FETCH FIRST ROW ONLY");
				ResultSet rs1 = stmt1.executeQuery("select " + Field +  " from "
						+ Region + "." + Tablename + " where " + inp_key1 + "='" + inp_val1 + "' and " + inp_key2 + "="
						+ inp_val2 + " and " + inp_key3 + "=" + inp_val3 + " and " + inp_key4 + "='" + inp_val4
						+ "' and " + inp_key5 + "=" + inp_val5 +" FETCH FIRST ROW ONLY");

				ResultSetMetaData rsmd = rs1.getMetaData();
				int colnum1 = rsmd.getColumnCount();
				System.out.println(colnum1);
				while (rs1.next()) {
					for (int i = 1; i <= colnum1; i++) {

						columnValue = rs1.getString(i);
						dbvalues.add(columnValue);

					}
				}
			}
		}
		try {
			connection.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dbvalues;
	}
	
	public static String DB2Validation_Div(String Field,String Region,String Tablename,String keyfield,String keyvalue,String keyfield1,String keyvalue1) throws SQLException {
		String columnValue=null;
		String url1="jdbc:db2://GWYA8002:50002/DB0T";
		String user= Constants.dbuser;
		String password=Constants.passwd;
		Connection connection = null;
		try {
			//Load class into memory
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			//Establish connection
			connection = DriverManager.getConnection(url1, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{

			if(connection!=null){
				System.out.println("Connected successfully.");
				Statement stmt1 = connection.createStatement();
				ResultSet rs1 = stmt1.executeQuery("select "+Field+ " from "+ Region+"."+Tablename+" where "+keyfield+"='"+keyvalue+"' AND "+keyfield1+"="+keyvalue1+ " FETCH First row only");

				ResultSetMetaData rsmd=rs1.getMetaData();
				int colnum1=rsmd.getColumnCount();
				System.out.println(colnum1);
				while(rs1.next()){
					for(int i =1;i<=colnum1;i++){

						columnValue = rs1.getString(i);


					}
				}}
		}
		try {
			connection.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return columnValue;
	}
	
	public static String Total_DB2Validation_Div(String Field,String Region,String  Tablename,String keyfield,String keyvalue,String keyfield1,String keyvalue1) throws SQLException {
		String columnValue=null;
		String url1="jdbc:db2://GWYA8002:50002/DB0T";
		String user= Constants.dbuser;
		String password=Constants.passwd;
		Connection connection = null;
		try {
			//Load class into memory
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			//Establish connection
			connection = DriverManager.getConnection(url1, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{

			if(connection!=null){
				System.out.println("Connected successfully.");
				Statement stmt1 = connection.createStatement();
				ResultSet rs1 = stmt1.executeQuery("select SUM("+Field+ ") from "+ Region+"."+Tablename+" where "+keyfield+"='"+keyvalue+"' AND "+keyfield1+"="+keyvalue1);

				ResultSetMetaData rsmd=rs1.getMetaData();
				int colnum1=rsmd.getColumnCount();
				System.out.println(colnum1);
				while(rs1.next()){
					for(int i =1;i<=colnum1;i++){

						columnValue = rs1.getString(i);


					}
				}}
		}
		try {
			connection.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return columnValue;
	}
	
	public static String Total_DB2Validation_DivInputThree(String Field,String Region,String  Tablename,String keyfield,String keyvalue,String keyfield1,String keyvalue1,String keyfield2,String keyfield3) throws SQLException {
		String columnValue=null;
		String url1="jdbc:db2://GWYA8002:50002/DB0T";
		String user= Constants.dbuser;
		String password=Constants.passwd;
		Connection connection = null;
		try {
			//Load class into memory
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			//Establish connection
			connection = DriverManager.getConnection(url1, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{

			if(connection!=null){
				System.out.println("Connected successfully.");
				Statement stmt1 = connection.createStatement();
				ResultSet rs1 = stmt1.executeQuery("select SUM("+Field+ ") from "+ Region+"."+Tablename+" where "+keyfield+"='"+keyvalue+"' AND "+keyfield1+"="+keyvalue1+ " AND " +keyfield2+"="+keyfield3);

				ResultSetMetaData rsmd=rs1.getMetaData();
				int colnum1=rsmd.getColumnCount();
				System.out.println(colnum1);
				while(rs1.next()){
					for(int i =1;i<=colnum1;i++){

						columnValue = rs1.getString(i);


					}
				}}
		}
		try {
			connection.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return columnValue;
	}
	
	
	public static String SingleOutput_DB2Validation_DivInputFourKeyValue(String Field,String Region,String  Tablename,String keyfield,String keyvalue,String keyfield1,String keyvalue1,String keyfield2,String keyfield3,String keyvalue2,String keyvalue3) throws SQLException {
		String columnValue=null;
		String url1="jdbc:db2://GWYA8002:50002/DB0T";
		String user= Constants.dbuser;
		String password=Constants.passwd;
		Connection connection = null;
		try {
			//Load class into memory
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			//Establish connection
			connection = DriverManager.getConnection(url1, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{

			if(connection!=null){
				System.out.println("Connected successfully.");
				Statement stmt1 = connection.createStatement();
				System.out.println("select " +Field+ " from "+ Region+"."+Tablename+" where "+keyfield+"='"+keyvalue+"' AND "+keyfield1+"="+keyvalue1+ " AND " +keyfield2+"="+keyvalue2+ " AND " +keyfield3+"="+keyvalue3+ " Fetch First Row Only");
				ResultSet rs1 = stmt1.executeQuery("select " +Field+ " from "+ Region+"."+Tablename+" where "+keyfield+"='"+keyvalue+"' AND "+keyfield1+"="+keyvalue1+ " AND " +keyfield2+"="+keyvalue2+ " AND " +keyfield3+"="+keyvalue3+ " Fetch First Row Only");

				ResultSetMetaData rsmd=rs1.getMetaData();
				int colnum1=rsmd.getColumnCount();
				System.out.println(colnum1);
				while(rs1.next()){
					for(int i =1;i<=colnum1;i++){

						columnValue = rs1.getString(i);


					}
				}}
		}
		try {
			connection.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return columnValue;
	}
	
	
	public static String SingleOutput_DB2Validation_DivInputFour(String Field,String Region,String  Tablename,String keyfield,String keyvalue,String keyfield1,String keyvalue1,String keyfield2,String keyfield3) throws SQLException {
		String columnValue=null;
		String url1="jdbc:db2://GWYA8002:50002/DB0T";
		String user= Constants.dbuser;
		String password=Constants.passwd;
		Connection connection = null;
		try {
			//Load class into memory
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			//Establish connection
			connection = DriverManager.getConnection(url1, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{

			if(connection!=null){
				System.out.println("Connected successfully.");
				Statement stmt1 = connection.createStatement();
				ResultSet rs1 = stmt1.executeQuery("select " +Field+ " from "+ Region+"."+Tablename+" where "+keyfield+"='"+keyvalue+"' AND "+keyfield1+"="+keyvalue1+ " AND " +keyfield2+"="+keyfield3+ " Fetch First Row Only");

				ResultSetMetaData rsmd=rs1.getMetaData();
				int colnum1=rsmd.getColumnCount();
				System.out.println(colnum1);
				while(rs1.next()){
					for(int i =1;i<=colnum1;i++){

						columnValue = rs1.getString(i);


					}
				}}
		}
		try {
			connection.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return columnValue;
	}
	
	public static List Ret_TwoValues_DB2Validation_InputFour(String Field,String field1,String Region,String  Tablename,String keyfield,String keyvalue,String keyfield1,String keyvalue1,String keyfield2,String keyvalue2,String keyfield3,String keyvalue3) throws SQLException {
		String columnValue=null;
		String url1="jdbc:db2://GWYA8002:50002/DB0T";
		String user= Constants.dbuser;
		String password=Constants.passwd;
		Connection connection = null;
		ArrayList<String> dbvalues = new ArrayList<String>();
		try {
			//Load class into memory
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			//Establish connection
			connection = DriverManager.getConnection(url1, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{

			if(connection!=null){
				System.out.println("Connected successfully.");
				Statement stmt1 = connection.createStatement();
				System.out.println("select "+Field+ ", "+field1+ " from "+ Region+"."+Tablename+" where "+keyfield+"='"+keyvalue+"' AND "+keyfield1+"="+keyvalue1+ " AND "+keyfield2+"="+keyvalue2+ " AND " +keyfield3+ "=" +keyvalue3);
				ResultSet rs1 = stmt1.executeQuery("select "+Field+ ", "+field1+ " from "+ Region+"."+Tablename+" where "+keyfield+"='"+keyvalue+"' AND "+keyfield1+"="+keyvalue1+ " AND "+keyfield2+"="+keyvalue2+ " AND " +keyfield3+ "=" +keyvalue3);

				ResultSetMetaData rsmd=rs1.getMetaData();
				int colnum1=rsmd.getColumnCount();
				System.out.println(colnum1);
				while(rs1.next()){
					for(int i =1;i<=colnum1;i++){

						columnValue = rs1.getString(i);
						dbvalues.add(columnValue);

					}
				}}
		}
		try {
			connection.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dbvalues;
	}
	public static List Ret_TwoValues_DB2Validation_Div(String Field,String field1,String Region,String  Tablename,String keyfield,String keyvalue,String keyfield1,String keyvalue1) throws SQLException {
		String columnValue=null;
		String url1="jdbc:db2://GWYA8002:50002/DB0T";
		String user= Constants.dbuser;
		String password=Constants.passwd;
		Connection connection = null;
		ArrayList<String> dbvalues = new ArrayList<String>();
		try {
			//Load class into memory
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			//Establish connection
			connection = DriverManager.getConnection(url1, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{

			if(connection!=null){
				System.out.println("Connected successfully.");
				Statement stmt1 = connection.createStatement();
				ResultSet rs1 = stmt1.executeQuery("select "+Field+ ", "+field1+ " from "+ Region+"."+Tablename+" where "+keyfield+"='"+keyvalue+"' AND "+keyfield1+"="+keyvalue1);

				ResultSetMetaData rsmd=rs1.getMetaData();
				int colnum1=rsmd.getColumnCount();
				System.out.println(colnum1);
				while(rs1.next()){
					for(int i =1;i<=colnum1;i++){

						columnValue = rs1.getString(i);
						dbvalues.add(columnValue);

					}
				}}
		}
		try {
			connection.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dbvalues;
	}
	
	
	
	
	public static List Ret_TwoValues_DB2Validation_InputThree(String Field,String field1,String Region,String  Tablename,String keyfield,String keyvalue,String keyfield1,String keyvalue1,String keyfield2,String keyvalue2) throws SQLException {
		String columnValue=null;
		String url1="jdbc:db2://GWYA8002:50002/DB0T";
		String user= Constants.dbuser;
		String password=Constants.passwd;
		Connection connection = null;
		ArrayList<String> dbvalues = new ArrayList<String>();
		try {
			//Load class into memory
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			//Establish connection
			connection = DriverManager.getConnection(url1, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{

			if(connection!=null){
				System.out.println("Connected successfully.");
				Statement stmt1 = connection.createStatement();
				ResultSet rs1 = stmt1.executeQuery("select "+Field+ ", "+field1+ " from "+ Region+"."+Tablename+" where "+keyfield+"='"+keyvalue+"' AND "+keyfield1+"="+keyvalue1+ " AND "+keyfield2+"="+keyvalue2+ " FETCH FIRST ROW ONLY" );

				ResultSetMetaData rsmd=rs1.getMetaData();
				int colnum1=rsmd.getColumnCount();
				System.out.println(colnum1);
				while(rs1.next()){
					for(int i =1;i<=colnum1;i++){

						columnValue = rs1.getString(i);
						dbvalues.add(columnValue);

					}
				}}
		}
		try {
			connection.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dbvalues;
	}
	

// This DB2 function returns a single value and accepts 3 values after WHERE condition.
// First where condition should be a string and next 2 should be integer.
// Author: Vamsi
public static String Ret_OneValue_DB2Validation_InputThree(String column1, String tablename, String Region1,
String keyfield1,String keyvalue1,String keyfield2,String keyvalue2, String keyfield3, String keyvalue3) throws SQLException {
		String columnValue=null;
		String url1="jdbc:db2://GWYA8002:50002/DB0T";
		String user= Constants.dbuser;
		String password=Constants.passwd;
		String Region = Constants.reg;
		Connection connection = null;
		try {
			//Load class into memory
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			//Establish connection
			connection = DriverManager.getConnection(url1, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{

			if(connection!=null){
				System.out.println("Connected successfully.");
				Statement stmt1 = connection.createStatement();
				System.out.println("SELECT "+column1+ " FROM "+ Region+"."+tablename+" WHERE "+keyfield1+"='"+keyvalue1+"' AND "
				+keyfield2+"="+keyvalue2+" AND "+keyfield3+"="+keyvalue3+" WITH UR;");
				ResultSet rs1 = stmt1.executeQuery("SELECT "+column1+ " FROM "+ Region+"."+tablename+" WHERE "+keyfield1+"='"+keyvalue1+"' AND "
				+keyfield2+"="+keyvalue2+" AND "+keyfield3+"="+keyvalue3+" WITH UR;");
				
				ResultSetMetaData rsmd=rs1.getMetaData();
				
				int colnum1=rsmd.getColumnCount();
				System.out.println(colnum1);
				while(rs1.next()){
					for(int i =1;i<=colnum1;i++){

						columnValue = rs1.getString(i);


					}
				}}
		}
		try {
			connection.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return columnValue;
	}

//This DB2 method will return a single value when there are 4 inputs, first one being string and rest being integer fields along with their values//
public static String SingleOutputValue_DB2Validation_DivInputFour(String Field,String Region,String  Tablename,String keyfield,String keyvalue,String keyfield1,String keyvalue1,String keyfield2,String keyvalue2,String keyfield3,String keyvalue3) throws SQLException {
	String columnValue=null;
	String url1="jdbc:db2://GWYA8002:50002/DB0T";
	String user= Constants.dbuser;
	String password=Constants.passwd;
	Connection connection = null;
	try {
		//Load class into memory
		Class.forName("com.ibm.db2.jcc.DB2Driver");
		//Establish connection
		connection = DriverManager.getConnection(url1, user, password);
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	finally{

		if(connection!=null){
			System.out.println("Connected successfully.");
			Statement stmt1 = connection.createStatement();
			System.out.println("select " +Field+ " from "+ Region+"."+Tablename+" where "+keyfield+"='"+keyvalue+"' AND "+keyfield1+"="+keyvalue1+ " AND " +keyfield2+"="+keyvalue2+ " AND " +keyfield3+"="+keyvalue3+ " Fetch First Row Only");
			ResultSet rs1 = stmt1.executeQuery("select " +Field+ " from "+ Region+"."+Tablename+" where "+keyfield+"='"+keyvalue+"' AND "+keyfield1+"="+keyvalue1+ " AND " +keyfield2+"="+keyvalue2+ " AND " +keyfield3+"="+keyvalue3+ " Fetch First Row Only");

			ResultSetMetaData rsmd=rs1.getMetaData();
			int colnum1=rsmd.getColumnCount();
			System.out.println(colnum1);
			while(rs1.next()){
				for(int i =1;i<=colnum1;i++){

					columnValue = rs1.getString(i);

				}
			}}
	}
	try {
		connection.close();
		
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return columnValue;
}

public static void DateComparision(String D1, String D2) throws  java.text.ParseException
	{
		 SimpleDateFormat sdf = new SimpleDateFormat("MMddyy");
	        Date date1 = sdf.parse(D1);
	        Date date2 = sdf.parse(D2);

	        System.out.println("date1 : " + sdf.format(date1));
	        System.out.println("date2 : " + sdf.format(date2));

	        if (date1.compareTo(date2) > 0) {
	            System.out.println("Date1 is after Date2");
	        } else if (date1.compareTo(date2) < 0) {
	            System.out.println("Date1 is before Date2");
	        } else if (date1.compareTo(date2) == 0) {
	            System.out.println("Date1 is equal to Date2");
	        } else {
	            System.out.println("How to get here?");
	        }

	}	
//This method returns a single output values
// There are 2 input - one is a char and 2nd is int
public static String SingleOutput_DB2Validation_DivInputThreeKeyValue(String Field,String Region,String  Tablename,String keyfield,String keyvalue,String keyfield1,String keyvalue1,String keyfield2,String keyvalue2) throws SQLException {
	String columnValue=null;
	String url1="jdbc:db2://GWYA8002:50002/DB0T";
	String user= Constants.dbuser;
	String password=Constants.passwd;
	Connection connection = null;
	try {
		//Load class into memory
		Class.forName("com.ibm.db2.jcc.DB2Driver");
		//Establish connection
		connection = DriverManager.getConnection(url1, user, password);
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	finally{

		if(connection!=null){
			System.out.println("Connected successfully.");
			Statement stmt1 = connection.createStatement();
			System.out.println("select " +Field+ " from "+ Region+"."+Tablename+" where "+keyfield+"='"+keyvalue+"' AND "+keyfield1+"="+keyvalue1+ "AND " +keyfield2+"="+keyvalue2+ " Fetch First Row Only");
			ResultSet rs1 = stmt1.executeQuery("select " +Field+ " from "+ Region+"."+Tablename+" where "+keyfield+"='"+keyvalue+"' AND "+keyfield1+"="+keyvalue1+ " AND " +keyfield2+"="+keyvalue2+" Fetch First Row Only");

			ResultSetMetaData rsmd=rs1.getMetaData();
			int colnum1=rsmd.getColumnCount();
			System.out.println(colnum1);
			while(rs1.next()){
				for(int i =1;i<=colnum1;i++){

					columnValue = rs1.getString(i);


				}
			}}
	}
	try {
		connection.close();
		
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return columnValue;
}
/*public static void TakeScreenshot() 
{ 
    try { 
        Thread.sleep(120); 
        Robot r = new Robot(); 

        // It saves screenshot to desired path 
        String path = "C:\\Users\\sjoseph9\\Desktop\\Screen\\Shot.jpg"; 

        // Used to get ScreenSize and capture image 
       // Rectangle capture =new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
        
        BufferedImage Image = r.createScreenCapture(capture); 
        ImageIO.write(Image, "jpg", new File(path)); 
        System.out.println("Screenshot saved"); 
    } 
    catch (AWTException | IOException | InterruptedException ex) { 
        System.out.println(ex); 
    } 
}*/
public void InquireFeeMax(String div,String schd,String cpt,String screen) throws GeneralLeanFtException, InterruptedException{
	PS475 p4 = new PS475();
	p4.schedule.setText(schd);
	p4.proc_code.setText(cpt);		
	p4.ScreenNameA.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	Thread.sleep(1000);
}

public void InquireProcCOde(String comm,String fr,String cpt_code) throws GeneralLeanFtException, InterruptedException{
		Procedure_PCFM p4 = new Procedure_PCFM();
	p4.command.setText(comm);
	p4.from.setText(fr);		
	p4.proc_code.setText(cpt_code);
	p4.proc_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	Thread.sleep(900);
}
//Shivi for Anesthesia
public void InquireFeeCode(String date,String place,String provType,String icp,String cpt) throws GeneralLeanFtException, InterruptedException {
	FeeMax_TB822 ftb=new FeeMax_TB822();
	ftb.dos.setText(date);
	ftb.pos.setText(place);		
	ftb.providerType.setText(provType);
	ftb.icp.setText("4");
	ftb.cpt.setText(cpt);
	ftb.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	Thread.sleep(500);

}


public static String SingleOutput_DB2Validation_DivInputThreeKeyValues(String Field,String Region,String  Tablename,String keyfield,String keyvalue,String keyfield1,String keyvalue1,String keyfield2,String keyvalue2) throws SQLException {
	String columnValue=null;
	String url1="jdbc:db2://GWYA8002:50002/DB0T";
	String user= Constants.dbuser;
	String password=Constants.passwd;
	Connection connection = null;
	try {
		//Load class into memory
		Class.forName("com.ibm.db2.jcc.DB2Driver");
		//Establish connection
		connection = DriverManager.getConnection(url1, user, password);
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	finally{

		if(connection!=null){
			System.out.println("Connected successfully.");
			Statement stmt1 = connection.createStatement();
			System.out.println("select " +Field+ " from "+ Region+"."+Tablename+" where "+keyfield+"='"+keyvalue+"' AND "+keyfield1+"='"+keyvalue1+"' AND " +keyfield2+"="+keyvalue2+" Fetch First Row Only");
			ResultSet rs1 = stmt1.executeQuery("select " +Field+ " from "+ Region+"."+Tablename+" where "+keyfield+"='"+keyvalue+"' AND "+keyfield1+"='"+keyvalue1+"' AND " +keyfield2+"="+keyvalue2+" Fetch First Row Only");
			
			ResultSetMetaData rsmd=rs1.getMetaData();
			int colnum1=rsmd.getColumnCount();
			System.out.println(colnum1);
			while(rs1.next()){
				for(int i =1;i<=colnum1;i++){

					columnValue = rs1.getString(i);
					

				}
			}}
	}
	try {
		connection.close();
		
	} catch (SQLException e) {
		e.printStackTrace();
	}
	System.out.println(columnValue);
	return columnValue;
}
//}
public  List getINITCODE(String screenname,String STATUS,int len) throws GeneralLeanFtException, InterruptedException
{
	Screen status_screen = null;
	Field statusnum;
	int status_found = 0;
	String act_status_code = null,act_rev_code = null,req_status = null;
	if(screenname.equalsIgnoreCase("HO409"))
	{
		status_screen = hos_claim_inq;
	}
	else if(screenname.equalsIgnoreCase("CL209"))
	{
		status_screen = phy_claim_inq;
	}


	
	for(int rev=8;rev<=22;rev++)
	{	
		Thread.sleep(1000);
		statusnum = status_screen.describe(Field.class, new FieldDescription.Builder()
			.length(2).startPosition(rev, 22).isProtected(true).build());
		act_status_code = statusnum.getText();
		if(act_status_code.equals(""))
		{	
			break;
		}	
		if(STATUS.equalsIgnoreCase(act_status_code) )
		{
			Thread.sleep(1000);
			status_found = 1;
			break;
		}
	}
	if (status_found ==0)
	{	
		for(int rev=8;rev<=22;rev++)
		{	
			Thread.sleep(1000);
			statusnum=status_screen.describe(Field.class, new FieldDescription.Builder()
				.length(2).startPosition(rev, 62).isProtected(true).build());
			act_status_code = statusnum.getText();
			if(act_status_code.equals(""))
			{
				break;
			}	
			if(STATUS.equalsIgnoreCase(act_status_code))
			{
				Thread.sleep(1000);
				status_found = 1;
				break;
			}
			
		}
		
	}
	Thread.sleep(1000);
	//req_rev = String.valueOf(review_found);
	ArrayList<String> list = new ArrayList();
	if(status_found==0)
	{
		
		list.add("Status not found");
		
	}
	else
	{	
		
		list.add(act_status_code);
		
	}	
	return list;
	
}
 public void takeScreenshot(String ScreenName,String Screenshot) throws GeneralLeanFtException, InterruptedException, IOException
 {

     if ((ScreenName.equalsIgnoreCase("CL209")) || (ScreenName.equalsIgnoreCase("CL202")))
    
	 {
    	 Physician_CL209 phy_screen1=new Physician_CL209();
 		RenderedImage im = phy_screen1.screenName.getSnapshot();
      ImageIO.write(im, "jpg", new File("C:\\Users\\agupt201\\Desktop\\Screen\\" +Screenshot+ ".jpg"));
     }
     else if (ScreenName.equalsIgnoreCase("CL201")) {
    	 Physician_CL201 phy_screen1=new Physician_CL201();
  		RenderedImage im = phy_screen1.cur_screen.getSnapshot();
       ImageIO.write(im, "jpg", new File("C:\\Users\\agupt201\\Desktop\\Screen\\" +Screenshot+ ".jpg"));
	}
 }


 
 
 public String AddUnits(String screenname,String units,int len) throws InterruptedException, GeneralLeanFtException, IOException {

	 String sumValue=null;
		Screen rev_screen = null;
		Hospital_HO400 H4=new Hospital_HO400();
		Field unitnum;
		
		String act_rev_code = null;
		int previous=0,sum,next;
		if(screenname.equalsIgnoreCase("HO400"))
		{
			rev_screen = hos_claim_inq;
		}
		for(int UNITFOUND=11;UNITFOUND<=14;UNITFOUND++)
		{	
			Thread.sleep(1000);
			unitnum = rev_screen.describe(Field.class, new FieldDescription.Builder().length(6).startPosition(UNITFOUND, 12).isProtected(true).build());
			act_rev_code = unitnum.getText();
			
			
			
			if(!act_rev_code.equals("")){
			
				next = Integer.parseInt(act_rev_code);
			
		
		    sum=previous+next;
			previous=next;
			previous=sum;
			if(  (!(H4.hos_msg_val().contains("NO MORE DETAILS"))) & (UNITFOUND==14)  ) {
				H4.hos_mainscreen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
				Thread.sleep(1000);
				UNITFOUND=10;
				
			}
			

		}
			if(act_rev_code.equals(""))
				{	
					System.out.println("Total Units are" +previous);
					break;
				}

 }
		sumValue=String.valueOf(previous);
		return sumValue;
}
 public void InquireProviderNo(String prov_1,String prov_2,String screen) throws GeneralLeanFtException, InterruptedException{
		PS308 p4 = new PS308();
		p4.prov_Code1.setText(prov_1);
		p4.prov_Code2.setText(prov_2);		
		p4.ScreenNameA.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		Thread.sleep(1000);
	}

 /*public  void getLegalEntityClearDetails(String screenname) throws GeneralLeanFtException, InterruptedException, IOException, ParseException
	{
	 TB470_Screen=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build());

	 Physician_CL202 cl202=new Physician_CL202();
	 boolean flag=false;
	 boolean flag1=false;

	 
	 String finId=Physician_CL202.Fin_id;
	 String leg=Physician_CL202.Legal_id;
		Screen tb_screen = null;
		Field legalID,EFFDate,finID,ExpDate,Excel_ID;
		int field_found = 0;
		String act_legalID_val = null,act_finID_val = null;
		if(screenname.equalsIgnoreCase("TB470"))
		{
			tb_screen = TB470_Screen;
		}
		
		else if(screenname.equalsIgnoreCase("CL209"))
		{
			tb_screen = phy_claim_inq;
		}

		
		for(int rev=8;rev<=22;rev++)
		{	
			Thread.sleep(1000);
			
			
			
			legalID =	Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
					.length(5).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(rev).setColumn(20)).build());
			
			
			act_legalID_val = legalID.getText();
			
		
			if(act_legalID_val.equals(""))
			{	
				break;
			}	
			if(act_legalID_val.equalsIgnoreCase(leg) )
			{
				Thread.sleep(1000);
				field_found = 1;

				finID =	Desktop.describe(Window.class, new WindowDescription.Builder()
						.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
										.length(5).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(rev).setColumn(30)).build());


				act_finID_val=finID.getText();
				break;
			}
		}
		if (field_found ==1)
		{	
			for(int rev=8;rev<=22;rev++)
			{	
				Thread.sleep(1000);
				if(act_finID_val.equals(""))
				{
					break;
				}	
				if(act_finID_val.equalsIgnoreCase(finId))
				{
					Thread.sleep(1000);
					field_found = 1;
					
					
					
					if(screenname.equalsIgnoreCase("TB470"))
					
					{
					
					EFFDate=Desktop.describe(Window.class, new WindowDescription.Builder()
							.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(6).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(rev).setColumn(61)).build());
					Excel_ID=Desktop.describe(Window.class, new WindowDescription.Builder()
							.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(4).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(rev).setColumn(71)).build());
					
					String act_EFFDate = EFFDate.getText();
					String act_EXCELDate = EFFDate.getText();
					if(act_EXCELDate.equals("")){
						System.out.println("NO entry is there for Excel date: pass");
						flag1=true;	
					}
					
					else{
						System.out.println("Entry is there for Excel date:fail");
						flag1=false;
					}
					if(act_EFFDate.equals(""))
					{
						System.out.println("NO entry is there for expire date: pass");
						flag=true;
						Assert.assertTrue(flag1);
						Assert.assertTrue(flag);
						break;
					}	
					
					else{
						Date d=new Date();
						SimpleDateFormat format1 = new SimpleDateFormat("MMddyy");
						String n=format1.format(d);	
						System.out.println(n);
					   SimpleDateFormat sdf = new SimpleDateFormat("MMddyy");
						Date date1 = sdf.parse(n);
						System.out.println("date 1 is :"+ date1);
						Date date2 = sdf.parse( act_EFFDate);
						System.out.println("date 2 is :"+ date2);
						
						
						long daysBetween = ChronoUnit.DAYS.between(date1.toInstant(), date2.toInstant());
						    System.out.println("Days Difference between Frm_Date and Thru_Date is" +daysBetween);
						    
					String temp=String.valueOf(daysBetween);
					if (!temp.contains("-")) {
						System.out.println("end date is correct");
						flag=true;
					}
					else if(temp.contains("0")){
						System.out.println("date is equal");
						
						flag=true;
					}
					else{
						System.out.println("end date is less than today date:error");
						
					}
										
				
					}
					
					Assert.assertTrue(flag1);
					Assert.assertTrue(flag);
					break;
				}
					
					 if (screenname.equalsIgnoreCase("TB477")) {
						
						
						ExpDate=	Desktop.describe(Window.class, new WindowDescription.Builder()
								.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
								.length(6).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(rev+1).setColumn(71)).build());
						
						
						String act_ExpDate = ExpDate.getText();
						if(act_ExpDate.equals(""))
						{
							System.out.println("NO entry is there: pass");
							flag=true;
							break;
						}	
						
						else{
							Date d=new Date();
							System.out.println(d);
							SimpleDateFormat format1 = new SimpleDateFormat("MMddyy");
							String n=format1.format(d);	
							System.out.println(n);
						SimpleDateFormat sdf = new SimpleDateFormat("MMddyy");
							Date date1 = sdf.parse(n);
							System.out.println("date 1 is :"+ date1);
							Date date2 = sdf.parse( act_ExpDate);
							System.out.println("date 2 is :"+ date2);
							
							
							long daysBetween = ChronoUnit.DAYS.between(date1.toInstant(), date2.toInstant());
							    System.out.println("Days Difference between Frm_Date and Thru_Date is" +daysBetween);
							    
						String temp=String.valueOf(daysBetween);
						if (temp.contains("-")) {
							System.out.println("date is expired");
							flag=true;
						}
						else if(temp.contains("0")){
							System.out.println("date is equal");
							
							flag=true;
						}
						else{
							System.out.println("expired date is not before date: error");
							
						}
											
						}
						
						break;
						
					}
				
			}
		}
			
		}
	
Assert.assertTrue(flag);	
	
		
}
 */
 
 
 
 
 public  void getLegalEntityDetailsOnTB470(String screenname) throws GeneralLeanFtException, InterruptedException, IOException, ParseException
	{
	 TB470_Screen=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build());

	 Physician_CL202 cl202=new Physician_CL202();
	 boolean flag=false;
	 boolean flag1=false;
	 int rev=0;
	 String act_EFFDate=null;	 
	 String finId=Physician_CL202.Fin_id;
	 String leg=Physician_CL202.Legal_id;
		Screen tb_screen = null;
		Field legalID,EFFDate,finID,ExpDate,Excel_ID;
		int field_found = 0;
		String act_legalID_val = null,act_finID_val = null;
		if(screenname.equalsIgnoreCase("TB470"))
		{
			tb_screen = TB470_Screen;
		}
		for(rev=8;rev<=22;rev++)
		{	
			Thread.sleep(1000);
			legalID =	Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
					.length(5).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(rev).setColumn(20)).build());
			
			
			act_legalID_val = legalID.getText();	
			if(act_legalID_val.equalsIgnoreCase(leg) )
			{
				Thread.sleep(1000);
				field_found = 1;

				EFFDate=Desktop.describe(Window.class, new WindowDescription.Builder()
						.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
						.length(6).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(rev).setColumn(61)).build());

				 act_EFFDate=EFFDate.getText();
				break;
			}
		}
		
		if(rev>22){
		System.out.println("There is not such record present for given legal id: pass");
		flag=true;
		}
					
					if(act_EFFDate.equals(""))
					{
						System.out.println("End date cannot be null: fail");
						flag=false;
					}	
					
					else{
						Date d=new Date();
						SimpleDateFormat format1 = new SimpleDateFormat("MMddyy");
						String n=format1.format(d);	
						System.out.println(n);
					   SimpleDateFormat sdf = new SimpleDateFormat("MMddyy");
						Date date1 = sdf.parse(n);
						System.out.println("date 1 is :"+ date1);
						Date date2 = sdf.parse( act_EFFDate);
						System.out.println("date 2 is :"+ date2);
						long daysBetween = ChronoUnit.DAYS.between(date1.toInstant(), date2.toInstant());
						    System.out.println("Days Difference between Frm_Date and Thru_Date is" +daysBetween);    
					String temp=String.valueOf(daysBetween);
					if (temp.contains("-")) {
						System.out.println("date is ok");
						flag=true;
					}
					else if(temp.contains("0")){
						System.out.println("date is ok");
						flag=true;
					}
					else{
						System.out.println("error");
					}
										
				
					}
					Assert.assertTrue(flag);		
}
 
 
 
 
 public  void getLegalEntityClearDetails(String screenname,String criteria) throws GeneralLeanFtException, InterruptedException, IOException, ParseException
	{
	 TB470_Screen=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build());

	 Physician_CL202 cl202=new Physician_CL202();
	 boolean flag=false;
	 boolean flag1=false;

	 
	 String finId=Physician_CL202.Fin_id;
	 String leg=Physician_CL202.Legal_id;
		Screen tb_screen = null;
		Field legalID,EFFDate,finID,ExpDate,Excel_ID;
		int field_found = 0;
		String act_legalID_val = null,act_finID_val = null;
		if(screenname.equalsIgnoreCase("TB470"))
		{
			tb_screen = TB470_Screen;
		}
		
		else if(screenname.equalsIgnoreCase("CL209"))
		{
			tb_screen = phy_claim_inq;
		}

		
		for(int rev=8;rev<=22;rev++)
		{	
			Thread.sleep(1000);
			
			
			
			legalID =	Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
					.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
					.length(5).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(rev).setColumn(20)).build());
			
			
			act_legalID_val = legalID.getText();
			
		
			if(act_legalID_val.equals(""))
			{	
				break;
			}	
			if(act_legalID_val.equalsIgnoreCase(leg) )
			{
				Thread.sleep(1000);
				field_found = 1;

				finID =	Desktop.describe(Window.class, new WindowDescription.Builder()
						.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
										.length(5).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(rev).setColumn(30)).build());


				act_finID_val=finID.getText();
				break;
			}
		}
		if (field_found ==1)
		{	
			for(int rev=8;rev<=22;rev++)
			{	
				Thread.sleep(1000);
				if(act_finID_val.equals(""))
				{
					break;
				}	
				if(act_finID_val.equalsIgnoreCase(finId))
				{
					Thread.sleep(1000);
					field_found = 1;
					
					
					
					if(screenname.equalsIgnoreCase("TB470"))
					
					{
					
					EFFDate=Desktop.describe(Window.class, new WindowDescription.Builder()
							.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(6).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(rev).setColumn(61)).build());
					Excel_ID=Desktop.describe(Window.class, new WindowDescription.Builder()
							.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(4).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(rev).setColumn(71)).build());
					
					String act_EFFDate = EFFDate.getText();
					String act_EXCELDate = EFFDate.getText();
					if(act_EXCELDate.equals("")){
						System.out.println("NO entry is there for Excel date: pass");
						flag1=true;	
					}
					
					else{
						System.out.println("Entry is there for Excel date:fail");
						flag1=false;
					}
					if(act_EFFDate.equals(""))
					{
						System.out.println("NO entry is there for expire date: pass");
						flag=true;
						Assert.assertTrue(flag1);
						Assert.assertTrue(flag);
						break;
					}	
					
					else{
						Date d=new Date();
						SimpleDateFormat format1 = new SimpleDateFormat("MMddyy");
						String n=format1.format(d);	
						System.out.println(n);
					   SimpleDateFormat sdf = new SimpleDateFormat("MMddyy");
						Date date1 = sdf.parse(n);
						System.out.println("date 1 is :"+ date1);
						Date date2 = sdf.parse( act_EFFDate);
						System.out.println("date 2 is :"+ date2);
						
						
						long daysBetween = ChronoUnit.DAYS.between(date1.toInstant(), date2.toInstant());
						    System.out.println("Days Difference between Frm_Date and Thru_Date is" +daysBetween);
						    
					String temp=String.valueOf(daysBetween);
					if (!temp.contains("-")) {
						System.out.println("end date is correct");
						flag=true;
					}
					else if(temp.contains("0")){
						System.out.println("date is equal");
						
						flag=true;
					}
					else{
						System.out.println("end date is less than today date:error");
						
					}
										
				
					}
					
					Assert.assertTrue(flag1);
					Assert.assertTrue(flag);
					break;
				}
					
					 if (screenname.equalsIgnoreCase("TB477")) {
						
						
						ExpDate=	Desktop.describe(Window.class, new WindowDescription.Builder()
								.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
								.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
								.length(6).isProtected(false).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(rev+1).setColumn(71)).build());
						
						
						String act_ExpDate = ExpDate.getText();
						
						
				if(criteria.equalsIgnoreCase("Not Met")){
						if(act_ExpDate.equals(""))
						{
							System.out.println("NO entry is there: pass");
							flag=true;
							break;
						}	
						
						else{
							Date d=new Date();
							System.out.println(d);
							SimpleDateFormat format1 = new SimpleDateFormat("MMddyy");
							String n=format1.format(d);	
							System.out.println(n);
						SimpleDateFormat sdf = new SimpleDateFormat("MMddyy");
							Date date1 = sdf.parse(n);
							System.out.println("date 1 is :"+ date1);
							Date date2 = sdf.parse( act_ExpDate);
							System.out.println("date 2 is :"+ date2);
							
							
							long daysBetween = ChronoUnit.DAYS.between(date1.toInstant(), date2.toInstant());
							    System.out.println("Days Difference between Frm_Date and Thru_Date is" +daysBetween);
							    
						String temp=String.valueOf(daysBetween);
						if (temp.contains("-")) {
							System.out.println("date is expired");
							flag=true;
						}
						else if(temp.contains("0")){
							System.out.println("date is equal");
							
							flag=true;
						}
						else{
							System.out.println("expired date is not before date: error");
							
						}
											
						}
						
						break;
						
					}
				
				//met
				
				if(criteria.equalsIgnoreCase("Met")){
						if(act_ExpDate.equals(""))
						{
							System.out.println("error: record should be present");
							break;
						}	
						
						else{
							Date d=new Date();
							System.out.println(d);
							SimpleDateFormat format1 = new SimpleDateFormat("MMddyy");
							String n=format1.format(d);	
							System.out.println(n);
						SimpleDateFormat sdf = new SimpleDateFormat("MMddyy");
							Date date1 = sdf.parse(n);
							System.out.println("date 1 is :"+ date1);
							Date date2 = sdf.parse( act_ExpDate);
							System.out.println("date 2 is :"+ date2);
							
							
							long daysBetween = ChronoUnit.DAYS.between(date1.toInstant(), date2.toInstant());
							    System.out.println("Days Difference between Frm_Date and Thru_Date is" +daysBetween);
							    
						String temp=String.valueOf(daysBetween);
						if (temp.contains("-")) {
							System.out.println("date is less:error");
							
						}
						else if(temp.contains("0")){
							System.out.println("date is equal:error");
				
						}
						else{
							System.out.println("expired date is after today date: pass");
							flag=true;
							
						}
											
						}
						
						break;
						
					}
				
			}
		}
			
		}
			
	
Assert.assertTrue(flag);	
		}
		
}
 
 

 @SuppressWarnings("deprecation")
public  void getDMEDetailsOnCL657(String screenname,String criteria) throws GeneralLeanFtException, InterruptedException, IOException, ParseException
	{
	 CL657_Screen=Desktop.describe(Window.class, new WindowDescription.Builder()
				.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
						.label("UNI").build());
	
	 Physician_CL201 cl201=new Physician_CL201();
	 CL657 cl657=new CL657();
	 boolean flag=false;
	 boolean flag1=false;

	 
	 String procCode=AdjudiproStepDefinition.pro_code;
	
		Screen tb_screen = null;
		Field procedure,ExpDate,DME;
		int field_found = 0;
		String act_procedure_val = null,act_dme_val = null;
		if(screenname.equalsIgnoreCase("CL657"))
		{
			tb_screen = CL657_Screen;
		}
		
		else if(screenname.equalsIgnoreCase("CL209"))
		{
			tb_screen = phy_claim_inq;
		}

		
		for(int rev=9;rev<=18;rev++)
		{	
			Thread.sleep(1000);
			
			
			
			procedure =	Desktop.describe(Window.class, new WindowDescription.Builder()
					.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(rev).setColumn(8)).build());
			
			
			act_procedure_val = procedure.getText();
			
		
			if(act_procedure_val.equals(""))
			{	
				break;
			}	
			if(act_procedure_val.equalsIgnoreCase(procCode) )
			{
				Thread.sleep(1000);
				field_found = 1;
			
					 if (screenname.equalsIgnoreCase("CL657")) {
						
						
						ExpDate=	Desktop.describe(Window.class, new WindowDescription.Builder()
								.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
										.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
										.length(6).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(rev+1).setColumn(53)).build());
						
						String act_ExpDate = ExpDate.getText();
						
						
				if(criteria.equalsIgnoreCase("Not Met")){
						if(act_ExpDate.equals(""))
						{
							System.out.println("NO entry is there: pass");
							flag=true;
							break;
						}	
						
						else{
							Date d=new Date();
							System.out.println(d);
							SimpleDateFormat format1 = new SimpleDateFormat("MMddyy");
							String n=format1.format(d);	
							System.out.println(n);
						SimpleDateFormat sdf = new SimpleDateFormat("MMddyy");
							Date date1 = sdf.parse(n);
							System.out.println("date 1 is :"+ date1);
							Date date2 = sdf.parse( act_ExpDate);
							System.out.println("date 2 is :"+ date2);
							
							
							long daysBetween = ChronoUnit.DAYS.between(date1.toInstant(), date2.toInstant());
							    System.out.println("Days Difference between Frm_Date and Thru_Date is" +daysBetween);
							    
						String temp=String.valueOf(daysBetween);
						if (temp.contains("-")) {
							System.out.println("date is expired");
							flag=true;
						}
						else if(temp.contains("0")){
							System.out.println("date is equal");
							
							flag=true;
						}
						else{
							System.out.println("expired date is not before date: error");
							
						}
											
						}
						
						break;
						
					}
				
				//met
				
				if(criteria.equalsIgnoreCase("Met")){
						if(act_ExpDate.equals(""))
						{
							System.out.println("error: record should be present");
							break;
						}	
						
						else{
							Date d=new Date();
							System.out.println(d);
							SimpleDateFormat format1 = new SimpleDateFormat("MMddyy");
							String n=format1.format(d);	
							System.out.println(n);
						SimpleDateFormat sdf = new SimpleDateFormat("MMddyy");
							Date date1 = sdf.parse(n);
							System.out.println("date 1 is :"+ date1);
							Date date2 = sdf.parse( act_ExpDate);
							System.out.println("date 2 is :"+ date2);
							
							
							long daysBetween = ChronoUnit.DAYS.between(date1.toInstant(), date2.toInstant());
							    System.out.println("Days Difference between Frm_Date and Thru_Date is" +daysBetween);
							    
						String temp=String.valueOf(daysBetween);
						if (temp.contains("-")) {
							System.out.println("date is less:error");
							
						}
						else if(temp.contains("0")){
							System.out.println("date is equal:error");
				
						}
						else{
							System.out.println("expired date is after today date: pass");
							flag=true;
							
						}
											
						}
						
						break;
						
					}
				
			}
		}
			
		}
			
	
AssertJUnit.assertTrue(flag);	
		}
	
 
//







public static String DB2ValidationForTwoString(String Field,String Region,String  Tablename,String keyfield,String keyvalue,String keyfield1,String keyvalue1) throws SQLException {
		String columnValue=null;
		String url1="jdbc:db2://GWYA8002:50002/DB0T";
		String user= Constants.dbuser;
		String password=Constants.passwd;
		Connection connection = null;
		//String columnValue = null;
		try {
			//Load class into memory
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			//Establish connection
			connection = DriverManager.getConnection(url1, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{

			if(connection!=null){
				System.out.println("Connected successfully.");
				Statement stmt1 = connection.createStatement();
			String query=	"select "+Field+ " from "+ Region+"."+Tablename+" where "+keyfield+"="+keyvalue+" AND "+keyfield1+"='"+keyvalue1+"'";
			System.out.println("the quey is:  "+query);
				ResultSet rs1 = stmt1.executeQuery("select "+Field+ " from "+ Region+"."+Tablename+" where "+keyfield+"="+keyvalue+" AND "+keyfield1+"='"+keyvalue1+"'");

				ResultSetMetaData rsmd=rs1.getMetaData();
				int colnum1=rsmd.getColumnCount();
				System.out.println(colnum1);
				while(rs1.next()){
					for(int i =1;i<=colnum1;i++){

						columnValue = rs1.getString(i);


					}
				}}
		}
		try {
			connection.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return columnValue;
	}



}





