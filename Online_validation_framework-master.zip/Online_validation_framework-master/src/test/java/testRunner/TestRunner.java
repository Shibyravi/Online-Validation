package testRunner;

import java.io.File;


import org.junit.AfterClass;
import org.junit.runner.RunWith;

import com.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

//updated
@RunWith(Cucumber.class)
@CucumberOptions(
		monochrome = true,
		features="src//test//java//Feature",
		glue = "stepDefinition",
		plugin = {"com.cucumber.listener.ExtentCucumberFormatter:"},
		dryRun = false,
		tags = {"@Fee_Sch1"}
		)
public class TestRunner {
	@AfterClass
	public static void writeExtentReport() {
		Reporter.loadXMLConfig(new File("src//test//java//config//extent-config.xml"));
		
	}
	
}
		
		

