package stepDefinition;

import org.testng.Assert;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Physician_CL201;
import pages.Physician_CL209;

public class BilateralStepDefinition
{

	
public String Audit_number,Div;
	
@When("^The place of service Code \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
public void the_place_of_service_Code_is_present_on_screen(String POS, String Screen1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	Physician_CL201 phy_screen1 = new Physician_CL201();
	String Actposcode=phy_screen1.pos_val();
	System.out.println("Actual POS is :"  +Actposcode);
	Assert.assertEquals(Actposcode, POS);
}

@When("^the Proc Code \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
public void the_Proc_Code_is_present_on_screen(String Proc_Code, String Screen1) throws Throwable {
	Physician_CL201 phy_screen1 = new Physician_CL201();
	String Actproccode=phy_screen1.proc1_mod1_val();
	System.out.println("Actual Proc__Code is :"  +Actproccode);
	Assert.assertEquals(Actproccode, Proc_Code);

}

@When("^the provider type \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
public void the_provider_type_is_present_on_screen(String Provider_Type, String Screen1) throws Throwable {
	Physician_CL201 phy_screen1 = new Physician_CL201();
	String Actprovider_type=phy_screen1.prov_type_val();
	System.out.println("Actual Provider_type is :"  +Actprovider_type);
	Assert.assertEquals(Actprovider_type, Provider_Type);
	
}



	


	}

