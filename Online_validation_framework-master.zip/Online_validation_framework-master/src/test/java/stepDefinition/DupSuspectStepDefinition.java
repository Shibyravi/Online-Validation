package stepDefinition;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Hospital_HO400;
import pages.Physician_CL201;
import pages.Physician_CL209;
import util.FunctionLibrary;

public class DupSuspectStepDefinition {
public String Audit_number,Div,act_review_code;

@Then("^the claim \"([^\"]*)\" is not header denied with the denial code \"([^\"]*)\" in screen \"([^\"]*)\" in division \"([^\"]*)\"$")
public void the_claim_is_header_denied_with_the_denial_code_in_screen_in_division(String Audit_number, String hdr_deny_code, String screen,String Div) throws Throwable {

	if(screen.equals("CL201"))
	{	
		Physician_CL201 phy_val = new Physician_CL201();
		if(phy_val.cur_screen.equals(2))
		{	
		String act_hdr_deny_code =phy_val.hdr_deny_val();
		Assert.assertEquals(act_hdr_deny_code,hdr_deny_code);
		Reporter.addStepLog("Header deny code is " +act_hdr_deny_code);
		}
		else
		{
			FunctionLibrary.navigateToDiv(screen);
			String act_hdr_deny_code =phy_val.hdr_deny_val();
			Assert.assertNotEquals(act_hdr_deny_code,hdr_deny_code);
			Reporter.addStepLog("Header deny code is " +act_hdr_deny_code);
			
		}
	}
	else if (screen.equals("HO400"))
	{

		Hospital_HO400 hos_val = new Hospital_HO400();
		if(hos_val.cur_screen.equals(2))
		{
		String act_hdr_deny_code =hos_val.hdr_deny_val();
		Assert.assertEquals(act_hdr_deny_code,hdr_deny_code);
		Reporter.addStepLog("Header deny code is " +act_hdr_deny_code);
		}
		else
		{
			FunctionLibrary.navigateToDiv(screen);
			Thread.sleep(1000);
			
			hos_val.HO400_Inquire(Audit_number, Div);
			String act_hdr_deny_code =hos_val.hdr_deny_val();
			Assert.assertNotEquals(act_hdr_deny_code,hdr_deny_code);
			Reporter.addStepLog("Header deny code is " +act_hdr_deny_code);
			
		}
	}
}

@Then("^the details of the claim are fetched to compare$")
public void fetched_to_compare() throws Throwable {

//	
//		Physician_CL201 phy_val = new Physician_CL201();
//		String act_hdr_deny_code =phy_val.hdr_deny_val();
//		Hospital_HO400 hos_val = new Hospital_HO400();
//		String act_hdr_deny_code1 =phy_val.hdr_deny_val();
}
		}