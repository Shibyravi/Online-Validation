package stepDefinition;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.*;
import pages.Hospital_HO400;
import pages.Physician_CL201;
import util.FunctionLibrary;

public class NPIautodenyStepDefinition {

	@When("^the Revenue code used is \"([^\"]*)\" for proc code \"([^\"]*)\"$")
	public void the_Revenue_code_used_is_for_proc_code(String rev, String cpt) throws Throwable {
		Hospital_HO400 hos_val = new Hospital_HO400();
		if(rev.equals(hos_val.rev_code1.getText()))
		{
			String act_rev =hos_val.rev_code1_val();
			Assert.assertEquals(act_rev,rev);
			Reporter.addStepLog("Rev code is " +act_rev);
		}
		else if(rev.equals(hos_val.rev_code2.getText()))
		{
			String act_rev =hos_val.rev_code2_val();
			Assert.assertEquals(act_rev,rev);
			Reporter.addStepLog("Rev code is" +act_rev);
		}

	}
	@Then("^the claim is header denied with the denial code \"([^\"]*)\" in screen \"([^\"]*)\"$")
	public void the_claim_is_header_denied_with_the_denial_code_in_screen(String hdr_deny_code, String screen) throws Throwable {
		if(screen.equals("CL201"))
		{	
			Physician_CL201 phy_val = new Physician_CL201();
			String act_hdr_deny_code =phy_val.hdr_deny_val();
			Assert.assertEquals(act_hdr_deny_code,hdr_deny_code);
			Reporter.addStepLog("Header deny code is " +act_hdr_deny_code);
		}
		else if (screen.equals("HO400"))
		{
			Hospital_HO400 hos_val = new Hospital_HO400();
			String act_hdr_deny_code =hos_val.hdr_deny_val();
			Assert.assertEquals(act_hdr_deny_code,hdr_deny_code);
			Reporter.addStepLog("Header deny code is " +act_hdr_deny_code);
		}
	}
	@Then("^the claim is not header denied with the denial code \"([^\"]*)\" in screen \"([^\"]*)\"$")
	public void the_claim_is_not_header_denied_with_the_denial_code_in_screen(String hdr_deny_code, String screen) throws Throwable {
		if(screen.equals("CL201"))
		{	
			Physician_CL201 phy_val = new Physician_CL201();
			String act_hdr_deny_code =phy_val.hdr_deny_val();
			Assert.assertNotEquals(act_hdr_deny_code,hdr_deny_code);
			Reporter.addStepLog("Header deny code is " +act_hdr_deny_code);
		}
		else if (screen.equals("HO400"))
		{
			Hospital_HO400 hos_val = new Hospital_HO400();
			String act_hdr_deny_code =hos_val.hdr_deny_val();
			Assert.assertNotEquals(act_hdr_deny_code,hdr_deny_code);
			Reporter.addStepLog("Header deny code is " +act_hdr_deny_code);
		}
	}
	@When("^the \"([^\"]*)\" value is \"([^\"]*)\" from \"([^\"]*)\" in database \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\"$")
	public void the_value_is_from_in_database_for_primary_key_as_and_as(String col_name, String col_value, String table, String dbname, String field, String val, String field1, String val1) throws Throwable {
		String exp_val = FunctionLibrary.DB2Validation(col_name, dbname, table, field, val, field1, val1).trim();
		if(exp_val.equals(col_value))
		{
			Assert.assertEquals(col_value, exp_val);
			Reporter.addStepLog("Actual billing NPI is " +col_value);
		}
		else
		{
			Reporter.addStepLog("Actual billing NPI is " +col_value);
		}

	}
	@When("^the \"([^\"]*)\" value is \"([^\"]*)\" and \"([^\"]*)\" is \"([^\"]*)\" and \"([^\"]*)\" is \"([^\"]*)\" and \"([^\"]*)\" is \"([^\"]*)\" from \"([^\"]*)\" in database \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\"$")
	public void the_value_is_and_is_and_is_and_is_from_in_database_for_primary_key_as(String field1, String value1, String field2, String value2, String field3, String value3, String field4, String value4, String table, String db, String prim_key, String prim_val) throws Throwable {
		ArrayList<String> exp_values = new ArrayList<String>();
		List<String> act_values = FunctionLibrary.DB2_return_mutliple_values(field1, db, table, prim_key, prim_val, field2, field3, field4);
		exp_values.add(value1.trim());
		exp_values.add(value2.trim());
		exp_values.add(value3.trim());
		exp_values.add(value4.trim());
		for(int i=0;i<exp_values.size();i++){
			if(exp_values.get(i).trim().equals(act_values.get(i).trim())){
				Reporter.addStepLog("Passed: Expected db values " +exp_values.get(i));
				Reporter.addStepLog("Passed: Actual db values " +act_values.get(i));
			}
			else{
				Reporter.addStepLog("Failed: Expected db values " +exp_values.get(i));
				Reporter.addStepLog("Failed: Actual db values " +act_values.get(i));
			}
		}	
	}
	

}