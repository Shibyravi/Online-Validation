package stepDefinition;

import org.testng.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.*;
import pages.Physician_CL201;

public class PreventiveNewPatient {
	
	@Then("^the claimed amount \"([^\"]*)\" on subaudit \"([^\"]*)\" is equal to rolled up amounts of detail line denied with \"([^\"]*)\" and \"([^\"]*)\" of audit \"([^\"]*)\" in division \"([^\"]*)\" in screen \"([^\"]*)\"$")
	public void the_claimed_amount_on_subaudit_is_equal_to_rolled_up_amounts_of_detail_line_denied_with_and_of_audit_in_division_in_screen(String sub_claimed, String subaudit, double claimed1, double claimed2, String Audit_number, String Div, String screen) throws Throwable {
		Physician_CL201 phy_val1 = new Physician_CL201();
		String act_total_claimed =phy_val1.claimed1_val();
		double subaudit_total_claimed=Double.parseDouble(act_total_claimed);
		phy_val1.CL201_Inquire(Audit_number, Div);
		Thread.sleep(1000);
		//logic to determine rolled up amount
		/*String act_deny_code = null;
		if (Screen1.equals("CL201"))
		//{
			//Physician_CL201 phy_val1 = new Physician_CL201();
			//phy_val1.CL201_Inquire(Audit_number, Div);
			if(cpt.equals(phy_val1.proc_code1.getText()))
			{	
				act_deny_code =phy_val1.det1_deny_val();
				Assert.assertEquals(act_deny_code,deny_code );
			}
			else if(cpt.equals(phy_val1.proc_code2.getText()))
			{
				act_deny_code =phy_val1.det2_deny_val();
				Assert.assertEquals(act_deny_code,deny_code );
			}
			else
			{
				while(!phy_val1.claim_msg_val().trim().equals("LAST RECORD"))
				{
					phy_val1.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
					Thread.sleep(1000);
					if(cpt.equals(phy_val1.proc_code1.getText()))
					{
						act_deny_code =phy_val1.det1_deny_val();
					}
					else if(cpt.equals(phy_val1.proc_code2.getText()))
					{
						act_deny_code =phy_val1.det2_deny_val();
					}
				}
			}
			
			Reporter.addStepLog("Deny code is " +act_deny_code +" for cpt code " +cpt);
		
		*/
		
		
		
		
		
		claimed1=Double.parseDouble(phy_val1.claimed1_val());
		claimed2=Double.parseDouble(phy_val1.claimed2_val());
		double rollup_value = claimed1+claimed2;
		if(subaudit_total_claimed==rollup_value)
		{
			Assert.assertEquals(rollup_value,subaudit_total_claimed);
			Reporter.addStepLog(" Claimed amount of subaudit is matching to rolled up amounts from detail line");
		}
		else
		{
			Reporter.addStepLog(" Claimed amount of subaudit is not matching with rolled up amounts from detail line");
		}
	}
	@When("^the schedule type is not \"([^\"]*)\" on screen \"([^\"]*)\"$")
	public void the_schedule_type_is_not_on_screen(String exp_schd_type, String screen) throws Throwable {
		Physician_CL201 phy_val1 = new Physician_CL201();
		String act_schd_type =phy_val1.schd1_val();
		if(!exp_schd_type.equalsIgnoreCase(act_schd_type))
		{
			Assert.assertNotEquals(act_schd_type,exp_schd_type);
			Reporter.addStepLog(" Passed: Scheduled tupe is not FLAT rate. Actual rate type is " +act_schd_type);
		}
		else
		{
			Reporter.addStepLog("Failed: Scheduled tupe is FLAT rate. Adjudipro wont apply expected deny code");
		}
	}

}
