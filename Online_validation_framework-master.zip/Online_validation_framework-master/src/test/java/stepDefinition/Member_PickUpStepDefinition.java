package stepDefinition;




import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Assert;

import com.cucumber.listener.Reporter;
import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Hospital_HO400;
import pages.Member_GI101;
import pages.Member_GI325;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL360;
import util.FunctionLibrary;

public class Member_PickUpStepDefinition {



	public Member_PickUpStepDefinition(){
		
	}
	
	
	
	/*@When("^the rsn number \"([^\"]*)\" is displayed in the screen \"([^\"]*)\"$")
	public void the_rsn_number_is_displayed_in_the_screen(String rsn, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		String act_rsn=null;
		String act_phy_rsn=null;
		if(screen.equals("HO400"))
	  	{	
	  		
	  		Hospital_HO400 hos_val = new Hospital_HO400();
	  	//hos_val.HO409_Inquire(Audit_number, Div);
	  		Thread.sleep(1000);
	  		act_rsn=hos_val.det_deny1_val();
	  		
	  		Assert.assertEquals(act_rsn,rsn);
	  		
	  		System.out.println("The actual rsn is:" +act_rsn);
	  		Reporter.addStepLog("The actual rsn is:" +act_rsn);
	}
		
		else if (screen.equals("CL201"))
	  	{	
	  		
			Physician_CL201 phy_val = new Physician_CL201();
	  	//hos_val.HO409_Inquire(Audit_number, Div);
	  		Thread.sleep(1000);
	  		act_phy_rsn=phy_val.det1_deny_val();
	  		
	  		Assert.assertEquals(act_phy_rsn,rsn);
	  		
	  		System.out.println("The actual rsn is:" +act_phy_rsn);
	  		Reporter.addStepLog("The actual rsn is:" +act_phy_rsn);
	}
	}*/
	
	@Then("^the required memberID \"([^\"]*)\" is inquired in the screen \"([^\"]*)\"$")
	public void the_required_memberID_is_inquired_in_the_screen(String mem_id, String screen1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(1000);
		FunctionLibrary.navigateToDiv(screen1);
		Thread.sleep(1000);
		 if (screen1.equals("GI101")){
		Member_GI101 mb= new Member_GI101();
		String member_id=mem_id.replaceAll("-","");
		mb.GI101_Inquire(member_id);
		System.out.println("The member id is :"+member_id);
	}
	}
	
	
	
	@Then("^the date of service \"([^\"]*)\" is displayed in the screen \"([^\"]*)\"$")
	public void the_date_of_service_is_displayed_in_the_screen(String dateofservice, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		FunctionLibrary.navigateToDiv(screen);
		if (screen.equals("CL201"))
		{
			Physician_CL201 phy_val1 = new Physician_CL201();
			//phy_val1.CL202_Inquire(Audit_number, Div);
			Thread.sleep(500);
			String act_dos =phy_val1.frm_dos1_val();
			Assert.assertEquals(act_dos,dateofservice);
			System.out.println("The Date of Service is:" +act_dos);
			Reporter.addStepLog("The Date of Service is: " +act_dos);
		}	
	}
	@Given("^The user is in division \"([^\"]*)\" and navigates to screen \"([^\"]*)\"$")
	public void the_user_is_in_division_and_navigates_to_screen(String Div, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		FunctionLibrary.navigateToDiv(Div);
		Screen sys_menu = Desktop.describe(Window.class, new WindowDescription.Builder()
    			.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
    			.label("Unit").build());
		Field begin = sys_menu.describe(Field.class, new FieldDescription.Builder()
    			.attachedText("field347").isProtected(false).build());
		begin.setText(screen);
		sys_menu.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		
	}

//	@When("^the user inquires for the select \"([^\"]*)\" and \"([^\"]*)\" in the screen \"([^\"]*)\"$")
//	public void the_user_inquires_for_the_select_and_in_the_screen(String select,String key, String screen) throws Throwable {
//	    // Write code here that turns the phrase above into concrete actions
//		if (screen.equals("CL360")){
//			Physician_CL360 phy_val1 = new Physician_CL360();
//			phy_val1.select.setText("");
//			phy_val1.key.setText("");
//			phy_val1.CL360_Inquire(select,key);
//		}	
//		}
// 

	@When("^the user inquires for the key \"([^\"]*)\" in div \"([^\"]*)\" on the screen \"([^\"]*)\"$")
	public void the_user_inquires_for_the_key_in_div_on_the_screen(String key1, String Div,String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if (screen.equals("CL360")){
			Physician_CL360 phy_val1 = new Physician_CL360();
			System.out.println("The key inquired is:"+key1);
			phy_val1.CL360_Inquire(key1,Div,screen);
			Thread.sleep(1000);
			
	}
	}
	
	@When("^the dependent code \"([^\"]*)\" on detail line is displayed in screen \"([^\"]*)\"$")
	public void the_dependent_code_on_detail_line_is_displayed_in_screen(int exp_dep_code, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String dep_code=null;
		Physician_CL360 phy_val1 = new Physician_CL360();
	    dep_code=phy_val1.getdependentCode();
		
		System.out.println("The required dependent code is:"+dep_code);
	}

	@Then("^the status \"([^\"]*)\" is displayed in the screen \"([^\"]*)\"$")
	public void the_status_is_displayed_in_the_screen(String status, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//FunctionLibrary.navigateToDiv(screen);
		if (screen.equals("CL360")){
			Physician_CL360 phy_val1 = new Physician_CL360();
			String phy_status=phy_val1.getStatus();
			Assert.assertEquals(phy_status,status);
			System.out.println("The status is:"+phy_status);
			Reporter.addStepLog("The status is:"+phy_status);
	}
	}
	@Then("^validate expiry date \"([^\"]*)\" is before/after the date of service \"([^\"]*)\" in screen \"([^\"]*)\"$")
	public void validate_expiry_date_is_before_after_the_date_of_service_in_screen(String exp_date, String dos, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		FunctionLibrary.navigateToDiv(screen);
		if (screen.equals("GI101"))
		{
			Member_GI101 mem_GI = new Member_GI101();
			Thread.sleep(1000);
			String act_expriry =mem_GI.ExpiryDate_val();
			Assert.assertEquals(act_expriry,exp_date);
			System.out.println("The expiry date is :"+act_expriry);
	SimpleDateFormat sdf = new SimpleDateFormat("MMddyy");
	Date date1 = sdf.parse(exp_date);
	Date date2 = sdf.parse(dos);
	if(date1.before(date2))
	{
		System.out.println("Member's expiry date "+act_expriry+" is before member's date of service " +dos);
		Reporter.addStepLog("Member's expiry date "+act_expriry+" is before member's date of service " +dos);
	}
	else
	{
		System.out.println("Member's expiry date "+act_expriry+" is after member's date of service " +dos);
		Reporter.addStepLog("Member's expiry date "+act_expriry+" is after member's date of service " +dos);
	}
	
    
}
	
	}}
