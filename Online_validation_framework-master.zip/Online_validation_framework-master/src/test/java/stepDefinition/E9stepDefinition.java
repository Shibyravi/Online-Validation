package stepDefinition;

import static org.testng.Assert.assertEquals;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.xmlbeans.XmlENTITIES;
import org.testng.Assert;
import com.hp.lft.sdk.te.Screen;
import cucumber.api.DataTable;
import cucumber.api.java.en.*;
import driver.DriverScript;
import pages.Hospital_HO400;
import pages.Hospital_HO409;
import pages.Hospital_HO410;
import pages.Hospital_HO430;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL209;
import util.FunctionLibrary;

public class E9stepDefinition {
	
	public String  Audit_number,Div;
	
	@When("^Disallow amount \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
	public void disallow_amount_is_present_on_screen(String act_disallow, String Screen) throws Throwable {
		String act_tot_disallow =null;
		//String act_copay=null;
		if(Screen.equals("CL201"))
		{	
				
	    Physician_CL201 phy_screen1 = new Physician_CL201();
	   // act_copay = phy_screen1.tot_copay_Val();
		act_tot_disallow =phy_screen1.tot_disallow_Val();
		
		
		}		
		else if(Screen.equals("HO400"))
		{
			System.out.println("nothing");
			}
	}

	@When("^Copay amount \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
	public void copay_amount_is_present_on_screen(String act_copay, String Screen) throws Throwable {
		String act_tot_copay =null;
		if(Screen.equals("CL201"))
		{	
				
	    Physician_CL201 phy_screen1 = new Physician_CL201();
		act_tot_copay =phy_screen1.tot_copay_Val();
		
		
		}		
		else if(Screen.equals("HO400"))
		{
			System.out.println("nothing");
			}
	}
	
	@Then("^total copay \"([^\"]*)\" value  in database \"([^\"]*)\" from \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\" is validated against \"([^\"]*)\"$")
	public void total_copay_value_in_database_from_for_primary_key_as_and_as_is_validated_against(String fieldname, String reg,String table, String keyf, String keyval, String keyf1, String keyval1,String copay) throws Throwable {
		   
				String dbcopay = FunctionLibrary.DB2Validation(fieldname,reg,table, keyf, keyval,keyf1,keyval1);
				
				Physician_CL201 phy_val2 = new Physician_CL201();
						
				String tot_copay=phy_val2.tot_copay_Val();
			   Assert.assertEquals(dbcopay,tot_copay);
	   
	 
	}
	 
	
	@Then("^total disallow \"([^\"]*)\" value  in database \"([^\"]*)\" from Table \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\" is validated against \"([^\"]*)\"$")
	public void total_disallow_value_in_database_from_Table_for_primary_key_as_and_as_is_validated_against(String fieldname, String reg,String table, String keyf, String keyval, String keyf1, String keyval1,String disallow ) throws Throwable {
			String col = FunctionLibrary.DB2Validation(fieldname, reg,table, keyf, keyval,keyf1,keyval1);
			
			Physician_CL201 phy_val2 = new Physician_CL201();
					
			String tot_disallow=phy_val2.tot_disallow_Val();
		   Assert.assertEquals(col,tot_disallow);
	   }
	
	@When("^TDA Claim \"([^\"]*)\" is Present on screen \"([^\"]*)\"$")
	public void tda_Claim_is_Present_on_screen(String audit, String Screen ) throws Throwable {
	 // String  adj_msg= null;
		
		this.Audit_number = audit;
		if(Screen.equals("CL201")){
			Physician_CL201 phy_val2 = new Physician_CL201();
			
		String adj_msg=phy_val2.adj_msg_Val();
			if(adj_msg=="ORG"){
			do{
				FunctionLibrary fl_xmit = new FunctionLibrary();
				fl_xmit.xmit();
				}while(adj_msg=="ADJ");
	       
		Assert.assertEquals(adj_msg,"ADJ");
			
		}}
	}
@Then("^TDA \"([^\"]*)\" value in Database \"([^\"]*)\" from Table \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\" is validated against Y$")
	public void tda_value_in_Database_from_Table_for_primary_key_as_and_as_is_validated_against_Y(String fieldname , String reg, String table, String keyf, String keyval, String keyf1, String keyval1) throws Throwable {
	    
	
	String col = FunctionLibrary.DB2Validation(fieldname,reg,table,keyf,keyval,keyf1,keyval1);
	Assert.assertEquals(col,"Y");
	
	
	
}	
	
@When("^denial code is present on screen \"([^\"]*)\" of the detail line \"([^\"]*)\"$")
public void denial_code_is_present_on_screen_of_the_detail_line(String denycode, String Screen) throws Throwable {
	String act_denycode=null;
	Physician_CL201 phy_val2 = new Physician_CL201();
	act_denycode=phy_val2.det1_deny_val(); 
	System.out.println("Deny code present on the claim is "+act_denycode);
	
}


@Then("^Deny code \"([^\"]*)\" value in database\"([^\"]*)\" from Table \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" ,\"([^\"]*)\" as \"([^\"]*)\"and \"([^\"]*)\" as \"([^\"]*)\" is validated\\.$")
public void deny_code_value_in_database_from_Table_for_primary_key_as_as_and_as_is_validated(String fieldname, String reg, String table, String keyf, String keyval, String keyf1, String keyval1, String keyf2, String keyval2) throws Throwable {
	//public void deny_code_value_in_database_from_Table_for_primary_key_as_as_and_as_is_validated(String fieldname, String reg, String table, String keyf, String keyval, String keyf1, String keyval1, String keyf2, String keyval2) throws Throwable {   
	String col = FunctionLibrary.DB2Validation(fieldname,reg,table, keyf, keyval,keyf1,keyval1,keyf2,keyval2);
	
	Physician_CL201 phy_val2 = new Physician_CL201();
	String Denycode =phy_val2.det2_deny_val();
	
	System.out.println(col);
	//Assert.assertEquals(col,Denycode);
	if(Denycode.charAt(0)=='0'){
		
		Denycode=Denycode.substring(1, 4);
	}
	Assert.assertEquals(col, Denycode);
	
	
	}

@Then("^Validate the TPSMservice value \"([^\"]*)\" in database \"([^\"]*)\"from Table \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" ,\"([^\"]*)\" as \"([^\"]*)\"$")
public void validate_the_TPSMservice_value_in_database_from_Table_for_primary_key_as_as(String fieldname, String reg, String table, String keyf, String keyval, String keyf1, String keyval1) throws Throwable {
    
String col = FunctionLibrary.DB2Validation(fieldname,reg,table, keyf, keyval,keyf1,keyval1);
	System.out.println(col);
Assert.assertEquals(col,"99Z");
}

@Then("^Validate the TPSMservicedesc value \"([^\"]*)\" in database \"([^\"]*)\"from Table \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" ,\"([^\"]*)\" as \"([^\"]*)\"$")
public void validate_the_TPSMservicedesc_value_in_database_from_Table_for_primary_key_as_as(String fieldname, String reg, String table, String keyf, String keyval, String keyf1, String keyval1) throws Throwable {
   
	String col = FunctionLibrary.DB2Validation(fieldname,reg,table, keyf, keyval,keyf1,keyval1);
	System.out.println(col);
	Assert.assertEquals(col,"DEFA");
	

}

@When("^Limitedservice is present on screen \"([^\"]*)\" of the detail line \"([^\"]*)\"$")
public void limitedservice_is_present_on_screen_of_the_detail_line(String Lim_svc, String Screen) throws Throwable {
   String act_lim_svc=null;
	
	Physician_CL201 phy_val2 = new Physician_CL201();
	act_lim_svc=phy_val2.lim_svc1_val();
	
	System.out.println(act_lim_svc);
	
}

@Then("^Validate the Limited service number \"([^\"]*)\" in database \"([^\"]*)\"from Table \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\"$")
public void validate_the_Limited_service_number_in_database_from_Table_for_primary_key_as_and_as_and_as(String fieldname, String reg, String table, String keyf, String keyval, String keyf1, String keyval1, String keyf2, String keyval2) throws Throwable {
	String col = FunctionLibrary.DB2Validation(fieldname,reg,table, keyf, keyval,keyf1,keyval1,keyf2,keyval2);
	System.out.println(col);
	Physician_CL201 phy_val2 = new Physician_CL201();
	String limsvc =(phy_val2.lim_svc1_val()).substring(0,1);
	
	Assert.assertEquals(col,limsvc);
}

@When("^Provider type (\\d+) is present on screen \"([^\"]*)\"$")
public void provider_type_is_present_on_screen(int provtype, String Screen) throws Throwable {
	 String act_provtype=null;
		
		Physician_CL201 phy_val2 = new Physician_CL201();
		act_provtype=phy_val2.prov_type_val();
		
		System.out.println(act_provtype);
	
}

@Then("^the claim is hit with review \"([^\"]*)\" in screen \"([^\"]*)\" and is processed by Pricing \"([^\"]*)\"$")
public void the_claim_is_hit_with_review_in_screen_and_is_processed_by_Pricing(String Review, String  Screen2, String Rev_user_code) throws Throwable {
    
	FunctionLibrary.navigateToDiv(Screen2);
	Physician_CL209 phy_val1 = new Physician_CL209();
	//FunctionLibrary.navigateToDiv(arg2);
	phy_val1.CL209_Inquire(Audit_number,Div);
	List<String> exp_result = new ArrayList<String>();
	exp_result.add(Review);
	exp_result.add(Rev_user_code);
	List act_review_code =phy_val1.review_val(Review);
	Assert.assertEquals(act_review_code,exp_result);
	//Assert.assertEquals(exp_review,exp_Deny.get(0).get(0) );
	System.out.println("Values returned " +act_review_code);
	System.out.println("Expected outcome " +act_review_code);
	
	
	
	
}

@Then("^Validate the Pricer code\"([^\"]*)\" in database \"([^\"]*)\" from Table \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" Against \"([^\"]*)\"$")
public void validate_the_Pricer_code_in_database_from_Table_for_primary_key_as_Against(String fieldname, String reg, String table, String keyf, String keyval, String prccode) throws Throwable {
   
	String col = FunctionLibrary.DB2Validation(fieldname,reg,table, keyf, keyval);
	System.out.println(col);
	
	Assert.assertEquals(col, prccode);
	
	
}

@Then("^Validate the Pricer code\"([^\"]*)\" in database \"([^\"]*)\" from Table \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\" Against \"([^\"]*)\"$")
public void validate_the_Pricer_code_in_database_from_Table_for_primary_key_as_and_as_Against(String fieldname, String reg, String table, String keyf, String keyval, String keyf1, String keyval1, String prccode) throws Throwable {
    
	String col = FunctionLibrary.DB2Validation(fieldname,reg,table,keyf,keyval,keyf1,keyval1);
	System.out.println(col);

}

@When("^the subaudit \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
public void the_subaudit_is_present_on_screen(String subaud, String Screen) throws Throwable {
    
	this.Div = Div;
	this.Audit_number = Audit_number;
	FunctionLibrary.changeSite();
	//FunctionLibrary.retScreenObject(Screen, Audit_number, Div);
	
	
	//Physician_CL201 phy_screen1 = new Physician_CL201();
	if(Screen.equals("CL201"))
	{	
		Physician_CL201 phy_screen1 = new Physician_CL201();
		phy_screen1.CL201_Inquire(Audit_number,Div);
	}
	else if(Screen.equals("CL202"))
	{
		Physician_CL202 phy_screen2 = new Physician_CL202();
		phy_screen2.CL202_Inquire(Audit_number,Div);
	}
	else if(Screen.equals("CL209"))
	{
		Physician_CL209 phy_screen3 = new Physician_CL209();
		phy_screen3.CL209_Inquire(Audit_number,Div);
	}
	else if(Screen.equals("HO400"))
	{
		Hospital_HO400 hos_screen1 = new Hospital_HO400();
		hos_screen1.HO400_Inquire(Audit_number,Div);
	}
	else if(Screen.equals("HO410"))
	{
		Hospital_HO410 hos_screen2 = new Hospital_HO410();
		hos_screen2.HO410_Inquire(Audit_number,Div);
	}
	else if(Screen.equals("HO430"))
	{
		Hospital_HO430 hos_screen3 = new Hospital_HO430();
		hos_screen3.HO430_Inquire(Audit_number,Div);
	}
	else if(Screen.equals("HO409"))
	{
		Hospital_HO409 hos_screen4 = new Hospital_HO409();
		hos_screen4.HO409_Inquire(Audit_number,Div);
	}
	
	
	
}

@Then("^POS \"([^\"]*)\" for \"([^\"]*)\"  and POS \"([^\"]*)\" for \"([^\"]*)\" should be  different$")
public void pos_for_and_POS_for_should_be_different(String POS, String audit, String pos1, String subaudit) throws Throwable {

    
	String act_pos1,act_pos2= null;
	
	Physician_CL201 phy_val1 = new Physician_CL201();
	act_pos1 =phy_val1.pos_val();
	act_pos2 =phy_val1.pos2_val();
	Assert.assertNotEquals(act_pos1, act_pos2);

	}

@When("^Detail line \"([^\"]*)\" is denied with Denycode \"([^\"]*)\"$")
public void detail_line_is_denied_with_Denycode(String dtl_lin, String Denycode) throws Throwable {

    
	String act_dtl_lin,act_denycode= null;
	
	Physician_CL201 phy_val1 = new Physician_CL201();
	
	
	//if(dtl_lin=="1")
	
	act_denycode=phy_val1.det1_deny_val();
	
	/*else if(dtl_lin=="3")
	{
	
		FunctionLibrary.xmit();
		act_denycode=phy_val1.det1_deny_val();
	
    }else{
		
		act_denycode=phy_val1.det2_deny_val();
	}*/
	
	Assert.assertEquals(Denycode, act_denycode);
	
	
}

@Then("^Validate the Close message \"([^\"]*)\" on screen \"([^\"]*)\"$")
public void validate_the_Close_message_on_screen(String cls_msg, String Screen) throws Throwable {

   String act_cls_msg = null;
   
   Physician_CL201 phy_val1 = new Physician_CL201();
   
	act_cls_msg=phy_val1.clm_sts_Val();
	
	Assert.assertEquals(act_cls_msg, "CLS");
	
	
}

@Then("^Validate \"([^\"]*)\" in database \"([^\"]*)\" from Table \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\"  and \"([^\"]*)\" as \"([^\"]*)\" Against \"([^\"]*)\"$")
public void validate_in_database_from_Table_for_primary_key_as_and_as_Against(String fieldname,String reg, String table, String keyf,  String keyval,String keyf1,String keyval1, String cls_cde) throws Throwable {
   

	String col = FunctionLibrary.DB2Validation(fieldname,reg,table,keyf,keyval,keyf1,keyval1);
	
	System.out.println(col);
	
}

@Then("^Validate \"([^\"]*)\" in database \"([^\"]*)\" from Table \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\"  and \"([^\"]*)\" as \"([^\"]*)\"$")
public void validate_in_database_from_Table_for_primary_key_as_and_as(String fieldname, String reg, String table, String keyf, String keyval, String keyf1, String keyval1) throws Throwable {
   
String col = FunctionLibrary.DB2Validation(fieldname,reg,table,keyf,keyval,keyf1,keyval1);
	
	System.out.println(col);
	
	
    }
	
	
	
	
}

	








	


	
	
	
	

