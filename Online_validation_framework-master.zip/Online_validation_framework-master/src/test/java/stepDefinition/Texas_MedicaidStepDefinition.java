package stepDefinition;

import org.junit.Assert;

import cucumber.api.java.en.When;
import pages.Physician_CL201;
import pages.Physician_CL202;
import util.FunctionLibrary;

public class Texas_MedicaidStepDefinition {

	
	
	
	@When("^the claim type \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
	public void the_claim_type_is_present_on_screen(String claim,String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String claimtype=null;
	    Thread.sleep(1000);
	    if(screen.equals("CL202")){
	    Physician_CL202 phy_claim= new Physician_CL202();
	    claimtype=phy_claim.claim_type_val();
	    System.out.println("The value of claim type is:"+claimtype);
	    Assert.assertEquals(claim,claimtype);
	}
	}

	@When("^the out of area \"([^\"]*)\" status is displayed on the screen \"([^\"]*)\"$")
	public void the_out_of_area_status_is_displayed_on_the_screen(String area, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String areaType=null;
	    FunctionLibrary.navigateToDiv(screen);
	    Thread.sleep(1000);
	    if(screen.equals("CL202")){
	    Physician_CL202 phy_area= new Physician_CL202();
	    areaType=phy_area.outofarea_val();
	    System.out.println("The value of area network is:"+areaType);
	    Assert.assertEquals(area,areaType);
	}
	

	}
	@When("^the user inquires for the audit number \"([^\"]*)\" in division \"([^\"]*)\" fee max in screen \"([^\"]*)\" is \"([^\"]*)\" percent of base fee$")
	public void the_user_inquires_for_the_audit_number_in_division_fee_max_in_screen_is_percent_of_base_fee(String Audit_number, String Div, String screen, String pcnt) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
String percent=null;
		FunctionLibrary.navigateToDiv(screen);
         Thread.sleep(1000);
		if (screen.equals("CL201")) {
			Physician_CL201 phy_val1 = new Physician_CL201();
			phy_val1.CL201_Inquire(Audit_number, Div);
			percent=phy_val1.percent_val();
	    System.out.println("The value of percentage is:"+percent);
	    Assert.assertEquals(pcnt,percent);
	}
	}
	
}
