package stepDefinition;

import java.io.IOException;
import java.util.List;

import org.testng.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Hospital_HO400;
import pages.Physician_CL201;

public class ObstetricsStepDefination {
	public String Audit_number,Div;
	
public ObstetricsStepDefination() {
		
	}

@When("^the provider type is \"([^\"]*)\" is displayed on screen \"([^\"]*)\"$")
public void the_provider_type_is_is_displayed_on_screen(String Prov_type, String Screen) throws Throwable {
	
		String act_prov_type=null;
		if(Screen.equals("CL201"))
		{	
			Physician_CL201 phy_screen1 = new Physician_CL201();
			act_prov_type =phy_screen1.prov_type_val();
			
		}
		else if(Screen.equals("HO400"))
		{
			Hospital_HO400 hos_screen1 = new Hospital_HO400();
			act_prov_type =hos_screen1.prov_type_val();
		}
		
			Assert.assertEquals(act_prov_type, Prov_type);
		
		//Assert.assertEquals(act_pos,POS);
		System.out.println("Expected  provtype is " +Prov_type);
		Reporter.addStepLog("Expected  provtype is " +Prov_type);
		System.out.println("Actual provtype is " +act_prov_type);
		Reporter.addStepLog("Actual provtype is " +act_prov_type);
	} 

@When("^The provider No\\. on claim is \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
public void the_provider_No_on_claim_is_is_present_on_screen(String prov, String screen) throws Throwable {
	if(screen.equals("CL201"))
	{	
		Physician_CL201 phy_val = new Physician_CL201();
		String act_provider =phy_val.prov_val1();
		Assert.assertEquals(act_provider,prov);
		Reporter.addStepLog("Actual provider is " +act_provider);
	}
	
}
@Then("^allowed value_(\\d+) \"([^\"]*)\" for cpt \"([^\"]*)\" is displayed on screen \"([^\"]*)\"$")
public void allowed_value__for_cpt_is_displayed_on_screen(int arg1, String allowed_amount, String CPT, String Screen) throws Throwable {
	if(Screen.equals("CL201"))
	{	
		Physician_CL201 phy_val = new Physician_CL201();
		String act_allowed_Amount =phy_val.allowed1_val();
		Assert.assertEquals(act_allowed_Amount,allowed_amount);
		Reporter.addStepLog("Actual allowed_1 is " +allowed_amount);
	}
	
}

@Then("^allowed value_(\\d+) used \"([^\"]*)\" for cpt \"([^\"]*)\" is displayed on screen \"([^\"]*)\"$")
public void allowed_value__used_for_cpt_is_displayed_on_screen(int arg1, String allowed_amount, String CPT, String Screen) throws Throwable {
	if(Screen.equals("CL201"))
	{	
		Physician_CL201 phy_val = new Physician_CL201();
		String act_allowed_Amount =phy_val.allowed2_val();
		Assert.assertEquals(act_allowed_Amount,allowed_amount);
		Reporter.addStepLog("Actual allowed_2 is " +allowed_amount);
	}
}

//
//@Then("^copay value_(\\d+) \"([^\"]*)\" for cpt \"([^\"]*)\" is displayed on screen \"([^\"]*)\"$")
//public void copay_value__for_cpt_is_displayed_on_screen(int arg1, String copay_amount, String CPT, String Screen) throws Throwable {
//	if(Screen.equals("CL201"))
//	{	
//		Physician_CL201 phy_val = new Physician_CL201();
//		String act_copay_Amount =phy_val.copay1_val();
//		Assert.assertEquals(act_copay_Amount,copay_amount);
//		Reporter.addStepLog("Actual copay is " +copay_amount);
//	}
//}
//
//@Then("^copay value_(\\d+) used \"([^\"]*)\" for cpt \"([^\"]*)\" is displayed on screen \"([^\"]*)\"$")
//public void copay_value__used_for_cpt_is_displayed_on_screen(int arg1, String copay_amount, String CPT, String Screen) throws Throwable {
//	if(Screen.equals("CL201"))
//	{	
//		Physician_CL201 phy_val = new Physician_CL201();
//		String act_copay_Amount =phy_val.copay2_val();
//		Assert.assertEquals(act_copay_Amount,copay_amount);
//		Reporter.addStepLog("Actual copay is " +copay_amount);
//	}
//}
//
//@Then("^deductedvalue_(\\d+) \"([^\"]*)\" for cpt \"([^\"]*)\" is displayed on screen \"([^\"]*)\"$")
//public void deductedvalue__for_cpt_is_displayed_on_screen(int arg1, String ded_amount, String CPT, String Screen) throws Throwable {
//	if(Screen.equals("CL201"))
//	{	
//		Physician_CL201 phy_val = new Physician_CL201();
//		String act_ded_Amount1 =phy_val.ded1_val();
//		Assert.assertEquals(act_ded_Amount1,ded_amount);
//		Reporter.addStepLog("Actual copay is " +ded_amount);
//	}
//}
//
//@Then("^deductedvalue_(\\d+) used \"([^\"]*)\" for cpt \"([^\"]*)\" is displayed on screen \"([^\"]*)\"$")
//public void deductedvalue__used_for_cpt_is_displayed_on_screen(int arg1,  String ded_amount, String CPT, String Screen) throws Throwable {
//	if(Screen.equals("CL201"))
//	{	
//		Physician_CL201 phy_val = new Physician_CL201();
//		String act_ded_Amount2 =phy_val.ded1_val();
//		Assert.assertEquals(act_ded_Amount2,ded_amount);
//		Reporter.addStepLog("Actual copay is " +ded_amount);
//	}
//}

}

