package stepDefinition;

import java.awt.image.RenderedImage;
import java.io.File;

import javax.imageio.ImageIO;

import cucumber.api.java.en.Then;
import pages.Physician_CL201;
import pages.Physician_CL209;

public class Max_FrequencyStepdefination {

	
	@Then("^Screenshot taken on screen \"([^\"]*)\" with name \"([^\"]*)\"$")
	public void screenshot_taken_on_screen_with_name(String ScreenName, String Screenshot) throws Throwable {
		if ((ScreenName.equalsIgnoreCase("CL209")) || (ScreenName.equalsIgnoreCase("CL202")))
	    {
	   	 Physician_CL209 phy_screen1=new Physician_CL209();
			RenderedImage im = phy_screen1.screenName.getSnapshot();
	     ImageIO.write(im, "jpg", new File("C:\\Users\\agupt201\\Desktop\\Screen\\" +Screenshot+ ".jpg"));
	    }
	    else if (ScreenName.equalsIgnoreCase("CL201")) {
	   	 Physician_CL201 phy_screen1=new Physician_CL201();
	 		RenderedImage im = phy_screen1.cur_screen.getSnapshot();
	      ImageIO.write(im, "jpg", new File("C:\\Users\\agupt201\\Desktop\\Screen\\" +Screenshot+ ".jpg"));
		}
	}
}
