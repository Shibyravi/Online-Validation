package stepDefinition;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.DataTable;
import cucumber.api.java.en.*;
import driver.DriverScript;
import pages.Hospital_HO400;
import pages.Hospital_HO409;
import pages.Hospital_HO410;
import pages.Hospital_HO430;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL209;
import pages.Physician_CL360;
import pages.TB_470;
import util.FunctionLibrary;

public class AdjudiproStepDefinition {
	
	public static String pro_code=null;
	public String Audit_number,Div;
	FunctionLibrary fl_inq1 = new FunctionLibrary();

public AdjudiproStepDefinition() {
		
	}

@Given("^User launches mainframes environment and login to KOS session with valid credentials$")
public void user_launches_mainframes_environment_and_login_to_KOS_session_with_valid_credentials() throws Throwable {
	DriverScript.getInstance();
  
}
@Given("^The user is in division \"([^\"]*)\" and inquires for the audit number \"([^\"]*)\" in the screen \"([^\"]*)\"$")
public void the_user_is_in_division_and_inquires_for_the_audit_number_in_the_screen(String Div, String Audit_number, String Screen) throws Throwable {
	this.Div = Div;
	this.Audit_number = Audit_number;
	Thread.sleep(1000);
	FunctionLibrary.changeSite();
	//FunctionLibrary.retScreenObject(Screen, Audit_number, Div);
	//Physician_CL201 phy_screen1 = new Physician_CL201();
	if(Screen.equals("CL201"))
	{	
		Physician_CL201 phy_screen1 = new Physician_CL201();
		phy_screen1.CL201_Inquire(Audit_number,Div);
	}
	else if(Screen.equals("CL202"))
	{
		Physician_CL202 phy_screen2 = new Physician_CL202();
		phy_screen2.CL202_Inquire(Audit_number,Div);
	}
	else if(Screen.equals("CL209"))
	{
		Physician_CL209 phy_screen3 = new Physician_CL209();
		phy_screen3.CL209_Inquire(Audit_number,Div);
	}
	else if(Screen.equals("HO400"))
	{
		Hospital_HO400 hos_screen1 = new Hospital_HO400();
		hos_screen1.HO400_Inquire(Audit_number,Div);
	}
	else if(Screen.equals("HO410"))
	{
		Hospital_HO410 hos_screen2 = new Hospital_HO410();
		hos_screen2.HO410_Inquire(Audit_number,Div);
	}
	else if(Screen.equals("HO430"))
	{
		Hospital_HO430 hos_screen3 = new Hospital_HO430();
		hos_screen3.HO430_Inquire(Audit_number,Div);
	}
	else if(Screen.equals("HO409"))
	{
		Hospital_HO409 hos_screen4 = new Hospital_HO409();
		hos_screen4.HO409_Inquire(Audit_number,Div);
	}
	else if(Screen.equals("CL360"))
	{
		Physician_CL360 phy_screen = new Physician_CL360();
	    phy_screen.CL360_Inquire(Audit_number, Div, Screen);
	}
	
	
}

@When("^The place of service \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
public void the_place_of_service_is_present_on_screen(String POS, String Screen) throws Throwable {
	String act_pos=null,act_svc;
	Thread.sleep(1000);
	//Physician_CL201 phy_val3 = new Physician_CL201();
	if(Screen.equals("CL201"))
	{	
		
		Physician_CL201 phy_screen1 = new Physician_CL201();
		act_pos =phy_screen1.pos_val();
		
		act_svc = phy_screen1.svc1_val();
		
	}
	
	else if(Screen.equals("HO400"))
	{
		Hospital_HO400 hos_screen1 = new Hospital_HO400();
		act_pos =hos_screen1.pos_val();
		
	}
	Assert.assertEquals(act_pos,POS);
	System.out.println("Actual POS is " +act_pos);
	Reporter.addStepLog("Actual POS is " +act_pos);
}

@When("^The CPT code used is \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_CPT_code_used_is(String CPT,String Screen) throws Throwable {
	String act_CPT = null;
	if(Screen.equals("CL201"))
	{	
		Physician_CL201 phy_screen1 = new Physician_CL201();
		if(phy_screen1.proc_code1.getText().contains(CPT))
		{
		
			act_CPT =phy_screen1.proc1_val();
		}
		else if(phy_screen1.proc_code2.getText().contains(CPT))
		{
			 act_CPT =phy_screen1.proc2_val();
		}
		else
		{
			
			while(!phy_screen1.claim_msg_val().trim().contains("LAST RECORD"))
			{
				phy_screen1.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
				Thread.sleep(1000);
				if(phy_screen1.proc_code1.getText().contains(CPT))
				{
					act_CPT =phy_screen1.proc1_val();
				}
				else if(phy_screen1.proc_code2.getText().contains(CPT))
				{
					act_CPT =phy_screen1.proc2_val();
				}
				break;
			}
		}
	}
	
	else if(Screen.equals("HO400"))
	{
		Hospital_HO400 hos_screen1 = new Hospital_HO400();
		if(hos_screen1.cpt1.getText().contains(CPT))
		{
			act_CPT =hos_screen1.cpt1_val();
		}
		else if(hos_screen1.cpt2.getText().contains(CPT))
		{
			act_CPT =hos_screen1.cpt2_val();
		}
		else if(hos_screen1.cpt3.getText().contains(CPT))
		{
			act_CPT =hos_screen1.cpt3_val();
		}
		else if(hos_screen1.cpt4.getText().contains(CPT))
		{
			act_CPT =hos_screen1.cpt4_val();
		}
		
	}
	pro_code=act_CPT;
	Assert.assertEquals(act_CPT,CPT);
	System.out.println("CPT code is " +act_CPT);
	Reporter.addStepLog("CPT code is " +act_CPT);
	//return act_CPT;*/
/*	Physician_CL201 phy_val1 = new Physician_CL201();
	if(CPT.equals(phy_val1.proc_code1))
	{
		act_CPT =phy_val1.proc1_val();
		Assert.assertEquals(act_CPT,CPT);
		System.out.println("CPT code is" +act_CPT);
		//return act_CPT;
	}
	else if(CPT.equals(phy_val1.proc_code2))
	{
		act_CPT =phy_val1.proc2_val();
		Assert.assertEquals(act_CPT,CPT);
		System.out.println("CPT code is" +act_CPT);
	}*/
	
}

@When("^the modifier \"([^\"]*)\" is used in \"([^\"]*)\"$")
public void the_modifier_is_used_in(String arg1, String arg2) throws Throwable {
	Physician_CL201 phy_val1 = new Physician_CL201();
    if(arg1.equals(phy_val1.proc_code1_mod1.getText()))
    {		
    	String act_mod1 =phy_val1.proc1_mod1_val();
    	Assert.assertEquals(act_mod1,arg1);
    	System.out.println("Modifier code is" +act_mod1);
    	Reporter.addStepLog("Modifier code is" +act_mod1);
    }	
    else if(arg1.equals(phy_val1.proc_code1_mod2.getText()))
    {		
       	String act_mod1 =phy_val1.proc1_mod2_val();
    	Assert.assertEquals(act_mod1,arg1);
    	System.out.println("Modifier code is" +act_mod1);
    	Reporter.addStepLog("Modifier code is" +act_mod1);
    }
    else if(arg1.equals(phy_val1.proc_code1_mod3.getText()))
    {		
       	String act_mod1 =phy_val1.proc1_mod3_val();
    	Assert.assertEquals(act_mod1,arg1);
    	System.out.println("Modifier code is" +act_mod1);
    	Reporter.addStepLog("Modifier code is" +act_mod1);
    }
    else if(arg1.equals(phy_val1.proc_code1_mod4))
    {		
       	String act_mod1 =phy_val1.proc1_mod4_val();
    	Assert.assertEquals(act_mod1,arg1);
    	System.out.println("Modifier code is" +act_mod1);
    	Reporter.addStepLog("Modifier code is" +act_mod1);
    }
    else if(arg1.equals(phy_val1.proc_code2_mod1.getText()))
    {		
       	String act_mod1 =phy_val1.proc2_mod1_val();
    	Assert.assertEquals(act_mod1,arg1);
    	System.out.println("Modifier code is" +act_mod1);
    	Reporter.addStepLog("Modifier code is" +act_mod1);
    }
    else if(arg1.equals(phy_val1.proc_code2_mod2.getText()))
    {		
       	String act_mod1 =phy_val1.proc2_mod2_val();
    	Assert.assertEquals(act_mod1,arg1);
    	System.out.println("Modifier code is" +act_mod1);
    	Reporter.addStepLog("Modifier code is" +act_mod1);
    }
    else if(arg1.equals(phy_val1.proc_code2_mod3.getText()))
    {		
       	String act_mod1 =phy_val1.proc2_mod3_val();
    	Assert.assertEquals(act_mod1,arg1);
    	System.out.println("Modifier code is" +act_mod1);
    	Reporter.addStepLog("Modifier code is" +act_mod1);
    }
    else if(arg1.equals(phy_val1.proc_code2_mod4.getText()))
    {		
       	String act_mod1 =phy_val1.proc2_mod4_val();
    	Assert.assertEquals(act_mod1,arg1);
    	System.out.println("Modifier code is" +act_mod1);
    	Reporter.addStepLog("Modifier code is" +act_mod1);
    }
}

@When("^the provider status \"([^\"]*)\" is displayed in screen \"([^\"]*)\"$")
public void the_provider_status_is_displayed_in_screen(String Prov_status, String Screen3) throws Throwable {
	Thread.sleep(1000);
	FunctionLibrary.navigateToDiv(Screen3);
	if (Screen3.equals("CL202"))
	{
		
		Physician_CL202 phy_val1 = new Physician_CL202();
		phy_val1.CL202_Inquire(Audit_number, Div);
		Thread.sleep(1000);
		String act_prov_stat =phy_val1.par_status_val();
		Thread.sleep(1000);
		Assert.assertEquals(act_prov_stat,Prov_status);
		System.out.println("Prov status is " +act_prov_stat);
		Reporter.addStepLog("Prov status is " +act_prov_stat);
	}	
	else if(Screen3.equals("HO410"))
	{
		Hospital_HO410 hos_val1 = new Hospital_HO410();
		hos_val1.HO410_Inquire(Audit_number, Div);
		Thread.sleep(1000);
		String act_prov_stat =hos_val1.par_status_val();
		Assert.assertEquals(act_prov_stat,Prov_status);
		System.out.println("Prov status is " +act_prov_stat);
		Reporter.addStepLog("Prov status is " +act_prov_stat);
	}

}

@Then("^the \"([^\"]*)\" value from \"([^\"]*)\" in database \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" is validated against \"([^\"]*)\"$")
public void the_value_from_in_database_for_primary_key_as_is_validated_against(String fieldname, String table, String reg, String keyf, String keyval, String cpt) throws Throwable {
	String col = FunctionLibrary.DB2Validation(fieldname, reg, table, keyf, keyval);
    Physician_CL201 phy_val1 = new Physician_CL201();
    String main_proc =phy_val1.proc1_val();
    Assert.assertEquals(col,main_proc);
}
@Then("^the claim is denied with the denial code \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_claim_is_denied_with_the_denial_code_in_screen(String Detail_deny_code1, String Screen1) throws Throwable {
	
	fl_inq1.navigateToDiv(Screen1);
	Physician_CL201 phy_val1 = new Physician_CL201();
	phy_val1.CL201_Inquire(Audit_number, Div);
	String act_deny_code =phy_val1.det1_deny_val();
	Assert.assertEquals(act_deny_code,Detail_deny_code1 );
	System.out.println("Deny code is " +act_deny_code);
	Reporter.addStepLog("Deny code is " +act_deny_code);
	fl_inq1.takeScreenshot("CL201","Verified_DenialCode");
}

@Then("^the claim is hit with review \"([^\"]*)\" in screen \"([^\"]*)\" and is processed by adjudipro \"([^\"]*)\"$")
public void the_claim_is_hit_with_review_in_screen_and_is_processed_by_adjudipro(String Review, String Screen2, String Rev_user_code) throws Throwable 

{
	Thread.sleep(800);


	if(Screen2.equals("CL209")){

	FunctionLibrary.navigateToDiv(Screen2);
	Physician_CL209 phy_val1 = new Physician_CL209();
	//FunctionLibrary.navigateToDiv(arg2);
	Thread.sleep(1000);
	phy_val1.CL209_Inquire(Audit_number,Div);
	Thread.sleep(1000);
	List<String> exp_result = new ArrayList<String>();
	exp_result.add(Review);
	exp_result.add(Rev_user_code);
	List act_review_code =phy_val1.review_val(Review);
	Assert.assertEquals(act_review_code,exp_result);
	//Assert.assertEquals(exp_review,exp_Deny.get(0).get(0) );
	System.out.println("Values returned " +act_review_code);
	Reporter.addStepLog("Values returned " +act_review_code);
	System.out.println("Expected outcome " +act_review_code);
	Reporter.addStepLog("Expected outcome " +act_review_code);
}
	if(Screen2.equals("HO409")){

	FunctionLibrary.navigateToDiv(Screen2);
	Hospital_HO409 phy_val1 = new Hospital_HO409();
	//FunctionLibrary.navigateToDiv(arg2);
	Thread.sleep(1000);
	phy_val1.HO409_Inquire(Audit_number,Div);
	Thread.sleep(1000);
	List<String> exp_result = new ArrayList<String>();
	exp_result.add(Review);
	exp_result.add(Rev_user_code);
	List act_review_code =phy_val1.review_val(Review);
	Assert.assertEquals(act_review_code,exp_result);
	//Assert.assertEquals(exp_review,exp_Deny.get(0).get(0) );
	System.out.println("Values returned " +act_review_code);
	Reporter.addStepLog("Values returned " +act_review_code);
	System.out.println("Expected outcome " +act_review_code);
	Reporter.addStepLog("Expected outcome " +act_review_code);
	}}
@Then("^the claim is not hit with review \"([^\"]*)\" in screen \"([^\"]*)\" and is not processed by adjudipro \"([^\"]*)\"$")
public void the_claim_is_not_hit_with_review_in_screen_and_is_not_processed_by_adjudipro(String Review, String Screen2, String Rev_user_code) throws Throwable {
	if(Screen2.equals("CL209")){
	FunctionLibrary.navigateToDiv(Screen2);
	Physician_CL209 phy_val1 = new Physician_CL209();
	//FunctionLibrary.navigateToDiv(arg2);

	//Thread.sleep(1000);
	//phy_val1.CL209_Inquire(Audit_number,Div);
  Thread.sleep(1000);
 phy_val1.CL209_Inquire(Audit_number,Div);
	Thread.sleep(1000);
	List<String> exp_result = new ArrayList<String>();
	exp_result.add(Review);
	exp_result.add(Rev_user_code);
	List act_review_code =phy_val1.review_val(Review);
	Assert.assertNotEquals(act_review_code,exp_result);
	System.out.println("Values returned " +act_review_code);
	Reporter.addStepLog("Values returned " +act_review_code);
	System.out.println("Expected outcome " +act_review_code);
	Reporter.addStepLog("Expected outcome " +act_review_code);
}
	if(Screen2.equals("HO409")){
		//FunctionLibrary.navigateToDiv(Screen2);
		FunctionLibrary.navigateToDiv(Screen2);
		Hospital_HO409 phy_val1 = new Hospital_HO409();
		//FunctionLibrary.navigateToDiv(arg2);
		Thread.sleep(1000);
		phy_val1.HO409_Inquire(Audit_number,Div);


		Thread.sleep(1000);
		List<String> exp_result = new ArrayList<String>();
		exp_result.add(Review);
		exp_result.add(Rev_user_code);
		List act_review_code =phy_val1.review_val(Review);
		Assert.assertNotEquals(act_review_code,exp_result);
		System.out.println("Values returned " +act_review_code);
		Reporter.addStepLog("Values returned " +act_review_code);
		System.out.println("Expected outcome " +act_review_code);
		Reporter.addStepLog("Expected outcome " +act_review_code);
		}}
@Then("^the claim inquired for the status \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_claim_inquired_for_the_status_in_screen(String Status, String Screen2) throws Throwable {
	FunctionLibrary.navigateToDiv(Screen2);
	Physician_CL209 phy_val1 = new Physician_CL209();
	//FunctionLibrary.navigateToDiv(arg2);
	Thread.sleep(1000);
	phy_val1.CL209_Inquire(Audit_number,Div);
	Thread.sleep(1000);
	List<String> exp_result = new ArrayList<String>();
	exp_result.add(Status);
	List act_status_code =phy_val1.status_val(Status);
	Assert.assertEquals(act_status_code,exp_result);
	//Assert.assertEquals(exp_review,exp_Deny.get(0).get(0) );
	System.out.println("Values returned " +act_status_code);
	Reporter.addStepLog("Values returned " +act_status_code);
	System.out.println("Expected outcome " +act_status_code);
	Reporter.addStepLog("Expected outcome " +act_status_code);
	

//DriverScript.captureScreenShot();

	//	DriverScript ldriver = null;
//	 if(ldriver == null){
//         try {
//        	 ldriver = new DriverScript();
//				//DriverScript.initialization();
//			} catch (IOException e) {
//				
//				e.printStackTrace();
//			} catch (Exception e) {
//				
//				e.printStackTrace();
//			}
//     }
	//FunctionLibrary.captureScreenShot(ldriver);
	//DriverScript ds = null;
	//WebDriver driver = null;
	//ScreenshotHook ssss=new ScreenshotHook();
	//Scenario scenario = null;
	//ssss.embedScreenshot(scenario);
//	util.ScreenshotHook hgy=new util.ScreenshotHook();
//	Scenario scenario = null;
//	hgy.embedScreenshot(scenario);
}
@Given("^The user is in division \"([^\"]*)\" and inquires for the history claim \"([^\"]*)\" in the screen \"([^\"]*)\"$")
public void the_user_is_in_division_and_inquires_for_the_history_claim_in_the_screen(String Div, String his_claim, String screen) throws Throwable {
	boolean his_audit_present = false;
	this.Div=Div;
	this.Audit_number=his_claim;
	FunctionLibrary.changeSite();
	if(screen.equals("CL201"))
	{	
		Physician_CL201 phy_screen1 = new Physician_CL201();
		phy_screen1.CL201_Inquire(his_claim,Div);
		his_audit_present = phy_screen1.msg_val();
		Assert.assertEquals(his_audit_present,true);
	}
	if(screen.equals("HO400"))
	{	
		Hospital_HO400 hos_screen = new Hospital_HO400();
		hos_screen.HO400_Inquire(his_claim, Div);
		his_audit_present = hos_screen.msg_val();
		//Assert.assertTrue(his_audit_present);
		Assert.assertEquals(his_audit_present,true);
	}
    System.out.println("Audit status is " +his_audit_present);
    Reporter.addStepLog("Audit status is " +his_audit_present);
}

@Given("^the history claim doesn't have modifier \"([^\"]*)\" for cpt code \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_history_claim_doesn_t_have_modifier_for_cpt_code_in_screen(String mod, String cpt, String screen) throws Throwable {
	
	if(screen.equals("CL201"))
	{
		Physician_CL201 phy_screen = new Physician_CL201();
		String act_cpt = phy_screen.proc1_val();
		if(cpt.contains(act_cpt))
		{
			System.out.println("Actual CPT " + act_cpt);
			Reporter.addStepLog("Actual CPT " + act_cpt);
			String act_mod = phy_screen.proc1_mod1_val();
			if (!act_mod.equalsIgnoreCase("No Modifier"))
			{		
				Assert.assertNotEquals(act_mod, mod);
				System.out.println("Actual mod " + act_mod);
				Reporter.addStepLog("Actual mod " + act_mod);
			}
			else
			{
				System.out.println("No modifiers for hostory claim");
				Reporter.addStepLog("No modifiers for hostory claim");
			}
		}
			
	}
	else if(screen.equals("HO400"))
	{
		Hospital_HO400 hos_screen = new Hospital_HO400();
		String act_cpt = hos_screen.cpt1_val();
		Assert.assertEquals(act_cpt, cpt);
		if(cpt.contains(act_cpt))
		{
			Reporter.addStepLog("Actual CPT " + act_cpt);
			String act_mod = hos_screen.cpt1_mod1_val();
			if (!act_mod.equalsIgnoreCase("No Modifier"))
			{		
				Assert.assertNotEquals(act_mod, mod);
				System.out.println("Actual mod " + act_mod);
				Reporter.addStepLog("Actual mod " + act_mod);
			}
			else
			{
				System.out.println("No modifiers for hostory claim");
				Reporter.addStepLog("No modifiers for hostory claim");
			}
		}
	}
}

@When("^The place of service is not \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
public void the_place_of_service_is_not_is_present_on_screen(List<String> pos, String screen) throws Throwable {
	String act_pos=null;
	if(screen.equals("CL201"))
	{	
		Physician_CL201 phy_screen1 = new Physician_CL201();
		act_pos =phy_screen1.pos_val();
	}
	else if(screen.equals("HO400"))
	{
		Hospital_HO400 hos_screen1 = new Hospital_HO400();
		act_pos =hos_screen1.pos_val();
	}
	int no_pos_list = pos.size();
	for(String each_pos : pos)
	{
		Assert.assertNotEquals(act_pos, each_pos);
	}
	//Assert.assertEquals(act_pos,POS);
	System.out.println("Expected  POS is " +pos);
	Reporter.addStepLog("Expected  POS is " +pos);
	System.out.println("Actual POS is " +act_pos);
	Reporter.addStepLog("Expected  POS is " +act_pos);
    
}

@When("^the provider type is not \"([^\"]*)\" on screen \"([^\"]*)\"$")
public void the_provider_type_is_not_on_screen(List<String> prov, String screen) throws Throwable {
	String act_prov_type=null;
	if(screen.equals("CL201"))
	{	
		Physician_CL201 phy_screen1 = new Physician_CL201();
		act_prov_type =phy_screen1.prov_type_val();
		
	}
	else if(screen.equals("HO400"))
	{
		Hospital_HO400 hos_screen1 = new Hospital_HO400();
		act_prov_type =hos_screen1.prov_type_val();
	}
	for(String each_type : prov)
	{
		Assert.assertNotEquals(act_prov_type, each_type);
	}
	//Assert.assertEquals(act_pos,POS);
	System.out.println("Expected  provtype is " +prov);
	Reporter.addStepLog("Expected  provtype is " +prov);
	System.out.println("Actual provtype is " +act_prov_type);
	Reporter.addStepLog("Actual provtype is " +act_prov_type);
}

@When("^The CPT code used is within the range of \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_CPT_code_used_is_within_the_range_of_in_screen(List<String> cpt1, String screen) throws Throwable {
	String act_CPT=null;
	boolean cpt_match = false;
	if(screen.equals("CL201"))
	{	
		Physician_CL201 phy_screen1 = new Physician_CL201();
		for(String each_cpt : cpt1)
		{
			if(phy_screen1.proc_code1.getText().contains(each_cpt))
			{
		
				act_CPT =phy_screen1.proc1_val();
				Assert.assertEquals(act_CPT, each_cpt);
				cpt_match = true;
			}
			
			else if(phy_screen1.proc_code2.getText().contains(each_cpt))
			{
				act_CPT =phy_screen1.proc2_val();
				Assert.assertEquals(act_CPT, each_cpt);
				cpt_match = true;
			}	
			
		}
		if(!cpt_match)
		{
			act_CPT =phy_screen1.proc1_val();
			Assert.assertEquals(act_CPT, cpt1);
		}
	}
	else if(screen.equals("HO400"))
	{
		Hospital_HO400 hos_screen1 = new Hospital_HO400();
		for(String each_cpt : cpt1)
		{
		
			if(hos_screen1.cpt1.getText().contains(each_cpt))
			{
				act_CPT =hos_screen1.cpt1_val();
				Assert.assertEquals(act_CPT, each_cpt);
				cpt_match = true;
			}
			else if(hos_screen1.cpt2.getText().contains(each_cpt))
			{
				act_CPT =hos_screen1.cpt2_val();
				Assert.assertEquals(act_CPT, each_cpt);
				cpt_match = true;
			}
			else if(hos_screen1.cpt3.getText().contains( each_cpt))
			{
				act_CPT =hos_screen1.cpt3_val();
				Assert.assertEquals(act_CPT, each_cpt);
				cpt_match = true;
			}
			else if(hos_screen1.cpt4.getText().contains(each_cpt))
			{
				act_CPT =hos_screen1.cpt4_val();
				Assert.assertEquals(act_CPT, each_cpt);
				cpt_match = true;
			}
			else
			{
				act_CPT =hos_screen1.cpt4_val();
				Assert.assertEquals(act_CPT, each_cpt);
			}
		}	
		if(!cpt_match)
		{	
			act_CPT =hos_screen1.cpt1_val();
			Assert.assertEquals(act_CPT, cpt1);
		}
	}
	
	Reporter.addStepLog("Expected  CPT is " +cpt1);
	Reporter.addStepLog("Actual CPT is " +act_CPT);
   
}


@Given("^the history claim has modifier \"([^\"]*)\" for cpt code \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_history_claim_has_modifier_for_cpt_code_in_screen(String mod, String cpt, String screen) throws Throwable {
	if(screen.equals("CL201"))
	{
		Physician_CL201 phy_screen = new Physician_CL201();
		String act_cpt = phy_screen.proc1_val();
		if(cpt.contains(act_cpt))
		{
			Reporter.addStepLog("Actual CPT " + act_cpt);
			String act_mod = phy_screen.proc1_mod1_val();
			if (!act_mod.equalsIgnoreCase("No Modifier"))
			{		
				Assert.assertEquals(act_mod, mod);
				Reporter.addStepLog("Actual mod " + act_mod);
			}
			else
			{
				Reporter.addStepLog("No modifiers for hostory claim");
			}
		}
			
	}
	else if(screen.equals("HO400"))
	{
		Hospital_HO400 hos_screen = new Hospital_HO400();
		String act_cpt = hos_screen.cpt1_val();
		Assert.assertEquals(act_cpt, cpt);
		if(cpt.contains(act_cpt))
		{
			Reporter.addStepLog("Actual CPT " + act_cpt);
			String act_mod = hos_screen.cpt1_mod1_val();
			if (!act_mod.equalsIgnoreCase("No Modifier"))
			{		
				Assert.assertNotEquals(act_mod, mod);
				Reporter.addStepLog("Actual mod " + act_mod);
			}
			else
			{
				Reporter.addStepLog("No modifiers for hostory claim");
			}
		}
	}
}

@Given("^the history claim has modifier_two \"([^\"]*)\" for cpt code \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_history_claim_has_modifier_two_for_cpt_code_in_screen(String mod, String cpt, String screen) throws Throwable {
	if(screen.equals("CL201"))
	{
		Physician_CL201 phy_screen = new Physician_CL201();
		String act_cpt = phy_screen.proc2_val();
		
		if(cpt.contains(act_cpt))
		{
			Reporter.addStepLog("Actual CPT " + act_cpt);
			String act_mod = phy_screen.proc2_mod1_val();
			if (!act_mod.equalsIgnoreCase("No Modifier"))
			{		
				Assert.assertEquals(act_mod, mod);
				Reporter.addStepLog("Actual mod " + act_mod);
			}
			else
			{
				Reporter.addStepLog("No modifiers for hostory claim");
			}
		}
			
	}
	else if(screen.equals("HO400"))
	{
		Hospital_HO400 hos_screen = new Hospital_HO400();
		String act_cpt = hos_screen.cpt2_val();
		Assert.assertEquals(act_cpt, cpt);
		if(cpt.contains(act_cpt))
		{
			Reporter.addStepLog("Actual CPT " + act_cpt);
			String act_mod = hos_screen.cpt2_mod1_val();
			if (!act_mod.equalsIgnoreCase("No Modifier"))
			{		
				Assert.assertNotEquals(act_mod, mod);
				Reporter.addStepLog("Actual mod " + act_mod);
			}
			else
			{
				Reporter.addStepLog("No modifiers for hostory claim");
			}
		}
	}
}	
@When("^The billed charges is less than \"([^\"]*)\"$")
public void the_billed_charges_is_less_than(String amt) throws Throwable {
	Physician_CL201 phy_screen = new Physician_CL201();
	String act_claimed =phy_screen.claimed1_val();
	double amt_claimed = Double.parseDouble(act_claimed);
	double e_claimed;
	int exp_claimed = Integer.parseInt(amt);
	e_claimed =exp_claimed;
	if(amt_claimed<e_claimed)
	{
		Reporter.addStepLog("Billed amount is less than 1000");
	}
	    
}
@When("^The billed charges is greater than \"([^\"]*)\"$")
public void the_billed_charges_is_greater_than(String amt) throws Throwable {
	Physician_CL201 phy_screen = new Physician_CL201();
	String act_claimed =phy_screen.claimed1_val();
	double amt_claimed = Double.parseDouble(act_claimed);
	double e_claimed;
	int exp_claimed = Integer.parseInt(amt);
	e_claimed =exp_claimed;
	if(amt_claimed>e_claimed)
	{
		Reporter.addStepLog("Billed amount is greater than 1000");
	}
	    
	
}
@Then("^the claim is hit with review \"([^\"]*)\" in screen \"([^\"]*)\" and is not processed by adjudipro \"([^\"]*)\"$")
public void the_claim_is_hit_with_review_in_screen_and_is_not_processed_by_adjudipro(String Review, String Screen2, String Rev_user_code) throws Throwable {
	FunctionLibrary.navigateToDiv(Screen2);
	Physician_CL209 phy_val1 = new Physician_CL209();
	phy_val1.CL209_Inquire(Audit_number,Div);
	Thread.sleep(800);
	List<String> exp_result = new ArrayList<String>();
	exp_result.add(Review);
	exp_result.add(Rev_user_code);
	List act_review_code =phy_val1.review_val(Review);
	Assert.assertNotEquals(act_review_code, exp_result);
	System.out.println("Review not found:Pass");
	//Assert.assertEquals(act_review_code,exp_result);
	Reporter.addStepLog("Values returned " +act_review_code);
	Reporter.addStepLog("Expected outcome " +act_review_code);
}
@Then("^the subaudit \"([^\"]*)\" is created with single detail line \"([^\"]*)\" with modifier \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_subaudit_is_created_with_single_detail_line_with_modifier_in_screen(String sub_aud, String cpt, String mod, String Screen1) throws Throwable {
	FunctionLibrary.navigateToDiv(Screen1);
	boolean his_audit_present=false;
	//Physician_CL201 phy_val1 = new Physician_CL201();
	//phy_val1.CL201_Inquire(sub_aud,Div);
	String act_CPT = null;
	String act_mod1=null;
	if(Screen1.equals("CL201"))
	{	
		Physician_CL201 phy_screen1 = new Physician_CL201();
		phy_screen1.CL201_Inquire(sub_aud,Div);
		his_audit_present = phy_screen1.msg_val();
		Assert.assertEquals(his_audit_present,true);
		if(phy_screen1.proc_code1.getText().contains(cpt))
		{
		
			act_CPT =phy_screen1.proc1_val();
			act_mod1 =phy_screen1.proc1_mod1_val();
	    	//Assert.assertEquals(act_mod1,mod);
		}
		else if(phy_screen1.proc_code2.getText().contains(cpt))
		{
			 act_CPT =phy_screen1.proc2_val();
			 act_mod1 =phy_screen1.proc1_mod1_val();
		     //Assert.assertEquals(act_mod1,mod);
		}	
		Assert.assertEquals(act_CPT, cpt);
		Assert.assertEquals(act_mod1,mod);
		Reporter.addStepLog("Actual cpt is " +act_CPT);
		Reporter.addStepLog("Actual modifier is " +act_mod1);
	}
	
	else if(Screen1.equals("HO400"))
	{
		Hospital_HO400 hos_screen1 = new Hospital_HO400();
		if(hos_screen1.cpt1.getText().contains(cpt))
		{
			act_CPT =hos_screen1.cpt1_val();
		}
		else if(hos_screen1.cpt2.getText().contains(cpt))
		{
			act_CPT =hos_screen1.cpt2_val();
		}
		else if(hos_screen1.cpt3.getText().contains(cpt))
		{
			act_CPT =hos_screen1.cpt3_val();
		}
		else if(hos_screen1.cpt4.getText().contains(cpt))
		{
			act_CPT =hos_screen1.cpt4_val();
		}
		
	}
	
	Assert.assertEquals(act_CPT,cpt);
	Reporter.addStepLog("CPT code is " +act_CPT);
}
@Then("^the claim is denied with the denial code \"([^\"]*)\" for detail line \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_claim_is_denied_with_the_denial_code_for_detail_line_in_screen(String deny_code, String cpt, String Screen1) throws Throwable {
	FunctionLibrary.navigateToDiv(Screen1);
	String act_deny_code = null;
	if (Screen1.equals("CL201"))
	{
		Physician_CL201 phy_val1 = new Physician_CL201();
		String aud_nbr = phy_val1.phy_aud_val();
		Thread.sleep(500);
		if(aud_nbr.equalsIgnoreCase(""))
		{	
			phy_val1.CL201_Inquire(Audit_number, Div);
		}	
		if(cpt.equals(phy_val1.proc_code1.getText()))
		{	
			act_deny_code =phy_val1.det1_deny_val();
			Assert.assertEquals(act_deny_code,deny_code );
		}
		else if(cpt.equals(phy_val1.proc_code2.getText()))
		{
			act_deny_code =phy_val1.det2_deny_val();
			Assert.assertEquals(act_deny_code,deny_code );
		}
		else
		{
			while(!phy_val1.claim_msg_val().trim().contains("LAST RECORD"))
			{
				phy_val1.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
				Thread.sleep(1000);
				if(cpt.equals(phy_val1.proc_code1.getText()))
				{
					act_deny_code =phy_val1.det1_deny_val();
				}
				else if(cpt.equals(phy_val1.proc_code2.getText()))
				{
					act_deny_code =phy_val1.det2_deny_val();
				}
			}
		}
		
		Reporter.addStepLog("Deny code is " +act_deny_code +" for cpt code " +cpt);
	}

	//System.out.println("Deny code is " +act_deny_code);
}
@Then("^the claim has some amount \"([^\"]*)\" for detail line \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_claim_has_some_amount_for_detail_line_in_screen(String amt, String cpt, String Screen1) throws Throwable {
	FunctionLibrary.navigateToDiv(Screen1);
	double exp_allowed_amt = Double.parseDouble(amt);
	double allowed_amt=0;
	if (Screen1.equals("CL201"))
	{
		Physician_CL201 phy_val1 = new Physician_CL201();
		phy_val1.CL201_Inquire(Audit_number, Div);
		if(cpt.contains(phy_val1.proc_code1.getText()))
		{	
			allowed_amt =Double.parseDouble(phy_val1.allowed1_val());
		}
		else
		{
			allowed_amt =Double.parseDouble(phy_val1.allowed2_val());
		}
	}
	if(allowed_amt > exp_allowed_amt)
	{
		Assert.assertTrue(true);
		Physician_CL201 phy_val1 = new Physician_CL201();
		Reporter.addStepLog("Allowed amt is " +allowed_amt +" for cpt code " +phy_val1.proc_code1.getText() );
	}
}
@When("^The billed charges is in between \"([^\"]*)\" and \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_billed_charges_is_in_between_and_in_screen(String min, String max, String screen) throws Throwable {
   if(screen.equals("CL201"))
   {
	   Physician_CL201 phy_screen = new Physician_CL201();
	   double min_claimed =Double.parseDouble(min);
	   double max_claimed =Double.parseDouble(max);
	   String act_billed =phy_screen.tot_billed_val();
	   double amt_claimed = Double.parseDouble(act_billed);
	   double e_claimed;
	   if(min_claimed <=amt_claimed && amt_claimed<=max_claimed)
	   {
		   Reporter.addStepLog("Total claimed is " +amt_claimed);
	   }
	   else
	   {
		   Reporter.addStepLog("Total claimed is out of 1000-3000 range" +amt_claimed);
	   }
	}
}

@Then("^the claim is paid at (\\d+)% of billed charges in screen \"([^\"]*)\"$")
public void the_claim_is_paid_at_of_billed_charges_in_screen(int pc, String screen) throws Throwable {
    if(screen.equals("CL201"))
    {
    	FunctionLibrary.navigateToDiv(screen);
    	Physician_CL201 phy_screen = new Physician_CL201();
    	phy_screen.CL201_Inquire(Audit_number, Div);
    	Thread.sleep(1000);
       	String act_billed =phy_screen.tot_billed_val();
    	double amt_claimed = Double.parseDouble(act_billed);
    	double exp_allowed = amt_claimed*pc/100;
    	System.out.println("Expected allowed amount is " +exp_allowed);
    	String act_allowed = phy_screen.tot_allowed_val();
    	double amt_allowed = Double.parseDouble(act_allowed);
    	if(exp_allowed==amt_allowed)
    	{
    		Reporter.addStepLog("Actual allowed amount is " +exp_allowed);
    		Assert.assertEquals(exp_allowed, amt_allowed);
    	}
    }
}
@When("^claim has modifier \"([^\"]*)\" for cpt code \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void claim_has_modifier_for_cpt_code_in_screen(String mod, String cpt, String screen) throws Throwable {
	if(screen.equals("CL201"))
	{
		Physician_CL201 phy_screen = new Physician_CL201();
		String act_cpt = phy_screen.proc1_val();
		if(cpt.contains(act_cpt))
		{
			Reporter.addStepLog("Actual CPT " + act_cpt);
			String act_mod = phy_screen.proc1_mod1_val();
			if (!act_mod.equalsIgnoreCase("No Modifier"))
			{		
				Assert.assertEquals(act_mod, mod);
				Reporter.addStepLog("Actual mod " + act_mod);
			}
			else
			{
				Reporter.addStepLog("No modifiers on claim");
			}
		}
			
	}
	else if(screen.equals("HO400"))
	{
		Hospital_HO400 hos_screen = new Hospital_HO400();
		String act_cpt = hos_screen.cpt1_val();
		Assert.assertEquals(act_cpt, cpt);
		if(cpt.contains(act_cpt))
		{
			Reporter.addStepLog("Actual CPT " + act_cpt);
			String act_mod = hos_screen.cpt1_mod1_val();
			if (!act_mod.equalsIgnoreCase("No Modifier"))
			{		
				Assert.assertNotEquals(act_mod, mod);
				Reporter.addStepLog("Actual mod " + act_mod);
			}
			else
			{
				Reporter.addStepLog("No modifiers on claim");
			}
		}
	}
}


@When("^claim has modifier \"([^\"]*)\" for cpt2 code \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void claim_has_modifier_for_cpt2_code_in_screen(String mod, String cpt, String screen) throws Throwable {
	if(screen.equals("CL201"))
	{
		Physician_CL201 phy_screen = new Physician_CL201();
		
		String act_cpt1=phy_screen.proc2_val();

		if(cpt.contains(act_cpt1))
		{
			Reporter.addStepLog("Actual CPT " + act_cpt1);
			String act_mod = phy_screen.proc2_mod1_val();
			if (!act_mod.equalsIgnoreCase("No Modifier"))
			{		
				Assert.assertEquals(act_mod, mod);
				Reporter.addStepLog("Actual mod " + act_mod);
			}
			else
			{
				Reporter.addStepLog("No modifiers on claim");
			}
		}
			
	}
	else if(screen.equals("HO400"))
	{
		Hospital_HO400 hos_screen = new Hospital_HO400();
		String act_cpt = hos_screen.cpt1_val();
		Assert.assertEquals(act_cpt, cpt);
		if(cpt.contains(act_cpt))
		{
			Reporter.addStepLog("Actual CPT " + act_cpt);
			String act_mod = hos_screen.cpt1_mod1_val();
			if (!act_mod.equalsIgnoreCase("No Modifier"))
			{		
				Assert.assertNotEquals(act_mod, mod);
				Reporter.addStepLog("Actual mod " + act_mod);
			}
			else
			{
				Reporter.addStepLog("No modifiers on claim");
			}
		}
	}
}



@When("^The CPT code used is within the range of \"([^\"]*)\" for audit number \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_CPT_code_used_is_within_the_range_of_for_audit_number_in_screen(List<String> cpt1, String audit, String screen) throws Throwable {
	
	String act_CPT=null;
	boolean cpt_match = false;
	if(screen.equals("CL201"))
		
	{	
		FunctionLibrary.navigateToDiv(screen);
		Physician_CL201 phy_screen1 = new Physician_CL201();
    	phy_screen1.CL201_Inquire(audit, Div);
		
		for(String each_cpt : cpt1)
		{
			if(phy_screen1.proc_code1.getText().contains(each_cpt))
			{
		
				act_CPT =phy_screen1.proc1_val();
				Assert.assertEquals(act_CPT, each_cpt);
				cpt_match = true;
			}
			
			else if(phy_screen1.proc_code2.getText().contains(each_cpt))
			{
				act_CPT =phy_screen1.proc2_val();
				Assert.assertEquals(act_CPT, each_cpt);
				cpt_match = true;
			}	
			
		}
		if(!cpt_match)
		{
			act_CPT =phy_screen1.proc1_val();
			Assert.assertEquals(act_CPT, cpt1);
		}
	}
	else if(screen.equals("HO400"))
	{
		Hospital_HO400 hos_screen1 = new Hospital_HO400();
		for(String each_cpt : cpt1)
		{
		
			if(hos_screen1.cpt1.getText().contains(each_cpt))
			{
				act_CPT =hos_screen1.cpt1_val();
				Assert.assertEquals(act_CPT, each_cpt);
				cpt_match = true;
			}
			else if(hos_screen1.cpt2.getText().contains(each_cpt))
			{
				act_CPT =hos_screen1.cpt2_val();
				Assert.assertEquals(act_CPT, each_cpt);
				cpt_match = true;
			}
			else if(hos_screen1.cpt3.getText().contains( each_cpt))
			{
				act_CPT =hos_screen1.cpt3_val();
				Assert.assertEquals(act_CPT, each_cpt);
				cpt_match = true;
			}
			else if(hos_screen1.cpt4.getText().contains(each_cpt))
			{
				act_CPT =hos_screen1.cpt4_val();
				Assert.assertEquals(act_CPT, each_cpt);
				cpt_match = true;
			}
			else
			{
				act_CPT =hos_screen1.cpt4_val();
				Assert.assertEquals(act_CPT, each_cpt);
			}
		}	
		if(!cpt_match)
		{	
			act_CPT =hos_screen1.cpt1_val();
			Assert.assertEquals(act_CPT, cpt1);
		}
	}
	
	Reporter.addStepLog("Expected  CPT is " +cpt1);
	Reporter.addStepLog("Actual CPT is " +act_CPT);
}

}