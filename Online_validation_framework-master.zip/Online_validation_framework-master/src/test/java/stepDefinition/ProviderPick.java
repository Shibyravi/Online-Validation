package stepDefinition;

import java.util.Iterator;


import org.testng.Assert;

import com.cucumber.listener.Reporter;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Hospital_HO360;
import pages.Hospital_HO430;
import pages.PS308;
import pages.PS475;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL360;
import pages.Physician_CL510;
import util.FunctionLibrary;

public class ProviderPick {

	String pro_Type=null;
	@Given("^provider type \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
	public void provider_type_is_present_on_screen(String Provider_Type, String Screen) throws Throwable {
		Physician_CL202 phy_screen2=new Physician_CL202();
		Hospital_HO430 hs_screen=new Hospital_HO430();
		String pro_Type=null;

		if(Screen.equals("CL202")){
			pro_Type=phy_screen2.prov_type_val_new();
		}
		else if(Screen.endsWith("HO430")){
			pro_Type=hs_screen.prov_type_val_new();	
		}
		//String pro_Type=phy_screen2.prov_type_val_new();
		System.out.println("New value: "+pro_Type);
		Assert.assertEquals(pro_Type, Provider_Type);
		System.out.println("Provider_type matched");
	}


	
	@Given("^The user is in division \"([^\"]*)\" and inquires for the provider no in the screen \"([^\"]*)\"$")
	public void the_user_is_in_division_and_inquires_for_the_provider_no_in_the_screen(String Div, String Screen) throws Throwable {
		Thread.sleep(1000);
		String prov1=null;
		String prov2=null;
		String provArr[]=null;

		provArr=pro_Type.split("-");
		prov1=provArr[0];
		prov2=provArr[1];
		System.out.println("ist no: "+prov1);
		System.out.println("2nd 	no: "+prov2);
		
		
		FunctionLibrary.navigateToDiv(Screen);
		PS308 ps=new PS308();
		ps.PS308_Inquire(prov1, prov2, Screen);
	}
	@When("^the PTI is set from the range of \"([^\"]*)\" on Screen \"([^\"]*)\" in Div \"([^\"]*)\" with Provider Type \"([^\"]*)\"$")
	public void the_PTI_is_set_from_the_range_of_on_Screen_in_Div_with_Provider_Type(String PTI, String Screen2, String Div, String Provider_Type) throws Throwable {		
		boolean flag=false;
		PS308 ps=new PS308();
		String PTI_val=ps.PTI_val();

		if(PTI.contains(",")){

			String ptArr[]=PTI.split(",");
			for (String itr : ptArr) {
				if(PTI_val.equalsIgnoreCase(itr)){
					System.out.println("PTI is in the given range");
					flag=true;
					break;
				}
			}
			Assert.assertTrue(flag);
		}
		else{
			Assert.assertEquals(PTI, PTI_val);
		}

		Reporter.addStepLog("Actual PTI is verified " +PTI_val);
	}

	@When("^type IND is set \"([^\"]*)\"  on Screen \"([^\"]*)\" in Div \"([^\"]*)\" with Provider Type \"([^\"]*)\"$")
	public void type_IND_is_set_on_Screen_in_Div_with_Provider_Type(String IND, String Screen2, String Div, String Provider_Type) throws Throwable {
		boolean flag=false;
		PS308 ps=new PS308();
		String valArr[]=null;
		String ind_val=ps.IND_val();

		if(IND.contains(",")){
			valArr=IND.split(",");
			for (String itr : valArr) {
				if(itr.equals(ind_val)){
					System.out.println("Value Matched for IND");
					flag=true;
					break;
				}
			}
			Assert.assertTrue(flag);
		}
		else{
			Assert.assertEquals(IND, ind_val);
		}

		System.out.println("Type IND checked");
		Reporter.addStepLog("Actual IND is verified " +ind_val);
	}

	@When("^SRC IND is \"([^\"]*)\" for NDB pick on Screen \"([^\"]*)\" in Div \"([^\"]*)\" with Provider Type \"([^\"]*)\"$")
	public void src_IND_is_for_NDB_pick_on_Screen_in_Div_with_Provider_Type(String SCR_IND, String Screen2, String Div, String Provider_type) throws Throwable {
		PS308 ps=new PS308();
		String src_ind_val=ps.SRC_IND_val();
		Assert.assertEquals(src_ind_val, SCR_IND);
		System.out.println("SRC IND checked");
		Reporter.addStepLog("Actual SRC IND is verified " +src_ind_val);
	}


	@Then("^the PPT letter should be \"([^\"]*)\" on Screen \"([^\"]*)\" with audit \"([^\"]*)\" in div \"([^\"]*)\"$")
	public void the_PPT_letter_should_be_on_Screen_with_audit_in_div(String PPT_letter, String Screen,String AuditNo,String Div) throws Throwable {
		Physician_CL202 phy_screen2=new Physician_CL202();
		Hospital_HO430 hs_screen=new Hospital_HO430();
		PS308 ps=new PS308();
		Thread.sleep(400);
		ps.enter_NewScreen(Screen);
		Thread.sleep(800);
		if(Screen.equals("CL202")){
			Thread.sleep(800);
			phy_screen2.CL202_Inquire(AuditNo,Div);
			String letter=phy_screen2.get_pp_letter();
			System.out.println("pp letter on screen: "+letter);
			Assert.assertEquals(letter, PPT_letter);
			System.out.println("PPT letter value matched");
		}
		else if (Screen.equals("HO430")) {
			Thread.sleep(800);
			hs_screen.HO430_Inquire(AuditNo, Div);
			String letter=hs_screen.pp_flag_val();
			System.out.println("pp letter on screen: "+letter);
			Assert.assertEquals(letter, PPT_letter);
			System.out.println("PPT letter value matched");
		}
		Reporter.addStepLog("PP Letter verified " +PPT_letter);
	}

	@When("^user gets the provider no from \"([^\"]*)\"$")
	public void user_gets_the_provider_no_from(String Screen) throws Throwable {
		Physician_CL202 phy_screen2=new Physician_CL202();
		Hospital_HO430 hs_screen=new Hospital_HO430();
	
		if(Screen.equals("CL202")){
			pro_Type=phy_screen2.prov_type_val_new();
		}
		else if(Screen.endsWith("HO430")){
			pro_Type=hs_screen.prov_type_val_new();	
		}
		Thread.sleep(1000);
	}
	
	
	@Given("^SRC IND is \"([^\"]*)\" for NDB Pick on Screen \"([^\"]*)\" in Div \"([^\"]*)\" with Provider Type \"([^\"]*)\"$")
	public void src_IND_is_for_NDB_Pick_on_Screen_in_Div_with_Provider_Type(String SCR_IND, String Screen2, String Div, String Provider_type) throws Throwable {
		PS308 ps=new PS308();
		boolean flag=false;
		String src_ind_val=ps.SRC_IND_val();
		
		if(!src_ind_val.equalsIgnoreCase(SCR_IND)){
			System.out.println("SCR IND is not equal to: "+src_ind_val);
			flag=true;
		}
		else{
			System.out.println("SCR IND is equal to: "+src_ind_val);
			flag=false;
		}

		Reporter.addStepLog("Actual SRC IND is verified " +src_ind_val);
	}
	
	
	@Then("^user is able to see status \"([^\"]*)\" with selection \"([^\"]*)\" and key \"([^\"]*)\" in the screen \"([^\"]*)\"$")
	public void user_is_able_to_see_status_with_selection_and_key_in_the_screen(String status, String select, String key, String Screen) throws Throwable {
	
	 PS308 ps=new PS308();
	 String Status=null;
	 boolean flag=false;
	 String statusArr[]=null;
	 ps.enter_NewScreen(Screen);
	 
	 if (Screen.equals("CL360")) {
		 Physician_CL360 phy_screen=new Physician_CL360();
		 phy_screen.enter_Select(select);
		 Thread.sleep(500);
		 phy_screen.enter_Key(key);
		 Thread.sleep(800);
		Status= phy_screen.getStatus();
	}
	 else if (Screen.endsWith("HO360")) {
		Hospital_HO360 hos_screen= new Hospital_HO360();
		hos_screen.enter_Select(select);
		 Thread.sleep(500);
		 hos_screen.enter_Key(key);
		 Thread.sleep(800);
		Status= hos_screen.getStatus();
	
	}
	 
	 statusArr=status.split(",");
	
	if (Status.equalsIgnoreCase(statusArr[0])||Status.equalsIgnoreCase(statusArr[1])) {
		System.out.println("Status verified");
		flag=true;	
	}
	else{
		System.out.println("status not verified");
	}
	Assert.assertTrue(flag);
	Reporter.addStepLog("Status verified " +Status);
	 
	}


}




