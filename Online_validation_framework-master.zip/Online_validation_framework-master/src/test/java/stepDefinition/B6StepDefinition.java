package stepDefinition;

import static org.testng.Assert.assertEquals;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.xmlbeans.XmlENTITIES;
import org.testng.Assert;
import com.hp.lft.sdk.te.Screen;
import cucumber.api.DataTable;
import cucumber.api.java.en.*;
import driver.DriverScript;
import pages.Hospital_HO400;
import pages.Hospital_HO409;
import pages.Hospital_HO410;
import pages.Hospital_HO430;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL209;
import util.FunctionLibrary;


public class B6StepDefinition {

	
 @When("^Provider status \"([^\"]*)\" field in the screen \"([^\"]*)\"$")
public  void provider_status_field_in_the_screen(String parnpar, String Screen) throws Throwable {
	String act_par_status= null;
	FunctionLibrary.navigateToDiv(Screen);
	Hospital_HO410 hos_val = new Hospital_HO410();
	 act_par_status =hos_val.par_status_val();
	Assert.assertEquals(parnpar,act_par_status);
		}
 
 @Then("^Validate the review \"([^\"]*)\" in screen \"([^\"]*)\"$")
 public void validate_the_review_in_screen(String Rvw, String Screen) throws Throwable {
	 
	 FunctionLibrary.navigateToDiv(Screen);
	 Hospital_HO409 hos_val =new Hospital_HO409();
	 
	 String Auditnumber = null,Div = null;
		hos_val.HO409_Inquire(Auditnumber,Div);
		List<String> exp_result = new ArrayList<String>();
		exp_result.add(Rvw);
		
		List act_review_code =hos_val.review_val(Rvw);
		Assert.assertEquals(act_review_code,exp_result);
		System.out.println("Values returned " +act_review_code);
		System.out.println("Expected outcome " +act_review_code);
		
	 
	 
 }
 
 
 
/*@Then("^Validate the \"([^\"]*)\" is present on the claim$")
public void validate_the_is_present_on_the_claim(String Screen,String Rvw) throws Throwable {

	FunctionLibrary.navigateToDiv(Screen);
	//Physician_CL209 phy_val1 = new Physician_CL209();
	
    Hospital_HO409 hos_val =new Hospital_HO409();
	//FunctionLibrary.navigateToDiv(arg2);
	//phy_val1.CL209_Inquire(Audit_number,Div);
    
    String Auditnumber = null,Div = null;
	hos_val.HO409_Inquire(Auditnumber,Div);
	List<String> exp_result = new ArrayList<String>();
	exp_result.add(Rvw);
	//exp_result.add(Rev_user_code);
	List act_review_code =hos_val.review_val(Rvw);
	Assert.assertEquals(act_review_code,exp_result);
	//Assert.assertEquals(exp_review,exp_Deny.get(0).get(0) );
	System.out.println("Values returned " +act_review_code);
	System.out.println("Expected outcome " +act_review_code);
	



}*/	}


