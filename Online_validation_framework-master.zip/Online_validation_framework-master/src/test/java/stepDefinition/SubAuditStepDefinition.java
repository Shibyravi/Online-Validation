package stepDefinition;

import java.io.IOException;
import java.util.List;

import org.junit.Assert;

import com.cucumber.listener.Reporter;
import com.hp.lft.sdk.GeneralLeanFtException;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Hospital_HO400;
import pages.Hospital_HO409;
import pages.Hospital_HO410;
import pages.Hospital_HO430;
import pages.Member_GI301;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL209;
import pages.Provider_GI302;
import util.FunctionLibrary;

public class SubAuditStepDefinition {
public String lineNo=null;
public String Audit_number,Div;
public SubAuditStepDefinition(){
	
	}
	
@Given("^the source value \"([^\"]*)\" is displayed in the screen \"([^\"]*)\"$")
public void the_source_value_is_displayed_in_the_screen(String source, String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	
	if (screen.equals("CL201")){
		Physician_CL201 phy_val1 = new Physician_CL201();
		String phy_source=phy_val1.source_value();
		Assert.assertEquals(phy_source,source);
		System.out.println("The source is:"+phy_source);
		Reporter.addStepLog("The source is:"+phy_source);
}
}



//
//@When("^The CPT code used is within the range of \"([^\"]*)\" for detail line \"([^\"]*)\" in screen \"([^\"]*)\"$")
//public void the_CPT_code_used_is_within_the_range_of_for_detail_line_in_screen(List<String> cpt1, String detail_line_No ,String screen ) throws Throwable {
// 
//	
//	String act_CPT=null;
//	String mod=null;
//	String proc_mod=null;
//	boolean cpt_match = false;
//	if(screen.equals("CL201"))
//	{	
//		Physician_CL201 phy_screen1 = new Physician_CL201();
//	
//		if(detail_line_No.equals("1")){
//		for(String each_cpt : cpt1)
//		{
//			if(phy_screen1.proc_code1.getText().contains(each_cpt))
//		
//		{
//
//			act_CPT =phy_screen1.proc1_val();
//			mod=phy_screen1.proc1_mod1_val();
//			proc_mod=act_CPT.concat(mod);
//			Assert.assertEquals(proc_mod, each_cpt);
//			  System.out.println("actual cpt is "+proc_mod);
//			cpt_match = true;
//		}	
//		}
//		}
//		
//	
//		else if(detail_line_No.equals("2")){
//				for(String each_cpt : cpt1)
//				{
//					if(phy_screen1.proc_code2.getText().contains(each_cpt))
//				
//				{
//						act_CPT =phy_screen1.proc2_val();
//						mod=phy_screen1.proc2_mod1_val();
//						proc_mod=act_CPT.concat(mod);
//						Assert.assertEquals(proc_mod, each_cpt);
//						  System.out.println("actual cpt is "+proc_mod);
//						cpt_match = true;
//				}	
//				}	
//		}
//		else if(detail_line_No.equals("3")){
//			
//			phy_screen1.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
//			Thread.sleep(1000);
//			for(String each_cpt : cpt1)
//			{
//				if(phy_screen1.proc_code1.getText().contains(each_cpt))
//			
//			{
//
//					act_CPT =phy_screen1.proc1_val();
//					mod=phy_screen1.proc1_mod3_val1();
//					proc_mod=act_CPT.concat(mod);
//					Assert.assertEquals(proc_mod, each_cpt);
//					  System.out.println("actual cpt is "+proc_mod);
//					cpt_match = true;
//			}	
//			}	
//	}
//else if(detail_line_No.equals("4")){
//			
//			
//			for(String each_cpt : cpt1)
//			{
//				if(phy_screen1.proc_code2.getText().contains(each_cpt))
//			
//			{
//
//					act_CPT =phy_screen1.proc2_val();
//					mod=phy_screen1.proc2_mod4_val1();
//					proc_mod=act_CPT.concat(mod);
//					Assert.assertEquals(proc_mod, each_cpt);
//					  System.out.println("actual cpt is "+proc_mod);
//					cpt_match = true;
//			}	
//			}	
//	}
//
//	}
//	Reporter.addStepLog("Each value of CPT codes has been verified");
//}



@When("^The CPT code used is within range of \"([^\"]*)\" for detail line \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_CPT_code_used_is_within_range_of_for_detail_line_in_screen(List<String> cpt1, String detail_line_No ,String screen ) throws Throwable {
 
	
	String act_CPT=null;
	String mod=null;
	String proc_mod=null;
	boolean cpt_match = false;
	if(screen.equals("CL201"))
	{	
		Physician_CL201 phy_screen1 = new Physician_CL201();
	
		if(detail_line_No.equals("1")){
		for(String each_cpt : cpt1)
		{
			if(phy_screen1.proc_code1.getText().contains(each_cpt))
		
		{

			act_CPT =phy_screen1.proc1_val();
			mod=phy_screen1.proc1_mod1_val();
			proc_mod=act_CPT.concat(mod);
			Assert.assertEquals(proc_mod, each_cpt);
			  System.out.println("actual cpt is "+proc_mod);
			cpt_match = true;
		}	
		}
		}
		
	
		else if(detail_line_No.equals("2")){
				for(String each_cpt : cpt1)
				{
					if(phy_screen1.proc_code2.getText().contains(each_cpt))
				
				{
						act_CPT =phy_screen1.proc2_val();
						mod=phy_screen1.proc2_mod1_val();
						proc_mod=act_CPT.concat(mod);
						Assert.assertEquals(proc_mod, each_cpt);
						  System.out.println("actual cpt is "+proc_mod);
						cpt_match = true;
				}	
				}	
		}
		else if(detail_line_No.equals("3")){
			
			phy_screen1.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			Thread.sleep(1000);
			for(String each_cpt : cpt1)
			{
				if(phy_screen1.proc_code1.getText().contains(each_cpt))
			
			{

					act_CPT =phy_screen1.proc1_val();
					mod=phy_screen1.proc1_mod3_val1();
					proc_mod=act_CPT.concat(mod);
					Assert.assertEquals(proc_mod, each_cpt);
					  System.out.println("actual cpt is "+proc_mod);
					cpt_match = true;
			}	
			}	
	}
else if(detail_line_No.equals("4")){
			
			
			for(String each_cpt : cpt1)
			{
				if(phy_screen1.proc_code2.getText().contains(each_cpt))
			
			{

					act_CPT =phy_screen1.proc2_val();
					mod=phy_screen1.proc2_mod4_val1();
					proc_mod=act_CPT.concat(mod);
					Assert.assertEquals(proc_mod, each_cpt);
					  System.out.println("actual cpt is "+proc_mod);
					cpt_match = true;
			}	
			}	
	}

	}
	Reporter.addStepLog("Each value of CPT codes has been verified");
}
@Then("^the provider number \"([^\"]*)\" is inquired in screen \"([^\"]*)\"$")
public void the_provider_number_is_inquired_in_screen(String provider_num, String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
   FunctionLibrary.navigateToDiv(screen);
   if (screen.equals("GI302")){
	   Provider_GI302 p=new Provider_GI302();
		p.provider_inq(provider_num, screen);
}
   
}

@Then("^the value of indicator is \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_value_of_indicator_is_in_screen(String ind,String screen) throws IOException, GeneralLeanFtException, InterruptedException{
	String split_ind=null;String splitind=null;
	
	if(screen.equals("GI301")){
		 Member_GI301 p=new Member_GI301();
		 split_ind= p.Indicator_val();
		 final String value;
		 if (split_ind == null || split_ind.length() <= 0) {
		     value = "Y";
		 } else if (split_ind.length() <= 14) {
		     value = split_ind;
		 } else { 
		     value = split_ind.substring(13,14);
		 }
		
		 System.out.println("The value of indicator is:"+value);
		 Assert.assertEquals(ind,value);
	}
	
}

@Then("^the message \"([^\"]*)\" displayed in screen \"([^\"]*)\"$")
public void the_message_displayed_in_screen(String msg, String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String hos_msg=null;
	if(screen.equals("HO400"))
	{	
		Hospital_HO400 hos_screen = new Hospital_HO400();
		//hos_screen.HO400_Inquire(Auditnumber, Div);
		hos_msg = hos_screen.hos_msg_val();
		//Assert.assertTrue(his_audit_present);
		System.out.println("The message displayed is:"+hos_msg);
		Assert.assertEquals(hos_msg,msg);
	}
	else {
		System.out.println("No message found");
	}
	System.out.println("Audit status is " +hos_msg);
	Reporter.addStepLog("Audit status is " +hos_msg);
	}


//@Then("^the subaudit \"([^\"]*)\" is created with single detail line \"([^\"]*)\" with assistant surgeon modifier \"([^\"]*)\" and modifier \"([^\"]*)\" in screen \"([^\"]*)\" in division \"([^\"]*)\"$")
//public void the_subaudit_is_created_with_single_detail_line_with_assistant_surgeon_modifier_and_modifier_in_screen_in_division(String sub_aud, String cpt, String mod1,String mod2, String Screen1,String Div) throws Throwable {
//      FunctionLibrary.navigateToDiv(Screen1);
//      boolean his_audit_present=false;
//      boolean flag=false;
//      String act_CPT = null;
//      String act_mod1=null;
//      String act_mod2=null;
//
//      String assSurgMod[]=mod1.split(",");
//
//      if(Screen1.equals("CL201"))
//      {      
//             Physician_CL201 phy_screen1 = new Physician_CL201();
//             phy_screen1.CL201_Inquire(sub_aud,Div);
//             his_audit_present = phy_screen1.msg_val();
//             Assert.assertEquals(his_audit_present,true);
//             if(phy_screen1.proc_code1.getText().contains(cpt))
//             {
//
//                    act_CPT =phy_screen1.proc1_val();
//                    act_mod1 =phy_screen1.proc1_mod1_val();
//                    act_mod2 =phy_screen1.proc1_mod2_val();
//
//
//             }
//             else if(phy_screen1.proc_code2.getText().contains(cpt))
//             {
//                    act_CPT =phy_screen1.proc2_val();
//                    act_mod1 =phy_screen1.proc1_mod1_val();
//                    act_mod2 =phy_screen1.proc1_mod2_val();
//             }      
//             Assert.assertEquals(act_CPT, cpt);
//
//             if(act_mod1.equals(assSurgMod[0])||act_mod1.endsWith(assSurgMod[1])){
//                    System.out.println("Assistant surgeon code verified");       
//                    flag=true;
//             }
//             Assert.assertTrue(flag);
//             Assert.assertEquals(act_mod2,mod2);
//             System.out.println("CC modifer verified");
//             Reporter.addStepLog("Actual cpt is " +act_CPT);
//             Reporter.addStepLog("Actual modifier is " +act_mod1);
//      }
//
//      else if(Screen1.equals("HO400"))
//      {
//             Hospital_HO400 hos_screen1 = new Hospital_HO400();
//             if(hos_screen1.cpt1.getText().contains(cpt))
//             {
//                    act_CPT =hos_screen1.cpt1_val();
//             }
//             else if(hos_screen1.cpt2.getText().contains(cpt))
//             {
//                    act_CPT =hos_screen1.cpt2_val();
//             }
//             else if(hos_screen1.cpt3.getText().contains(cpt))
//             {
//                    act_CPT =hos_screen1.cpt3_val();
//             }
//             else if(hos_screen1.cpt4.getText().contains(cpt))
//             {
//                    act_CPT =hos_screen1.cpt4_val();
//             }
//
//      }
//
//      Assert.assertEquals(act_CPT,cpt);
//      Reporter.addStepLog("CPT code is " +act_CPT);



@Then("^the subaudit \"([^\"]*)\" is created with single detail line \"([^\"]*)\" with sub modifier \"([^\"]*)\" and modifier \"([^\"]*)\" in screen \"([^\"]*)\" in division \"([^\"]*)\"$")
public void the_subaudit_is_created_with_single_detail_line_with_sub_modifier_and_modifier_in_screen_in_division(String sub_aud, String cpt, String mod1,String mod2, String Screen1,String Div) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	 FunctionLibrary.navigateToDiv(Screen1);
     boolean his_audit_present=false;
     boolean flag=false;
     String act_CPT = null;
     String act_mod1=null;
     String act_mod2=null;

     String assSurgMod[]=mod1.split(",");

     if(Screen1.equals("CL201"))
     {      
            Physician_CL201 phy_screen1 = new Physician_CL201();
            phy_screen1.CL201_Inquire(sub_aud,Div);
            his_audit_present = phy_screen1.msg_val();
            Assert.assertEquals(his_audit_present,true);
            if(phy_screen1.proc_code1.getText().contains(cpt))
            {

                   act_CPT =phy_screen1.proc1_val();
                   act_mod1 =phy_screen1.proc1_mod1_val();
                   act_mod2 =phy_screen1.proc1_mod2_val();


            }
            else if(phy_screen1.proc_code2.getText().contains(cpt))
            {
                   act_CPT =phy_screen1.proc2_val();
                   act_mod1 =phy_screen1.proc1_mod1_val();
                   act_mod2 =phy_screen1.proc1_mod2_val();
            }      
            Assert.assertEquals(act_CPT, cpt);

            if(act_mod1.equals(assSurgMod[0])||act_mod1.endsWith(assSurgMod[1])){
                   System.out.println("Sub-Audit code verified");       
                   flag=true;
            }
            Assert.assertTrue(flag);
            Assert.assertEquals(act_mod2,mod2);
            System.out.println("CC modifer verified");
            Reporter.addStepLog("Actual cpt is " +act_CPT);
            Reporter.addStepLog("Actual modifier is " +act_mod1);
     }

     else if(Screen1.equals("HO400"))
     {
            Hospital_HO400 hos_screen1 = new Hospital_HO400();
            if(hos_screen1.cpt1.getText().contains(cpt))
            {
                   act_CPT =hos_screen1.cpt1_val();
            }
            else if(hos_screen1.cpt2.getText().contains(cpt))
            {
                   act_CPT =hos_screen1.cpt2_val();
            }
            else if(hos_screen1.cpt3.getText().contains(cpt))
            {
                   act_CPT =hos_screen1.cpt3_val();
            }
            else if(hos_screen1.cpt4.getText().contains(cpt))
            {
                   act_CPT =hos_screen1.cpt4_val();
            }

     }

     Assert.assertEquals(act_CPT,cpt);
     Reporter.addStepLog("CPT code is " +act_CPT);

}


@When("^the claim schedule type is \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_claim_schedule_type_is_in_screen(String schd, String Screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    Physician_CL201 cl201=new Physician_CL201();
    String schedule=null;
    if(Screen.equals("Cl201")){
    schedule= cl201.schd1_val();
    System.out.println("Teh value of Schedule is:"+schedule);
    Assert.assertEquals(schd, schedule);
    }
}

/*@When("^The CPT code used is within range of \"([^\"]*)\" for detail line \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_CPT_code_used_is_within_range_of_for_detail_line_in_screen(List<String> cpt1, String detail_line_No ,String screen ) throws Throwable {
 
	
	String act_CPT=null;
	String mod=null;
	String proc_mod=null;
	boolean cpt_match = false;
	if(screen.equals("CL201"))
	{	
		Physician_CL201 phy_screen1 = new Physician_CL201();
	
		if(detail_line_No.equals("1")){
		for(String each_cpt : cpt1)
		{
			if(phy_screen1.proc_code1.getText().contains(each_cpt))
		
		{

			act_CPT =phy_screen1.proc1_val();
			mod=phy_screen1.proc1_mod1_val();
			proc_mod=act_CPT.concat(mod);
			Assert.assertEquals(proc_mod, each_cpt);
			  System.out.println("actual cpt is "+proc_mod);
			cpt_match = true;
		}	
		}
		}
		
	
		else if(detail_line_No.equals("2")){
				for(String each_cpt : cpt1)
				{
					if(phy_screen1.proc_code2.getText().contains(each_cpt))
				
				{
						act_CPT =phy_screen1.proc2_val();
						mod=phy_screen1.proc2_mod1_val();
						proc_mod=act_CPT.concat(mod);
						Assert.assertEquals(proc_mod, each_cpt);
						  System.out.println("actual cpt is "+proc_mod);
						cpt_match = true;
				}	
				}	
		}
		else if(detail_line_No.equals("3")){
			
			phy_screen1.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			Thread.sleep(1000);
			for(String each_cpt : cpt1)
			{
				if(phy_screen1.proc_code1.getText().contains(each_cpt))
			
			{

					act_CPT =phy_screen1.proc1_val();
					mod=phy_screen1.proc1_mod3_val1();
					proc_mod=act_CPT.concat(mod);
					Assert.assertEquals(proc_mod, each_cpt);
					  System.out.println("actual cpt is "+proc_mod);
					cpt_match = true;
			}	
			}	
	}
else if(detail_line_No.equals("4")){
			
			
			for(String each_cpt : cpt1)
			{
				if(phy_screen1.proc_code2.getText().contains(each_cpt))
			
			{

					act_CPT =phy_screen1.proc2_val();
					mod=phy_screen1.proc2_mod4_val1();
					proc_mod=act_CPT.concat(mod);
					Assert.assertEquals(proc_mod, each_cpt);
					  System.out.println("actual cpt is "+proc_mod);
					cpt_match = true;
			}	
			}	
	}

	}
	Reporter.addStepLog("Each value of CPT codes has been verified");
}


*/


@Then("^the claim with service code \"([^\"]*)\" for detail line \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_claim_with_service_code_for_detail_line_in_screen(String svc, String line, String Screen1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	FunctionLibrary.navigateToDiv(Screen1);
	String act_svc_code = null;
	if (Screen1.equals("CL201"))
	{
		Physician_CL201 phy_val1 = new Physician_CL201();
		phy_val1.press_enter();
		String aud_nbr = phy_val1.phy_aud_val();
		Thread.sleep(500);
		if(aud_nbr.equalsIgnoreCase(""))
		{	
			phy_val1.CL201_Inquire(Audit_number, Div);
		}	
		if(svc.equals(phy_val1.svc1.getText()))
		{	
			act_svc_code =phy_val1.svc1_val();
			Assert.assertEquals(act_svc_code,svc );
			System.out.println("Service code of third line:"+act_svc_code);
		}
		if(svc.equals(phy_val1.svc2.getText()))
		{
			act_svc_code =phy_val1.svc2_val();
			Assert.assertEquals(act_svc_code,svc );
			System.out.println("Service code of fourth line:"+act_svc_code);
		}
		else
		{
			
		System.out.println("Service code is " +act_svc_code +" for only one detail line present:" +svc);
		
		Reporter.addStepLog("Service code is " +act_svc_code +" for only one detail line present:" +svc);
		}
	}
}


@When("^the subaudit \"([^\"]*)\" with div \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
public void the_subaudit_with_div_is_present_on_screen(String subaud,String Div, String Screen) throws Throwable {
    
	FunctionLibrary.changeSite();
	//FunctionLibrary.retScreenObject(Screen, Audit_number, Div);
	
	
	//Physician_CL201 phy_screen1 = new Physician_CL201();
	if(Screen.equals("CL201"))
	{	
		Physician_CL201 phy_screen1 = new Physician_CL201();
		phy_screen1.CL201_Inquire(subaud,Div);
	}
	else if(Screen.equals("CL202"))
	{
		Physician_CL202 phy_screen2 = new Physician_CL202();
		phy_screen2.CL202_Inquire(subaud,Div);
	}
	else if(Screen.equals("CL209"))
	{
		Physician_CL209 phy_screen3 = new Physician_CL209();
		phy_screen3.CL209_Inquire(subaud,Div);
	}
	else if(Screen.equals("HO400"))
	{
		Hospital_HO400 hos_screen1 = new Hospital_HO400();
		hos_screen1.HO400_Inquire(subaud,Div);
	}
	else if(Screen.equals("HO410"))
	{
		Hospital_HO410 hos_screen2 = new Hospital_HO410();
		hos_screen2.HO410_Inquire(subaud,Div);
	}
	else if(Screen.equals("HO430"))
	{
		Hospital_HO430 hos_screen3 = new Hospital_HO430();
		hos_screen3.HO430_Inquire(subaud,Div);
	}
	else if(Screen.equals("HO409"))
	{
		Hospital_HO409 hos_screen4 = new Hospital_HO409();
		hos_screen4.HO409_Inquire(subaud,Div);
	}
	
	
	
}

}
