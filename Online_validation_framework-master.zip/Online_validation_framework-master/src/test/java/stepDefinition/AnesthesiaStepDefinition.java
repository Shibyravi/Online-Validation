package stepDefinition;

import org.testng.Assert;


import com.cucumber.listener.Reporter;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.FeeMax_TB822;
import pages.Hospital_HO410;
import pages.PS330;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_PS340;
import pages.Physician_PS343;
import pages.Procedure_PCFM;
import util.FunctionLibrary;

public class AnesthesiaStepDefinition {
	public String act_base_fee, feeMax, schd_value;
	
	public String Audit_number, Div;
	Procedure_PCFM fl_pcfm= new Procedure_PCFM();
    FeeMax_TB822 ftb=new FeeMax_TB822();
  
    String stdAnes=null;
    String percent=null;
    String noOfUnits=null;
    String act_mod1=null;
	String act_mod2=null;
	String calcType=null;
	String standard_fee_max1,anesfact1,anes_factor=null;
	int updated_Unit,Unit;
	String contr=null;
	String a=null;
	

	 double updated_Mode1,updated_Mode2,standardAnes,standardFeemaxFact,std_percent,std_fee_max,updated_anesfact,updated_req_feeMax,req_feeMax,AnesthesiaFact,fee_pcfm_anes,fee_pcfm; 
	 

public AnesthesiaStepDefinition() {
		
	}

	@Then("^the user inquires for the CPT code \"([^\"]*)\" and From date \"([^\"]*)\" on screen \"([^\"]*)\"$")
	public void the_user_inquires_for_the_CPT_code_and_From_date_on_screen(String cpt1 ,String fromDate,String screen) throws Throwable {
		Physician_CL201 phy_screen = new Physician_CL201();
		String from=phy_screen.from_val();
		String cpt=phy_screen.proc1_val();
		feeMax=phy_screen.fee_max_val();
		System.out.println("fee max is"+feeMax);
		FunctionLibrary.navigateToDiv(screen);
		
		if (screen.equals("PCFM")) {
			Procedure_PCFM phy_screen1 = new Procedure_PCFM();
			phy_screen1.Procedure_PCFM_Inquire("GET",from,cpt);
			Thread.sleep(2000);
			Procedure_PCFM phy_screen2 = new Procedure_PCFM();
			String standard_fee_max=phy_screen2.std_fee_max_val();
			System.out.println("standard fee max is string"+standard_fee_max);
			double fee_201 = Double.parseDouble(feeMax);
			double fee_pcfm = Double.parseDouble(standard_fee_max);
			System.out.println("standard fee max is "+fee_pcfm);
			Assert.assertEquals(fee_201, fee_pcfm);
			
		}
		
	}
	
	
/*	@When("^the required unit fee \"([^\"]*)\" with audit number \"([^\"]*)\" div \"([^\"]*)\" is displayed in the screen \"([^\"]*)\"$")
	public void the_required_unit_fee_with_audit_number_div_is_displayed_in_the_screen(String unit_fee,String Audit_Number,String aud1,String Div, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String act_fee=null;
		String act_fee1=null;
		String req_unit_fee=null;
		int P3=015;
	    FunctionLibrary.navigateToDiv(screen);
	    Thread.sleep(1000);
	    
	    if(screen.equals("CL201"))
		{	
			
			Physician_CL201 phy_val = new Physician_CL201();
			 
			    phy_val.CL201_Inquire(aud1, Div);
			    act_fee=phy_val.unitfee_val();
				Thread.sleep(1000);
				req_unit_fee=(P3+act_fee);
				System.out.println("The unit fee is:"+req_unit_fee);
				phy_val.CL201_Inquire(Audit_Number, Div);
			    unit_fee=phy_val.unitfee_val();
			    Assert.assertEquals(req_unit_fee,unit_fee);
				System.out.println("The actual unit fee is:"+req_unit_fee);
			    Reporter.addStepLog("The actual unit fee is:" +req_unit_fee);
		}
	   
	}*/

	@When("^the required unit fee \"([^\"]*)\" with audit number \"([^\"]*)\" and audit number \"([^\"]*)\" div \"([^\"]*)\" is displayed in the screen \"([^\"]*)\"$")
	public void the_required_unit_fee_with_audit_number_and_audit_number_div_is_displayed_in_the_screen(String unit_fee,String Audit_Number,String aud1,String Div, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String act_fee=null;
		String act_fee1=null;
		int req_unit_fee;
		int P3=15;
	    FunctionLibrary.navigateToDiv(screen);
	    Thread.sleep(1000);
	    
	    if(screen.equals("CL201"))
		{	
			
			Physician_CL201 phy_val = new Physician_CL201();
			 
			    phy_val.CL201_Inquire(aud1, Div);
			    act_fee=phy_val.unitfee_val();
			    int unit2 = Integer.parseInt(act_fee);
				Thread.sleep(1000);
				req_unit_fee=P3+unit2;
				String unitF= String.format("%03d", req_unit_fee);
				System.out.println("The unit fee is from calculation:"+unitF);
				phy_val.CL201_Inquire(Audit_Number, Div);
			    unit_fee=phy_val.unitfee_val();
			    Assert.assertEquals(unitF,unit_fee);
				System.out.println("The actual unit fee is:"+unitF);
			    Reporter.addStepLog("The actual unit fee is:" +unitF);
		}
	   
	}
	@When("^the unit fee \"([^\"]*)\" is displayed within the ranges in the screen \"([^\"]*)\"$")
	public void the_unit_fee_is_displayed_within_the_ranges_in_the_screen(String unit_fee, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String act_fee=null;
		int fee;
	    FunctionLibrary.navigateToDiv(screen);
	    Thread.sleep(1000);
	    
	    if(screen.equals("CL201"))
		{	
			
			Physician_CL201 phy_val = new Physician_CL201();
			 
			    act_fee=phy_val.unitfee_val();
			    
			    try
			    {
			      // perform the string to int conversion here
			    	fee = Integer.parseInt(act_fee);
			    	System.out.println("The unit fee is:"+fee);
			    	if(fee>1 && fee<999){
			    		System.out.println("The unit fee"+""+fee+""+"is a valid one");
			    	}
			    	else
			    		System.out.println("The unit fee" +fee +"is a not valid one");
			    }
			    catch (NumberFormatException nfe)
			    {
			    	System.out.println("The unit fee does not exists");
			    }
				
		}
	   
	}
	
	
	@Then("^the user fetch the NDB market number \"([^\"]*)\"  from Screen \"([^\"]*)\"$")
	public void the_user_fetch_the_NDB_market_number_from_Screen(String NDB, String Screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if (Screen.equalsIgnoreCase("PS340")) {
			Physician_PS340 ps=new Physician_PS340();
			String Ndb_no=ps.ndb_mkt_val();
			System.out.println("The NDB market no is :"+Ndb_no);
			Assert.assertEquals(NDB, Ndb_no);
			Thread.sleep(500);
		}
	}
	
	@Given("^The user is in division \"([^\"]*)\" and inquires for the audit number \"([^\"]*)\" should not be present in the screen \"([^\"]*)\" and display message \"([^\"]*)\"$")
	public void the_user_inquires_INVALID_audit_no(String div, String audit,String Screen,String msg) throws Throwable {
	this.Div = Div;
	this.Audit_number = Audit_number;
	Thread.sleep(1000);
	FunctionLibrary.changeSite();
	if(Screen.equals("CL201"))
	{ 
	Physician_CL201 phy_screen1 = new Physician_CL201();
	phy_screen1.CL201_Inquire(audit,div);
	String error=phy_screen1.invalid_audit_error_val();
	System.out.println("The inquired audit number is not present");
	Assert.assertEquals(error, msg);
	

	}


	}
	



	@Then("^the feemax \"([^\"]*)\" displayed in screen \"([^\"]*)\" with audit number \"([^\"]*)\" and div \"([^\"]*)\" is calculated from the screen \"([^\"]*)\" and screen \"([^\"]*)\" and contract from screen \"([^\"]*)\"$")
	public void the_feemax_displayed_in_screen_with_audit_number_and_div_is_calculated_from_the_screen_and_screen_and_contract_from_screen(String feemax, String screen,String Audit_number,String Div,String Screen2,String Screen3,String Screen4) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Physician_CL201 phy_screen = new Physician_CL201();
		FunctionLibrary.navigateToDiv(screen);
		phy_screen.CL201_Inquire(Audit_number, Div);
		String from=phy_screen.from_val();
		String cpt=phy_screen.proc1_val();
		feeMax=phy_screen.fee_max_val();
		String dos=phy_screen.frm_dos1_val();
		String pos= phy_screen.pos_val();
		String providerType=phy_screen.prov_type_val();
		System.out.println("fee max is:"+feeMax);
		FunctionLibrary.navigateToDiv(Screen2);
		
		if (Screen2.equals("PCFM")) {
			Procedure_PCFM phy_screen1 = new Procedure_PCFM();
			phy_screen1.Procedure_PCFM_Inquire("GET",from,cpt);
			Thread.sleep(2000);
			String standard_fee_max=phy_screen1.std_fee_max_val();
			if(standard_fee_max==null){
				System.out.println("Not found Standard Fee Max value in PCFM");
			}
			else{
			System.out.println("standard fee max is string"+standard_fee_max);
			fee_pcfm = Double.parseDouble(standard_fee_max);
			System.out.println("standard fee max is"+fee_pcfm);
			}
			String standard_Anes_max=phy_screen1.stdAnes_val();
			if(standard_Anes_max.equals("")){
				System.out.println("Anex Max Not found in PCFM");
			}
			else
			{
				System.out.println("Standard Anes max is string:"+standard_Anes_max);
				 fee_pcfm_anes = Double.parseDouble(standard_Anes_max);
				System.out.println("Standard Anes max in PCFM is: "+fee_pcfm_anes);
			}
		
			phy_screen1.command.setText("TB822");
			phy_screen1.com_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			FunctionLibrary.navigateToDiv(Screen3);
	    	 if(Screen3.equals("TB822")){
	    		 FeeMax_TB822 ftb= new FeeMax_TB822();
	    		 
	    		ftb.TB822_Inquire(dos, pos, providerType,"4", cpt);
	    		Thread.sleep(1000);
	    		calcType=ftb.calcType_val();
	    		System.out.println("The calc type is:"+calcType);
	    		String stdfeemaxfactor=ftb.feemax_val();
	    		System.out.println("The value of feemaxfactor:"+stdfeemaxfactor);
	    		standardFeemaxFact = Double.parseDouble(stdfeemaxfactor);
	    		System.out.println("The value of standard feemax factor is:"+standardFeemaxFact);
	    		 anes_factor=ftb.anesfact_val();
	    		 if(anes_factor.endsWith(":")){
	    			 System.out.println("Not found Anes Factor in TB822");
	    		 }
	    		 else{
	    		AnesthesiaFact = Double.parseDouble(anes_factor);
	    		System.out.println("The value of Anesthesia factor is:"+AnesthesiaFact);
	    		 }
	    	 }
	    	 else {
	 	    	System.out.println("The value of feemax factor is not found");
	    		} 
             ftb.cur_screen.setText("CL201");
	    	 ftb.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	         FunctionLibrary.navigateToDiv(screen);
	        
	    if(screen.equals("CL201")){
			 Physician_CL201 fl_cl= new Physician_CL201();
			 fl_cl.CL201_Inquire(Audit_number,Div);
			 percent= fl_cl.pcnt_val();
			 std_percent = Double.parseDouble(percent);
			 noOfUnits=fl_cl.unit_Val();
			 contr=fl_cl.getContract_No();
			  Unit = Integer.parseInt(noOfUnits);
			 //fl_cl.validate_Proc_Mode2_presentornot(screen);
			act_mod1 =fl_cl.proc1_mod1_val();
			act_mod2 =fl_cl.proc1_mod2_val();
			System.out.println("The value of actmod1 is:"+act_mod1);
			
			if(act_mod1.equals("QS")|| act_mod1.equals("QZ")){
				updated_Mode1=1.0;
				updated_Mode2=1.0;
			}
			else if(act_mod1.equals("QY")|| act_mod1.equals("QX")){
				if(act_mod1.equals("QX") && act_mod1.equals("QY")){
				updated_Mode1=0.5;
				updated_Mode2=0.5;
				}
				else if(act_mod1.equals("QX") || act_mod1.equals("")){
				updated_Mode1=0.5;
				updated_Mode2=1.0;
				}
				else if (act_mod1.equals("QY") || act_mod1.equals(""))
				{
			    updated_Mode1=1.0;
				updated_Mode2=0.5;
			}
			}
			else
			{
				
				updated_Mode1=1.0;
				updated_Mode2=1.0;
			}
			if(act_mod2.equals("P3")){
				updated_Unit=Unit+15;
			}
			else if(act_mod2.equals("P4")){
				updated_Unit=Unit+30;
			}
			else if(act_mod2.equals("P5")){
				updated_Unit=Unit+45;
			}
			else
			{
				updated_Unit=Unit+0;
			}
			System.out.println("The value of actmod2 is:"+act_mod2);
			System.out.println("The percent is:"+percent);
			
			if (calcType.equals("01"))
			{
				
				Double req_feeMax = (fee_pcfm)*(standardFeemaxFact);
				Double updated_req_feeMax=(req_feeMax) * (updated_Mode1)*(updated_Mode2)* (std_percent/100.00) * (updated_Unit);
				System.out.println("The required feemax is :"+updated_req_feeMax);
				double Rounded_updated_req_feeMax= Math.round(updated_req_feeMax * 100D) / 100D;
				System.out.println("The required feemax after rounding off is:"+Rounded_updated_req_feeMax);
			    String Rounded_updated_req_feeMax1 = Double.toString( Rounded_updated_req_feeMax ).replaceAll( "^0", "" );System.out.println( Rounded_updated_req_feeMax1 );
				Assert.assertEquals(feeMax, Rounded_updated_req_feeMax1);	
			}
			else if(calcType.equals("06"))
			{ 
               
				FunctionLibrary.navigateToDiv("PS343");
				Thread.sleep(1000);
				if(Screen4.equals("PS343"))
				{
				Physician_PS343 phy_con= new Physician_PS343();
			    phy_con.PS343_Inquire(contr, Screen4);
				System.out.println("The value of contract:"+contr);
				Thread.sleep(500);
				anesfact1=phy_con.anesfact_val();
				updated_anesfact = Double.parseDouble(anesfact1);
				System.out.println("The value of anes conversion factor is:"+updated_anesfact);
				req_feeMax = (fee_pcfm_anes)+((Unit/AnesthesiaFact));
				
				System.out.println("The value of feeMax is:"+req_feeMax);
				
			updated_req_feeMax=(req_feeMax) * (updated_Mode1) * (updated_Mode2) * (updated_anesfact)*(std_percent/100.00);
				System.out.println("Value:"+updated_req_feeMax);
				double Rounded_updated_req_feeMax= Math.round(updated_req_feeMax * 100D) / 100D;
				 System.out.println("The required feemax is:"+Rounded_updated_req_feeMax);
				feeMax= feeMax.trim();
						Assert.assertEquals(Rounded_updated_req_feeMax, feeMax);
				}
			 else
			   {
				System.out.println("Not found");
	            }
		}
	    
			

}}}
	@Then("^the feemax \"([^\"]*)\" displayed in screen \"([^\"]*)\" with audit number \"([^\"]*)\" and div \"([^\"]*)\" is calculated from the screen \"([^\"]*)\" and screen \"([^\"]*)\" and contract from screen \"([^\"]*)\" with no mode$")
	public void the_feemax_displayed_in_screen_with_audit_number_and_div_is_calculated_from_the_screen_and_screen_and_contract_from_screen_with_no_mode(String feemax, String screen,String Audit_number,String Div,String Screen2,String Screen3,String Screen4) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Physician_CL201 phy_screen = new Physician_CL201();
		FunctionLibrary.navigateToDiv(screen);
		phy_screen.CL201_Inquire(Audit_number, Div);
		String from=phy_screen.from_val();
		String cpt=phy_screen.proc1_val();
		feeMax=phy_screen.fee_max_val();
		String dos=phy_screen.frm_dos1_val();
		String pos= phy_screen.pos_val();
		String providerType=phy_screen.prov_type_val();
		System.out.println("fee max is:"+feeMax);
		FunctionLibrary.navigateToDiv(Screen2);
		
		if (Screen2.equals("PCFM")) {
			Procedure_PCFM phy_screen1 = new Procedure_PCFM();
			phy_screen1.Procedure_PCFM_Inquire("GET",from,cpt);
			Thread.sleep(2000);
			String standard_fee_max=phy_screen1.std_fee_max_val();
			if(standard_fee_max==null){
				System.out.println("Not found Standard Fee Max value in PCFM");
			}
			else{
			System.out.println("standard fee max is string"+standard_fee_max);
			fee_pcfm = Double.parseDouble(standard_fee_max);
			System.out.println("standard fee max is"+fee_pcfm);
			}
			String standard_Anes_max=phy_screen1.stdAnes_val();
			if(standard_Anes_max.equals("")){
				System.out.println("Anex Max Not found in PCFM");
			}
			else
			{
				System.out.println("Standard Anes max is string:"+standard_Anes_max);
				 fee_pcfm_anes = Double.parseDouble(standard_Anes_max);
				System.out.println("Standard Anes max in PCFM is: "+fee_pcfm_anes);
			}
		
			phy_screen1.command.setText("TB822");
			phy_screen1.com_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			FunctionLibrary.navigateToDiv(Screen3);
	    	 if(Screen3.equals("TB822")){
	    		 FeeMax_TB822 ftb= new FeeMax_TB822();
	    		 
	    		ftb.TB822_Inquire(dos, pos, providerType,"4", cpt);
	    		Thread.sleep(1000);
	    		calcType=ftb.calcType_val();
	    		System.out.println("The calc type is:"+calcType);
	    		String stdfeemaxfactor=ftb.feemax_val();
	    		System.out.println("The value of feemaxfactor:"+stdfeemaxfactor);
	    		standardFeemaxFact = Double.parseDouble(stdfeemaxfactor);
	    		System.out.println("The value of standard feemax factor is:"+standardFeemaxFact);
	    		 anes_factor=ftb.anesfact_val();
	    		 if(anes_factor.endsWith(":")){
	    			 System.out.println("Not found Anes Factor in TB822");
	    		 }
	    		 else{
	    		AnesthesiaFact = Double.parseDouble(anes_factor);
	    		System.out.println("The value of Anesthesia factor is:"+AnesthesiaFact);
	    		 }
	    	 }
	    	 else {
	 	    	System.out.println("The value of feemax factor is not found");
	    		} 
	         ftb.cur_screen.setText("CL201");
	    	 ftb.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	         FunctionLibrary.navigateToDiv(screen);
	        
	    if(screen.equals("CL201")){
			 Physician_CL201 fl_cl= new Physician_CL201();
			 fl_cl.CL201_Inquire(Audit_number,Div);
			 percent= fl_cl.pcnt_val();
			 std_percent = Double.parseDouble(percent);
			 noOfUnits=fl_cl.unit_Val();
			 contr=fl_cl.getContract_No();
			  Unit = Integer.parseInt(noOfUnits);
			 //fl_cl.validate_Proc_Mode2_presentornot(screen);
			act_mod1 =fl_cl.proc1_mod1_val();
			System.out.println("The value of actmod1 is:"+act_mod1);
			
			if(act_mod1.equals("QS")|| act_mod1.equals("QZ")){
				updated_Mode1=1.0;
				updated_Mode2=1.0;
			}
			else if(act_mod1.equals("QY")|| act_mod1.equals("QX") || act_mod1.equals("QK") ){
				if(act_mod1.equals("QX") && act_mod1.equals("QY")){
				updated_Mode1=0.5;
				updated_Mode2=0.5;
				}
				else if(act_mod1.equals("QX") || act_mod1.equals("")){
				updated_Mode1=0.5;
				updated_Mode2=1.0;
				}
				else if (act_mod1.equals("QY") || act_mod1.equals(""))
				{
			    updated_Mode1=1.0;
				updated_Mode2=0.5;
			}
				else if (act_mod1.equals("QK") || act_mod1.equals("QX")){
					updated_Mode1=0.5;
					updated_Mode2=0.5;
				}
				else if (act_mod1.equals("QK") || act_mod1.equals("QY")){
					updated_Mode1=0.5;
					updated_Mode2=0.5;
				}
				else if (act_mod1.equals("QK") || act_mod1.equals("")){
					updated_Mode1=0.5;
					updated_Mode2=1.0;
				}
			}
			else
			{
				
				updated_Mode1=1.0;
				updated_Mode2=1.0;
			}
			/*if(act_mod2.equals("P3")){
				updated_Unit=Unit+15;
			}
			else if(act_mod2.equals("P4")){
				updated_Unit=Unit+30;
			}
			else if(act_mod2.equals("P5")){
				updated_Unit=Unit+45;
			}
			else
			{
				updated_Unit=Unit+0;
			}
			System.out.println("The value of actmod2 is:"+act_mod2);*/
			System.out.println("The percent is:"+percent);
			
			if (calcType.equals("01"))
			{
				
				Double req_feeMax = (fee_pcfm)*(standardFeemaxFact);
				Double updated_req_feeMax=(req_feeMax) * (updated_Mode1)*(updated_Mode2)* (std_percent/100.00) * (updated_Unit);
				System.out.println("The required feemax is :"+updated_req_feeMax);
				double Rounded_updated_req_feeMax= Math.round(updated_req_feeMax * 100D) / 100D;
				System.out.println("The required feemax after rounding off is:"+Rounded_updated_req_feeMax);
			    String Rounded_updated_req_feeMax1 = Double.toString( Rounded_updated_req_feeMax ).replaceAll( "^0", "" );System.out.println( Rounded_updated_req_feeMax1 );
				Assert.assertEquals(feeMax, Rounded_updated_req_feeMax1);	
			}
			else if(calcType.equals("06"))
			{ 
	           
				FunctionLibrary.navigateToDiv("PS343");
				Thread.sleep(1000);
				if(Screen4.equals("PS343"))
				{
				Physician_PS343 phy_con= new Physician_PS343();
			    phy_con.PS343_Inquire(contr, Screen4);
				System.out.println("The value of contract:"+contr);
				Thread.sleep(500);
				anesfact1=phy_con.anesfact_val();
				updated_anesfact = Double.parseDouble(anesfact1);
				System.out.println("The value of anes conversion factor is:"+updated_anesfact);
				req_feeMax = (fee_pcfm_anes)+((Unit/AnesthesiaFact));
				
				System.out.println("The value of feeMax is:"+req_feeMax);
				
			updated_req_feeMax=(req_feeMax) * (updated_Mode1) * (updated_Mode2) * (updated_anesfact)*(std_percent/100.00);
				System.out.println("Value:"+updated_req_feeMax);
				double Rounded_updated_req_feeMax= Math.round(updated_req_feeMax * 100D) / 100D;
				 System.out.println("The required feemax is:"+Rounded_updated_req_feeMax);
						Assert.assertEquals(feeMax, Rounded_updated_req_feeMax);
				}
			 else
			   {
				System.out.println("Not found");
	            }
		}
	    
			

	}}}
	}
