package stepDefinition;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;

import com.cucumber.listener.Reporter;
import com.hp.lft.sdk.GeneralLeanFtException;

import cucumber.api.java.en.*;
import pages.ConditionCode_TB223;
import pages.ConditionCode_TB455;
import pages.Hospital_HO400;
import pages.Hospital_HO409;
import pages.Hospital_HO410;
import pages.Hospital_HO430;
import pages.Hospital_HO440;
import pages.Physician_CL201;
import pages.Physician_CL209;
import util.FunctionLibrary;
public class Facility_InpatientStepDefination {
	
	public String Audit_number,Div;

	@Then("^user find the difference \"([^\"]*)\" between FromDate \"([^\"]*)\" and \"([^\"]*)\" on Screen \"([^\"]*)\"$")
	public static long user_find_the_difference_between_FromDate_and_on_Screen(String Difference, String FromDate, String ThruDate, String Screen1) throws Throwable {
		
		String exp_fromDate;
		String exp_thruDate;
		int Days = Integer.parseInt(Difference);	
		if(Screen1.equals("HO400"))
		{
		Hospital_HO400 hos_400 = new Hospital_HO400();
		exp_fromDate=hos_400.from_date();
		System.out.println("From Date is:"+exp_fromDate);
		exp_thruDate=hos_400.thru_date();
		System.out.println("Thru Date is:"+exp_thruDate);
		SimpleDateFormat sdf = new SimpleDateFormat("MMddyy");
		Date date1 = sdf.parse(exp_fromDate);
		Date date2 = sdf.parse(exp_thruDate);
		long daysBetween = ChronoUnit.DAYS.between(date1.toInstant(), date2.toInstant());
	    System.out.println("Days Difference between Frm_Date and Thru_Date is" +daysBetween);
	    Assert.assertEquals(Days, daysBetween);
	    return daysBetween;
}
		return Days;
		}
	@When("^the claim \"([^\"]*)\" uses a review code \"([^\"]*)\" listed in screen \"([^\"]*)\"$")
	public void the_claim_uses_a_review_code_listed_in_screen(String arg1, String Review_Code, String screen) throws Throwable {
		Thread.sleep(2000);
		FunctionLibrary.navigateToDiv(screen);
		ConditionCode_TB455 TB455_val= new ConditionCode_TB455();
		TB455_val.TB455_Inquire(Review_Code);
	    String line1_review_code=TB455_val.review_val();
	    if(Review_Code.equalsIgnoreCase(line1_review_code))
	    {
	    	Reporter.addStepLog("Condition code " +line1_review_code+ " is present in screen TB223");
	    	Assert.assertTrue(true);
	    }
	    
	}
	
	@When("^Allow Days \"([^\"]*)\" are present on screen \"([^\"]*)\"$")
	public String allow_Days_are_present_on_screen(String AllowedDays, String screen) throws Throwable {
		String act_allowed_days=null;
		ConditionCode_TB455 TB455_val= new ConditionCode_TB455();
		Thread.sleep(1000);
		act_allowed_days =TB455_val.Allowed_days_val();
		Assert.assertEquals(act_allowed_days,AllowedDays);
		Reporter.addStepLog("Allowed Days are " +act_allowed_days);
		System.out.println("Allowerd Days are" +act_allowed_days);
		return act_allowed_days;
	}
	
	@Then("^user find the units \"([^\"]*)\" on screen \"([^\"]*)\"$")
	public void user_find_the_units_on_screen(String Units, String Screen1) throws Throwable {
		int UnitsSum;
		   //int unit = Integer.parseInt(Units);
		   if(Screen1.equals("HO400")){

//				FunctionLibrary.navigateToDiv(Screen1);
		    Hospital_HO400 hos_val1 = new Hospital_HO400();
//				//FunctionLibrary.navigateToDiv(arg2);
//				Thread.sleep(1000);
//				hos_val1.HO400_Inquire(Audit_number, Div);
//				Thread.sleep(1000);
				List<String> exp_result = new ArrayList<String>();
				exp_result.add(Units);
				//exp_result.add(Rev_user_code);
				String act_units =hos_val1.unit_val(Units);
				Assert.assertEquals(act_units,Units);
				//Assert.assertEquals(exp_review,exp_Deny.get(0).get(0) );
				System.out.println("Values returned " +act_units);
				Reporter.addStepLog("Values returned " +act_units);
			}
	}
	
	@Then("^user verifiy that SumofUnits\"([^\"]*)\" is grater then AllowedUnits \"([^\"]*)\" on screen \"([^\"]*)\"$")
	public void user_verifiy_that_SumofUnits_is_grater_then_AllowedUnits_on_screen(String UnitsSum, String Diff, String Screen1) throws Throwable {
	 int Sumofunits=Integer.parseInt(UnitsSum);
	 int AllowedUnits=Integer.parseInt(Diff);
	Assert.assertTrue(Sumofunits>AllowedUnits);
	}
	
	@When("^user finds the NotifDays \"([^\"]*)\" on Screen \"([^\"]*)\"$")
	public void user_finds_the_NotifDays_on_Screen(String NotifDays, String Screen1) throws Throwable {
		Hospital_HO400 hos_screen400 = new Hospital_HO400();
		String Act_NOTIF_DAYS=hos_screen400.NOTIFDAYS_val();
		Assert.assertEquals(Act_NOTIF_DAYS, NotifDays);
	    System.out.println("PRC_Flag is" +Act_NOTIF_DAYS);
	    Reporter.addStepLog("Member_NBR is" +Act_NOTIF_DAYS);
	}
	
	@Then("^user verifiy that SumofUnits\"([^\"]*)\" is lesser then AllowedUnits \"([^\"]*)\" on screen \"([^\"]*)\"$")
	public void user_verifiy_that_SumofUnits_is_lesser_then_AllowedUnits_on_screen(String UnitsSum, String Diff, String Screen1) throws Throwable {
		int Sumofunits=Integer.parseInt(UnitsSum);
		 int AllowedUnits=Integer.parseInt(Diff);
		Assert.assertTrue(AllowedUnits>Sumofunits);
	}
	

	@Then("^PRC FLG \"([^\"]*)\" is displayed on screen \"([^\"]*)\"$")
	public void prc_FLG_is_displayed_on_screen(String arg1, String arg2) throws Throwable {
		Hospital_HO430 hos_screen430 = new Hospital_HO430();
		String Act_PRC_FLAG=hos_screen430.prc_flg_val();
		//Assert.assertEquals(Act_MemberID, Member_NBR);
	    System.out.println("PRC_Flag is" +Act_PRC_FLAG);
	    Reporter.addStepLog("Member_NBR is" +Act_PRC_FLAG);
	}
	
}
