package stepDefinition;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.ClaimsProcessing_TB201;
import pages.ClaimsProcessing_TB875;
import pages.Hospital_HO400;
import pages.Hospital_HO410;
import pages.Physician_CL201;
import pages.Physician_CL209;
import util.FunctionLibrary;

public class TimelyFilingStepDefinition {
public String Audit_number,Div,act_review_code;

@When("^the claim is processed \"([^\"]*)\" late$")
public void claim_submitted_late(String days) throws Throwable {
	Hospital_HO400 phy_val1 = new Hospital_HO400();
	 int no_of_days=Integer.parseInt(days);
	 String rec_date=phy_val1.rec_date_val();
	 String thru_date=phy_val1.thru_date();
	 System.out.println(rec_date);
	 System.out.println(thru_date);
	 SimpleDateFormat myFormat = new SimpleDateFormat("MMddyy");
	 Date date1 = myFormat.parse(rec_date);
	 Date date2 = myFormat.parse(thru_date);
	 System.out.println(date1);
	 System.out.println(date2);
	 long diff = (date1.getTime() - date2.getTime());
	 System.out.println ("Days: " + TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS));
	 Assert.assertTrue(diff>no_of_days);
	
}
@Then("^the hospital timely filing on screen \"([^\"]*)\" is value \"([^\"]*)\" for site \"([^\"]*)\"$")
public void hospital_timely_filing_value(String screen,String value,String site) throws Throwable {
	FunctionLibrary.navigateToDiv(screen);
	ClaimsProcessing_TB201 phy_val1 = new ClaimsProcessing_TB201();
	phy_val1.site.setText(site);
	phy_val1.screenname.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	Thread.sleep(2000);
	String x=phy_val1.hospital_timely_filing_val();
	Assert.assertEquals(x, value);	
	
}
@Then("^the physician timely filing on screen \"([^\"]*)\" is value \"([^\"]*)\" for site \"([^\"]*)\"$")
public void physician_timely_filing_value(String screen,String value,String site) throws Throwable {
	FunctionLibrary.navigateToDiv(screen);
	ClaimsProcessing_TB201 phy_val1 = new ClaimsProcessing_TB201();
	phy_val1.site.setText(site);
	phy_val1.screenname.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	Thread.sleep(2000);
	String x=phy_val1.physician_timely_filing_val();
	Assert.assertEquals(x, value);	
	
}


@Then("^the EXP MDY is \"([^\"]*)\" and bypass logic is \"([^\"]*)\" on screen \"([^\"]*)\" for days \"([^\"]*)\"$")
public void exp_mdy_and_bypass_logic(String exp,String bypass,String screen,String days) throws Throwable {
	FunctionLibrary.navigateToDiv(screen);
	ClaimsProcessing_TB875 phy_val1 = new ClaimsProcessing_TB875();
	phy_val1.days.setText(days);
	phy_val1.screenname.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	Thread.sleep(1000);
	String x=phy_val1.exp_mdy_val();
	String y=phy_val1.bypass_val();
	if(exp.equals("empty or greater than today's date")){
		Assert.assertEquals("", x);
		
	}
	
	Assert.assertEquals(bypass, y);
	
	
}
@When("^the claim is processed with \"([^\"]*)\" days difference with DOS$")
public void claim_processsed_day_difference_with_DOS(String days) throws Throwable {
	Physician_CL201 phy_screen = new Physician_CL201();
	String DOS1 =phy_screen.frm_dos1_val();
	String DOS2 =phy_screen.frm_dos2_val();
	int no_of_days=Integer.parseInt(days.substring(1));
	System.out.println(no_of_days);
	 String rec_date=phy_screen.rcvd_date();
	 System.out.println(rec_date);
	 System.out.println(DOS1);
	 System.out.println(DOS1);	 
	 SimpleDateFormat myFormat = new SimpleDateFormat("MMddyy");
	 Date date1 = myFormat.parse(rec_date);
	 Date date2 = myFormat.parse(DOS1);
	 Date date3 = myFormat.parse(DOS2);
	 long diff1 = (date2.getTime() - date1.getTime());
	 long diff2 = (date3.getTime() - date1.getTime());
	 System.out.println ("Days: " + TimeUnit.DAYS.convert(diff1, TimeUnit.MILLISECONDS));
	 System.out.println ("Days: " + TimeUnit.DAYS.convert(diff2, TimeUnit.MILLISECONDS));
	 if(days.equals(">120 & <180")){
		 Assert.assertTrue(diff1>120 && diff1<180);
		 Assert.assertTrue(diff2>120 && diff1<180);
		 
	 }
	 if(days.substring(0,0).equals(">")){
		 Assert.assertTrue(diff1>no_of_days);
		 Assert.assertTrue(diff2>no_of_days);
		 
	 }
	 if(days.substring(0,0).equals("<")){
		 Assert.assertTrue(diff1<no_of_days);
		 Assert.assertTrue(diff2<no_of_days);
	 }
	 
	
	
	
}

@When("^the claim is processed with \"([^\"]*)\" days difference with first DOS$")
public void claim_processsed_day_difference_with_DOS1(String days) throws Throwable {
	Physician_CL201 phy_screen = new Physician_CL201();
	String DOS1 =phy_screen.frm_dos1_val();
	int no_of_days=Integer.parseInt(days.substring(1));
	System.out.println(no_of_days);
	 String rec_date=phy_screen.rcvd_date();
	 System.out.println(rec_date);
	 System.out.println(DOS1);
	 SimpleDateFormat myFormat = new SimpleDateFormat("MMddyy");
	 Date date1 = myFormat.parse(rec_date);
	 Date date2 = myFormat.parse(DOS1);
	 long diff1 = (date2.getTime() - date1.getTime());
	 System.out.println ("Days: " + TimeUnit.DAYS.convert(diff1, TimeUnit.MILLISECONDS));
	  if(days.equals(">120 & <180")){
		 Assert.assertTrue(diff1>120 && diff1<180);
		 
		 
	 }
	 if(days.substring(0,0).equals(">")){
		 Assert.assertTrue(diff1>no_of_days);
		 
		 
	 }
	 if(days.substring(0,0).equals("<")){
		 Assert.assertTrue(diff1<no_of_days);
		 
	 }
	 
	
	
	
}

@When("^the hospital claim is processed with \"([^\"]*)\" days difference with DOS$")
public void hosp_claim_processsed_day_difference_with_DOS(String days) throws Throwable {
	Hospital_HO400 phy_screen = new Hospital_HO400();
	String DOS1 =phy_screen.dos1_val();
	int no_of_days=Integer.parseInt(days.substring(1));
	System.out.println(no_of_days);
	 String rec_date=phy_screen.rec_date_val();
	 System.out.println(rec_date);
	 System.out.println(DOS1);
	 SimpleDateFormat myFormat = new SimpleDateFormat("MMddyy");
	 Date date1 = myFormat.parse(rec_date);
	 Date date2 = myFormat.parse(DOS1);
	 long diff1 = (date2.getTime() - date1.getTime());
	 System.out.println ("Days: " + TimeUnit.DAYS.convert(diff1, TimeUnit.MILLISECONDS));
	
	 if(days.equals(">120 & <180")){
		 Assert.assertTrue(diff1>120 && diff1<180);
		
		 
	 }
	 if(days.substring(0,0).equals(">")){
		 Assert.assertTrue(diff1>no_of_days);
		
		 
	 }
	 if(days.substring(0,0).equals("<")){
		 Assert.assertTrue(diff1<no_of_days);
		 
	 }
	 
	
	
	
}

@When("^the hospital claim is processed with \"([^\"]*)\" days difference with two DOS$")
public void hospital_claim_processsed_day_difference_with_two_DOS(String days) throws Throwable {
	Hospital_HO400 phy_screen = new Hospital_HO400();
	String DOS1 =phy_screen.dos1_val();
	String DOS2 =phy_screen.dos2_val();
	int no_of_days=Integer.parseInt(days.substring(1));
	System.out.println(no_of_days);
	 String rec_date=phy_screen.rec_date_val();
	 System.out.println(rec_date);
	 System.out.println(DOS1);
	 System.out.println(DOS1);	 
	 SimpleDateFormat myFormat = new SimpleDateFormat("MMddyy");
	 Date date1 = myFormat.parse(rec_date);
	 Date date2 = myFormat.parse(DOS1);
	 Date date3 = myFormat.parse(DOS2);
	 long diff1 = (date2.getTime() - date1.getTime());
	 long diff2 = (date3.getTime() - date1.getTime());
	 System.out.println ("Days: " + TimeUnit.DAYS.convert(diff1, TimeUnit.MILLISECONDS));
	 System.out.println ("Days: " + TimeUnit.DAYS.convert(diff2, TimeUnit.MILLISECONDS));
	 if(days.equals(">120 & <180")){
		 Assert.assertTrue(diff1>120 && diff1<180);
		 Assert.assertTrue(diff2>120 && diff1<180);
		 
	 }
	 if(days.substring(0,0).equals(">")){
		 Assert.assertTrue(diff1>no_of_days);
		 Assert.assertTrue(diff2>no_of_days);
		 
	 }
	 if(days.substring(0,0).equals("<")){
		 Assert.assertTrue(diff1<no_of_days);
		 Assert.assertTrue(diff2<no_of_days);
	 }
	 
	
	
	
}
@When("^the claim is processed within the range \"([^\"]*)\" days difference with DOS$")
public void claim_processsed1_day_difference_with_DOS(String days) throws Throwable {
	Physician_CL201 phy_screen = new Physician_CL201();
	String DOS1 =phy_screen.frm_dos1_val();
	String DOS2 =phy_screen.frm_dos2_val();
	//int no_of_days=Integer.parseInt(days.substring(1));
	//System.out.println(no_of_days);
	 String rec_date=phy_screen.rcvd_date();
	 System.out.println(rec_date);
	 System.out.println(DOS1);
	 System.out.println(DOS1);	 
	 SimpleDateFormat myFormat = new SimpleDateFormat("MMddyy");
	 Date date1 = myFormat.parse(rec_date);
	 Date date2 = myFormat.parse(DOS1);
	 Date date3 = myFormat.parse(DOS2);
	 long diff1 = (date1.getTime() - date2.getTime());
	 long diff2 = (date1.getTime() - date3.getTime());
	 System.out.println ("Days: " + TimeUnit.DAYS.convert(diff1, TimeUnit.MILLISECONDS));
	 System.out.println ("Days: " + TimeUnit.DAYS.convert(diff2, TimeUnit.MILLISECONDS));
	 diff1=TimeUnit.DAYS.convert(diff1, TimeUnit.MILLISECONDS);
	 diff2=TimeUnit.DAYS.convert(diff2, TimeUnit.MILLISECONDS);
	 if(days.equals(">120 & <180")){
		 Assert.assertTrue(diff1>120);
		 Assert.assertTrue(diff1<180);
		 Assert.assertTrue(diff2>120);
		 Assert.assertTrue(diff2<180);
		 
	 }
//	 if(days.substring(0,0).equals(">")){
//		 Assert.assertTrue(diff1>no_of_days);
//		 Assert.assertTrue(diff2>no_of_days);
//		 
//	 }
//	 if(days.substring(0,0).equals("<")){
//		 Assert.assertTrue(diff1<no_of_days);
//		 Assert.assertTrue(diff2<no_of_days);
//	 }
	 
	
	
	
}
@Then("^the fin prod on screen \"([^\"]*)\"  is value \"([^\"]*)\" for audit number \"([^\"]*)\" in division \"([^\"]*)\"$")
public void value_of_fin_prod(String screen,String value,String hos_aud,String c_div) throws Throwable {
	FunctionLibrary.navigateToDiv(screen);	
	Hospital_HO410 phy_screen = new Hospital_HO410();
	phy_screen.HO410_Inquire(hos_aud, c_div);
	Thread.sleep(2000);
	String fin_prod_act =phy_screen.fin_prod_val();
	System.out.println(fin_prod_act);
	if(value.equals("00017 or 00018 or 00078")){
		Assert.assertTrue(fin_prod_act.equals("00017") || fin_prod_act.equals("00018") || fin_prod_act.equals("00078"));
	}
	
	

	
}
@Then("^Then second detail line should be paid as expected$")
public void paid_as_expected() throws Throwable {
	

	
}

}