package stepDefinition;
import java.io.IOException;

import org.testng.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import pages.Hospital_HO410;
import pages.PS308;
import pages.Physician_CL201;
public class UBHStepDefination {
	public String Audit_number,Div;
	
public UBHStepDefination() {
		
	}

//gjgj
@Given("^The Metal Health Flag \"([^\"]*)\" displayed in screen \"([^\"]*)\"$")
public void the_Metal_Health_Flag_displayed_in_screen(String Mental_Health_Flag, String screen) throws Throwable {
	if(screen.equals("HO410"))
	{	
		Hospital_HO410 hos_val = new Hospital_HO410();
		String act_Mental_health =hos_val.hos_Medical_val();
		Assert.assertEquals(act_Mental_health,Mental_Health_Flag);
		Reporter.addStepLog("Actual Mental_Health_Flag is " +act_Mental_health);
		Thread.sleep(1000);
	} 
	}
	

@Then("^user verify the provider indent \"([^\"]*)\" on screen \"([^\"]*)\"$")
public void user_verify_the_provider_indent_on_screen(String Provider_indent, String screen) throws Throwable {
	if(screen.equals("PS308"))
	{	
		PS308 pos_val = new PS308();
	
		String act_Provider_Indent =pos_val.Provider_Indent_val();
		System.out.println("The Value of Provider Intent:"+act_Provider_Indent);
		Assert.assertEquals(act_Provider_Indent,Provider_indent);
		Reporter.addStepLog("Actual Provider_Indent is " +act_Provider_Indent);
		
}
}

@Then("^user verify the provider indent \"([^\"]*)\" is not on screen \"([^\"]*)\"$")
public void user_verify_the_provider_indent_is_not_on_screen(String Provider_indent, String screen) throws Throwable {
	if(screen.equals("PS308"))
	{	
		PS308 pos_val = new PS308();
	
		String act_Provider_Indent =pos_val.Provider_Indent_val();
		System.out.println("The Value of Provider Intent:"+act_Provider_Indent);
		Assert.assertNotEquals(act_Provider_Indent, Provider_indent);
		Reporter.addStepLog("Actual Provider_Indent is " +act_Provider_Indent);
}


}
}
