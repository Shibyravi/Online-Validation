package stepDefinition;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import driver.DriverScript;
import pages.Hospital_HO400;
import pages.Hospital_HO409;
import pages.Hospital_HO410;
import pages.Hospital_HO430;
import pages.PS475;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL209;
import pages.Physician_CL360;
import util.FunctionLibrary;

public class Radiology {
	
	public static String pro_code=null;
	public String Audit_number,Div;
	FunctionLibrary fl_inq1 = new FunctionLibrary();



@When("^the schedule type is \"([^\"]*)\" on screen \"([^\"]*)\"$")
public void the_schedule_type_is_on_screen(String exp_schd_type, String screen) throws Throwable {
	Physician_CL201 phy_val1 = new Physician_CL201();
	String act_schd_type = phy_val1.schd1_val();
	if (exp_schd_type.equalsIgnoreCase(act_schd_type)) {
		Assert.assertEquals(act_schd_type, exp_schd_type);
		Reporter.addStepLog(" Passed: Scheduled type is fine");
	} else {
		Reporter.addStepLog("Failed: Scheduled type is not fine");
	}

}

 @Then("^the fee max is calculated correctly$")
 public void the_fee_max_at_of_base_fee(String screen,int pc, int
 factor) throws Throwable {
	 FunctionLibrary.navigateToDiv(screen);
	 Physician_CL201 phy_val1 = new Physician_CL201();
	 PS475 ps_val1 = new PS475(); 
	 //phy_screen.CL201_Inquire(Audit_number, Div);
	 Thread.sleep(1000); String act_base_fee=ps_val1.base_fee_val(); double
	 amt_base_fee = Double.parseDouble(act_base_fee);
	 String act_fee_max = phy_val1.fee_max_val();
	 double amt_fee_max = Double.parseDouble(act_fee_max);
	 double exp_fee_max = amt_base_fee*factor*pc/100;
	 System.out.println("Expected fee max is " +exp_fee_max);
	 if(exp_fee_max==amt_fee_max) {
		 Reporter.addStepLog("Actual fee max is " +exp_fee_max);
		 Assert.assertEquals(exp_fee_max, act_fee_max); } 
	 }
 


}