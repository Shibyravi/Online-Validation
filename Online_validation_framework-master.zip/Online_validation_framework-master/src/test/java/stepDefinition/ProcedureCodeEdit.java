package stepDefinition;

import org.testng.Assert;

import cucumber.api.java.en.Given;
import pages.Physician_CL201;

public class ProcedureCodeEdit {

	//shalu
	@Given("^the provider type \"([^\"]*)\" should not present on screen \"([^\"]*)\"$")
	public void the_provider_type_should_not_present_on_screen(String Provider_Type, String Screen) throws Throwable {
		boolean flag=false;
		Physician_CL201 phy_screen1 = new Physician_CL201();
		String Actprovider_type=phy_screen1.prov_type_val();
		System.out.println(Actprovider_type);
		if (!Actprovider_type.equalsIgnoreCase(Provider_Type)) {
			flag=true;
			System.out.println("Provider Type is not equal to 20");
		}
	
	}
}
