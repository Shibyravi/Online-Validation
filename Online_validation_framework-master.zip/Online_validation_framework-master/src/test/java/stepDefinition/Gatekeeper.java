package stepDefinition;

import org.testng.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Hospital_HO400;
import pages.Hospital_HO410;
import pages.PS303;
import pages.PS308;
import pages.PS330;
import pages.PS331;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Provider_GI302;
import util.FunctionLibrary;

//
public class Gatekeeper {

	public static String pcp=null;
	public static String Ref_no=null;
	public static String Ref_no1=null;
	public static String Ref_no2=null;
	public static String Fed_Tax1=null;
	public static String Fed_Tax2=null;
	String result=null;
	/*	@Then("^the Service code should present with correct benefit no \"([^\"]*)\" on Screen \"([^\"]*)\" with type \"([^\"]*)\"$"  )
	public void the_Service_code_should_present_with_correct_benefit_no_on_Screen(String benlevel, String Screen,String type) throws Throwable {
String service_code=null;
String benefit_level=null;
Thread.sleep(500);
PS303 ps=new PS303();
if (type.equalsIgnoreCase("GateKeeper") ){
	Assert.assertEquals("pass", result);
	System.out.println("This is gatekeeper provider");
	Reporter.addStepLog("Gatekeeper Provider");
}
else if (type.equalsIgnoreCase("Non_GateKeeper")) {
	Assert.assertEquals("fail", result);
	System.out.println("This is not gatekeeper provider");
	Reporter.addStepLog("Not Gatekeeper Provider");
}
Physician_CL201 cl201=new Physician_CL201();
service_code=cl201.svc1_val();
benefit_level=service_code.substring(4, 6);
Assert.assertEquals(benefit_level, benlevel);
System.out.println("Benefit level matched");
Reporter.addStepLog("Benefit level is verified successfully" +benefit_level);

	}
	 */
	@Then("^the Service code should present with correct benefit no \"([^\"]*)\" on Screen \"([^\"]*)\" with type \"([^\"]*)\"$"  )
	public void the_Service_code_should_present_with_correct_benefit_no_on_Screen(String benlevel, String Screen,String type) throws Throwable {
		String service_code=null;
		String benefit_level=null;
		Thread.sleep(500);
		if (Screen.equalsIgnoreCase("CL201")) {
			
		
		Physician_CL201 cl201=new Physician_CL201();
		service_code=cl201.svc1_val();
		benefit_level=service_code.substring(4, 6);

		//customize condition if required
		if (type.equalsIgnoreCase("NonGateKeeper")) {
			String bn=PS331.BN;
			Assert.assertEquals(benefit_level, bn);
			System.out.println("Benefit level matched");
			Reporter.addStepLog("Benefit level is verified successfully" +benefit_level);
		}
		else{
		Assert.assertEquals(benefit_level, benlevel);
		System.out.println("Benefit level matched");
		Reporter.addStepLog("Benefit level is verified successfully" +benefit_level);
		}
		}
		else if (Screen.equalsIgnoreCase("HO400")) {
			Hospital_HO400 ho_400=new Hospital_HO400();
			service_code=ho_400.svc1_val();
			benefit_level=service_code.substring(4, 6);
			//customize condition if required
			if (type.equalsIgnoreCase("NonGateKeeper")) {
				String bn=PS331.BN;
				Assert.assertEquals(benefit_level, bn);
				System.out.println("Benefit level matched");
				Reporter.addStepLog("Benefit level is verified successfully" +benefit_level);
			}
			else{
			Assert.assertEquals(benefit_level, benlevel);
			System.out.println("Benefit level matched");
			Reporter.addStepLog("Benefit level is verified successfully" +benefit_level);
			}
			
		}
	}


	@Given("^the user gets Reference Provider no from Screen \"([^\"]*)\"$")
	public void the_user_gets_Reference_Provider_no_from_Screen(String Screen) throws Throwable {
		
		if (Screen.equalsIgnoreCase("CL201")) {
			Physician_CL201 cl201=new Physician_CL201();
			Ref_no=cl201.getRefProv_No();
			String refarr[]=Ref_no.split("-");
			Ref_no1=refarr[0];
			Ref_no2=refarr[1];
			System.out.println("Reference provider no is: "+Ref_no);	
		}
		else if (Screen.equalsIgnoreCase("HO410")) {
			Hospital_HO410 ho_410=new Hospital_HO410();
			Ref_no=ho_410.ref_prvdr_val();
			Ref_no1=Ref_no.substring(0, 4);
			Ref_no2=Ref_no.substring(4,11);
			System.out.println("Reference provider no is: "+Ref_no);
		}
		

	}

	@Given("^the user gets pcp from Screen \"([^\"]*)\"$")
	public void the_user_gets_pcp_from_Screen(String Screen) throws Throwable {
		if (Screen.equalsIgnoreCase("CL202")) {
			Physician_CL202 phy_val1 = new Physician_CL202();
			pcp= phy_val1.get_pcp();

		}
		else if (Screen.equalsIgnoreCase("HO410")) {
			Hospital_HO410 ho410=new Hospital_HO410();
			pcp=ho410.pcp_prvdr_val();
			
		}
	
	}

	@Then("^the user verify pcp and provider no \"([^\"]*)\"on Screen \"([^\"]*)\"$")
	public void the_user_verify_pcp_and_provider_no_on_Screen(String Provider_type, String Screen) throws Throwable {
		Thread.sleep(600);
		if (Provider_type.equalsIgnoreCase("Billing_Provider")) {
			String prov_no=Medica.prov;
			Assert.assertEquals(pcp, prov_no);
			System.out.println("Matched");
		}  
		else if (Provider_type.equalsIgnoreCase("Reference_Provider")) {
			Assert.assertEquals(Ref_no, pcp);
			System.out.println("Matched");

		} 
		else if (Provider_type.equalsIgnoreCase("Pricare_Provider")) {
			Assert.assertNotEquals(Ref_no, pcp);
			System.out.println("Not Matched");
			System.out.println("Need to check in PS331");
		}
		else if (Provider_type.equalsIgnoreCase("Par_Provider")) {
			Assert.assertNotEquals(Ref_no, pcp);
			System.out.println("Not Matched");
			System.out.println("Need to check in PS331");
		}
		
		else if (Provider_type.equalsIgnoreCase("Non_Par_Provider")) {
			Assert.assertNotEquals(Ref_no, pcp);
			System.out.println("Not Matched");
			System.out.println("Need to check in PS331");
		}
	}

	/*	@Then("^user verify that provider is gatekeeper or not on Screen \"([^\"]*)\"$")
	public void user_verify_that_provider_is_gatekeeper_or_not_on_Screen(String Screen,String type) throws Throwable {
	 PS303 ps=new PS303();
	String PType=null;
	 Thread.sleep(800);
	 result= ps.validate_GatekeeperOrNot();
	if (result.equalsIgnoreCase("pass")) {
		System.out.println("This is gatekeeper provider");
		PType="GateKeeper";
		Assert.assertEquals(PType, type);
		Reporter.addStepLog("Gatekeeper Provider");

	}
	else{
		System.out.println("THis is not a gatekeeper provider");
		PType="NonGateKeeper";
		Assert.assertEquals(PType, type);
		Reporter.addStepLog("Not Gatekeeper Provider");

	}
	System.out.println("provider verified as gatekkeeper");
	}
	 */


	@Then("^user verify that provider is gatekeeper or not on Screen \"([^\"]*)\" with type \"([^\"]*)\"$")
	public void user_verify_that_provider_is_gatekeeper_or_not_on_Screen_with_type(String Screen,String type) throws Throwable {
		PS303 ps=new PS303();
		String PType=null;
		Thread.sleep(800);
		result= ps.validate_GatekeeperOrNot();
		if (result.equalsIgnoreCase("pass")) {
			System.out.println("This is gatekeeper provider");
			PType="GateKeeper";
			Assert.assertEquals(PType, type);
			Reporter.addStepLog("Gatekeeper Provider");

		}
		else{
			System.out.println("THis is not a gatekeeper provider");
			PType="NonGateKeeper";
			Assert.assertEquals(PType, type);
			Reporter.addStepLog("Not Gatekeeper Provider");

		}
		System.out.println("provider verified as gatekkeeper");
	}  


	@Then("^the user enters new Screen \"([^\"]*)\" on Screen \"([^\"]*)\"$")
	public void the_user_enters_new_Screen_on_Screen(String Screen1, String Screen2) throws Throwable {
		if (Screen2.equalsIgnoreCase("PS303")) {
			PS303 ps=new PS303();
			ps.enter_NewScreen(Screen1);
			Thread.sleep(500);	
		}
		else if (Screen2.equalsIgnoreCase("PS331")) {
			PS331 ps=new PS331();
			ps.enter_NewScreen(Screen1);
			Thread.sleep(500);	
		}
		else if (Screen2.equalsIgnoreCase("PS308")) {
			PS308 ps=new PS308();
			ps.enter_NewScreen(Screen1);
			Thread.sleep(500);	
		}
		else if (Screen2.equals("GI302")){
			Provider_GI302 p302=new Provider_GI302();
			p302.enter_NewScreen(Screen1);
			Thread.sleep(500);
		}
	}
	/*	@Given("^the PCP should present against required panel number with provider status \"([^\"]*)\" and role \"([^\"]*)\"$")
	public void the_PCP_should_present_against_required_panel_number_with_provider_status_and_role(String status, String role) throws Throwable {
PS331 ps=new PS331();
ps.validatePCP(status, role);
	}*/

	@Given("^the PCP should present against required panel number with provider status \"([^\"]*)\" and role \"([^\"]*)\" with \"([^\"]*)\"$")
	public void the_PCP_should_present_against_required_panel_number_with_provider_status_and_role_with(String status, String role, String provider_type) throws Throwable {
		PS331 ps=new PS331();
		ps.validatePCP(status, role,provider_type);
	}

	@Then("^the notification Number \"([^\"]*)\" is displayed in screen does not match \"([^\"]*)\"$")
	public void the_notification_Number_is_displayed_in_screen_does_not_match(String notifno, String screen) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Thread.sleep(500);
		String notification_number1=null;
		if(screen.equals("CL201"))
		{	
			Physician_CL201 phy_not = new Physician_CL201();
			//	phy_not.CL201_Inquire(Audit_number,Div);
			notification_number1=phy_not.notif_num();
			System.out.println("Notification number:"+notification_number1);
			Assert.assertNotEquals(notification_number1,notifno);
			System.out.println("Notification no is not all zeros");
		}

	}


	@Given("^the user inquires with provider no on screen \"([^\"]*)\" with provider \"([^\"]*)\"$")
	public void the_user_inquires_with_provider_no_on_screen_with_provider(String Screen, String provider_type) throws Throwable {
		if (Screen.equalsIgnoreCase("PS330")) {
			FunctionLibrary fun=new FunctionLibrary();
			Thread.sleep(400);
			fun.navigateToDiv(Screen);
			Thread.sleep(900);
			PS330 ps=new PS330();
			ps.enter_providerNo1();
			Thread.sleep(400);
			ps.enter_providerNo2();
		}
		else if (Screen.equalsIgnoreCase("PS303")) {
			FunctionLibrary fun=new FunctionLibrary();
			Thread.sleep(400);
			fun.navigateToDiv(Screen);
			Thread.sleep(900);
			PS303 ps=new PS303();
			ps.enter_providerNo1();
			Thread.sleep(400);
			ps.enter_providerNo2();
		}



		else if (Screen.equalsIgnoreCase("PS331")) {
			FunctionLibrary fun=new FunctionLibrary();
			Thread.sleep(400);
			fun.navigateToDiv(Screen);
			Thread.sleep(900);
			PS331 ps=new PS331();

			//inquire in PS331 based on provider type
			ps.enter_providerNo1(provider_type);
			Thread.sleep(400);
			ps.enter_providerNo2(provider_type);

		}
	}

	



	@Then("^the refernce provider \"([^\"]*)\" should present on Screen \"([^\"]*)\"$")
	public void the_refernce_provider_should_present_on_Screen(String ref_prvdr, String Screen) throws Throwable {
		  //verifyiing reference no
				Assert.assertEquals(Ref_no, ref_prvdr);
				System.out.println("Reference provoder no is matced");
				Reporter.addStepLog("Reference provoder no is matced: "+Ref_no);
	}
	
	
	
	@When("^the user get fed Tax id from Screen \"([^\"]*)\" for provider \"([^\"]*)\"$")
	public void the_user_get_fed_Tax_id_from_Screen_for_provider(String Screen, String prov) throws Throwable {
		if (Screen.equalsIgnoreCase("PS308")) {
			PS308 ps=new PS308();
			Thread.sleep(900);
			if (prov.equalsIgnoreCase("Billing_Prov")) {
				Fed_Tax1=ps.fed_Tax_val();
			}
			else if (prov.equalsIgnoreCase("Reference_Prov")) {
				Fed_Tax2=ps.fed_Tax_val();
			}
			Thread.sleep(900);
		}
			
	}
	@When("^the user inquires with reference provider on Screen \"([^\"]*)\"$")
	public void the_user_inquires_with_reference_provider_on_Screen(String Screen) throws Throwable {
		if(Screen.equalsIgnoreCase("PS308")){
			FunctionLibrary fun=new FunctionLibrary();
			Thread.sleep(900);
			fun.navigateToDiv(Screen);
			Thread.sleep(900);
			PS308 ps=new PS308();
			ps.PS308_Inquire(Ref_no1, Ref_no2, Screen);
		}

	}
	

	@Then("^the fed tax id should be same for billing and reference provider on Screen \"([^\"]*)\"$")
	public void the_fed_tax_id_should_be_same_for_billing_and_reference_provider_on_Screen(String Screen) throws Throwable {
	if (Screen.equalsIgnoreCase("PS308")) {
		Assert.assertEquals(Fed_Tax1, Fed_Tax2);
		System.out.println("Fed Tax id matched for billing provider and reference provider");
		Reporter.addStepLog("Fed Tax id matched for billing provider and reference provider");
	}
	}

}
