package stepDefinition;
import java.util.List;

import org.testng.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Hospital_HO400;
import pages.Hospital_HO409;
import pages.Hospital_HO410;
import pages.OutPatient_AU300;
import pages.Physician_CL140;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL209;
import util.FunctionLibrary;

//
//
public class ServiceCodesStepDefinition {
	public String Audit_number,Div;
	
	
	@Then("^verify the multiple detail lines with service codes \"([^\"]*)\" and \"([^\"]*)\" are displayed in screen \"([^\"]*)\"$")
	public void verify_the_multiple_detail_lines_with_service_codes_and_are_displayed_in_screen(String svc1, String svc2, String screen) throws Throwable{
		    // Write code here that turns the phrase above into concrete actions
		if(screen.equals("CL201"))
		{	
		Physician_CL201 phy_val = new Physician_CL201();
		String act_service_code1 = phy_val.svc1_val();
		String act_service_code2 = phy_val.svc2_val();
		System.out.println("The first service code is:"+act_service_code1);
		System.out.println("The second service code is:"+act_service_code2);
		Assert.assertEquals(act_service_code1,act_service_code2);
		if(act_service_code1.equals(act_service_code2)){
			System.out.println("Two service line on a claim and falls into same Service Codes.");
		}
		
		else{

			
			System.out.println("Two service line on a claim and falls into different Service Codes.");
		
		}

		}
	}
	
	@When("^the member Number \"([^\"]*)\" is displayed in screen \"([^\"]*)\"$")
	public void the_member_Number_is_displayed_in_screen(String member_num, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if(screen.equals("CL201"))
		{
		
		Physician_CL201 phy_member = new Physician_CL201();
		String mem_num=phy_member.member.getText();
		System.out.println("Member number:"+mem_num);
		Thread.sleep(1000);
		Assert.assertEquals(mem_num,member_num);
	}}
	

//	@When("^the notification Number \"([^\"]*)\" is displayed in screen \"([^\"]*)\"$")
//	public void the_notification_Number_is_displayed_in_screen(String notification_num, String screen) throws Throwable {
//	    // Write code here that turns the phrase above into concrete actions
//		String notification_number1=null;
//		if(screen.equals("CL201"))
//		{
//		Physician_CL201 phy_notif = new Physician_CL201();
//		notification_number1=phy_notif.notif_num();
//		System.out.println("Notification number is:"+notification_number1);
//		Assert.assertEquals(notification_num,notification_number1);
//	}
//	}



	@When("^the risk type \"([^\"]*)\" is displayed on screen \"([^\"]*)\" for audit number \"([^\"]*)\" in division \"([^\"]*)\"$")
	public void the_risk_type_is_displayed_on_screen_for_audit_number_in_division(String risk_type, String screen,String Audit_number, String Div) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		FunctionLibrary.navigateToDiv(screen);
		Thread.sleep(1000);
		if(screen.equals("CL202"))
		{	
		Physician_CL202 phy_val1 = new Physician_CL202();
		phy_val1.CL202_Inquire(Audit_number, Div);
		Thread.sleep(1000);
		String risk_num=phy_val1.risk_type_val();
		System.out.println("Risk Type is:"+risk_num);
		Assert.assertEquals(risk_type,risk_num);
	}
		
		}
	
	
	@When("^the notification Number \"([^\"]*)\" is displayed in screen \"([^\"]*)\"$")
	public void the_notification_Number_is_displayed_in_screen(String notifno, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(500);
		Boolean flag=false;
			String notification_number1=null;
			if(screen.equals("CL201"))
			{	
				Physician_CL201 phy_not = new Physician_CL201();
			//	phy_not.CL201_Inquire(Audit_number,Div);
				notification_number1=phy_not.notif_num();
				System.out.println("Notification number:"+notification_number1);
				if (notifno.contains(",")) {
					String notif[]=notifno.split(",");
					if(!(notif[0].equalsIgnoreCase(notification_number1)&& notif[1].equalsIgnoreCase(notification_number1))) {
						System.out.println("Notification no neither all zeros nor all 9's: pass");
						flag=true;
					}
					else{
						System.out.println("Notification no either 0's or 9's: fail");
						flag=false;
					}
					Assert.assertTrue(flag);
					System.out.println("Notfication no verified");
					Reporter.addStepLog("Notfication no verified");
				}
				else{
				Assert.assertEquals(notification_number1,notifno);
				System.out.println("Notification no matched");
				Reporter.addStepLog("Notfication no verified");
				}
		   
		}
			else if (screen.equals("HO400")) {
				Hospital_HO400 hos=new Hospital_HO400();
				notification_number1=hos.get_notif_num();
				System.out.println("Notification number:"+notification_number1);
				if (notifno.contains(",")) {
					String notif[]=notifno.split(",");
					if(!(notif[0].equalsIgnoreCase(notification_number1)&& notif[1].equalsIgnoreCase(notification_number1))) {
						System.out.println("Notification no neither all zeros nor all 9's: pass");
						flag=true;
					}
					else{
						System.out.println("Notification no either 0's or 9's: fail");
						flag=false;
					}
					Assert.assertTrue(flag);
					System.out.println("Notfication no verified");
					Reporter.addStepLog("Notfication no verified");
				}
				else{
				Assert.assertEquals(notification_number1,notifno);
				System.out.println("Notification no matched");
				Reporter.addStepLog("Notfication no verified");
				}
		   
				
			}
		}
	
	@Given("^the notification status \"([^\"]*)\" is displayed in screen \"([^\"]*)\" for audit number \"([^\"]*)\" in division \"([^\"]*)\"$")
	public void the_notification_status_is_displayed_in_for_audit_number_in_division(String notif_status , String screen,String Audit_number,String Div) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		
       FunctionLibrary.navigateToDiv(screen);
		Thread.sleep(1000);
		String notif_stat=notif_status.substring(9,11);
		if(screen.equals("CL201"))
		{
		Physician_CL201 phy_notif_status = new Physician_CL201();
		phy_notif_status.CL201_Inquire(Audit_number, Div);
		Thread.sleep(1000);
		 String act_notif_stat=phy_notif_status.notif_num();
		 String act_notif = act_notif_stat.trim();
		System.out.println("The notification status is:"+act_notif);
		Assert.assertEquals(act_notif,notif_stat);
		}
		else if(screen.equals("HO400")){
		Hospital_HO400 hos_notif_status = new Hospital_HO400();
		hos_notif_status.HO400_Inquire(Audit_number, Div);
		Thread.sleep(1000);
		 String act_hos_notif_stat=hos_notif_status.notif_num();
		// String act_hos_notif = act_hos_notif_stat.trim();
		System.out.println("The notification status is:"+act_hos_notif_stat);
		Assert.assertEquals(notif_stat,act_hos_notif_stat);
		}
	}
		
		@Then("^the user inquires the notification number \"([^\"]*)\" in screen \"([^\"]*)\"$")
	public void the_user_inquires_the_notification_number_in_screen(String intake_num, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
			FunctionLibrary.navigateToDiv(screen);
			Thread.sleep(1000);
			String intake=intake_num.substring(0,8);
			System.out.println("Intake number is:"+intake);
			if(screen.equals("AU300"))
			{	
			OutPatient_AU300 out_intake = new OutPatient_AU300();
			out_intake.AU300_Inquire(intake,screen);
			
		}
	   

	}
	
	

	@Then("^the required service code \"([^\"]*)\" is displayed in screen \"([^\"]*)\" for audit number \"([^\"]*)\" in division \"([^\"]*)\"$")
	public void the_required_service_code_is_displayed_in_screen_for_audit_number_in_division(String Serv_Code, String screen,String Audit_number,String Div) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//String svc_code = Serv_Code.substring(4,6) ;
		String svc_code=null;
		
		FunctionLibrary.navigateToDiv(screen);
		Thread.sleep(1000);
		Physician_CL201 phy_svc = new Physician_CL201();
		phy_svc.CL201_Inquire(Audit_number, Div);
		svc_code=phy_svc.svc1_val();
		System.out.println("The required service_Code is:"+svc_code);
		Assert.assertEquals(svc_code,Serv_Code);
			
		
		
	}
		
	@Then("^the required service code \"([^\"]*)\" is displayed in screen \"([^\"]*)\"$")
	public void the_required_service_code_is_displayed_in_screen(String Serv_Code, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
			String hos_svc=null;
		String svc_code=null;
		FunctionLibrary.navigateToDiv(screen);
		Thread.sleep(1000);
		if(screen.equals("HO400"))
		{
			Hospital_HO400 hos_screen1 = new Hospital_HO400();
			hos_screen1.HO400_Inquire(Audit_number, Div);
			hos_svc =hos_screen1.svc1_val();
			Assert.assertEquals(hos_svc,Serv_Code);
			System.out.println("Actual SVC is " +hos_svc);
			Reporter.addStepLog("Actual SVC is " +hos_svc);
	}
		else if(screen.equals("CL201"))
		{
		Physician_CL201 phy_svc = new Physician_CL201();
		//phy_svc.CL201_Inquire(Audit_number, Div);
		svc_code=phy_svc.svc1_val();
		System.out.println("The required service_Code is:"+svc_code);
		Assert.assertEquals(svc_code,Serv_Code);
			
	}
	}
		
	
	@Then("^the required Benefit level \"([^\"]*)\" is displayed in the screen \"([^\"]*)\"$")
	public void the_required_Benefit_level_is_displayed_in_the_screen(String benefit_lvl, String screen) throws Throwable{
		String ben_lvl=null;
		/*FunctionLibrary.navigateToDiv(screen);
		Thread.sleep(1000);*/
		if(screen.equals("CL201"))
		{
		Physician_CL201 phy_svc_ben = new Physician_CL201();
		//phy_svc_ben.CL201_Inquire(Audit_number, Div);
		String svc_code_ben=phy_svc_ben.svc1_val().substring(4,6);
		System.out.println("Benefit_Level is:"+svc_code_ben);
		
		 ben_lvl=svc_code_ben.trim();
		Assert.assertEquals(ben_lvl,benefit_lvl);
			
		}
		else if(screen.equals("HO400"))
		{
			String hos_ben_lvl=null;
		Hospital_HO400 hos_svc_ben = new Hospital_HO400();
		hos_svc_ben.HO400_Inquire(Audit_number, Div);
		String svc_code_ben_hos=hos_svc_ben.svc1_val().substring(4,6);
		System.out.println("Benefit_Level is:"+svc_code_ben_hos);
		
		hos_ben_lvl=svc_code_ben_hos.trim();
		Assert.assertEquals(hos_ben_lvl,benefit_lvl);
		}
	}
	@Given("^the provider number \"([^\"]*)\" is displayed in \"([^\"]*)\"$")
	public void the_provider_number_is_displayed_in(String provider_num, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String provider_number=null;
		if(screen.equals("CL201"))
		{
		Physician_CL201 phy_prov_num = new Physician_CL201();
		provider_number=phy_prov_num.prov_val1();
		System.out.println("The provider number is:"+provider_number);
		Assert.assertEquals(provider_num,provider_number);
	}
	}
	/*@Given("^the notification status \"([^\"]*)\" is displayed in \"([^\"]*)\"$")
	public void the_notification_status_is_displayed_in(String notif_status, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		FunctionLibrary.navigateToDiv(screen);
		
		String notif_stat=notif_status.substring(9,11);
		if(screen.equals("CL201"))
		{
		Physician_CL201 phy_notif_status = new Physician_CL201();
		 String act_notif_stat=phy_notif_status.notification_status();
		 String act_notif = act_notif_stat.trim();
		System.out.println("The notification status is:"+act_notif);
		Assert.assertEquals(act_notif,notif_stat);
		
	}
	}
	*/
	
	
	@When("^the fromDate \"([^\"]*)\" is displayed in the screen \"([^\"]*)\"$") 
	public void the_fromDate_is_displayed_in_the_screen(String act_fromDate , String screen) throws Throwable{
		
		String exp_fromDate= null;
		if(screen.equals("HO400"))
		{
		Hospital_HO400 hos_fromDate = new Hospital_HO400();
		
		exp_fromDate=hos_fromDate.from_date();
		System.out.println("From Date is:"+exp_fromDate);
		Assert.assertEquals(exp_fromDate,act_fromDate);
	}
		
	}
	
	@When("^the toDate \"([^\"]*)\" is displayed in the screen \"([^\"]*)\"$")
	public void the_toDate_is_displayed_in_the_screen(String act_toDate, String screen) throws Throwable{
	
		String exp_thruDate= null;
		if(screen.equals("HO400"))
		{
			Hospital_HO400 hos_thruDate = new Hospital_HO400();
			
			exp_thruDate=hos_thruDate.from_date();
			System.out.println("Thru Date is:"+exp_thruDate);
			Assert.assertEquals(exp_thruDate,act_toDate);
	}
	}
	
	/*@Then("^BPL \"([^\"]*)\" is not valid for the claim if the date range does not fall in between from date \"([^\"]*)\" and through \"([^\"]*)\" date in screen \"([^\"]*)\"$")
	public void bpl_is_not_valid_for_the_claim_if_the_date_range_does_not_fall_in_between_from_date_and_through_date_in_screen(String act_bpl, String from, String thru, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String exp_bpl= null;
		FunctionLibrary.navigateToDiv(screen);
		Thread.sleep(1000);
		if(screen.equals("CL140"))
		{
			Physician_CL140 phy_validity = new Physician_CL140();
			phy_validity.validationDate("effectiveDate","expireDate");

			if(from.compareTo(thru)>0 && (from.compareTo(thru))<0){
				FunctionLibrary.navigateToDiv(screen);
				Thread.sleep(1000);
				if(screen.equals("CL201")){
					Physician_CL201 phy_bpl = new Physician_CL201();
					exp_bpl=phy_bpl.bpl_val();
					Assert.assertEquals(exp_bpl,act_bpl);
					System.out.println("The BPL is valid:"+exp_bpl);
				}
				else{
					System.out.println("The BPL is not valid");
				}
			}
		}
	}

	*/


@When("^the BPL number \"([^\"]*)\" is inquired in screen \"([^\"]*)\"$")
public void the_BPL_number_is_inquired_in_screen(String bpl,String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	//String exp_bpl=null;
	FunctionLibrary.navigateToDiv(screen);
	Thread.sleep(1000);
	if(screen.equals("CL140")){
		
	Physician_CL140 phy_bpl = new Physician_CL140();
    phy_bpl.CL140_Inquire(bpl,screen);
	
	}
}
@When("^the effective date \"([^\"]*)\" is displayed in screen \"([^\"]*)\"$")
public void the_effective_date_is_displayed_in_screen(String effec_date, String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String exp_effective_date= null;
	if(screen.equals("CL140"))
	{
	Physician_CL140 phy_effDate = new Physician_CL140();
	exp_effective_date=phy_effDate.effectiveDateValidation();
	System.out.println("The effective date is:"+exp_effective_date);
	//Assert.assertEquals(exp_effective_date,effec_date);
}}


/*@Then("^BPL \"([^\"]*)\" is valid in screen \"([^\"]*)\" using audit number \"([^\"]*)\" in division \"([^\"]*)\" with effective \"([^\"]*)\" in \"([^\"]*)\" date ranges in fromdate \"([^\"]*)\" and thrudate \"([^\"]*)\" in \"([^\"]*)\"$")
public void bpl_is_valid_in_screen_using_audit_number_in_division_with_effective_in_date_ranges_in_fromdate_and_thrudate_in(String bpl, String screen1,String Audit_number,String Div,String effective, String screen2, String from, String screen3, String thru) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	FunctionLibrary.navigateToDiv(screen1);
	Thread.sleep(1000);
	String exp_bpl_num= null;
	if(screen1.equals("HO400")){
		Hospital_HO400 hos_bpl_valid = new Hospital_HO400();
		hos_bpl_valid.HO400_Inquire(Audit_number,Div);
		exp_bpl_num=hos_bpl_valid.bpl_num();
		System.out.println("The BPL number is:"+exp_bpl_num);
		//FunctionLibrary.DateComparision(effective,from,thru);
		FunctionLibrary.navigateToDiv(screen2);
		Thread.sleep(1000);
		String exp_review= null;
		String exp_bpl = null;
		String exp_effective_date = null;
		String exp_from_date = null;
		String exp_thru_date= null;
		exp_review=hos_bpl_valid.review_status();
		System.out.println("The required review code is:"+exp_review);
		exp_bpl=hos_bpl_valid.bpl_num();
		exp_from_date = hos_bpl_valid.from_date();
		exp_thru_date = hos_bpl_valid.thru_date();
		if(screen2.equals("CL140"))
		{
		Physician_CL140 phy_effDate = new Physician_CL140();
		phy_effDate.CL140_Inquire(bpl,screen2);
		exp_effective_date=phy_effDate.effectiveDateValidation();
		//FunctionLibrary.DateComparision(effective_date1, from_date2, thru_date3);
		
		if((exp_effective_date.compareTo(exp_from_date))>0 || exp_effective_date.compareTo(exp_thru_date)>0 ){
			
		    System.out.println("The BPL Code is :"+exp_bpl);
	    	System.out.println("The effective date is greater than the from date,BPL is valid");
	    }
	    else
	    	{
	    	if(exp_effective_date.compareTo(exp_from_date)<0 || exp_effective_date.compareTo(exp_thru_date)<0){
	    		
	    		System.out.println("The BPL Code is :"+exp_bpl);
	    	System.out.println("The effective date is greater than the thru date,BPL is not valid");
	    }
	    	else{
	    		System.out.println("The effective date is smaller than from and thru date,BPL is not valid");
	    	}
	    }
		
	}
		
		
	}
	}

*/
/*@Then("^verify if BPL \"([^\"]*)\" is valid in screen \"([^\"]*)\" with effective \"([^\"]*)\" in \"([^\"]*)\" date ranges in fromdate \"([^\"]*)\" and thrudate \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void verify_if_BPL_is_valid_in_screen_with_effective_in_date_ranges_in_fromdate_and_thrudate_in_screen(String bpl, String screen, String effective, String from, String thru) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	
	FunctionLibrary.navigateToDiv(screen);
	Thread.sleep(1000);
	String exp_bpl_num= null;
	if(screen.equals("HO400")){
		Hospital_HO400 phy_bpl_valid = new Hospital_HO400();
		exp_bpl_num=phy_bpl_valid.bpl_num();
		System.out.println("The BPL number is:"+exp_bpl_num);
		FunctionLibrary.DateComparision(effective,from,thru);
		
		//Assert.assertEquals(bpl,exp_bpl_num);
		}
	else{
		
		System.out.println("The BPL is not valid");
	}
}
*/
/*@SuppressWarnings("unchecked")
@Then("^the claim is hit with review \"([^\"]*)\" in screen \"([^\"]*)\" with audit number \"([^\"]*)\" in division \"([^\"]*)\" $")
public void the_claim_is_hit_with_review_in_screen_with_audit_number_in_division(String screen, String Audit_number,String rev_code,String Div) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	List<String> exp_review= null;
	FunctionLibrary.navigateToDiv(screen);
	Thread.sleep(1000);
	if(screen.equals("HO409"))
	{
	Hospital_HO409 hos_rev_code = new Hospital_HO409();
	hos_rev_code.HO409_Inquire(Audit_number,Div);
	exp_review=hos_rev_code.review_val(rev_code);
	System.out.println("The required review code is:"+exp_review);
	Assert.assertEquals(exp_review,rev_code);
	}
}*/
@Then("^the claim is hit with review \"([^\"]*)\" in screen \"([^\"]*)\" with audit number \"([^\"]*)\" in division \"([^\"]*)\"$")
public void the_claim_is_hit_with_review_in_screen_with_audit_number_in_division(String rev_code, String screen, String Audit_number, String Div) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	List<String> exp_review= null;
	List<String> exp_phy_rev=null;
	FunctionLibrary.navigateToDiv(screen);
	Thread.sleep(1000);
	if(screen.equals("HO409"))
	{
	Hospital_HO409 hos_rev_code = new Hospital_HO409();
	hos_rev_code.HO409_Inquire(Audit_number,Div);
	exp_review=hos_rev_code.review_val(rev_code);
	System.out.println("The required review code is:"+exp_review);
	Assert.assertEquals(exp_review,rev_code);
	}
	else if(screen.equals("CL209"))
	{
		Physician_CL209 phy_screen1 = new Physician_CL209();
		phy_screen1.CL209_Inquire(Audit_number, Div);
		exp_phy_rev=phy_screen1.review_val(rev_code);
		System.out.println("The required review code is:"+exp_phy_rev);
		Assert.assertEquals(exp_phy_rev,rev_code);
	}
	
}

@Then("^verify if BPL \"([^\"]*)\" is valid in screen \"([^\"]*)\" with review code \"([^\"]*)\" for audit number \"([^\"]*)\" in division \"([^\"]*)\"$")
public void verify_if_BPL_is_valid_in_screen_with_review_code_for_audit_number_in_division(String Audit_number,String Div, String screen, String bpl, String review) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	FunctionLibrary.navigateToDiv(screen);
	Thread.sleep(1000);
	String exp_review= null;
	String exp_bpl = null;
	String exp_effective_date = null;
	String exp_from_date = null;
	String exp_thru_date= null;
	if(screen.equals("HO400"))
	{
	Hospital_HO400 hos_rev_code = new Hospital_HO400();
	hos_rev_code.HO400_Inquire(Audit_number,Div);
	
	exp_review=hos_rev_code.review_status();
	System.out.println("The required review code is:"+exp_review);
	exp_bpl=hos_rev_code.bpl_num();
	exp_from_date = hos_rev_code.from_date();
	exp_thru_date = hos_rev_code.thru_date();
	if(screen.equals("CL140"))
	{
	Physician_CL140 phy_effDate = new Physician_CL140();
	exp_effective_date=phy_effDate.effectiveDateValidation();
	//FunctionLibrary.DateComparision(effective_date1, from_date2, thru_date3);
	
	if((exp_effective_date.compareTo(exp_from_date))>0 || exp_effective_date.compareTo(exp_thru_date)>0 ){
		
	    System.out.println("The BPL Code is :"+exp_bpl);
    	System.out.println("The effective date is greater than the from & thru date,BPL is valid");
    }
    else
    	{
    	if(exp_effective_date.compareTo(exp_from_date)<0 || exp_effective_date.compareTo(exp_thru_date)<0){
    		
    		System.out.println("The BPL Code is :"+exp_bpl);
    	System.out.println("The effective date is smaller than the from & thru date,BPL is not valid");
    }
    	else{
    		System.out.println("The effective date is equal to from and thru date,BPL is not valid");
    	}
    }
	
}
	
	
}
}
/*@Then("^ verify if BPL \"([^\"]*)\" is valid in screen \"([^\"]*)\" with review code \"([^\"]*)\" for audit number \"([^\"]*)\" in division \"([^\"]*)\"$")
public void verify_if_BPL_is_valid_in_screen_with_review_code_for_audit_number_in_division(String bpl, String screen, String review,String Audit_number,String Div) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	FunctionLibrary.navigateToDiv(screen);
	Thread.sleep(1000);
	String exp_review= null;
	if(screen.equals("HO400"))
	{
	Hospital_HO400 phy_rev_code = new Hospital_HO400();
	phy_rev_code.HO400_Inquire(Audit_number, Div);
	exp_review=phy_rev_code.rev_code1.getText();
	System.out.println("The required review code is:"+exp_review);
}
*/



	
	/*@Then("^BPL \"([^\"]*)\" is not valid for the claim if the date range does not fall in from date \"([^\"]*)\" and through \"([^\"]*)\" date in screen \"([^\"]*)\"$")
	public void BPL_is_not_valid_for_the_claim_if_the_date_range_does_not_fall_in_between_from_and_through_date_in_screen(String act_bpl,String from,String thru, String screen) throws Throwable{
		String exp_bpl= null;
	
		if(screen.equals("CL140"))
		{
			Physician_CL140 phy_validity = new Physician_CL140();
			phy_validity.validationDate("effectiveDate","expireDate");
			if(from.compareTo(thru)>0 && (from.compareTo(thru))<0){
				if(screen.equals("CL201")){
					Physician_CL201 phy_bpl = new Physician_CL201();
					exp_bpl=phy_bpl.bpl_val();
					Assert.assertEquals(exp_bpl,act_bpl);
					System.out.println("The BPL is valid:"+exp_bpl);
				}
				else{
					System.out.println("The BPL is not valid");
				}
			}
		}
		}
		*/
/*@When("^the provider status \"([^\"]*)\" is displayed in screen \"([^\"]*)\"$")
public void the_provider_status_is_displayed_in_screen(String Prov_status, String Screen3) throws Throwable {
	FunctionLibrary.navigateToDiv(Screen3);
	Thread.sleep(1000);
	if(Screen3.equals("CL202")){
	Physician_CL202 phy_val1 = new Physician_CL202();
	phy_val1.CL202_Inquire(Audit_number, Div);
	Thread.sleep(500);
	String act_prov_stat =phy_val1.par_status_val();
	Assert.assertEquals(act_prov_stat,Prov_status);
	System.out.println("Prov status is " +act_prov_stat);
	Reporter.addStepLog("Prov status is " +act_prov_stat);

}
else if(Screen3.equals("HO410"))
{
	Hospital_HO410 hos_screen1 = new Hospital_HO410();
	hos_screen1.HO410_Inquire(Audit_number, Div);
	Thread.sleep(500);
	String act_prov_stat =hos_screen1.par_status_val();
	Assert.assertEquals(act_prov_stat,Prov_status);
	System.out.println("Prov status is " +act_prov_stat);
	Reporter.addStepLog("Prov status is " +act_prov_stat);
}
}*/}



	
	
