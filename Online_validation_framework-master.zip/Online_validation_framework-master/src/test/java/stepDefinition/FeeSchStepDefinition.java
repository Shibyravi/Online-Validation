package stepDefinition;

import java.text.DecimalFormat;
import java.util.List;

import org.testng.Assert;

import com.cucumber.listener.Reporter;
import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Hospital_HO440;
import pages.Physician_CL201;
import pages.Physician_PS340;
import util.FunctionLibrary;

public class FeeSchStepDefinition {
String contract=null;
	
	@When("^the user fetch contract number \"([^\"]*)\" from the screen \"([^\"]*)\"$")
	public void the_user_fetch_contract_number_from_the_screen(String exp_contract, String Screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//String contract=null;
//		FunctionLibrary.navigateToDiv(Screen);
	//	 Thread.sleep(1000);
		 
		 if(Screen.equals("CL201")){
			 FunctionLibrary.navigateToDiv(Screen);
			 Thread.sleep(1000);
	Physician_CL201 phy_contract= new Physician_CL201();
		Thread.sleep(1000);
		contract=phy_contract.getContract_No();
		 System.out.println("The contract no is:"+contract);
		
	}
		 else if (Screen.equals("HO440")) {
			
					Field hello=Desktop.describe(Window.class, new WindowDescription.Builder()
							.shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build()).describe(Field.class, new FieldDescription.Builder()
							.length(5).startPosition(new com.hp.lft.sdk.te.PositionProperty().setRow(1).setColumn(3)).build());
					Thread.sleep(2000);
					hello.setText("HO440");
					Screen hi=Desktop.describe(Window.class, new WindowDescription.Builder().shortName("A").build()).describe(Screen.class, new ScreenDescription.Builder()
							.label("UNI").build());
							hi.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
							
					
				
			 
					Hospital_HO440 hos_contract= new Hospital_HO440();
					
				//	hos_contract.HO440_Inquire("007355870", "EVC");
					//	Thread.sleep(1000);
						contract=hos_contract.feeschd_val();
						 System.out.println("The FEE SCHEDULE no is:"+contract); 
				
			}
	}


	@Then("^The pricer edit code used is \"([^\"]*)\" in screen \"([^\"]*)\"$")
	public void the_pricer_edit_code_used_is_in_screen(String editCode, String Screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String edit_code=null;
		 //FunctionLibrary.navigateToDiv(screen);
		 Thread.sleep(1000);
		 if(Screen.equals("PS340")){
		Physician_PS340 phy_pay= new Physician_PS340();
		phy_pay.editCode.setText("G");
		
		 
	}
	}
	@Then("^the user inquires a contract number \"([^\"]*)\" from screen \"([^\"]*)\" in the screen \"([^\"]*)\"$")
	public void the_user_inquires_a_contract_number_in_the_screen(String exp_contract,String Screen, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String contract_CL201=null;
		Physician_PS340 phy_contract= new Physician_PS340();
		Physician_CL201 phy= new Physician_CL201();
		 FunctionLibrary.navigateToDiv(Screen);
		 Thread.sleep(1000);
		 if(Screen.equals("CL201")){
			 Thread.sleep(1000);
	contract_CL201=phy.getContract_No();
		Thread.sleep(1000);
		Assert.assertEquals(exp_contract,contract_CL201);
		FunctionLibrary.navigateToDiv(screen);
		phy_contract.PS340_Inquire(contract_CL201, "PS340");
		
	}
	}

	@SuppressWarnings("deprecation")
	@Then("^the fee schedule \"([^\"]*)\" has (\\d+) digits in screen \"([^\"]*)\"$")
	public void the_fee_schedule_has_digits_in_screen(String feeSched, int dig, String Screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String fee_Schedule=null;
		int exp_fee_sch=0;
		 //FunctionLibrary.navigateToDiv(screen);
		 Thread.sleep(1000);
		 if(Screen.equals("PS340")){
		Physician_PS340 phy_pay= new Physician_PS340();
		fee_Schedule=phy_pay.feeSch_val();
		exp_fee_sch=fee_Schedule.length();
		Thread.sleep(1000);
		Assert.assertEquals(feeSched, fee_Schedule);
		if(exp_fee_sch==dig){
			
			 System.out.println("The fee schedule"+ " " +fee_Schedule +" " +"is of"+ " " +dig + " "+"digits");
		}
		else{
		 System.out.println("The fee schedule"+" "+fee_Schedule +" "+"is not of"+ " " +dig + " "+"digits");
	}
		 }
	}
	@Then("^the proc code \"([^\"]*)\" for audit \"([^\"]*)\" with div \"([^\"]*)\" in screen \"([^\"]*)\" should match with MCD_DATA table proc code value and fee_max \"([^\"]*)\" should match with MCD_DATA table fee max value$")
	public void the_proc_code_for_audit_with_div_in_screen_should_match_with_MCD_DATA_table_proc_code_value_and_fee_max_should_match_with_MCD_DATA_table_fee_max_value(String proc_code, String AuditNumber,String Div, String Screen, String FeeMax) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String procCode,feeMax=null;
		 FunctionLibrary.navigateToDiv(Screen);
		 Thread.sleep(1000);
		 if(Screen.equals("CL201")){
			 Thread.sleep(1000);
	Physician_CL201 phy_proc= new Physician_CL201();
		Thread.sleep(1000);
		phy_proc.CL201_Inquire(AuditNumber, Div);
		Thread.sleep(1000);
		procCode=phy_proc.proc1_val();
		 System.out.println("The procedure code is:"+procCode);
		 Assert.assertEquals(proc_code, procCode);
		 feeMax=phy_proc.fee_max_val();
		 System.out.println("The fee Max is:"+feeMax);
		 Assert.assertEquals(FeeMax, feeMax);
	
		 List<String> proc_fee = FunctionLibrary.Ret_TwoValues_DB2Validation_Div("MCD_PROC", "MCD_AMT_MAX", "D9331COA", "MCD_DATA", "MCD_SITE_ID", "EVC", "MCD_FEE_SCHED", "29001");
		 System.out.println("The value of procedure code and fee Max in CL201 is:"+proc_fee);
		 String exp_proc=proc_fee.get(0);
		 System.out.println("The value of expected Procedure code is:"+exp_proc);
		 String exp_feemax=proc_fee.get(1);
		 System.out.println("The value of expected Fee Max is:"+exp_feemax);
		if(procCode.equals(exp_proc)){
			Assert.assertEquals(procCode, exp_proc);
			System.out.println("The value of procedure code is same in DB"+ " " +exp_proc +" " +"and CL201" +" "+procCode );
		}
		else{
			System.out.println("The value of procedure code is not same in DB"+ " " +exp_proc +" " +"and CL201" +" "+procCode );
		}
		if(feeMax.equals(exp_feemax)){
			System.out.println("The value of Fee Max is same in DB"+" "+exp_feemax +" "+"and CL201"+" "+feeMax);
		Assert.assertEquals(feeMax, exp_feemax);
		}
		else{
			System.out.println("The value of Fee Max is not same in DB"+" "+exp_feemax +" "+"and CL201"+" "+feeMax);
		}
	}
	}

	
	
	
	//Abhishek's Paap
	
	@When("^the fee schedule validate \"([^\"]*)\" has (\\d+) digits in screen \"([^\"]*)\"$")
	public void the_fee_schedule_validate_has_digits_in_screen(String feeSched, int dig, String Screen) throws Throwable {
	String fee_Schedule=null;
	int exp_fee_sch=0;
	//FunctionLibrary.navigateToDiv(screen);
	Thread.sleep(1000);
	if(Screen.equals("HO440")){
	Hospital_HO440 hos_pay= new Hospital_HO440();
	fee_Schedule=hos_pay.feeschd_val();
	exp_fee_sch=fee_Schedule.length()-1;
	Thread.sleep(1000);
	Assert.assertEquals(exp_fee_sch,5);
	if(exp_fee_sch==dig){

	System.out.println("The fee schedule"+ " " +fee_Schedule +" " +"is of"+ " " +dig + " "+"digits");
	}
	else{
	System.out.println("The fee schedule"+" "+fee_Schedule +" "+"is not of"+ " " +dig + " "+"digits");
	}}
	}

	@When("^the user retrieves the div as \"([^\"]*)\" with the contract number \"([^\"]*)\" and div as \"([^\"]*)\" from region as \"([^\"]*)\" and table \"([^\"]*)\"$")
	public void the_user_retrieves_the_div(String fsdiv, String contract,String div,String region,String table) throws Throwable {
		String exp_fsdiv=fsdiv;
		String act_fsdiv=FunctionLibrary.DB2Validation("HDTL_FS_GB_DIV",region,table,"HDTL_SITE_ID",div,"HDTL_FS_NBR",contract);
		System.out.println(act_fsdiv);
		Assert.assertEquals(exp_fsdiv, act_fsdiv);
				
	}

	@Then("^the proc code \"([^\"]*)\" for audit \"([^\"]*)\" in screen \"([^\"]*)\" should match with MCD_DATA table proc code value and fee_max \"([^\"]*)\" should match with MCD_DATA table fee max value$")
	public void the_user_checks_proc_code_and_fee_max(String proc, String audit,String screen,String fee_max) throws Throwable {
		FunctionLibrary.navigateToDiv(screen);
		 Thread.sleep(1000);
		 if(screen.equals("HO440")){
			 Thread.sleep(1000);
	Hospital_HO440 phy_proc= new Hospital_HO440();
		Thread.sleep(1000);
		String act_proc=phy_proc.proc_code_val();
		String act_conamt=phy_proc.conamt_val();
		double act_conamt2=Double.parseDouble(act_conamt);
		List results=FunctionLibrary.Ret_TwoValues_DB2Validation_Div("MCD_PROC","MCD_AMT_MAX","D9331COA","MCD_DATA","MCD_SITE_ID","EVC","MCD_FEE_SCHED","29001");
		System.out.println(results.get(0));
		String x=(String) results.get(1);		
	    double con_amnt1=Double.parseDouble(x);
		Assert.assertEquals(results.get(0),act_proc);
		double con_db=con_amnt1/10;
		DecimalFormat f = new DecimalFormat("#.00");
	    System.out.println(f.format(con_db));
	    String con_amnt2=f.format(con_db);
	    double con_dbamnt2=Double.parseDouble(con_amnt2);
		Assert.assertEquals(con_dbamnt2,act_conamt2);
	}
}}