package stepDefinition;

import java.util.ArrayList;

import java.util.List;

import org.junit.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Hospital_HO400;
import pages.Hospital_HO409;
import pages.Hospital_HO410;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL209;
import util.FunctionLibrary;

public class HomeHealthCareStepDefinition {


public HomeHealthCareStepDefinition(){
	
}

//
@When("^the unit fee \"([^\"]*)\" is displayed in the screen \"([^\"]*)\"$")
public void the_unit_fee_is_displayed_in_the_screen(String unit_fee, String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String act_fee=null;
	Thread.sleep(1000);
    FunctionLibrary.navigateToDiv(screen);
    Thread.sleep(1000);
    
    if(screen.equals("CL201"))
	{	
		
		Physician_CL201 phy_val = new Physician_CL201();
		 
		    act_fee=phy_val.unitfee_val();
			Thread.sleep(1000);
		    Assert.assertEquals(act_fee,unit_fee);
			System.out.println("The actual unit fee is:"+act_fee);
		    Reporter.addStepLog("The actual unit fee is:" +act_fee);
	}
    else  if(screen.equals("HO400")){
    	Hospital_HO400 ho_400=new Hospital_HO400();
	    act_fee=ho_400.units1_val();
    	Thread.sleep(1000);
	    Assert.assertEquals(act_fee,unit_fee);
		System.out.println("The actual unit fee is:"+act_fee);
	    Reporter.addStepLog("The actual unit fee is:" +act_fee);
    }
}

@When("^the provider panel \"([^\"]*)\" is displayed in screen \"([^\"]*)\"$")
public void the_provider_panel_is_displayed_in_screen(String panel, String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String act_panel=null;
	String act_panel_hos=null;
	
    FunctionLibrary.navigateToDiv(screen);

    
    if(screen.equals("CL202"))
	{	
		
		Physician_CL202 phy_val = new Physician_CL202();
		 
		    act_panel=phy_val.prov_panel_val();
			Thread.sleep(1000);
		    Assert.assertEquals(act_panel,panel);
			System.out.println("The actual provider panel is:"+act_panel);
		    Reporter.addStepLog("The actual provider panel is:" +act_panel);
	

}
    else if (screen.equals("HO410")){
    	
    	Hospital_HO410 hos_val = new Hospital_HO410();
		 //hos_val.HO410_Inquire(Audit_nubmer,Div);
	    act_panel_hos=hos_val.prov_panel_val();
		Thread.sleep(1000);
	    Assert.assertEquals(act_panel_hos,panel);
		System.out.println("The actual provider panel is:"+act_panel_hos);
	    Reporter.addStepLog("The actual provider panel is:" +act_panel_hos);

    }
}
@Then("^the claim \"([^\"]*)\" in division \"([^\"]*)\" is hit with review \"([^\"]*)\" in screen \"([^\"]*)\" processed by home health care \"([^\"]*)\"$")
public void the_claim_in_division_is_hit_with_review_in_screen_processed_by_home_health_care(String Audit_number, String Div, String Review, String screen,String Rev_user_code) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    List act_review=null;
    List act_review_hos=null;
	FunctionLibrary.navigateToDiv(screen);
	Thread.sleep(1000);
      if(screen.equals("CL209"))
	{	
		
		Physician_CL209 phy_val = new Physician_CL209();
		phy_val.CL209_Inquire(Audit_number, Div);
		Thread.sleep(1000);
		List<String> exp_result = new ArrayList<String>();
		act_review=phy_val.review_val(Review);
		exp_result.add(Review);
        exp_result.add(Rev_user_code);
		
		Assert.assertEquals(act_review,exp_result);
		
		System.out.println("Values returned " +act_review);
		Reporter.addStepLog("Values returned " +act_review);
		System.out.println("Expected outcome " +act_review);
		Reporter.addStepLog("Expected outcome " +act_review);
}
      else if(screen.equals("HO409"))
  	{	
  		Thread.sleep(1000);
  		Hospital_HO409 hos_val = new Hospital_HO409();
  		hos_val.HO409_Inquire(Audit_number, Div);
  		Thread.sleep(1000);
  		List<String> exp_result = new ArrayList<String>();
  		act_review_hos=hos_val.review_val(Review);
  		exp_result.add(Review);
          exp_result.add(Rev_user_code);
  		
  		Assert.assertEquals(act_review_hos,exp_result);
  		
  		System.out.println("Values returned " +act_review_hos);
  		Reporter.addStepLog("Values returned " +act_review_hos);
  		System.out.println("Expected outcome " +act_review_hos);
  		Reporter.addStepLog("Expected outcome " +act_review_hos);
}
}




@When("^the rsn number \"([^\"]*)\" is displayed in the screen \"([^\"]*)\"$")
public void the_rsn_number_is_displayed_in_the_screen(String rsn, String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	
	String act_rsn=null;
	String act_phy_rsn=null;
	if(screen.equals("HO400"))
  	{	
  		
  		Hospital_HO400 hos_val = new Hospital_HO400();
  	//hos_val.HO409_Inquire(Audit_number, Div);
  		Thread.sleep(1000);
  		act_rsn=hos_val.det_deny1_val();
  		
  		Assert.assertEquals(act_rsn,rsn);
  		
  		System.out.println("The actual rsn is:" +act_rsn);
  		Reporter.addStepLog("The actual rsn is:" +act_rsn);
}
	
	else if (screen.equals("CL201")){
		Physician_CL201 phy_val = new Physician_CL201();
		String act_RSN=null;
		if(phy_val.rsn1.getText().contains(rsn))
		{
		
			act_RSN =phy_val.det1_deny_val();
		}
		else if(phy_val.rsn2.getText().contains(rsn))
		{
			act_RSN =phy_val.det2_deny_val();
		}
		
Assert.assertEquals(act_RSN,rsn);
  		
  		System.out.println("The actual rsn is:" +act_RSN);
  		Reporter.addStepLog("The actual rsn is:" +act_RSN);
	}
}



@When("^the bill type \"([^\"]*)\" is displayed in the screen \"([^\"]*)\"$")
public void the_bill_type_is_displayed_in_the_screen(String billtype, String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	
	String act_billtype=null;
	if(screen.equals("HO410"))
  	{	
  		
  		Hospital_HO410 hos_val = new Hospital_HO410();
  	//hos_val.HO409_Inquire(Audit_number, Div);
  		Thread.sleep(1000);
  		act_billtype=hos_val.bill_type_val();
  		
  		Assert.assertEquals(act_billtype,billtype);
  		
  		System.out.println("The actual Bill type is:" +act_billtype);
  		Reporter.addStepLog("The actual Bill type is:" +act_billtype);
}
}
}