package stepDefinition;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.Then;
import pages.Hospital_HO400;
import pages.Physician_CL201;
import pages.Physician_CL209;
import util.FunctionLibrary;

public class MultiProcStepDefinition {
	
	
	
	
	@Then("^verify the last digit \"([^\"]*)\" of service code in screen \"([^\"]*)\"$")
	public void verify_the_last_digit_of_service_code_in_screen(String l_digit, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String last_digit=null;
		/*FunctionLibrary.navigateToDiv(screen);
		Thread.sleep(1000);*/
		if(screen.equals("CL201"))
		{
		Physician_CL201 phy_last_dgt = new Physician_CL201();
		//phy_svc_ben.CL201_Inquire(Audit_number, Div);
		last_digit=phy_last_dgt.svc1_val().substring(5,6);
		System.out.println("The last digit of SVC is:"+last_digit);
		String l_dgt=last_digit.trim();
		Assert.assertEquals(l_dgt,l_digit);
	}
	}

	@Then("^the claim \"([^\"]*)\" in division \"([^\"]*)\" is hit with review \"([^\"]*)\" in screen \"([^\"]*)\" processed by multi procedures \"([^\"]*)\"$")
	public void the_claim_in_division_is_hit_with_review_in_screen_processed_by_multi_procedures(String Audit_number, String Div, String Review, String screen, String Rev_user_code) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		FunctionLibrary.navigateToDiv(screen);
		Physician_CL209 phy_val1 = new Physician_CL209();
		//FunctionLibrary.navigateToDiv(arg2);
		Thread.sleep(1000);
		phy_val1.CL209_Inquire(Audit_number,Div);
		Thread.sleep(1000);
		List<String> exp_result = new ArrayList<String>();
		exp_result.add(Review);
		exp_result.add(Rev_user_code);
		List act_review_code =phy_val1.review_val(Review);
		Assert.assertEquals(act_review_code,exp_result);
		//Assert.assertEquals(exp_review,exp_Deny.get(0).get(0) );
		System.out.println("Values returned " +act_review_code);
		Reporter.addStepLog("Values returned " +act_review_code);
		System.out.println("Expected outcome " +act_review_code);
		Reporter.addStepLog("Expected outcome " +act_review_code);
	}
	
	@Then("^verify the payable amount \"([^\"]*)\" of claim \"([^\"]*)\" in screen \"([^\"]*)\" is lesser/greater than the claimed amount \"([^\"]*)\" minus total discount \"([^\"]*)\"$")
	public void the_payable_amount_of_claim_in_screen_is_lesser_greater_than_the_claimed_amount_minus_total_discount(String exp_allowed, String Audit_number, String Screen, String claimed_amt, String discount) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(500);
		FunctionLibrary.navigateToDiv(Screen);
		Physician_CL201 phy_val= new Physician_CL201();
		String act_allowed=null;
		
		String act_claimed=null;
		String act_discount = null;
		String rsn_code1=phy_val.det1_deny_val();
		String rsn_code2=phy_val.det2_deny_val();
		
			if(rsn_code1.equals("0019"))
		{
			act_allowed =phy_val.allowed1_val();
			act_claimed=phy_val.claimed1_val();
			act_discount = phy_val.disc1_val();
		}
		else if(rsn_code2.equals("0019"))
		{
			act_allowed =phy_val.allowed2_val();
			act_claimed=phy_val.claimed2_val();
			act_discount = phy_val.disc2_val();
		}
		//double amt_allowed = Double.parseDouble(act_allowed);

		double e_allowed;
		double exp_allowed_amt = Double.parseDouble(act_allowed);
		double act_claimed_amt = Double.parseDouble(claimed_amt);
		
		e_allowed =exp_allowed_amt;
		double tot_discount = Double.parseDouble(act_discount);
		Double tot_allowed = act_claimed_amt-tot_discount;
		if (tot_allowed>exp_allowed_amt){
			System.out.println("The payable amount: "+e_allowed + " is lesser than the allowed amount: "+tot_allowed);
		}
			else if(tot_allowed<exp_allowed_amt)
			{
				System.out.println("The payable amount: "+e_allowed + " is greater than the allowed amount: "+tot_allowed);
			}
			else{
				System.out.println("The payable amount: "+e_allowed + " is equal to the allowed amount: "+tot_allowed);
	}
	}
		
	}
