package stepDefinition;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.DataTable;
import cucumber.api.java.en.*;
import driver.DriverScript;
import pages.Hospital_HO400;
import pages.Hospital_HO409;
import pages.Hospital_HO410;
import pages.Hospital_HO430;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL209;
import pages.Physician_CL214;
import pages.ReasonCode_TB208;
import util.FunctionLibrary;

public class PromptPayStepDefinition {
	
	public String Audit_number,Div;

public PromptPayStepDefinition() {
		
	}

@When("^the process claim is more than \"([^\"]*)\" days late$")
public void the_process_claim_is_more_than_30_days_late(String days) throws Throwable {
	
	
	 Physician_CL201 phy_val1 = new Physician_CL201();
	 int no_of_days=Integer.parseInt(days);
	 String rec_date=phy_val1.rcvd_date();
	 String paid_date=phy_val1.paid_date_val();
	 System.out.println(rec_date);
	 System.out.println(paid_date);
	 SimpleDateFormat myFormat = new SimpleDateFormat("MMddyy");
	 Date date1 = myFormat.parse(rec_date);
	 Date date2 = myFormat.parse(paid_date);
	 System.out.println(date1);
	 System.out.println(date2);
	 long diff = (date2.getTime() - date1.getTime());
	 System.out.println ("Days: " + TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS));
	 Assert.assertTrue(diff>no_of_days);
	
	
}

@When("^the hospital claim is more than \"([^\"]*)\" days late$")
public void the_hospital_claim_is_more_than_30_days_late(String days) throws Throwable {
	
	 Hospital_HO400 phy_val1 = new Hospital_HO400();
	 int no_of_days=Integer.parseInt(days);
	 String rec_date=phy_val1.Receive_date_val();
	 String paid_date=phy_val1.paid_date_val();
	 System.out.println(rec_date);
	 System.out.println(paid_date);
	 SimpleDateFormat myFormat = new SimpleDateFormat("MMddyy");
	 Date date1 = myFormat.parse(rec_date);
	 Date date2 = myFormat.parse(paid_date);
	 System.out.println(date1);
	 System.out.println(date2);
	 long diff = (date2.getTime() - date1.getTime());
	 System.out.println ("Days: " + TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS));
	 Assert.assertTrue(diff>no_of_days);
	
	
}


@When("^the allowed amount is greater than zero on screen \"([^\"]*)\"$")
public void the_allowed_amount_is_greater_than_zero(String screen) throws Throwable {
	Physician_CL201 phy_val1 = new Physician_CL201();
	String allowed=phy_val1.tot_allowed_val();
	System.out.println(allowed);
	double allowed1 = Double.parseDouble(allowed);
	Assert.assertTrue(allowed1>0);
	
	
}

@Then("^the interest amount is interest \"([^\"]*)\" on screen \"([^\"]*)\" for audit number \"([^\"]*)\" and division \"([^\"]*)\"$")
public void interest_amount_is_correct(String interest,String screen,String Audit_number,String div) throws Throwable {
	FunctionLibrary.navigateToDiv(screen);
	if(screen.equals("CL202")){
		Physician_CL202 phy_val1 = new Physician_CL202();
		Thread.sleep(1000);
		phy_val1.CL202_Inquire(Audit_number, div);
		Thread.sleep(1000);
		String act_interest=phy_val1.interest_val();
		int len=act_interest.length();
		System.out.println(len);
		if(interest.length()==0){
			Assert.assertEquals(act_interest, interest);
			
		}
		else{
		if(act_interest.substring(len-1).equals("-")){
			
			act_interest=act_interest.substring(0,len-1);
			
		}
		if (interest.equals(">0")){
			double x = Double.parseDouble(act_interest);		
			Assert.assertTrue(x>0);		
		
		}
		else{
		Assert.assertEquals(act_interest, interest);
		}}
		
	}
	else if (screen.equals("HO430")){
		Hospital_HO430 phy_val1 = new Hospital_HO430();
		Thread.sleep(1000);
		phy_val1.HO430_Inquire(Audit_number,div);
		Thread.sleep(1000);
		String act_interest=phy_val1.interest_val();
		int len=act_interest.length();
		System.out.println(len);
          if(interest.equals("ENDS WITH -")){
			
			Assert.assertTrue((act_interest.substring(len-1).equals("-")));
			
		}
		if(act_interest.substring(len-1).equals("-")){
			
			act_interest=act_interest.substring(0,len-1);
			
		}
		if (interest.equals(">0")){
			double x = Double.parseDouble(act_interest);		
			Assert.assertTrue(x>0);		
		
		}
		
		else if(interest.equals("matches with DB2")){
			String interest_DB=FunctionLibrary.DB2Validation("CPC_PROMPT_PAY_DIS", "D9331CSF", "CPC_DATA", "CPC_AUDIT", Audit_number);
			Assert.assertEquals(interest_DB, act_interest);
		}
		else{
		Assert.assertEquals(act_interest, interest);
		}
		
	}
	
	
}

@Then("^the claim status is found to be status \"([^\"]*)\" on screen \"([^\"]*)\"$")
public void the_claim_is_found_to_be_closed(String status,String Screen) throws Throwable {
	if(Screen.equals("CL201")){
		Physician_CL201 phy_val1 = new Physician_CL201();
		String claim_status=phy_val1.closed_claim_val();
		System.out.println("Actual message is "+claim_status);
		Assert.assertEquals(claim_status, status);
	}
	else if(Screen.equals("HO400")){
		
		Hospital_HO400 phy_val1 = new Hospital_HO400();
		String claim_status=phy_val1.closed_claim_message_val();
		System.out.println("Actual message is "+claim_status);
		Assert.assertEquals(claim_status, status);
		
	}
		
	
	
}

@Then("^the claim should be adjusted$")
public void the_claim_should_be_adjusted() throws Throwable {
	String page;
	Physician_CL201 phy_val1 = new Physician_CL201();
	phy_val1.phy_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	page=phy_val1.page_val();
	while(!(page.equals("ADJ"))){
		
		phy_val1.phy_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		Thread.sleep(1000);
		page=phy_val1.page_val();
		
	}
	
	
	if(page.equals("ADJ")){
		Assert.assertEquals(page, "ADJ");		
	}
	
	
}

@Then("^the deny code should be a closed claim deny code$")
public void the_deny_code_should_be_a_closed_claim_deny_code() throws Throwable {
	Thread.sleep(1000);
	Hospital_HO400 phy_val1 = new Hospital_HO400();
	String deny_code=phy_val1.Cause_Deny_val();
	System.out.println("DEnial code is "+deny_code);
	phy_val1.enter_NewScreen("TB208");
	//FunctionLibrary.navigateToDiv("TB208");
	ReasonCode_TB208 phy_val2 = new ReasonCode_TB208();
	phy_val2.reason_code.setText(deny_code);
	phy_val2.ScreenNameA.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	Thread.sleep(1000);
	Assert.assertTrue(phy_val2.ClsCode_val().equals("Y"));
	Assert.assertTrue(phy_val2.GovCl_val().equals("Y"));
	
	
}

@Then("^the closure codes should be of non closure codes$")
public void the_closure_codes_should_be_of_non_closure_codes() throws Throwable {
	Thread.sleep(1000);
	Hospital_HO400 phy_val1 = new Hospital_HO400();
	String deny_code=phy_val1.det_deny1_val();
	System.out.println("DEnial code is "+deny_code);
	phy_val1.enter_NewScreen("TB208");
	//FunctionLibrary.navigateToDiv("TB208");
	ReasonCode_TB208 phy_val2 = new ReasonCode_TB208();
	phy_val2.reason_code.setText(deny_code);
	phy_val2.ScreenNameA.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
	Thread.sleep(1000);
	Assert.assertTrue(phy_val2.ClsCode_val().equals("N"));
	Assert.assertTrue(phy_val2.GovCl_val().equals("N"));
	
	
}
@Then("^the original audit number \"([^\"]*)\" is correctly displayed on screen \"([^\"]*)\" for audit number \"([^\"]*)\" in division \"([^\"]*)\"$")
public void the_original_audit_number_is_correctly_displayed(String ori_aud,String screen,String phys_aud,String c_div) throws Throwable {
	FunctionLibrary.navigateToDiv(screen);
	Physician_CL202 phy_val1 = new Physician_CL202();
	phy_val1.CL202_Inquire(phys_aud, c_div);
	String org_audit=phy_val1.original_audit_val();
	Assert.assertEquals(org_audit, ori_aud);
	
}

@Then("^claim resubmit is \"([^\"]*)\" and claim frequency code is \"([^\"]*)\"$")
public void claim_resubmit_is_correct(String clm_resubmit,String claim_freq) throws Throwable {
	String claim_resubmit=FunctionLibrary.DB2Validation("CLM_RESBMT_CLM_IND", "D9331CSF", "DRCLAIMS", "CLM_AUDNBR" , "08695751", "CLM_AUDSUB", "00");
	Assert.assertEquals(claim_resubmit, clm_resubmit);
	String claim_frequency=FunctionLibrary.DB2Validation("CLM_FREQ_CDE", "D9331CSF", "DRCLAIMS", "CLM_AUDNBR" , "08695751", "CLM_AUDSUB", "00");
	Assert.assertEquals(claim_frequency, claim_freq);
	
}

@Then("^pp discount is \"([^\"]*)\" on screen \"([^\"]*)\" for audit number \"([^\"]*)\" in division \"([^\"]*)\"$")
public void pp_discount_is_correct(String pp_discount, String screen,String hos_aud,String c_div) throws Throwable {
	FunctionLibrary.navigateToDiv(screen);
	Hospital_HO430 phy_val1 = new Hospital_HO430();
	phy_val1.HO430_Inquire(hos_aud, c_div);
	Thread.sleep(1000);
	String pp_disc=phy_val1.pp_discount();
	double pp_disc1 = Double.parseDouble(pp_disc);
	if(pp_discount.equals(">0")){
		Assert.assertTrue(pp_disc1>0);
	}
	else if(pp_discount.equals("matches with DB2")){
		String pp_disc_db=FunctionLibrary.DB2Validation("CPC_PROMPT_PAY_DIS", "D9331CSF", "CPC_DATA", "CPC_AUDIT", hos_aud);
		Assert.assertEquals(pp_disc, pp_disc_db);
		
	}
	
	
	
}

@When("^the payable amount is greater than zero on screen \"([^\"]*)\"$")
public void the_payable_amount_is_greater_than_zero(String screen) throws Throwable {
	Hospital_HO400 phy_val1 = new Hospital_HO400();
	String payable=phy_val1.payable3_val();
	System.out.println(payable);
	double allowed1 = Double.parseDouble(payable);
	Assert.assertTrue(allowed1>0);
	
	
}

@Then("^the claim is denied with the reason code \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_claim_denied_with_reason_code(String reason, String screen) throws Throwable {
	if(screen.equals("HO400")){
		Hospital_HO400 phy_val1 = new Hospital_HO400();
		String act_deny_code =phy_val1.Cause_Deny_val();
		Assert.assertEquals(act_deny_code,reason);
		System.out.println("Deny code is " +act_deny_code);
		
	}
	

}

@Then("^the claim is not hit with review \"([^\"]*)\" in screen \"([^\"]*)\" and is processed by adjudipro \"([^\"]*)\" for audit number \"([^\"]*)\" in division \"([^\"]*)\"$")
public void the_claim_is_hit_with_review_in_screen_and_is_not_processed_by_adjudipro(String Review, String Screen2, String Rev_user_code,String Audit_number,String Div) throws Throwable {
	FunctionLibrary.navigateToDiv(Screen2);
	Physician_CL209 phy_val1 = new Physician_CL209();
	phy_val1.CL209_Inquire(Audit_number,Div);
	List<String> exp_result = new ArrayList<String>();
	exp_result.add(Review);
	exp_result.add(Rev_user_code);
	List act_review_code =phy_val1.review_val(Review);
	Assert.assertNotEquals(act_review_code,exp_result);
	Reporter.addStepLog("Values returned " +act_review_code);
	Reporter.addStepLog("Expected outcome " +act_review_code);
}

@Then("^the date \"([^\"]*)\" should be \"([^\"]*)\" on screen \"([^\"]*)\" for audit number \"([^\"]*)\" in division \"([^\"]*)\"$")
public void the_date(String date_name, String date,String screen,String aud, String div) throws Throwable {
	FunctionLibrary.navigateToDiv(screen);
	Thread.sleep(1000);
	Physician_CL214 phy_val1 = new Physician_CL214();
	phy_val1.CL214_Inquire(aud,div);
	if(date_name.equals("INFORMATION FOLLOW UP LETTER")){
		String x=phy_val1.Information_follow_up_letter_val();
		Assert.assertEquals(x,date);
	}
	if(date_name.equals("Enrolee notification letter")){
		String x=phy_val1.Enrolee_notification_letter_val();
		Assert.assertEquals(x,date);
	}
	if(date_name.equals("Additional info letter")){
		String x=phy_val1.Additional_info_letter_val();		
		Assert.assertEquals(x,date);
	}
	
	
}

@Then("^we have correct DB flag \"([^\"]*)\" for closed claim for audit_number \"([^\"]*)\"$")
public void we_have_correct_DB2_flag_for_closed_claim(String expected_flag,String audit_number) throws Throwable {
	String value1="";
	if(audit_number.length()==10){
		 value1=audit_number.substring(0, audit_number.length()-2);
		 String closed_claim_flag=FunctionLibrary.DB2Validation("CLM_CLOSE_FLG", "D9331CSF", "DRCLAIMS", "CLM_AUDNBR", value1, "CLM_AUDSUB", "00");
		 System.out.println("Actual flag is "+closed_claim_flag);
		 Assert.assertEquals(closed_claim_flag, expected_flag);
	}
	
	else if ((audit_number.length()<10)){
		String closed_claim_flag=FunctionLibrary.DB2Validation("HPC_CLOSE_FLG", "D9331CSF", "HPC_DATA", "HPC_AUDIT_NBR", audit_number);	
		System.out.println("Actual flag is "+closed_claim_flag);
		Assert.assertEquals(closed_claim_flag, expected_flag);
	}
	
	
	
}

@Then("^claim resubmit is correct$")
public void claim_resubmit_is_correct() throws Throwable {
	String CLM_RESBMT_CLM_IND=FunctionLibrary.DB2Validation("CLM_RESBMT_CLM_IND", "D9331CSF", "DRCLAIMS", "CLM_AUDNBR", "08695751", "CLM_AUDSUB", "00");
	 Assert.assertEquals(CLM_RESBMT_CLM_IND, "2");
	
}

@Then("^the source is \"([^\"]*)\"$")
public void value_of_source(String source) throws Throwable {
	Physician_CL201 phy_val1 = new Physician_CL201();
	String source_act=phy_val1.source_Val();
	Assert.assertEquals(source, source_act);
	
}

@Then("^the date \"([^\"]*)\" should be \"([^\"]*)\" on screen \"([^\"]*)\"$")
public void date_checking(String datename,String date2,String screen) throws Throwable {
	FunctionLibrary.navigateToDiv(screen);
//	Physician_CL201 phy_val1 = new Physician_CL201();
//	String source_act=phy_val1.source_Val();
//	Assert.assertEquals(source, source_act);
}

//@Then("^the DOL data entry are updated correctly$")
//public void Then_the_DOL_data_entry_are_updated_correctly() throws Throwable {
//	String x=FunctionLibrary.DB2Validation("DOL_ADD_INFO_CDE", "D9331CSF", "DOL_DATA", "CLM_AUDNBR", "79678939", "CLM_AUDSUB", "00");
//	 Assert.assertEquals(x, "9");
//	// String y=FunctionLibrary.DB2Validation("DOL_TRG_SITE_ID", "D9331CSF", "DOLTRG_DATA", "CLM_AUDNBR", "79678939", "CLM_AUDSUB", "00");
//	// Assert.assertNotEquals(y, "", "Entry not in DOLTRG_DATA");
//	
//	
//}















//if (screen.equals("CL201")) {
//	Physician_CL201 phy_val1 = new Physician_CL201();
//	Thread.sleep(1000);
//	phy_val1.CL201_Inquire(Audit_number, Div);
//	// PS475 ps_val1 = new PS475();
//	// String act_base_fee=ps_val1.base_fee_val();
//	double amt_base_fee = Double.parseDouble(act_base_fee);
//	String act_fee_max = phy_val1.fee_max_val();
//	double amt_fee_max = Double.parseDouble(act_fee_max);
//	double exp_fee_max = amt_base_fee * factor * pc / 100;
//	// System.out.println("Expected fee max is " +exp_fee_max);
//	if (exp_fee_max == amt_fee_max) {
//		Reporter.addStepLog("Actual fee max is " + exp_fee_max);
//		Assert.assertEquals(exp_fee_max, act_fee_max);

}