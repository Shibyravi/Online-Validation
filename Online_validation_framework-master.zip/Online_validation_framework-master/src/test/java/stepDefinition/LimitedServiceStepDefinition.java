package stepDefinition;



import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Hospital_HO400;
import pages.LimitedService_CL147;
import pages.LimitedService_CL148;
import pages.Member_GI301;
import pages.Member_GI325;
import pages.Physician_CL201;
import pages.Physician_CL209;
import util.FunctionLibrary;

public class LimitedServiceStepDefinition {


	public String Audit_number,Div;

public LimitedServiceStepDefinition() {
		
	}



@When("^The MemberID \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
	public void the_MemberID_is_present_on_screen(String Member_ID, String Screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	FunctionLibrary.navigateToDiv(Screen);
	if (Screen.equals("CL201")){
	Physician_CL201 phy_screen1 = new Physician_CL201();
	String Act_MemberID=phy_screen1.mem_val();
	//Assert.assertEquals(Act_MemberID, Member_ID);
	    System.out.println("Member ID is:"+Act_MemberID);
	    Reporter.addStepLog("Member ID is" +Act_MemberID);
	}

	}



@Then("^the memberId \"([^\"]*)\"-\"([^\"]*)\"-\"([^\"]*)\" is inquired on screen \"([^\"]*)\"$")
public void the_memberId_is_inquired_on_screen(String mem_number, String member_number2, String member_number3, String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	FunctionLibrary.navigateToDiv(screen);
	if (screen.equals("CL147")){
    LimitedService_CL147 ls= new LimitedService_CL147();
    Thread.sleep(1000);
    ls.member_inq(mem_number, member_number2, member_number3, screen);
	}
    else if (screen.equals("CL148")){
    	LimitedService_CL148 ls1= new LimitedService_CL148();
    	Thread.sleep(1000);
        ls1.member_inq(mem_number, member_number2, member_number3, screen);
    }
    
}

@Then("^the required memberID \"([^\"]*)\" is inquired in screen \"([^\"]*)\"$")
public void the_required_memberID_is_inquired_in_screen(String mem_number_GI, String screen1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	Thread.sleep(1000);
	FunctionLibrary.navigateToDiv(screen1);
	Thread.sleep(1000);
	 if (screen1.equals("GI325")){
	Member_GI325 mb= new Member_GI325();
	mb.member_inq(mem_number_GI, screen1);
	 }
	else if(screen1.equals("GI301")){
		Member_GI301 mb= new Member_GI301();
		mb.member_inq(mem_number_GI, screen1);
}
}


@Then("^the limited service code \"([^\"]*)\" is displayed in screen \"([^\"]*)\"$")
public void the_limited_service_code_is_displayed_in_screen(String limited_SVC, String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String limited_service=null;
	String limited_service1=null;
	   Thread.sleep(1000);
	FunctionLibrary.navigateToDiv(screen);
	Thread.sleep(1000);
	if (screen.equals("CL201")){
		Physician_CL201 phy_screen1 = new Physician_CL201();
     limited_service=phy_screen1.lim_svc1_val();
     Assert.assertEquals(limited_SVC,limited_service);
     System.out.println("The limited service code is:" +limited_service);
	    Reporter.addStepLog("The limited service code is:" +limited_service);
}
	else if (screen.equals("HO400")){
		   Thread.sleep(1000);
		Hospital_HO400 hos_screen1 = new Hospital_HO400();
	     limited_service1=hos_screen1.limited_SVC_code();
	    Thread.sleep(1000);
	     Assert.assertEquals(limited_SVC,limited_service1);
	     System.out.println("The limited service code is:" +limited_service1);
		    Reporter.addStepLog("The limited service code is:" +limited_service1);
	}
}

	
@Then("^the user enters limited service code \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_user_enters_limited_service_code_in_screen(String limited_Service, String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	
	FunctionLibrary.navigateToDiv(screen);
	if (screen.equals("CL147")){
		Thread.sleep(1000);
    LimitedService_CL147 ls= new LimitedService_CL147();
     ls.limitedServ_Inquire(limited_Service);
    
}
	else if (screen.equals("CL148")){
		Thread.sleep(1000);
	    LimitedService_CL148 lsv1= new LimitedService_CL148();
	     lsv1.limitedServ_Inquire(limited_Service);
	}
}
@Then("^verify the unit count \"([^\"]*)\" is displayed in screen \"([^\"]*)\"$")
public void verify_the_unit_count_is_displayed_in_screen(String unit_count, String screen) throws Throwable {

	String act_unit_count=null;
	String act_unit_count1=null;
	String act_unit_count2 = null;
	//FunctionLibrary.navigateToDiv(screen);
	Thread.sleep(1000);
	if (screen.equals("CL147")){
    LimitedService_CL147 ls= new LimitedService_CL147();
     act_unit_count=ls.unit_count_val();
     Thread.sleep(1000);
     System.out.println("The actual unit count is:"+act_unit_count);
     Assert.assertEquals(act_unit_count, unit_count);
	}
	else if (screen.equals("CL148")){
		Thread.sleep(1000);
    LimitedService_CL148 lsvc= new LimitedService_CL148();
    act_unit_count1=lsvc.unit_val();
    Thread.sleep(1000);
    System.out.println("The actual unit count is:"+act_unit_count1);
    Assert.assertEquals(act_unit_count1, unit_count);
	}
	else if (screen.equals("HO400")){
		Thread.sleep(1000);
    Hospital_HO400 hos_lsvc= new Hospital_HO400();
    act_unit_count2=hos_lsvc.limited_SVC_code();
    Thread.sleep(1000);
    System.out.println("The actual unit count is:"+act_unit_count2);
    Assert.assertEquals(act_unit_count2, unit_count);
	}
	
}
/*@Then("^the benefit number \"([^\"]*)\" is displayed in screen \"([^\"]*)\"$")
public void the_benefit_number_is_displayed_in_screen(String benefit_number, String screen) throws Throwable {
	String act_benefit_number=null;
	//FunctionLibrary.navigateToDiv(screen);
	if (screen.equals("CL148")){
    LimitedService_CL148 l_svc= new LimitedService_CL148();
 
   //act_benefit_number=l_svc.benefit_number_val();
	List<String> exp_benefit = new ArrayList<String>();
	exp_benefit.add(benefit_number);
	//exp_benefit.add(Audit_number);
	List act_ben_num = l_svc.benefit_val(benefit_number);
	Assert.assertEquals(act_ben_num,exp_benefit);
	System.out.println("Values returned " +act_ben_num);
	Reporter.addStepLog("Values returned " +act_ben_num);
	System.out.println("Expected returned " +act_ben_num);
	Reporter.addStepLog("Expected outcome " +act_ben_num);

}
}
}*/
	
@Then("^the benefit number \"([^\"]*)\" is displayed in screen \"([^\"]*)\"$")
public void the_benefit_number_is_displayed_in_screen(String benefit_number, String screen) throws Throwable {
	//String act_benefit_number=null;
	String act_benefit_number=null;
if (screen.equals("CL148")){
	 // Thread.sleep(1000);
    LimitedService_CL148 l_svc= new LimitedService_CL148();
   Thread.sleep(1000);
   act_benefit_number=l_svc.benefit_number_val();
  System.out.println("The actual benefit number is:"+act_benefit_number);
     Assert.assertEquals(act_benefit_number, benefit_number);
	}
}


@Given("^For the member \"([^\"]*)\" status \"([^\"]*)\" for the given audit number \"([^\"]*)\" is displayed in the screen \"([^\"]*)\"$")
public void For_the_status_for_the_given_audit_number_is_displayed_in_the_screen(String memberId,String status,String aud_num, String screen) throws Throwable {
//FunctionLibrary.navigateToDiv(Screen2);
Thread.sleep(1000);
if(screen.equals("GI325")){
	Member_GI325 mem = new Member_GI325();
	mem.member_inq(memberId, screen);
	List<String> exp_result1 = new ArrayList<String>();
exp_result1.add(aud_num);
exp_result1.add(status);
System.out.println("The expected result:"+exp_result1);


}
}}