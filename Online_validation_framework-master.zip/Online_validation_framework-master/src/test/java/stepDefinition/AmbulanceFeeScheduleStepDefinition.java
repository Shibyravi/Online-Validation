package stepDefinition;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Hospital_HO400;
import pages.Physician_CL201;
import pages.Physician_CL209;
import util.FunctionLibrary;

public class AmbulanceFeeScheduleStepDefinition {
public String Audit_number,Div,act_review_code;

@When("^the provider type is \"([^\"]*)\" on screen \"([^\"]*)\"$")
public void the_provider_type_is_on_screen(String prov_type, String screen) throws Throwable {
	
	String act_prov_type=null;
	if(screen.equals("CL201"))
	{	
		Physician_CL201 phy_screen = new Physician_CL201();
		act_prov_type =phy_screen.prov_type_val();
		
	}
	else if(screen.equals("HO400"))
	{
		Hospital_HO400 hos_screen = new Hospital_HO400();
		act_prov_type =hos_screen.prov_type_val();
	}
	if(prov_type.equals(act_prov_type))
	{	
		
		Assert.assertEquals(act_prov_type,prov_type);
		System.out.println("Expected  provtype is " +prov_type);
		Reporter.addStepLog("Expected  provtype is " +prov_type);
		System.out.println("Actual provtype is " +act_prov_type);
		Reporter.addStepLog("Actual provtype is " +act_prov_type);
	}
	else
	{
		Reporter.addStepLog("Expected  provtype is " +prov_type);
		Reporter.addStepLog("Actual provtype is " +act_prov_type);
	}
}





@Then("^the claim \"([^\"]*)\" in division \"([^\"]*)\" is hit with review \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_claim_is_hit_with_review_in_screen_and_is_not_processed_by_ambulance(String Audit_number,String Div, String Review, String Screen2) throws Throwable {
	FunctionLibrary.navigateToDiv(Screen2);
	Physician_CL209 phy_val1 = new Physician_CL209();
	phy_val1.CL209_Inquire(Audit_number,Div);
	act_review_code=phy_val1.GetRev_Code3();
	Reporter.addStepLog("Values returned " +act_review_code);
	Reporter.addStepLog("Expected outcome " +act_review_code);
	Assert.assertEquals(act_review_code,Review);
	
}

@Then("^the claim \"([^\"]*)\" in division \"([^\"]*)\" is hit with 2nd review \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_claim_is_hit_with_2nd_review_in_screen_and_is_not_processed_by_ambulance(String Audit_number,String Div, String Review, String Screen2) throws Throwable {
	FunctionLibrary.navigateToDiv(Screen2);
	Physician_CL209 phy_val1 = new Physician_CL209();
	phy_val1.CL209_Inquire(Audit_number,Div);
	act_review_code=phy_val1.GetRev_Code4();
	Reporter.addStepLog("Values returned " +act_review_code);
	Reporter.addStepLog("Expected outcome " +act_review_code);
	Assert.assertEquals(act_review_code,Review);
	
}

@Then("^the claim \"([^\"]*)\" in division \"([^\"]*)\" is hit with 3rd review \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_claim_is_hit_with_3rd_review_in_screen_and_is_not_processed_by_ambulance(String Audit_number,String Div, String Review, String Screen2) throws Throwable {
	FunctionLibrary.navigateToDiv(Screen2);
	Physician_CL209 phy_val1 = new Physician_CL209();
	phy_val1.CL209_Inquire(Audit_number,Div);
	act_review_code=phy_val1.GetRev_Code1();
	Reporter.addStepLog("Values returned " +act_review_code);
	Reporter.addStepLog("Expected outcome " +act_review_code);
	Assert.assertEquals(act_review_code,Review);
	
}

//@Then("^the claim \"([^\"]*)\" in division \"([^\"]*)\" is hit with review \"([^\"]*)\" in screen \"([^\"]*)\"")
//public void the_claim_is_hit_with_review_in_screen(String Audit_number,String Div,String Review1, String Screen2) throws Throwable {
//	String act_review_code=null;
//	FunctionLibrary.navigateToDiv(Screen2);
//	Physician_CL209 phy_val1 = new Physician_CL209();
//	phy_val1.CL209_Inquire(Audit_number,Div);
//	List<String> exp_result = new ArrayList<String>();
//	exp_result.add(Review1);
	//exp_result.add(Rev_user_code);
//	act_review_code = phy_val1.
//	Assert.assertEquals(act_review_code,exp_result);
//	Reporter.addStepLog("Values returned " +act_review_code);
//	Reporter.addStepLog("Expected outcome " +act_review_code);
//}


@Then("^the required unit level \"([^\"]*)\" is displayed in the screen \"([^\"]*)\"$")
public void the_required_Benefit_level_is_displayed_in_the_screen(String benefit_lvl, String screen) throws Throwable{
	String ben_lvl=null;
	/*FunctionLibrary.navigateToDiv(screen);
	Thread.sleep(1000);*/
	if(screen.equals("CL201"))
	{
	Physician_CL201 phy_svc_ben = new Physician_CL201();
	//phy_svc_ben.CL201_Inquire(Audit_number, Div);
	String svc_code_ben=phy_svc_ben.svc1_val().substring(5,6);
	System.out.println("Benefit_Level is:"+svc_code_ben);
	
	 ben_lvl=svc_code_ben.trim();
	Assert.assertEquals(ben_lvl,benefit_lvl);
		
	}
	else if(screen.equals("HO400"))
	{
		String hos_ben_lvl=null;
	Hospital_HO400 hos_svc_ben = new Hospital_HO400();
	hos_svc_ben.HO400_Inquire(Audit_number, Div);
	String svc_code_ben_hos=hos_svc_ben.svc1_val().substring(4,6);
	System.out.println("Benefit_Level is:"+svc_code_ben_hos);
	
	hos_ben_lvl=svc_code_ben_hos.trim();
	Assert.assertEquals(hos_ben_lvl,benefit_lvl);
	}
}


}