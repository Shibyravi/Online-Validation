package stepDefinition;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;

import com.cucumber.listener.Reporter;
import com.hp.lft.sdk.te.Field;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Hospital_HO400;
import pages.Hospital_HO409;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL209;
import util.FunctionLibrary;

public class Fraud_Abuse {
	
	public Field audit,subaudit;
public String Audit_number,Div;

	public Fraud_Abuse(){
	
	}
	
	@Then("^the claim is header denied with the denial code \"([^\"]*)\" in screen \"([^\"]*)\" with audit number \"([^\"]*)\" in div \"([^\"]*)\"$")
	public void the_claim_is_header_denied_with_the_denial_code_in_screen_with_audit_number_in_div(String hdr_deny_code,String screen,String Audit_number, String Div) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		FunctionLibrary.navigateToDiv(screen);
		Thread.sleep(1000);
		String act_hdr_deny_code=null;
		if(screen.equals("CL201"))
		{	
			
			Physician_CL201 phy_val = new Physician_CL201();
			phy_val.CL201_Inquire(Audit_number, Div);
		
			Thread.sleep(1000);
			 act_hdr_deny_code =phy_val.hdr_deny_val();
			
		  Assert.assertEquals(act_hdr_deny_code,hdr_deny_code);
		    System.out.println("The actual header code is:"+act_hdr_deny_code);
			Reporter.addStepLog("Header deny code is " +act_hdr_deny_code);
		}
		else if (screen.equals("HO400"))
		{
			Hospital_HO400 hos_val = new Hospital_HO400();
			hos_val.HO400_Inquire(Audit_number, Div);
			act_hdr_deny_code =hos_val.hdr_deny_val();
			System.out.println("The hospital header code is:"+act_hdr_deny_code);
			Assert.assertEquals(act_hdr_deny_code,hdr_deny_code);
			Reporter.addStepLog("Header deny code is " +act_hdr_deny_code);
		}
	}
	
	

	@Then("^the claim status \"([^\"]*)\" is displayed in the screen \"([^\"]*)\" with audit number \"([^\"]*)\" in Div \"([^\"]*)\"$")
	public void the_claim_status_is_displayed_in_the_screen_with_audit_number_in_Div(String claim_status, String Screen2, String Audit_number, String Div) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		FunctionLibrary.navigateToDiv(Screen2);
		String act_cls=null;
		if(Screen2.equals("CL201")){
	Physician_CL201 phy_cls = new Physician_CL201();
	phy_cls.CL201_Inquire(Audit_number,Div);
	Thread.sleep(1000);
	act_cls=phy_cls.clm_sts_Val();
	System.out.println("The claim status is :"+act_cls);
	Assert.assertEquals(claim_status,act_cls);
		}
	  }




	/*@Then("^the remarks flag \"([^\"]*)\" value is \"([^\"]*)\" from \"([^\"]*)\" in database \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\"$")
	public void the_remarks_flag_value_is_from_in_database_for_primary_key_as_and_as(String keyfield, String frd_flg, String Table, String db, String keyfield1, String Audit_number, String keyfield2, String subaudit_number) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String act_remark_flag = FunctionLibrary.DB2Validation_Div(keyfield, db, Table, keyfield1, Audit_number, keyfield2, subaudit_number);
		//Thread.sleep(1000);
		if(frd_flg.equals(act_remark_flag))
		{
			Assert.assertEquals(frd_flg, act_remark_flag);
			Reporter.addStepLog("Actual remark flag is " +act_remark_flag);
		}
		else
		{
			Reporter.addStepLog("Actual remark flag is " +act_remark_flag);
		}
	}*/
		
		/*@Then("^the remarks flag \"([^\"]*)\" value is \"([^\"]*)\" from \"([^\"]*)\" in database \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\"$")
		public void the_remarks_flag_value_is_from_in_database_for_primary_key_as(String keyfield, String frd_flg, String Table, String db, String keyfield1, String Audit_number) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String act_remark_flag = FunctionLibrary.DB2Validation(keyfield, db, Table, keyfield1, Audit_number);
			//Thread.sleep(1000);
			if(frd_flg.equals(act_remark_flag))
			{
				Assert.assertEquals(frd_flg, act_remark_flag);
				Reporter.addStepLog("Actual remark flag is " +act_remark_flag);
			}
			else
			{
				Reporter.addStepLog("Actual remark flag is " +act_remark_flag);
			}
	}*/



/*@Then("^the claim \"([^\"]*)\" in div \"([^\"]*)\" is hit with review \"([^\"]*)\" in screen \"([^\"]*)\" and is processed by fraud batch \"([^\"]*)\"$")
public void the_claim_in_div_is_hit_with_review_in_screen_and_is_processed_by_fraud_batch(String Audit_number, String Div, String Screen, String Review,String Rev_user_code) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    FunctionLibrary.navigateToDiv(Screen);
    Thread.sleep(1000);
    if(Screen.equals("CL209")){
    	Physician_CL209 phy_val = new Physician_CL209();
    	System.out.println("Audit number:"+Audit_number);
		phy_val.CL209_Inquire(Audit_number,Div);
		List<String> exp_result1 = new ArrayList<String>();
		exp_result1.add(Review);
		exp_result1.add(Rev_user_code);
		List act_review_code =phy_val.review_val(Review);
		Assert.assertEquals(act_review_code,exp_result1);
		
		Reporter.addStepLog("Values returned " +act_review_code);
		Reporter.addStepLog("Expected outcome " +act_review_code);
    }
    else if (Screen.equals("HO409")){
    	Hospital_HO409 hos_val1 = new Hospital_HO409();
		hos_val1.HO409_Inquire(Audit_number,Div);
		List<String> exp_result1 = new ArrayList<String>();
		exp_result1.add(Review);
		exp_result1.add(Rev_user_code);
		List act_review_code =hos_val1.review_val(Review);
		Assert.assertEquals(act_review_code,exp_result1);
		
		Reporter.addStepLog("Values returned " +act_review_code);
		Reporter.addStepLog("Expected outcome " +act_review_code);
    }
}*/

@Then("^the claim \"([^\"]*)\" in \"([^\"]*)\" is hit with review \"([^\"]*)\" in screen \"([^\"]*)\" and is not processed by fraud batch \"([^\"]*)\"$")
public void the_claim_in_is_hit_with_review_in_screen_and_is_not_processed_by_fraud_batch(String Audit_number, String Div, String Review, String Screen2, String Rev_user_code) throws Throwable {
	Thread.sleep(1000);
	FunctionLibrary.navigateToDiv(Screen2);
	
	if(Screen2.equals("CL209")){
	Physician_CL209 phy_val1 = new Physician_CL209();
	phy_val1.CL209_Inquire(Audit_number,Div);
	List<String> exp_result = new ArrayList<String>();
	exp_result.add(Review);
	exp_result.add(Rev_user_code);
	List act_review_code =phy_val1.review_val(Review);
	Assert.assertEquals(act_review_code,exp_result);
	System.out.println("Values returned " +act_review_code);
	Reporter.addStepLog("Values returned " +act_review_code);
	System.out.println("Expected returned " +act_review_code);
	Reporter.addStepLog("Expected outcome " +act_review_code);
}
	else if(Screen2.equals("HO409")){
		Hospital_HO409 hos_val1 = new Hospital_HO409();
		hos_val1.HO409_Inquire(Audit_number,Div);
		List<String> exp_result = new ArrayList<String>();
		exp_result.add(Review);
		exp_result.add(Rev_user_code);
		List act_review_code =hos_val1.review_val(Review);
		Assert.assertEquals(act_review_code,exp_result);
		System.out.println("Values returned " +act_review_code);
		Reporter.addStepLog("Values returned " +act_review_code);
		System.out.println("Expected returned " +act_review_code);
		Reporter.addStepLog("Expected outcome " +act_review_code);
		
	}	
}

@Then("^the claim \"([^\"]*)\" in \"([^\"]*)\" is hit with review \"([^\"]*)\" in screen \"([^\"]*)\" and is processed by fraud batch \"([^\"]*)\"$")
public void the_claim_in_is_hit_with_review_in_screen_and_is_processed_by_fraud_batch(String Audit_number, String Div, String Review, String Screen2, String Rev_user_code) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	List act_review_code,act_review_code1=null; 
	Thread.sleep(1000);
	FunctionLibrary.navigateToDiv(Screen2);
	
	if(Screen2.equals("CL209")){
	Physician_CL209 phy_val1 = new Physician_CL209();
	phy_val1.CL209_Inquire(Audit_number,Div);
	List<String> exp_result = new ArrayList<String>();
	exp_result.add(Review);
	exp_result.add(Rev_user_code);
 act_review_code =phy_val1.review_val(Review);
	Assert.assertEquals(act_review_code,exp_result);
	System.out.println("Values returned " +act_review_code);
	Reporter.addStepLog("Values returned " +act_review_code);
	System.out.println("Expected returned " +act_review_code);
	Reporter.addStepLog("Expected outcome " +act_review_code);
}
	else if(Screen2.equals("HO409")){
		Hospital_HO409 hos_val1 = new Hospital_HO409();
		hos_val1.HO409_Inquire(Audit_number,Div);
		Thread.sleep(1000);
		List<String> exp_result = new ArrayList<String>();
		exp_result.add(Review);
		exp_result.add(Rev_user_code);
		act_review_code1 =hos_val1.review_val(Review);
		Assert.assertEquals(act_review_code1,exp_result);
		System.out.println("Values returned " +act_review_code1);
		Reporter.addStepLog("Values returned " +act_review_code1);
		System.out.println("Expected returned " +act_review_code1);
		Reporter.addStepLog("Expected outcome " +act_review_code1);
		
	}	

}



@Then("^the remarks flag \"([^\"]*)\" value is \"([^\"]*)\" from \"([^\"]*)\" in database \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\"$")
public void the_remarks_flag_value_is_from_in_database_for_primary_key_as(String keyfield, String frd_flg, String Table, String db, String keyfield1, String Audit_number) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String act_remark_flag = FunctionLibrary.DB2Validation(keyfield, db, Table, keyfield1, Audit_number);
	//Thread.sleep(1000);
	if(frd_flg.equals(act_remark_flag))
	{
		Assert.assertEquals(frd_flg, act_remark_flag);
		Reporter.addStepLog("Actual remark flag is " +act_remark_flag);
	}
	else
	{
		Reporter.addStepLog("Actual remark flag is " +act_remark_flag);
	}
}






	
		@Then("^the claim is denied with the denial code \"([^\"]*)\" in screen \"([^\"]*)\" for audit number \"([^\"]*)\" in division \"([^\"]*)\"$")
		public void the_claim_is_denied_with_the_denial_code_in_screen_for_audit_number_in_division(String Detail_deny_code1, String Screen1,String Audit_number,String Div) throws Throwable {
			FunctionLibrary.navigateToDiv(Screen1);
			if(Screen1.equals("CL201")){
			Physician_CL201 phy_val1 = new Physician_CL201();
			phy_val1.CL201_Inquire(Audit_number,Div);
			String act_deny_code =phy_val1.det1_deny_val();
			System.out.println("Deny code is " +act_deny_code);
			Assert.assertEquals(act_deny_code,Detail_deny_code1);
			
			Reporter.addStepLog("Deny code is " +act_deny_code);
		}
			
		}
		@Then("^the claim is not denied with the denial code \"([^\"]*)\" in screen \"([^\"]*)\" for audit number \"([^\"]*)\" in division \"([^\"]*)\"$")
		public void the_claim_is_not_denied_with_the_denial_code_in_screen_for_audit_number_in_division(String Detail_deny_code1, String Screen1,String Audit_number,String Div) throws Throwable {
			FunctionLibrary.navigateToDiv(Screen1);
			if(Screen1.equals("CL201")){
			Physician_CL201 phy_val1 = new Physician_CL201();
			phy_val1.CL201_Inquire(Audit_number,Div);
			String act_deny_code =phy_val1.det1_deny_val();
			System.out.println("Deny code is " +act_deny_code);
			Assert.assertNotEquals(act_deny_code,Detail_deny_code1);
			
			Reporter.addStepLog("Deny code is " +act_deny_code);
		}
			
		}
		
		/*@When("^the provider status \"([^\"]*)\" is displayed in screen \"([^\"]*)\"$")
		public void the_provider_status_is_displayed_in_screen(String Prov_status, String Screen) throws Throwable {
			FunctionLibrary.navigateToDiv(Screen);
			Physician_CL202 phy_val1 = new Physician_CL202();
			phy_val1.CL202_Inquire(Audit_number, Div);
			Thread.sleep(500);
			String act_prov_stat =phy_val1.par_status_val();
			Assert.assertEquals(act_prov_stat,Prov_status);
			System.out.println("Prov status is " +act_prov_stat);
			Reporter.addStepLog("Prov status is " +act_prov_stat);

		}*/
}
