package stepDefinition;

import java.io.IOException;
import java.util.List;

import org.junit.Assert;

import com.cucumber.listener.Reporter;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Screen;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.CL657;
import pages.CL658;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.TB130;
import pages.TB491;
import util.FunctionLibrary;

public class DMEStepDefinition {
	String DME_CAT,unitFee_CL201,unitFee_CL658,prov_CL202,Provider_CL658=null;
	public Screen screen;
	 String unit_cl201,unit_cl658=null;
	    int unit_201,unit_658;
	
	@Then("^the expiry date should be less than or equals to current date for the given procedure and dme category on Screen \"([^\"]*)\" with criteria \"([^\"]*)\"$")
	public void the_expiry_date_should_be_less_than_or_equals_to_current_date_for_the_given_procedure_and_dme_category_on_Screen_with_criteria(String ScreenName, String Criteria) throws Throwable {
		FunctionLibrary f1=new FunctionLibrary();
		f1.navigateToDiv("CL657");
		f1.getDMEDetailsOnCL657(ScreenName,Criteria);
	}
	
	@Then("^the patient id is displayed in screen \"([^\"]*)\"$")
	public void the_patient_id_is_displayed_in_screen(String Screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String patient=null;
	    TB130 tb130=new TB130();
	    if(Screen.equalsIgnoreCase("TB130"))
	    	Thread.sleep(500);
	    patient=tb130.get_pat_id();
	    System.out.println("The patient Id is:"+patient);
	    
	}

	@Then("^the member zip is displayed on screen \"([^\"]*)\"$")
	public void the_member_zip_is_displayed_on_screen(String Screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String tb_zip=null;
		TB491 tb491 = new TB491();
		Thread.sleep(500);
		if(Screen.equalsIgnoreCase("TB491")){
			
		tb_zip=tb491.get_mem_zip();
		System.out.println("The member zip in TB491:"+tb_zip);
	}
	}

	@Then("^the med cap is displayed on screen \"([^\"]*)\"$")
	public void the_med_cap_is_displayed_on_screen(String Screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String tb_med=null;
		TB491 tb491 = new TB491();
		Thread.sleep(500);
		if(Screen.equalsIgnoreCase("TB491")){
		tb_med=tb491.get_med_cap();
		System.out.println("The member cap in TB491:"+tb_med);
	}
	}

	@When("^user enquires procedure code on screen \"([^\"]*)\" from screen \"([^\"]*)\" with audit \"([^\"]*)\" and div \"([^\"]*)\"$")
	public void user_enquires_procedure_code_on_screen_from_screen_with_audit_and_div(String Screen, String screen,String Audit,String Div) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		CL657 cl_657=new CL657();
		FunctionLibrary.navigateToDiv(Screen);
		if(Screen.equalsIgnoreCase("CL657")){
			cl_657.enter_proccode(screen,Audit,Div);
		}
	}

	@When("^user enquires dental medical equipment code on screen \"([^\"]*)\"$")
	public void user_enquires_dental_medical_equipment_code_on_screen(String Screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		CL658 phy_cl_658=new CL658();
		FunctionLibrary.navigateToDiv(Screen);
		
if(Screen.equalsIgnoreCase("CL658")){
	phy_cl_658.enter_dme_cat("CL657");	 
		}
	}
	
	@When("^user enquries dental medical equipment code from screen \"([^\"]*)\" on screen \"([^\"]*)\" with audit number \"([^\"]*)\" and div \"([^\"]*)\"$")
	public void user_enquries_dental_medical_equipment_code_from_screen_on_screen_with_audit_number_and_div(String Screen1, String Screen,String Audit_number, String Div) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		CL658 phy_cl_658=new CL658();
		FunctionLibrary.navigateToDiv(Screen);
		
if(Screen.equalsIgnoreCase("CL658")){
	
	phy_cl_658.enter_dme_cat("CL657",Screen,Audit_number,Div);

	
			 
		}
	}
	

	
	
	
	@Then("^the limit review \"([^\"]*)\" should be displayed on the screen \"([^\"]*)\" with audit \"([^\"]*)\" and div \"([^\"]*)\"$")
	public void the_limit_review_should_be_displayed_on_the_screen_with_audit_and_div(String review, String Screen,String Auditnumber,String Div) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		CL658 cl_658=new CL658();
		CL657 cl_67=new CL657();
		Physician_CL201 phy_CL201= new Physician_CL201();
		Physician_CL202 phy_CL202= new Physician_CL202();
		
		
		FunctionLibrary.navigateToDiv("CL201");
		phy_CL201.CL201_Inquire(Auditnumber,Div);
		
		unitFee_CL201=phy_CL201.unitfee_val();
		System.out.println("The value of unit fee in CL201:"+unitFee_CL201);
		
		FunctionLibrary.navigateToDiv("CL658");
		if(Screen.equals("CL658")){
			cl_658.enter_dme_cat(Screen);
		unitFee_CL658=cl_658.get_unit_fee();
		System.out.println("The value of unit fee in CL658:"+unitFee_CL658);
		}
		FunctionLibrary.navigateToDiv("CL202");
		
		phy_CL202.CL202_Inquire(Auditnumber,Div);
		prov_CL202=phy_CL202.prov_type_val_new();
		System.out.println("The value of provider status in CL202:"+prov_CL202);
		
		FunctionLibrary.navigateToDiv("CL658");
		
		Provider_CL658=cl_658.get_prov_code();
		System.out.println("The value of provider status in CL658:"+Provider_CL658);
		cl_658.enter_dme_cat("CL658");
		
		String lim_rev=null;
		Thread.sleep(500);
		    if(Screen.equalsIgnoreCase("CL658")){
		
		
			int compare = unitFee_CL201.compareToIgnoreCase(unitFee_CL658);
			if(compare < 0){
			    //-1, --> s is less than best. ( s comes alphabetically first)
				System.out.println("The unit fee of CL201 is less than unit fee of CL658");
			}
			else if(compare > 0 ){
			// best comes alphabetically first.
				System.out.println("The unit fee of CL201 is greater than unit fee of CL658");
				if(prov_CL202.contains("PAR")){
					if(Provider_CL658.equalsIgnoreCase("P")){
						System.out.println("The the limit review can be checked for Par provider");
					}
					else if(Provider_CL658.equalsIgnoreCase("N"))
					{
						System.out.println("The the limit review can be checked for Non-Par provider");
					}
				}
			}
			else{
			    // strings are equal.
				System.out.println("The unit fee of CL201 is equal with unit fee of CL658");
			}
			
		}
			lim_rev=cl_658.get_limit_rev();
			
			System.out.println("The value of Limited Review code is:"+lim_rev);
			Assert.assertEquals(review, lim_rev);
			Reporter.addStepLog("The value of Limited Review code is:"+lim_rev);
					 
				}
	
	@When("^verify if unit fee in screen \"([^\"]*)\" is greater than in the screen \"([^\"]*)\" for audit number \"([^\"]*)\" and div \"([^\"]*)\"$")
	public void verify_if_unit_fee_in_screen_is_greater_than_in_the_screen_for_audit_number_and_div(String Screen1, String Screen2,String Auditnumber,String Div) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    FunctionLibrary fun=new FunctionLibrary();
	   Thread.sleep(1000);
	    fun.navigateToDiv(Screen1);
	    if(Screen1.equals("CL201")){
	    	Physician_CL201 phy_val=new Physician_CL201();
	    	phy_val.CL201_Inquire(Auditnumber,Div);
	    	Thread.sleep(500);
	    	unit_cl201=phy_val.unitfee_val();
	    unit_201 = Integer.parseInt(unit_cl201);	
	    	System.out.println("Unit Fee in screen CL201:"+unit_201);
	    	
	    }
	    fun.navigateToDiv(Screen2);
	    Thread.sleep(1000);
	    CL658 cl658_screen=new CL658();
	    cl658_screen.enter_dme_cat("CL657", Screen2, Auditnumber, Div);
	    Thread.sleep(500);
	    unit_cl658= cl658_screen.get_unit_fee();
	    unit_658 = Integer.parseInt(unit_cl658);
	    System.out.println("Unit Fee in screen CL658:"+unit_658);
	    
	    if(unit_201>=unit_658){
	    	System.out.println("The unit fee in CL201 is greater than in CL658");
	    	// Assert.assertTrue("CL201 is greater than CL658", unit_201>=unit_658);
	    }
	    else
	    {
	    	System.out.println("The unit fee in CL201 is smaller than in CL658");
	    }
	   
	    }
	    
	
	

	@Then("^the limit review \"([^\"]*)\" should be displayed on the screen \"([^\"]*)\"$")
	public void the_limit_review_should_be_displayed_on_the_screen(String review, String Screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		String lim_rev=null;
		CL658 cl_658=new CL658();
		Thread.sleep(1000);
		
		    if(Screen.equalsIgnoreCase("CL658")){
			lim_rev=cl_658.get_limit_rev();
			
			System.out.println("The value of Limited Review code is:"+lim_rev);
			Assert.assertEquals(review, lim_rev);
			Reporter.addStepLog("The value of Limited Review code is:"+lim_rev);
					 
				}
	}
	
	@Then("^verify the provider status on the screen \"([^\"]*)\"$")
	public void verify_the_provider_status_on_the_screen(String Screen) throws IOException, GeneralLeanFtException
	
	{
		String provStatus=null;
		CL658 cl_658= new CL658();
		
		provStatus=cl_658.get_prov_code();
		if(provStatus.equals("P")){
			System.out.println("The provider is PAR:"+provStatus);
		}
		else if(provStatus.equals("N")){
			System.out.println("The provider is NON-PAR:"+provStatus);
		}
	}
	
	@Given("^claim has no modifier \"([^\"]*)\" for cpt code \"([^\"]*)\" in screen \"([^\"]*)\"$")
	public void claim_has_no_modifier_for_cpt_code_in_screen(String mod, String cpt, String screen) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
			if(screen.equals("CL201"))
			{
				Physician_CL201 phy_screen = new Physician_CL201();
				String act_cpt = phy_screen.proc1_val();
				

				if(cpt.contains(act_cpt))
				{
					Reporter.addStepLog("Actual CPT " + act_cpt);
					String act_mod = phy_screen.proc1_mod1_val();
					if (!act_mod.equalsIgnoreCase("No Modifier"))
					{		
						Assert.assertEquals(act_mod, mod);
						Reporter.addStepLog("Actual mod " + act_mod);
					}
					else
					{
						System.out.println("The claim has no modifier");
						Reporter.addStepLog("No modifiers on claim");
					}
				}
			}
			
	}
	@Given("^verify if the total claimed amount \"([^\"]*)\" is greater than (\\d+) in screen \"([^\"]*)\"$")
	public void verify_if_the_total_claimed_amount_is_greater_than_in_screen(String amt, double d, String Screen1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		FunctionLibrary.navigateToDiv(Screen1);
		double Total_amount=0;
	    d=10000.0;
		double totalAmt=0;
		if (Screen1.equals("CL201"))
		{
			Physician_CL201 phy_val1 = new Physician_CL201();
		//	phy_val1.CL201_Inquire(Audit_number, Div);
			 totalAmt=Double.parseDouble(amt);
			if(totalAmt>d)
			{	
				Total_amount =Double.parseDouble(phy_val1.tot_billed_val());
			}
			else
			{
				Total_amount =Double.parseDouble(phy_val1.tot_billed_val());
				System.out.println("Total claimed amount is " +Total_amount +" lesser than 10000.0");
			}
			Assert.assertTrue(true);
			System.out.println("Total claimed amount is " +Total_amount +" greater than 10000.0");
			Reporter.addStepLog("Total claimed amount is " +Total_amount +" ");
		}
		
	
	}
	
	@Then("^verify if the total claimed_amount \"([^\"]*)\" is greater than (\\d+) in screen \"([^\"]*)\"$")
	public void verify_if_the_tatal_claimed_amount_is_greater_than_1000_in_screen(String amt, String Screen1) throws Throwable {
		FunctionLibrary.navigateToDiv(Screen1);
		double Total_amount=0;
		double totalAmt=0;
		if (Screen1.equals("CL201"))
		{
			Physician_CL201 phy_val1 = new Physician_CL201();
		//	phy_val1.CL201_Inquire(Audit_number, Div);
			 totalAmt=Double.parseDouble(amt);
			if(totalAmt<1000.0)
			{	
				Total_amount =Double.parseDouble(phy_val1.tot_billed_val());
			}
			else
			{
				Total_amount =Double.parseDouble(phy_val1.tot_billed_val());
			}
		}
		if(totalAmt > 1000.0)
		{
			Assert.assertTrue(true);
			System.out.println("Total claimed amount is " +Total_amount +" lesser than 1000");
			Reporter.addStepLog("Total claimed amount is " +Total_amount +" lesser than 1000");
		}
	}
	@Then("^verify if NPD acn \"([^\"]*)\" value is \"([^\"]*)\" from \"([^\"]*)\" in database \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\"$")
	public void verify_if_NPD_acn_value_is_from_in_database_for_primary_key_as_and_as(String keyfield, String npd, String Table, String db,  String keyfield1, String Div,String keyfield2,String Audit_number) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String act_acn_value = FunctionLibrary.DB2Validation(keyfield, db, Table, keyfield1,Div,keyfield2, Audit_number);
		String actual_acn=act_acn_value.trim();
		//Thread.sleep(1000);
		if(npd.equals(actual_acn))
		{
			Assert.assertEquals(npd, actual_acn);
			System.out.println("The NPD acn value is:"+actual_acn);
			Reporter.addStepLog("Actual ncp text value is:" +actual_acn);
		}
		else
		{
			System.out.println("The NPD acn value is:"+actual_acn);
			Reporter.addStepLog("Actual ncp text value is:" +actual_acn);
		}
	}
	@Then("^verify if pricer value \"([^\"]*)\" value is \"([^\"]*)\" from \"([^\"]*)\" in database \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\"$")
	public void verify_if_pricer_value_is_from_in_database_for_primary_key_as_and_as(String keyfield, String pricer, String Table, String db,  String keyfield1, String Div,String keyfield2,String Audit_number) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String act_pricer_value = FunctionLibrary.DB2Validation(keyfield, db, Table, keyfield1,Div,keyfield2, Audit_number);
		//Thread.sleep(1000);
		if(pricer.equals(act_pricer_value))
		{
			Assert.assertEquals(pricer, act_pricer_value);
			System.out.println("The pricer value is:"+pricer);
			Reporter.addStepLog("Actual pricer value is:" +act_pricer_value);
		}
		else
		{
			System.out.println("The pricer value is:"+pricer);
			Reporter.addStepLog("Actual pricer value is:" +act_pricer_value);
		}
	}
	
	
	
	@Then("^the user enters on the screen \"([^\"]*)\"$")
	public void the_user_enters_on_the_screen(String screen) throws GeneralLeanFtException, IOException{
		//FunctionLibrary.navigateToDiv(screen);
		if (screen.equals("CL201")){
			Physician_CL201 cl201=new Physician_CL201();
			cl201.press_enter();
	}
	}
	
	}

