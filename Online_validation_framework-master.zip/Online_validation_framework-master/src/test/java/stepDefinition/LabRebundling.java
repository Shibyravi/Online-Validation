package stepDefinition;

import java.io.IOException;
import java.util.List;

import com.cucumber.listener.Reporter;
import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.java.Window;
import com.hp.lft.sdk.java.WindowDescription;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import pages.Hospital_HO400;
import pages.Physician_CL201;
import pages.Physician_CL202;
import util.FunctionLibrary;

//testing
public class LabRebundling {
	public String line=null;
	Physician_CL201 phy_val1 = new Physician_CL201();
	String label;

	@When("^the last record is present on screen \"([^\"]*)\" with audit number \"([^\"]*)\" and division \"([^\"]*)\"$")
	public void the_last_record_is_present_on_screen_with_audit_number_and_division(String Screen1, String Audit_number, String Div) throws Throwable {

		FunctionLibrary.navigateToDiv(Screen1);
		Physician_CL201 phy_val1 = new Physician_CL201();
		phy_val1.CL201_Inquire(Audit_number, Div);
		Thread.sleep(800);
		
		if (Screen1.equals("CL201"))
		{
			label=phy_val1.claim_msg_val();
			label=	label.trim();
			Thread.sleep(500);
			System.out.println("last record is "+label);

			if(label.equals("LAST RECORD")){

				String lineNo=phy_val1.dtl_lin2_val();
				if(lineNo.equals("2")){
					System.out.println("highest is 2");
					line="2";
				}
				else {
					System.out.println("highest line is 1");
					line="1";
				}

			}

			else{
				System.out.println("last record is not found on first page,press enter to go on next page");

				phy_val1.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);


				String lineNo=phy_val1.dtl_lin2_val();
				if(lineNo.equals("4")){
					line="4";
					System.out.println("higesh is 4");
				}
				else {
					line="3";
					System.out.println("highest line is 3");
				}


				
				

			}


		}
	}




	@Then("^the highest detailed line is denied with the duplicate denial code\"([^\"]*)\" for detail line CPT in screen \"([^\"]*)\" with audit number \"([^\"]*)\" and division \"([^\"]*)\"$")
	public void the_highest_detailed_line_is_denied_with_the_duplicate_denial_code_for_detail_line_CPT_in_screen_with_audit_number_and_division(String Detail_deny_code, String Screen1,String Audit_number, String Div) throws Throwable {

		boolean flag=false;   

		FunctionLibrary.navigateToDiv(Screen1);
		Physician_CL201 phy_val1 = new Physician_CL201();
		phy_val1.CL201_Inquire(Audit_number, Div);
		Thread.sleep(800);
		String reasonCode=null;
		if(line.equals("4")||line.equals("2")){
			reasonCode=phy_val1.det2_deny_val();	
		}
		else if(line.equals("1")||line.equals("3")){
			reasonCode=phy_val1.det1_deny_val();	
		}

		if(reasonCode.equalsIgnoreCase(Detail_deny_code)){
			System.out.println("Dupliacte denial code is displaying correclty");
			flag=true;
		}
		else{
			System.out.println("Error");
		}
		Assert.assertEquals(flag, true);
	}


@Then("^the subaudit \"([^\"]*)\" is created in division <\"([^\"]*)\"> with detail line \"([^\"]*)\" with modifier \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_subaudit_is_created_in_division_with_detail_line_with_modifier_in_screen(String New_Audit_number, String Div, String CPT2, String Modifier, String Screen1) throws Throwable {
	
	boolean flag=false;
	FunctionLibrary.navigateToDiv(Screen1);
	String ele[]=	CPT2.split(",");
	System.out.println("elements");
	System.out.println(ele[0]);
	System.out.println(ele[1]);
	boolean his_audit_present=false;
	//Physician_CL201 phy_val1 = new Physician_CL201();
	//phy_val1.CL201_Inquire(sub_aud,Div);
	String act_CPT = null;
	String act_mod1=null;
	if(Screen1.equals("CL201"))
	{	
		Physician_CL201 phy_screen1 = new Physician_CL201();
		phy_screen1.CL201_Inquire(New_Audit_number,Div);
		Thread.sleep(800);
		his_audit_present = phy_screen1.msg_val();
		Assert.assertEquals(his_audit_present,true);
		

		
		if(phy_screen1.proc_code1.getText().contains(ele[0])||phy_screen1.proc_code1.getText().contains(ele[1]))
		{

			act_CPT =phy_screen1.proc1_val();
			act_mod1 =phy_screen1.proc1_mod1_val();
			//Assert.assertEquals(act_mod1,mod);
		}
		else if(phy_screen1.proc_code2.getText().contains(ele[0])||phy_screen1.proc_code2.getText().contains(ele[1]))
		{
			act_CPT =phy_screen1.proc2_val();
			act_mod1 =phy_screen1.proc1_mod1_val();
			//Assert.assertEquals(act_mod1,mod);
		}	
		
		if(act_CPT.equals(ele[0])||act_CPT.equals(ele[1])){
			flag=true;
			Reporter.addStepLog("Actual cpt is " +act_CPT);		
		}
		
		Assert.assertEquals(act_mod1,Modifier);
		Reporter.addStepLog("Actual modifier is " +act_mod1);
		
		Assert.assertTrue(flag);
	}

	else if(Screen1.equals("HO400"))
	{
		Hospital_HO400 hos_screen1 = new Hospital_HO400();
		if(hos_screen1.cpt1.getText().contains(ele[0])||hos_screen1.cpt1.getText().contains(ele[1]))
		{
			act_CPT =hos_screen1.cpt1_val();
		}
		else if(hos_screen1.cpt2.getText().contains(ele[0])||hos_screen1.cpt2.getText().contains(ele[1]))
		{
			act_CPT =hos_screen1.cpt2_val();
		}
		
		else if(hos_screen1.cpt3.getText().contains(ele[0])||hos_screen1.cpt3.getText().contains(ele[1]))
		{
			act_CPT =hos_screen1.cpt3_val();
		}
		else if(hos_screen1.cpt4.getText().contains(ele[0])||hos_screen1.cpt4.getText().contains(ele[1]))
		{
			act_CPT =hos_screen1.cpt4_val();
		}
		if(act_CPT.equals(ele[0])||act_CPT.equals(ele[1])){
			flag=true;
			Reporter.addStepLog("Actual cpt is " +act_CPT);		
		}
		Assert.assertTrue(flag);
	}



//	Screenshot.captureScreen(Screen1);
	
}


@When("^The place of service \"([^\"]*)\" is present within range on screen \"([^\"]*)\"$")
public void the_place_of_service_is_present_within_range_on_screen(String POS, String Screen) throws Throwable {
	int i=0;
	boolean flag=false;
	String act_pos=null,act_svc;
	String pos[]=POS.split(",");
	//Physician_CL201 phy_val3 = new Physician_CL201();
	if(Screen.equals("CL201"))
	{	
		Physician_CL201 phy_screen1 = new Physician_CL201();
		act_pos =phy_screen1.pos_val();
		act_svc = phy_screen1.svc1_val();

	}

	else if(Screen.equals("HO400"))
	{
		Hospital_HO400 hos_screen1 = new Hospital_HO400();
		act_pos =hos_screen1.pos_val();

	}
	
for (i = 0; i < pos.length; i++) {
	
	if(pos[i].equals(act_pos)){
		System.out.println("Service code matched");
		flag=true;
		break;
	}

}

if(i==pos.length){
	System.out.println("Actual Place of service did not matched with expected values");
    flag=false;
}
	
	
	Assert.assertEquals(flag,true);
	System.out.println("Actual POS is " +act_pos);
	Reporter.addStepLog("Actual POS is " +act_pos);
}



/*@When("^The CPT code used is within  range of \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_CPT_code_used_is_within_range_of_in_screen(List<String> cpt1, String screen,String detail_line_No) throws Throwable {
	String act_CPT=null;
	boolean cpt_match = false;
	if(screen.equals("CL201"))
	{	
		Physician_CL201 phy_screen1 = new Physician_CL201();
	
		
		for(String each_cpt : cpt1)
		{
			if(phy_screen1.proc_code1.getText().contains(each_cpt))
			{

				act_CPT =phy_screen1.proc1_val();
				Assert.assertEquals(act_CPT, each_cpt);
				  System.out.println("actual cpt is "+act_CPT);
				cpt_match = true;
			}

			else if(phy_screen1.proc_code2.getText().contains(each_cpt))
			{
				act_CPT =phy_screen1.proc2_val();
				Assert.assertEquals(act_CPT, each_cpt);
				  System.out.println("actual cpt is "+act_CPT);
				cpt_match = true;
			}
			while(!phy_screen1.claim_msg_val().trim().contains("LAST RECORD"))
			{

				phy_screen1.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
				Thread.sleep(1000);
				if(phy_screen1.proc_code1.getText().contains(each_cpt))
				{

					act_CPT =phy_screen1.proc1_val();
					Assert.assertEquals(act_CPT, each_cpt);
			  System.out.println("actual cpt is "+act_CPT);
					cpt_match = true;
				}

				else if(phy_screen1.proc_code2.getText().contains(each_cpt))
				{
					act_CPT =phy_screen1.proc2_val();
					Assert.assertEquals(act_CPT, each_cpt);
					  System.out.println("actual cpt is "+act_CPT);
					cpt_match = true;
				}			
		}
		if(!cpt_match)
		{
			act_CPT =phy_screen1.proc1_val();
			Assert.assertEquals(act_CPT, cpt1);
		}
	}
	}

	else if(screen.equals("HO400"))
	{
		Hospital_HO400 hos_screen1 = new Hospital_HO400();
		for(String each_cpt : cpt1)
		{

			if(hos_screen1.cpt1.getText().contains(each_cpt))
			{
				act_CPT =hos_screen1.cpt1_val();
				Assert.assertEquals(act_CPT, each_cpt);
				cpt_match = true;
			}
			else if(hos_screen1.cpt2.getText().contains(each_cpt))
			{
				act_CPT =hos_screen1.cpt2_val();
				Assert.assertEquals(act_CPT, each_cpt);
				cpt_match = true;
			}
			else if(hos_screen1.cpt3.getText().contains( each_cpt))
			{
				act_CPT =hos_screen1.cpt3_val();
				Assert.assertEquals(act_CPT, each_cpt);
				cpt_match = true;
			}
			else if(hos_screen1.cpt4.getText().contains(each_cpt))
			{
				act_CPT =hos_screen1.cpt4_val();
				Assert.assertEquals(act_CPT, each_cpt);
				cpt_match = true;
			}
			else
			{
				act_CPT =hos_screen1.cpt4_val();
				Assert.assertEquals(act_CPT, each_cpt);
			}
		}	
		if(!cpt_match)
		{	
			act_CPT =hos_screen1.cpt1_val();
			Assert.assertEquals(act_CPT, cpt1);
		}
	}

	Reporter.addStepLog("Expected  CPT is " +cpt1);
	Reporter.addStepLog("Actual CPT is " +act_CPT);

}*/




@When("^The CPT code used is within the range of \"([^\"]*)\" for detail line \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_CPT_code_used_is_within_the_range_of_for_detail_line_in_screen(List<String> cpt1, String detail_line_No ,String screen ) throws Throwable {
 
	
	String act_CPT=null;
	boolean cpt_match = false;
	if(screen.equals("CL201"))
	{	
		Physician_CL201 phy_screen1 = new Physician_CL201();
	
		if(detail_line_No.equals("1")){
		for(String each_cpt : cpt1)
		{
			if(phy_screen1.proc_code1.getText().contains(each_cpt))
		
		{

			act_CPT =phy_screen1.proc1_val();
			Assert.assertEquals(act_CPT, each_cpt);
			  System.out.println("actual cpt is "+act_CPT);
			cpt_match = true;
		}	
		}
		}
		
	
		else if(detail_line_No.equals("2")){
				for(String each_cpt : cpt1)
				{
					if(phy_screen1.proc_code2.getText().contains(each_cpt))
				
				{

					act_CPT =phy_screen1.proc2_val();
					Assert.assertEquals(act_CPT, each_cpt);
					  System.out.println("actual cpt is "+act_CPT);
					cpt_match = true;
				}	
				}	
		}
		else if(detail_line_No.equals("3")){
			
			phy_screen1.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			Thread.sleep(1000);
			for(String each_cpt : cpt1)
			{
				if(phy_screen1.proc_code1.getText().contains(each_cpt))
			
			{

				act_CPT =phy_screen1.proc1_val();
				Assert.assertEquals(act_CPT, each_cpt);
				  System.out.println("actual cpt is "+act_CPT);
				cpt_match = true;
			}	
			}	
	}
else if(detail_line_No.equals("4")){
			
			
			for(String each_cpt : cpt1)
			{
				if(phy_screen1.proc_code2.getText().contains(each_cpt))
			
			{

				act_CPT =phy_screen1.proc2_val();
				Assert.assertEquals(act_CPT, each_cpt);
				  System.out.println("actual cpt is "+act_CPT);
				cpt_match = true;
			}	
			}	
	}

	}
	Reporter.addStepLog("Each value of CPT codes has been verified");
}



@Then("^the claim is denied with the denial code \"([^\"]*)\" for detail line \"([^\"]*)\" in screen \"([^\"]*)\" with audit number \"([^\"]*)\" in \"([^\"]*)\"$")
public void the_claim_is_denied_with_the_denial_code_for_detail_line_in_screen_with_audit_number_in(String deny_code, String detail_line_No, String Screen1,String Audit_number,String Div) throws Throwable {
	FunctionLibrary.navigateToDiv(Screen1);
	Physician_CL201 phy_val1 = new Physician_CL201();
	String act_deny_code = null;
	if (Screen1.equals("CL201"))
	{
		//Physician_CL201 phy_val1 = new Physician_CL201();
		String aud_nbr = phy_val1.phy_aud_val();
		Thread.sleep(500);
		if(aud_nbr.equalsIgnoreCase(""))
		{ 
		phy_val1.CL201_Inquire(Audit_number, Div);
		}
	
		if(detail_line_No.equals("1")){
		
			act_deny_code =phy_val1.det1_deny_val();
			Assert.assertEquals(act_deny_code,deny_code );
			System.out.println("denial code 1 matched");
		}
		else if(detail_line_No.equals("2"))
		{
			act_deny_code =phy_val1.det2_deny_val();
			Assert.assertEquals(act_deny_code,deny_code );
			System.out.println("denial code 2 matched");
		}
		
		else if(detail_line_No.equals("3"))
		{
			phy_val1.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			Thread.sleep(1000);
			act_deny_code =phy_val1.det1_deny_val();
			Assert.assertEquals(act_deny_code,deny_code );
			System.out.println("denial code 3 matched");
		}
		else if(detail_line_No.equals("4"))
		{
			act_deny_code =phy_val1.det2_deny_val();
			Assert.assertEquals(act_deny_code,deny_code );
			System.out.println("denial code 4 matched");
		}
	

		//Screenshot.captureScreen(Screen1);
		Reporter.addStepLog("Deny code is " +act_deny_code +"verified for all cpt codes");
	}  
}


	@Given("^the member \"([^\"]*)\" is present in screen \"([^\"]*)\"in division \"([^\"]*)\"  for the audit number \"([^\"]*)\"$")
	public void the_member_is_present_in_screen_in_division_for_the_audit_number(String member, String Screen1, String div, String auditNo) throws Throwable {
	  
		FunctionLibrary.navigateToDiv(Screen1);
		String memberId=null;
		boolean flag=false;
		if (Screen1.equals("CL201"))
		{
			Physician_CL201 phy_val1 = new Physician_CL201();
			String aud_nbr = phy_val1.phy_aud_val();
			Thread.sleep(500);
			if(aud_nbr.equalsIgnoreCase(""))
			{ 
			phy_val1.CL201_Inquire(auditNo, div);
			}
			
		memberId=phy_val1.mem_val();
		System.out.println("member id is "+memberId);
		if(memberId.equals(member)){
			System.out.println("member id verified");
			flag=true;
		}
		else{
			System.out.println("error");
		}
	}
		Assert.assertTrue(flag);
		Reporter.addStepLog("member id verified");
	}



@Then("^the check field \"([^\"]*)\" value should be present in screen \"([^\"]*)\" in division \"([^\"]*)\"  for the audit number \"([^\"]*)\"$")
public void the_check_field_value_should_be_present_in_screen_in_division_for_the_audit_number(String chk, String Screen1, String div, String auditNo) throws Throwable {

	FunctionLibrary.navigateToDiv(Screen1);
	String check=null;
	boolean flag=false;
	if (Screen1.equals("CL201"))
	{
		Physician_CL201 phy_val1 = new Physician_CL201();
		String aud_nbr = phy_val1.phy_aud_val();
		Thread.sleep(500);
		if(aud_nbr.equalsIgnoreCase(""))
		{ 
		phy_val1.CL201_Inquire(auditNo, div);
		}
		check=phy_val1.chk_val();
		if(!check.equals(chk)){
			System.out.println("Claim posted by checkwrite successfully");
			flag=true;
		}
		else{
			System.out.println("issue");
		}
}
	
	Assert.assertTrue(flag);
	Reporter.addStepLog("Claim posted by checkwrite msg verified");
}

}



