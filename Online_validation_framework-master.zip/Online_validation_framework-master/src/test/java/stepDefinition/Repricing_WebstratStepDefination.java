package stepDefinition;

import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Hospital_HO409;
import pages.Hospital_HO410;
import pages.Hospital_HO430;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL209;
import pages.Physician_CL215;
import util.FunctionLibrary;

public class Repricing_WebstratStepDefination {

	
	public String Audit_number,Div;
	
	@When("^The Review_Code \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
	public void the_Review_Code_is_present_on_screen(String Review, String Screen1) throws Throwable {
		Physician_CL209 phy_screen1 = new Physician_CL209();
		String ActRevCode=phy_screen1.GetRev_Code8();
		System.out.println("Actual Review Code is :"  +ActRevCode);
		Assert.assertEquals(ActRevCode, Review);
		
	}

	@When("^The Reveiw User Code \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
	public void the_Reveiw_User_Code_is_present_on_screen(String Rev_user_code, String Screen1) throws Throwable {
		Physician_CL209 phy_screen1 = new Physician_CL209();
		String ActRevUserCode=phy_screen1.Getuser_Code8();
		System.out.println("Actual User Review Code is :"  +ActRevUserCode);
		Assert.assertEquals(ActRevUserCode, Rev_user_code);
	    
	}
	
	@When("^The Review_Code(\\d+) \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
	public void the_Review_Code_is_present_on_screen(int a, String Review, String Screen1) throws Throwable {
		Physician_CL209 phy_screen1 = new Physician_CL209();
		String ActRevCode=phy_screen1.GetRev_Code5();
		System.out.println("Actual Review Code is :"  +ActRevCode);
		Assert.assertEquals(ActRevCode, Review);
	}

	@When("^The Reveiw User Code(\\d+) \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
	public void the_Reveiw_User_Code_is_present_on_screen(int a, String Rev_user_code, String Screen1) throws Throwable {
		Physician_CL209 phy_screen1 = new Physician_CL209();
		String ActRevUserCode=phy_screen1.Getuser_Code5();
		System.out.println("Actual User Review Code is :"  +ActRevUserCode);
		Assert.assertEquals(ActRevUserCode, Rev_user_code);
	}
	
	
	
	@Then("^User Enquire for audit No\\.\"([^\"]*)\" on screen \"([^\"]*)\" with div \"([^\"]*)\"$")
	public void user_Enquire_for_audit_No_on_screen_with_div(String Audit_number, String Screen2, String Div) throws Throwable {
		FunctionLibrary.navigateToDiv(Screen2);
		Physician_CL202 phy_screen2 = new Physician_CL202();
		Thread.sleep(2000);
		phy_screen2.CL202_Inquire(Audit_number, Div);	
	}
	

	@Then("^the Claim Status \"([^\"]*)\" is displayed in screen \"([^\"]*)\"$")
	public void the_Claim_Status_is_displayed_in_screen(String Claim_Status, String Screen2) throws Throwable {
		Physician_CL202 phy_screen2 = new Physician_CL202();
		Thread.sleep(2000);
		String Act_Claim_STATUS=phy_screen2.claim_status_val();
		Assert.assertTrue(Act_Claim_STATUS.contains(Claim_Status));
	    
	}
	
	@Then("^the ACN Code \"([^\"]*)\" is displayed in screen \"([^\"]*)\"$")
	public void the_ACN_Code_is_displayed_in_screen(String Acn_code1, String Screen2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String Actual_Acn_code1=null;
		Physician_CL202 phy_screen2 = new Physician_CL202();
		Actual_Acn_code1=phy_screen2.Acn_Code_val();
		System.out.println("Actual ACN Code is "  +Actual_Acn_code1);
		Assert.assertEquals(Acn_code1, Actual_Acn_code1);
	}

	
	@Then("^the SchdCode(\\d+) \"([^\"]*)\"  is displayed in screen \"([^\"]*)\"$")
	public void the_SchdCode_is_displayed_in_screen(int A, String Schd_Code1, String Screen2) throws Throwable {
		String Actual_Schd_code1=null;
		Physician_CL201 phy_screen2 = new Physician_CL201();
		Actual_Schd_code1=phy_screen2.schd1_val();
		System.out.println("Actual Schd_Code 1 is "  +Actual_Schd_code1);
		Assert.assertEquals(Schd_Code1, Actual_Schd_code1);  
	}
	
	@Then("^then the user will inquire for audit no \"([^\"]*)\"  and claimtype \"([^\"]*)\" on Screen \"([^\"]*)\" with div \"([^\"]*)\"$")
	public void then_the_user_will_inquire_for_audit_no_and_claimtype_on_Screen_with_div(String Audit, String Claim_Type, String Screen3, String Div) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		FunctionLibrary.navigateToDiv(Screen3);
		Physician_CL215 phy_screen2 = new Physician_CL215();
		Thread.sleep(2000);
		phy_screen2.CL215_Inquire(Audit, Div);
	}

	@Then("^then Date of Service \"([^\"]*)\"  is present on screen \"([^\"]*)\" and  verified$")
	public void then_Date_of_Service_is_present_on_screen_and_verified(String DOS, String Screen3) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    String Act_DOS=null;
	    Physician_CL215 phy_scrren5=new Physician_CL215();
	    Thread.sleep(2000);
	    Act_DOS=phy_scrren5.GetDOS();
	    Assert.assertEquals(Act_DOS, DOS );
	    
	}
	
	@When("^The Review Code \"([^\"]*)\" is present on screen \"([^\"]*)\" and verify$")
	public void the_Review_Code_is_present_on_screen_and_verify(String Review, String Screen2) throws Throwable {
		Hospital_HO409 hos_screen2 = new Hospital_HO409();
	    String ActReveiw=hos_screen2.GetReview_Num();
		System.out.println("Actual Review No. is :"  +ActReveiw);
		Assert.assertEquals(ActReveiw, Review);
	}

	@When("^The Reveiw_User Code \"([^\"]*)\" is present on screen \"([^\"]*)\" and verify$")
	public void the_Reveiw_User_Code_is_present_on_screen_and_verify(String Rev_user_code, String Screen2) throws Throwable {
		Hospital_HO409 hos_screen2 = new Hospital_HO409();
	    String ActUserCode=hos_screen2.GetUser_Code();
		System.out.println("Actual User Code is :"  +ActUserCode);
		Assert.assertEquals(ActUserCode, Rev_user_code);
	}
	
	
	@When("^The ReviewCode(\\d+) \"([^\"]*)\" is present on screen \"([^\"]*)\" and verify$")
	public void the_ReviewCode_is_present_on_screen_and_verify(int a,String Review, String Screen2) throws Throwable {
		Hospital_HO409 hos_screen2 = new Hospital_HO409();
	    String ActReveiw=hos_screen2.GetReview_Num_One();
		System.out.println("Actual Review No. is :"  +ActReveiw);
		Assert.assertEquals(ActReveiw, Review);
	}

	@When("^The Reveiw_UserCode(\\d+) \"([^\"]*)\" is present on screen \"([^\"]*)\" and verify$")
	public void the_Reveiw_UserCode_is_present_on_screen_and_verify(int B, String Rev_user_code, String Screen2) throws Throwable {
		Hospital_HO409 hos_screen2 = new Hospital_HO409();
	    String ActUserCode=hos_screen2.GetUser_Code_One();
		System.out.println("Actual User Code is :"  +ActUserCode);
		Assert.assertEquals(ActUserCode, Rev_user_code);
	}
	
	@When("^The Review Code two \"([^\"]*)\" is present on screen \"([^\"]*)\" and verify$")
	public void the_Review_Code_two_is_present_on_screen_and_verify(String Review_Two, String Screen2) throws Throwable {
		Hospital_HO409 hos_screen2 = new Hospital_HO409();
	    String ActReveiw=hos_screen2.GetReview_Num_Two();
		System.out.println("Actual Review No. is :"  +ActReveiw);
		Assert.assertEquals(ActReveiw, Review_Two);
	}

	@When("^The Reveiw_User Code Two \"([^\"]*)\" is present on screen \"([^\"]*)\" and verify$")
	public void the_Reveiw_User_Code_Two_is_present_on_screen_and_verify(String Rev_user_code_Two, String Screen2) throws Throwable {
		Hospital_HO409 hos_screen2 = new Hospital_HO409();
	    String ActUserCode=hos_screen2.GetUser_Code_Two();
		System.out.println("Actual User Code is :"  +ActUserCode);
		Assert.assertEquals(ActUserCode, Rev_user_code_Two);
	}
	
	@When("^The Review Code Five\"([^\"]*)\" is present on screen \"([^\"]*)\" and verify$")
	public void the_Review_Code_Five_is_present_on_screen_and_verify(String Review, String Screen2) throws Throwable {
		Hospital_HO409 hos_screen2 = new Hospital_HO409();
	    String ActReveiw=hos_screen2.GetReview_Num_Five();
		System.out.println("Actual Review No. is :"  +ActReveiw);
		Assert.assertEquals(ActReveiw, Review);
	}

	@When("^The Reveiw_User Code Five\"([^\"]*)\" is present on screen \"([^\"]*)\" and verify$")
	public void the_Reveiw_User_Code_Five_is_present_on_screen_and_verify(String Rev_user_code, String Screen2) throws Throwable {
		Hospital_HO409 hos_screen2 = new Hospital_HO409();
	    String ActUserCode=hos_screen2.GetUser_Code_Five();
		System.out.println("Actual User Code is :"  +ActUserCode);
		Assert.assertEquals(ActUserCode, Rev_user_code);
	}


	
//	@When("^then the user will inquire for audit no \"([^\"]*)\" on Screen \"([^\"]*)\" with div \"([^\"]*)\" and Verify ProvStatus\"([^\"]*)\" and type of bill \"([^\"]*)\"$")
//	public void then_the_user_will_inquire_for_audit_no_on_Screen_with_div_and_Verify_ProvStatus_and_type_of_bill(String Audit_number, String Screen3, String Div) throws Throwable {
//		FunctionLibrary.navigateToDiv(Screen3);
//		Hospital_HO410 hos_Screen2=new Hospital_HO410();
//		hos_Screen2.HO410_Inquire(Audit_number, Div);
//	}

	@When("^then the user will inquire for audit no \"([^\"]*)\" on Screen \"([^\"]*)\" with div \"([^\"]*)\"$")
	public void then_the_user_will_inquire_for_audit_no_on_Screen_with_div(String Audit_number, String Screen2, String Div) throws Throwable {
		FunctionLibrary.navigateToDiv(Screen2);
		Hospital_HO410 hos_Screen2=new Hospital_HO410();
		hos_Screen2.HO410_Inquire(Audit_number, Div);

	}

	@When("^User Verify Provider-Status \"([^\"]*)\" on screen \"([^\"]*)\"$")
	public void user_Verify_Provider_Status_on_screen(String Prov_Status, String Screen3) throws Throwable {
		String Act_Prov_Status=null;
		Hospital_HO410 hos_Screen2=new Hospital_HO410();
		Act_Prov_Status=hos_Screen2.par_status_val();
		System.out.println("Actual Provider status is " + Act_Prov_Status);
		Assert.assertEquals(Act_Prov_Status, Prov_Status);
		
	}
	

@When("^billType \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
public void billtype_is_present_on_screen(String bill_Type, String Screen3) throws Throwable {
	String Act_bill_type=null;
	Hospital_HO410 hos_Screen2=new Hospital_HO410();
	Act_bill_type=hos_Screen2.bill_type_val();
	System.out.println("Actual bill type is " + Act_bill_type);
}

	

	@Then("^User will inquire for audit no\\. \"([^\"]*)\" on Screen \"([^\"]*)\" with div \"([^\"]*)\"$")
	public void user_will_inquire_for_audit_no_on_Screen_with_div(String Audit_number, String Screen4, String Div) throws Throwable {
		FunctionLibrary.navigateToDiv(Screen4);
		Hospital_HO430 hos_Screen2=new Hospital_HO430();
		hos_Screen2.HO430_Inquire(Audit_number, Div);  
	}

	@Then("^user will verify the Prg flag \"([^\"]*)\" on screen \"([^\"]*)\"$")
	public void user_will_verify_the_Prg_flag_on_screen(String PRG_FLAG, String Screen4) throws Throwable {
		String Act_prgflag=null;
		Hospital_HO430 hos_Screen2=new Hospital_HO430();
		Act_prgflag=hos_Screen2.prc_flg_val();
		System.out.println("Actual prg flag is " + Act_prgflag);
		Assert.assertEquals(Act_prgflag, PRG_FLAG);
	}

	
	
	@When("^User Enquires for the audit No\\.\"([^\"]*)\" on screen \"([^\"]*)\" with div \"([^\"]*)\"$")
	public void user_Enquires_for_the_audit_No_on_screen_with_div(String Audit_number, String Screen2, String Div) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		FunctionLibrary.navigateToDiv(Screen2);
		Hospital_HO409 hos_Screen2=new Hospital_HO409();
		hos_Screen2.HO409_Inquire(Audit_number, Div);
	}
	
	@When("^Contract Amount \"([^\"]*)\" is displayed on the screen \"([^\"]*)\"$")
	public void contract_Amount_is_displayed_on_the_screen(String Contract_Amount, String Screen1) throws Throwable {
		String hos_Contract_Amount=null;
		Hospital_HO410 hos_screen=new Hospital_HO410();
		hos_Contract_Amount=hos_screen.Contract_Amount_val();
		Assert.assertEquals(hos_Contract_Amount, Contract_Amount, "Contract Amount validated");
	}

	@When("^Contract OverrideCD \"([^\"]*)\" is displayed on the screen \"([^\"]*)\"$")
	public void contract_OverrideCD_is_displayed_on_the_screen(String Overirde_CD, String Screen1) throws Throwable {
		String hos_OverrideCD=null;
		Hospital_HO410 hos_screen=new Hospital_HO410();
		hos_OverrideCD=hos_screen.OverrideCD_val();
		Assert.assertEquals(hos_OverrideCD, Overirde_CD);
	}

	@Then("^DRG Amount \"([^\"]*)\" is displayed on the screen \"([^\"]*)\"$")
	public void drg_Amount_is_displayed_on_the_screen(String DRG_AMT, String Screen2) throws Throwable {
		String hos_DRG_AMOUNT=null;
		Hospital_HO430 hos_screen=new Hospital_HO430();
		hos_DRG_AMOUNT=hos_screen.drg_amt_val();
		Assert.assertEquals(hos_DRG_AMOUNT, DRG_AMT);
	}
	
	
	@When("^The Reveiw_User Code \"([^\"]*)\" should not be present on screen \"([^\"]*)\" and verify$")
	public void the_Reveiw_User_Code_should_not_be_present_on_screen_and_verify(String Rev_user_code, String Screen2) throws Throwable {
		Hospital_HO409 hos_screen2 = new Hospital_HO409();
	    String ActUserCode=hos_screen2.GetUser_Code_Two();
		System.out.println("Actual User Code is :"  +ActUserCode);
		Assert.assertNotEquals(ActUserCode,Rev_user_code,"Perfect");

	}

	
	//drg_amt_val()
	
	//Contract_Amount_val()
	
		


}
