///*package stepDefinition;
//
//import org.testng.Assert;
//
//import com.cucumber.listener.Reporter;
//
//import cucumber.api.java.en.*;
//import pages.Physician_CL201;
//import pages.PS475;
//import util.FunctionLibrary;
//import pages.Procedure_PCFM;
//
//public class FeeScheduleStepDefinition {
//	public String act_base_fee, feeMax, schd_value;
//
//	public String Audit_number, Div;
//
//	@When("^the schedule type is \"([^\"]*)\" on screen \"([^\"]*)\"$")
//	public void the_schedule_type_is_on_screen(String exp_schd_type, String screen) throws Throwable {
//		Physician_CL201 phy_val1 = new Physician_CL201();
//		String act_schd_type = phy_val1.schd1_val();
//		if (exp_schd_type.equalsIgnoreCase(act_schd_type)) {
//			Assert.assertEquals(act_schd_type, exp_schd_type);
//			Reporter.addStepLog(" Passed: Scheduled type is fine");
//		} else {
//			Reporter.addStepLog("Failed: Scheduled type is not fine");
//		}
//
//	}
//
//	@Then("^the value of L is value \"([^\"]*)\"$")
//	public void value_of_l(String value) throws Throwable {
//		Physician_CL201 phy_val1 = new Physician_CL201();
//		String act_l_value = phy_val1.l_Val();
//		System.out.println("value of actual l"+act_l_value);
//		if (value.equalsIgnoreCase(act_l_value)) {
//			Assert.assertEquals(act_l_value, value);
//			Reporter.addStepLog(" Passed:Actual value of l is " + act_l_value);
//		} else {
//			Reporter.addStepLog("Failed: value of L is not correct");
//		}
//	}
//
//	@Then("^the user inquires for the audit number \"([^\"]*)\" in division \"([^\"]*)\" fee max in screen \"([^\"]*)\" is \"([^\"]*)\" percent of base fee with fee max factor \"([^\"]*)\"$")
//	public void the_fee_max_in_is_percent_of_base_fee_with_fee_max_factor(String Audit_number, String Div,
//			String screen, String pcnt, String fact) throws Throwable {
//
//		double pc = Double.parseDouble(pcnt);
//		double factor = Double.parseDouble(fact);
//		System.out.println(screen);
//		FunctionLibrary.navigateToDiv(screen);
//
//		if (screen.equals("CL201")) {
//			Physician_CL201 phy_val1 = new Physician_CL201();
//			Thread.sleep(1000);
//			phy_val1.CL201_Inquire(Audit_number, Div);
//			// PS475 ps_val1 = new PS475();
//			// String act_base_fee=ps_val1.base_fee_val();
//			double amt_base_fee = Double.parseDouble(act_base_fee);
//			String act_fee_max = phy_val1.fee_max_val();
//			double amt_fee_max = Double.parseDouble(act_fee_max);
//			double exp_fee_max = amt_base_fee * factor * pc / 100;
//			// System.out.println("Expected fee max is " +exp_fee_max);
//			if (exp_fee_max == amt_fee_max) {
//				Reporter.addStepLog("Actual fee max is " + exp_fee_max);
//				Assert.assertEquals(exp_fee_max, act_fee_max);
//
//			}
//		}
//	}
//
//	/*
//	 * @Then("^the fee max in \"([^\"]*)\" is (\\d+) percent of base fee with fee max factor \"([^\"]*)\"$"
//	 * ) public void the_fee_max_at_of_base_fee(String screen,int pc, int
//	 * factor) throws Throwable { FunctionLibrary.navigateToDiv(screen);
//	 * Physician_CL201 phy_val1 = new Physician_CL201(); PS475 ps_val1 = new
//	 * PS475(); //phy_screen.CL201_Inquire(Audit_number, Div);
//	 * Thread.sleep(1000); String act_base_fee=ps_val1.base_fee_val(); double
//	 * amt_base_fee = Double.parseDouble(act_base_fee); String act_fee_max
//	 * =phy_val1.fee_max_val(); double amt_fee_max =
//	 * Double.parseDouble(act_fee_max); double exp_fee_max =
//	 * amt_base_fee*factor*pc/100; System.out.println("Expected fee max is "
//	 * +exp_fee_max); if(exp_fee_max==amt_fee_max) {
//	 * Reporter.addStepLog("Actual fee max is " +exp_fee_max);
//	 * Assert.assertEquals(exp_fee_max, act_fee_max); } }
//	 * 
//	 */
//
//	@Then("^The user is in division \"([^\"]*)\" and inquires for the schedule type and CPT code \"([^\"]*)\" in the screen \"([^\"]*)\" and fetches base fee$")
//	public void fetching_the_base_fee(String div, String cpt, String screen) throws Throwable {
//		FunctionLibrary.navigateToDiv(screen);
//		PS475 ps_val1 = new PS475();
//		ps_val1.PS475_Inquire(Div, schd_value, cpt, screen);
//		act_base_fee = ps_val1.base_fee_val();
//		System.out.println("Actual base fee is" + act_base_fee);
//
//	}
//
//	
//	@When("^the schedule type is within number range on screen \"([^\"]*)\"$")
//	public void schedule_type_within_number_range(String screen) throws Throwable {
//		Physician_CL201 phy_screen = new Physician_CL201();
//		schd_value = phy_screen.schd1_val();
//		int schd_val = Integer.parseInt(schd_value);
//		org.junit.Assert.assertTrue(schd_val > 0 && schd_val <= 9999);
//
//	}
//	
//	@Then("^valid discount is applied$")
//	public void valid_discount_is_there() throws Throwable {
//		Physician_CL201 phy_screen = new Physician_CL201();
//		String disc=phy_screen.disc1_val();
//		String claim=phy_screen.claimed1_val();
//		String per=phy_screen.pcnt_val();
//		System.out.println(claim+"claim"+per+"per"+disc+"disc");
//		double discount = Double.parseDouble(disc);
//		double claimed = Double.parseDouble(claim);
//		double pc = Double.parseDouble(per);
//		Assert.assertEquals(discount, claimed*(100-pc)/100);
//				
//	}
//	@Then("^the user inquires for the CPT code and From date on screen \"([^\"]*)\"$")
//	public void the_user_inquires_for_the_CPT_code_and_From_date_on_screen(String screen) throws Throwable {
//		Physician_CL201 phy_screen = new Physician_CL201();
//		String from=phy_screen.from_val();
//		String cpt=phy_screen.proc1_val();
//		feeMax=phy_screen.fee_max_val();
//		System.out.println("fee max is"+feeMax);
//		FunctionLibrary.navigateToDiv(screen);
//		
//		if (screen.equals("PCFM")) {
//			Procedure_PCFM phy_screen1 = new Procedure_PCFM();
//			phy_screen1.Procedure_PCFM_Inquire("GET",from,cpt);
//			Thread.sleep(2000);
//			Procedure_PCFM phy_screen2 = new Procedure_PCFM();
//			String standard_fee_max=phy_screen2.std_fee_max_val();
//			System.out.println("standard fee max is string"+standard_fee_max);
//			double fee_201 = Double.parseDouble(feeMax);
//			double fee_pcfm = Double.parseDouble(standard_fee_max);
//			System.out.println("standard fee max is "+fee_pcfm);
//			Assert.assertEquals(fee_201, fee_pcfm);
//			
//		}
//		
//	}
//	
//	@Then("^the standard fee max on screen \"([^\"]*)\" is equal to fee max on screen \"([^\"]*)\"$")
//	public void the_standard_fee_max_on_screen2_is_equal_to_fee_max_on_screen1(String a,String screen2) throws Throwable {
//		Procedure_PCFM phy_screen2 = new Procedure_PCFM();
//		
//		String standard_fee_max=phy_screen2.std_fee_max_val();
//	//	FunctionLibrary.navigateToDiv(screen2);
//		System.out.println("standard fee max is "+standard_fee_max);
//		Assert.assertEquals(feeMax,standard_fee_max);
//		
//	}
//	
//	
//	
//	@When("^the percentage is \"([^\"]*)\" percent$")
//	public void percentage_is_correct(String per) throws Throwable {
//		Physician_CL201 phy_screen = new Physician_CL201();
//		String pc_value=phy_screen.pcnt_val();
//		float act_pc = Float.parseFloat(pc_value);
//		float exp_pc = Float.parseFloat(per);
//		Assert.assertEquals(act_pc, exp_pc);
//		
//	}
//	
//	@Then("^the fee max is greater then zero$")
//	public void fee_max_is_greater_than_zero() throws Throwable {
//		Physician_CL201 phy_screen = new Physician_CL201();
//		String feeMax=phy_screen.fee_max_val();
//		float fee = Float.parseFloat(feeMax);
//		Assert.assertTrue(fee>0);
//	}
//	
//	@Then("^the fee max is \"([^\"]*)\"$")
//	public void fee_max_is_null(String fee) throws Throwable {
//		if (fee.equals("")){
//			fee=null;
//		}		
//		Physician_CL201 phy_screen = new Physician_CL201();
//		String feeMax=phy_screen.fee_max_val();
//		System.out.println("actual fee max is"+feeMax);
//		Assert.assertEquals(feeMax, fee);
//	}
//	
//	
//	@Then("^the claimed value is equal to disallow value$")
//	public void claimed_equals_disallow() throws Throwable {
//		Physician_CL201 phy_screen = new Physician_CL201();
//		String act_claimed=phy_screen.claimed1_val();
//		String act_disallow=phy_screen.disallow1_val();
//		Assert.assertEquals(act_claimed, act_disallow);		
//	}
//	@Then("^value is printed$")
//	public void hello() throws Throwable {
//		Procedure_PCFM phy_screen2 = new Procedure_PCFM();		
//		String standard_fee_max=phy_screen2.std_fee_max_val();
//	//	FunctionLibrary.navigateToDiv(screen2);
//		System.out.println("standard fee max is "+standard_fee_max);
//		
//	}
//	
//	@When("^the unit is greater than zero$")
//	public void the_unit_is_greater_than_zero() throws Throwable {
//		Physician_CL201 phy_screen = new Physician_CL201();
//		String unit1=phy_screen.unit_Val();
//		int unit2 = Integer.parseInt(unit1);
//		Assert.assertTrue(unit2>0);
//		
//	}}
////			DB2{
////				SINGLEOUTPUT_DB2VALIDATION_DIVINPUTFOURKEYVALUE(STRING FIELD,STRING REGION,STRING  TABLENAME,STRING KEYFIELD,STRING KEYVALUE,STRING KEYFIELD1,STRING KEYVALUE1,STRING KEYFIELD2,STRING KEYFIELD3,STRING KEYVALUE2,STRING KEYVALUE3)
////			}
////	
//	
//
//
//// @Then("^the claim is paid at (\\d+)% of billed charges in screen
//// \"([^\"]*)\"$")
//// public void the_claim_is_paid_at_of_billed_charges_in_screen(int pc, String
//// screen) throws Throwable {
//// if(screen.equals("CL201"))
////
//// FunctionLibrary.navigateToDiv(screen);
//// Physician_CL201 phy_screen = new Physician_CL201();
//// phy_screen.CL201_Inquire(Audit_number, Div);
//// Thread.sleep(1000);
////
//// String act_allowed =phy_screen.allowed1_val();
//// double amt_allowed = Double.parseDouble(act_allowed);
//// double exp_allowed = amt_claimed*pc/100;
//// System.out.println("Expected allowed amount is " +exp_allowed);
//// String act_allowed = phy_screen.tot_allowed_val();
//// double amt_allowed = Double.parseDouble(act_allowed);
//// if(exp_allowed==amt_allowed)
//// {
//// Reporter.addStepLog("Actual allowed amount is " +exp_allowed);
//// Assert.assertEquals(exp_allowed, amt_allowed);
//// }
//// }
//// }
//// }
////
//*/