package stepDefinition;

import java.io.IOException;
import java.lang.reflect.Modifier;
import java.text.DecimalFormat;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import javax.swing.plaf.ActionMapUIResource;

import org.apache.tools.ant.taskdefs.Length;
import org.testng.Assert;

import com.cucumber.listener.Reporter;
import com.hp.lft.sdk.GeneralLeanFtException;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Hospital_HO400;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL510;
import util.FunctionLibrary;

public class AssistantSurgeon {

	public AssistantSurgeon() throws IOException, GeneralLeanFtException {
		String generalFee=null;
		Physician_CL201 phy_screen1 = new Physician_CL201();
		generalFee=phy_screen1.feemax_val_1();
	}
	@When("^audit \"([^\"]*)\" is created with single detail line \"([^\"]*)\" within range of modifer \"([^\"]*)\" in Screen \"([^\"]*)\" in division \"([^\"]*)\"$")
	public void audit_is_created_with_single_detail_line_within_range_of_modifer_in_Screen_in_division(String audit_no, String cpt, String mod, String Screen1, String div) throws Throwable {
		FunctionLibrary.navigateToDiv(Screen1);
		boolean flag=false;
		boolean his_audit_present=false;
		String act_CPT = null;
		String act_mod1=null;
		int i=0;int j=0;
		if(Screen1.equals("CL201"))
		{	
			Physician_CL201 phy_screen1 = new Physician_CL201();
			phy_screen1.CL201_Inquire(audit_no,div);
			his_audit_present = phy_screen1.msg_val();
			Assert.assertEquals(his_audit_present,true);


			if(cpt.contains(",")){
				String codes[]=cpt.split(",");	
				if(phy_screen1.proc_code1.getText().contains(codes[0])||phy_screen1.proc_code1.getText().contains(codes[1]))
				{

					act_CPT =phy_screen1.proc1_val();
					act_mod1 =phy_screen1.proc1_mod1_val();

				}
				else if(phy_screen1.proc_code2.getText().contains(codes[0])||phy_screen1.proc_code2.getText().contains(codes[1]))
				{
					act_CPT =phy_screen1.proc2_val();
					act_mod1 =phy_screen1.proc1_mod1_val();
				}	


				for (j = 0; j < codes.length; j++) {
					if(codes[j].equals(act_CPT)){
						System.out.println("CPT code verified from the given range");
						flag=true;
						break;
					}
				}

				if(j==codes.length){
					System.out.println("CPT code not found within range");
					flag=false;
				}

				Assert.assertTrue(flag);
			}


			else{


				if(phy_screen1.proc_code1.getText().contains(cpt))
				{

					act_CPT =phy_screen1.proc1_val();
					act_mod1 =phy_screen1.proc1_mod1_val();

				}
				else if(phy_screen1.proc_code2.getText().contains(cpt))
				{
					act_CPT =phy_screen1.proc2_val();
					act_mod1 =phy_screen1.proc1_mod1_val();
				}	

				Assert.assertEquals(act_CPT,cpt);
				System.out.println("CPT code verified:");
			}


			String modifier[]=mod.split(",");
			for (i = 0; i < modifier.length; i++) {
				if(modifier[i].equals(act_mod1)){
					System.out.println("Procedure code billed with correct modifier-" +modifier[i]);
					flag=true;
					break;
				}
			}
			if(i==modifier.length){
				System.out.println("No assistant surgeon modifier is present");
				flag=false;
			}
			Assert.assertTrue(flag);
			Reporter.addStepLog("Actual cpt is " +act_CPT);
			Reporter.addStepLog("Actual modifier is " +act_mod1);
		}

		else if(Screen1.equals("HO400"))
		{
			Hospital_HO400 hos_screen1 = new Hospital_HO400();
			if(hos_screen1.cpt1.getText().contains(cpt))
			{
				act_CPT =hos_screen1.cpt1_val();
			}
			else if(hos_screen1.cpt2.getText().contains(cpt))
			{
				act_CPT =hos_screen1.cpt2_val();
			}
			else if(hos_screen1.cpt3.getText().contains(cpt))
			{
				act_CPT =hos_screen1.cpt3_val();
			}
			else if(hos_screen1.cpt4.getText().contains(cpt))
			{
				act_CPT =hos_screen1.cpt4_val();
			}

			Assert.assertEquals(act_CPT,cpt);
			Reporter.addStepLog("CPT code is " +act_CPT); 
		}

	}


	@Then("^the subaudit \"([^\"]*)\" is created with single detail line \"([^\"]*)\" with assistant surgeon modifier \"([^\"]*)\" and modifier \"([^\"]*)\" in screen \"([^\"]*)\" in division \"([^\"]*)\"$")
	public void the_subaudit_is_created_with_single_detail_line_with_assistant_surgeon_modifier_and_modifier_in_screen_in_division(String sub_aud, String cpt, String mod1,String mod2, String Screen1,String Div) throws Throwable {
		FunctionLibrary.navigateToDiv(Screen1);
		boolean his_audit_present=false;
		boolean flag=false;
		String act_CPT = null;
		String act_mod1=null;
		String act_mod2=null;

		String assSurgMod[]=mod1.split(",");

		if(Screen1.equals("CL201"))
		{	
			Physician_CL201 phy_screen1 = new Physician_CL201();
			phy_screen1.CL201_Inquire(sub_aud,Div);
			his_audit_present = phy_screen1.msg_val();
			Assert.assertEquals(his_audit_present,true);
			if(phy_screen1.proc_code1.getText().contains(cpt))
			{

				act_CPT =phy_screen1.proc1_val();
				act_mod1 =phy_screen1.proc1_mod1_val();
				act_mod2 =phy_screen1.proc1_mod2_val();


			}
			else if(phy_screen1.proc_code2.getText().contains(cpt))
			{
				act_CPT =phy_screen1.proc2_val();
				act_mod1 =phy_screen1.proc1_mod1_val();
				act_mod2 =phy_screen1.proc1_mod2_val();
			}	
			Assert.assertEquals(act_CPT, cpt);

			if(act_mod1.equals(assSurgMod[0])||act_mod1.endsWith(assSurgMod[1])){
				System.out.println("Assistant surgeon code verified");	
				flag=true;
			}
			Assert.assertTrue(flag);
			Assert.assertEquals(act_mod2,mod2);
			System.out.println("CC modifer verified");
			Reporter.addStepLog("Actual cpt is " +act_CPT);
			Reporter.addStepLog("Actual modifier is " +act_mod1);
		}

		else if(Screen1.equals("HO400"))
		{
			Hospital_HO400 hos_screen1 = new Hospital_HO400();
			if(hos_screen1.cpt1.getText().contains(cpt))
			{
				act_CPT =hos_screen1.cpt1_val();
			}
			else if(hos_screen1.cpt2.getText().contains(cpt))
			{
				act_CPT =hos_screen1.cpt2_val();
			}
			else if(hos_screen1.cpt3.getText().contains(cpt))
			{
				act_CPT =hos_screen1.cpt3_val();
			}
			else if(hos_screen1.cpt4.getText().contains(cpt))
			{
				act_CPT =hos_screen1.cpt4_val();
			}

		}

		Assert.assertEquals(act_CPT,cpt);
		Reporter.addStepLog("CPT code is " +act_CPT);

	}



	/*
	@When("^get the outfield \"([^\"]*)\" in dbtable \"([^\"]*)\" for region \"([^\"]*)\" based on input field \"([^\"]*)\" value as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\"$")
	public void get_the_outfield_in_dbtable_for_region_based_on_input_field_value_as_and_input_field_as_and_input_field_as(String Field, String Tablename, String Region, String keyfield, String keyvalue, String keyfield1, String keyvalue1,String keyfield2, String keyvalue2) throws Throwable {
		String fee=null;
		Double Actualfee=0.0;
		boolean flag=false;
		double roundOff=0.0;

		Physician_CL201 ph=new Physician_CL201();

		try
		{

			fee = FunctionLibrary.SingleOutput_DB2Validation_DivInputThreeKeyValues(Field, Region, Tablename, keyfield1, keyvalue1, keyfield, keyvalue,keyfield2,keyvalue2);
			Actualfee=   Double.valueOf(fee);


			//calculating fee max  

			double feemax=0.0;
			double feemaxFactor=18.79;
			double feePercent=0.16;
			int mod_fac2=1;
			int unit=1;
			int FS_Percent=100/100;

			feemax=(Actualfee*feePercent*mod_fac2)*FS_Percent*feemaxFactor*unit;

			System.out.println("feemax is "+feemax);

			roundOff = Math.round(feemax * 100.0) / 100.0;
			System.out.println("Rounded off feemax is "+roundOff);
			roundOff= roundOff+.01;
			System.out.println("Corrected feemax is "+roundOff);

			fee= String.valueOf(roundOff);

			String feemaxOnScreen=ph.feemax_val_1();
			System.out.println(feemaxOnScreen);

			if(feemaxOnScreen.equals(fee)){
				System.out.println("Feemax verified successfully");
				flag=true;
			}
			else{
				System.out.println("Feemax not verified");
				flag=false;
			}

			Assert.assertTrue(flag);
			Reporter.addStepLog("feemax value is correct and verified" +feemaxOnScreen);
		}
		finally
		{
			Assert.assertTrue(true);


		}
	}



	 */

	@When("^get the outfield \"([^\"]*)\" in dbtable \"([^\"]*)\" for region \"([^\"]*)\" based on input field \"([^\"]*)\" value as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\" AND calculate feemax on modifier \"([^\"]*)\"$")
	public void get_the_outfield_in_dbtable_for_region_based_on_input_field_value_as_and_input_field_as_and_input_field_as_AND_calculate_feemax_on_modifier(String Field, String Tablename, String Region, String keyfield, String keyvalue, String keyfield1, String keyvalue1,String keyfield2, String keyvalue2, String Modifier) throws Throwable {
		String fee=null;
		Double Actualfee=0.0;
		Physician_CL201 ph=new Physician_CL201();

		try
		{

			fee = FunctionLibrary.SingleOutput_DB2Validation_DivInputThreeKeyValues(Field, Region, Tablename, keyfield1, keyvalue1, keyfield, keyvalue,keyfield2,keyvalue2);
			Actualfee=   Double.valueOf(fee);

			System.out.println("Actual fee from query is "+Actualfee);
			//calculating fee max  

			double feemax=0.0;
			double feemaxFactor=18.79;
			double feePercent=0.16;
			double feePercentAS=0.14;
			int mod_fac2=1;
			int unit=1;
			int FS_Percent=100/100;


			if (Modifier.equals("AS")){
				feemax=(Actualfee*feePercentAS*mod_fac2)*FS_Percent*feemaxFactor*unit;	
			}
			else{
				feemax=(Actualfee*feePercent*mod_fac2)*FS_Percent*feemaxFactor*unit;
			}

			System.out.println("feemax is "+feemax);

			fee=Double.toString(feemax);
			System.out.println(fee);
			String ele[]=fee.split("\\.");
			String sub=	ele[1].substring(0, 1);
			String newFee=ele[0]+"."+sub;
			System.out.println(newFee);
			String feemaxOnScreen=ph.feemax_val_1();
			String arr[]=feemaxOnScreen.split("\\.");
			String subs=arr[1].substring(0, 1);
			String newFeemaxOnScreen=arr[0]+"."+subs;

			System.out.println(feemaxOnScreen);
			Assert.assertEquals(newFeemaxOnScreen, newFee);
			System.out.println("Fee verified");
			Reporter.addStepLog("feemax value is correct and verified" +feemaxOnScreen);
		}
		finally
		{
			Assert.assertTrue(true);


		}
	}

	@When("^The calculated feemax is present for CPT \"([^\"]*)\" with appropriate modifier for detail line \"([^\"]*)\" in screen \"([^\"]*)\" in division \"([^\"]*)\" and inquires for the audit number \"([^\"]*)\"$")
	public void the_calculated_feemax_is_present_for_CPT_with_appropriate_modifier_for_detail_line_in_screen_in_division_and_inquires_for_the_audit_number(List<String> cpt1,String detail_line_No, String screen, String Div, String Audit_number) throws Throwable {
		String act_CPT=null;
		double feemax=0.0;
		double Actualfee=0.0;
		String feemaxOnScreen=null;
		String assistantFee=null;
		String fee=null;


		boolean cpt_match = false;
		if(screen.equals("CL201"))
		{	
			Physician_CL201 phy_screen1 = new Physician_CL201();

			feemaxOnScreen=phy_screen1.feemax_val_1();
			Actualfee= Double.valueOf(feemaxOnScreen);
			System.out.println("Actual fee on screen is in double"+Actualfee);


			if(detail_line_No.equals("1")){
				for(String each_cpt : cpt1)
				{

					if(phy_screen1.newProc_code1.getText().equals(each_cpt))

					{

						act_CPT =phy_screen1.new_proc1_val();
						if(act_CPT.endsWith("80")){

							feemax=(Actualfee*16)/100;
							fee=Double.toString(feemax);
							System.out.println(fee);
							String ele[]=fee.split("\\.");
							String sub=	ele[1].substring(0, 1);
							String newFee=ele[0]+"."+sub;
							System.out.println(newFee);
							
							feemaxOnScreen= phy_screen1.feemax_val_1();
							String arr[]=feemaxOnScreen.split("\\.");
							String subs=arr[1].substring(0, 1);
							String newFeemaxOnScreen=arr[0]+"."+subs;
							
							Assert.assertEquals(newFee, newFeemaxOnScreen);
							System.out.println("Feemax verified for" +act_CPT);
						}
						else if(act_CPT.endsWith("81")){
							feemax=(Actualfee*16)/100;
							fee=Double.toString(feemax);
							System.out.println(fee);
							String ele[]=fee.split("\\.");
							String sub=	ele[1].substring(0, 1);
							String newFee=ele[0]+"."+sub;
							System.out.println(newFee);
							
							feemaxOnScreen= phy_screen1.feemax_val_1();
							String arr[]=feemaxOnScreen.split("\\.");
							String subs=arr[1].substring(0, 1);
							String newFeemaxOnScreen=arr[0]+"."+subs;
							
							Assert.assertEquals(newFee, newFeemaxOnScreen);
							System.out.println("Feemax verified for" +act_CPT);
						}
						else if(act_CPT.endsWith("82")){
							feemax=(Actualfee*16)/100;
							fee=Double.toString(feemax);
							System.out.println(fee);
							String ele[]=fee.split("\\.");
							String sub=	ele[1].substring(0, 1);
							String newFee=ele[0]+"."+sub;
							System.out.println(newFee);
							
							feemaxOnScreen= phy_screen1.feemax_val_1();
							String arr[]=feemaxOnScreen.split("\\.");
							String subs=arr[1].substring(0, 1);
							String newFeemaxOnScreen=arr[0]+"."+subs;
							
							Assert.assertEquals(newFee, newFeemaxOnScreen);
							System.out.println("Feemax verified for" +act_CPT);
						}
						else if(act_CPT.endsWith("AS")){
							feemax=(Actualfee*14)/100;
							fee=Double.toString(feemax);
							System.out.println(fee);
							String ele[]=fee.split("\\.");
							String sub=	ele[1].substring(0, 1);
							String newFee=ele[0]+"."+sub;
							System.out.println(newFee);
							
							feemaxOnScreen= phy_screen1.feemax_val_1();
							String arr[]=feemaxOnScreen.split("\\.");
							String subs=arr[1].substring(0, 1);
							String newFeemaxOnScreen=arr[0]+"."+subs;
							
							Assert.assertEquals(newFee, newFeemaxOnScreen);
							System.out.println("Feemax verified for" +act_CPT);
						}
						else{
							System.out.println("No modifier is present,hence no assistance surgeon fee calculation required");
						}



						Assert.assertEquals(act_CPT, each_cpt);
						System.out.println("actual cpt is "+act_CPT);
						cpt_match = true;
					}	
				}
			}


			else if(detail_line_No.equals("2")){
				for(String each_cpt : cpt1)
				{
					if(phy_screen1.newProc_code2.getText().equals(each_cpt))

					{
						act_CPT =phy_screen1.new_proc2_val();

						if(act_CPT.endsWith("80")){

							feemax=(Actualfee*16)/100;
							fee=Double.toString(feemax);
							System.out.println(fee);
							String ele[]=fee.split("\\.");
							String sub=	ele[1].substring(0, 1);
							String newFee=ele[0]+"."+sub;
							System.out.println(newFee);
							
							feemaxOnScreen= phy_screen1.feemax_val_2();
							String arr[]=feemaxOnScreen.split("\\.");
							String subs=arr[1].substring(0, 1);
							String newFeemaxOnScreen=arr[0]+"."+subs;
							
							Assert.assertEquals(newFee, newFeemaxOnScreen);
							System.out.println("Feemax verified for" +act_CPT);
						}
						else if(act_CPT.endsWith("81")){
							feemax=(Actualfee*16)/100;
							fee=Double.toString(feemax);
							System.out.println(fee);
							String ele[]=fee.split("\\.");
							String sub=	ele[1].substring(0, 1);
							String newFee=ele[0]+"."+sub;
							System.out.println(newFee);
							
							feemaxOnScreen= phy_screen1.feemax_val_2();
							String arr[]=feemaxOnScreen.split("\\.");
							String subs=arr[1].substring(0, 1);
							String newFeemaxOnScreen=arr[0]+"."+subs;
							
							Assert.assertEquals(newFee, newFeemaxOnScreen);
							System.out.println("Feemax verified for" +act_CPT);
						}
						else if(act_CPT.endsWith("82")){
							feemax=(Actualfee*16)/100;
							fee=Double.toString(feemax);
							System.out.println(fee);
							String ele[]=fee.split("\\.");
							String sub=	ele[1].substring(0, 1);
							String newFee=ele[0]+"."+sub;
							System.out.println(newFee);
							
							feemaxOnScreen= phy_screen1.feemax_val_2();
							String arr[]=feemaxOnScreen.split("\\.");
							String subs=arr[1].substring(0, 1);
							String newFeemaxOnScreen=arr[0]+"."+subs;
							
							Assert.assertEquals(newFee, newFeemaxOnScreen);
							System.out.println("Feemax verified for" +act_CPT);
						}
						else if(act_CPT.endsWith("AS")){
							feemax=(Actualfee*14)/100;
							fee=Double.toString(feemax);
							System.out.println(fee);
							String ele[]=fee.split("\\.");
							String sub=	ele[1].substring(0, 1);
							String newFee=ele[0]+"."+sub;
							System.out.println(newFee);
							
							feemaxOnScreen= phy_screen1.feemax_val_2();
							String arr[]=feemaxOnScreen.split("\\.");
							String subs=arr[1].substring(0, 1);
							String newFeemaxOnScreen=arr[0]+"."+subs;
							
							Assert.assertEquals(newFee, newFeemaxOnScreen);
							System.out.println("Feemax verified for" +act_CPT);
						}
						else{
							System.out.println("No modifier is present,hence no assistance surgeon fee calculation required");
						}

						Assert.assertEquals(act_CPT, each_cpt);
						System.out.println("actual cpt is "+act_CPT);
						cpt_match = true;
					}	
				}	
			}
			else if(detail_line_No.equals("3")){
				phy_screen1.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
				Thread.sleep(1000);
				for(String each_cpt : cpt1)
				{
					if(phy_screen1.newProc_code1.getText().equals(each_cpt))

					{

						act_CPT =phy_screen1.new_proc1_val();
						if(act_CPT.endsWith("80")){

							feemax=(Actualfee*16)/100;
							fee=Double.toString(feemax);
							System.out.println(fee);
							String ele[]=fee.split("\\.");
							String sub=	ele[1].substring(0, 1);
							String newFee=ele[0]+"."+sub;
							System.out.println(newFee);
							
							feemaxOnScreen= phy_screen1.feemax_val_1();
							String arr[]=feemaxOnScreen.split("\\.");
							String subs=arr[1].substring(0, 1);
							String newFeemaxOnScreen=arr[0]+"."+subs;
							
							Assert.assertEquals(newFee, newFeemaxOnScreen);
							System.out.println("Feemax verified for" +act_CPT);
						}
						else if(act_CPT.endsWith("81")){
							feemax=(Actualfee*16)/100;
							fee=Double.toString(feemax);
							System.out.println(fee);
							String ele[]=fee.split("\\.");
							String sub=	ele[1].substring(0, 1);
							String newFee=ele[0]+"."+sub;
							System.out.println(newFee);
							
							feemaxOnScreen= phy_screen1.feemax_val_1();
							String arr[]=feemaxOnScreen.split("\\.");
							String subs=arr[1].substring(0, 1);
							String newFeemaxOnScreen=arr[0]+"."+subs;
							
							Assert.assertEquals(newFee, newFeemaxOnScreen);
							System.out.println("Feemax verified for" +act_CPT);
						}
						else if(act_CPT.endsWith("82")){
							feemax=(Actualfee*16)/100;
							fee=Double.toString(feemax);
							System.out.println(fee);
							String ele[]=fee.split("\\.");
							String sub=	ele[1].substring(0, 1);
							String newFee=ele[0]+"."+sub;
							System.out.println(newFee);
							
							feemaxOnScreen= phy_screen1.feemax_val_1();
							String arr[]=feemaxOnScreen.split("\\.");
							String subs=arr[1].substring(0, 1);
							String newFeemaxOnScreen=arr[0]+"."+subs;
							
							Assert.assertEquals(newFee, newFeemaxOnScreen);
							System.out.println("Feemax verified for" +act_CPT);
						}
						else if(act_CPT.endsWith("AS")){
							feemax=(Actualfee*14)/100;
							fee=Double.toString(feemax);
							System.out.println(fee);
							String ele[]=fee.split("\\.");
							String sub=	ele[1].substring(0, 1);
							String newFee=ele[0]+"."+sub;
							System.out.println(newFee);
							
							feemaxOnScreen= phy_screen1.feemax_val_1();
							String arr[]=feemaxOnScreen.split("\\.");
							String subs=arr[1].substring(0, 1);
							String newFeemaxOnScreen=arr[0]+"."+subs;
							
							Assert.assertEquals(newFee, newFeemaxOnScreen);
							System.out.println("Feemax verified for" +act_CPT);
						}
						else{
							System.out.println("No modifier is present,hence no assistance surgeon fee calculation required");
						}

						Assert.assertEquals(act_CPT, each_cpt);
						System.out.println("actual cpt is "+act_CPT);
						cpt_match = true;
					}	
				}	
			}
			else if(detail_line_No.equals("4")){
				phy_screen1.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
				Thread.sleep(1000);		
				feemaxOnScreen=phy_screen1.feemax_val_1();
				Actualfee= Double.valueOf(feemaxOnScreen);
				System.out.println("Actual fee on screen is in double"+Actualfee);
				phy_screen1.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
				Thread.sleep(1000);	
				for(String each_cpt : cpt1)
				{
					if(phy_screen1.newProc_code2.getText().equals(each_cpt))

					{

						act_CPT =phy_screen1.new_proc2_val();
						if(act_CPT.endsWith("80")){

							feemax=(Actualfee*16)/100;
							fee=Double.toString(feemax);
							System.out.println(fee);
							String ele[]=fee.split("\\.");
							String sub=	ele[1].substring(0, 1);
							String newFee=ele[0]+"."+sub;
							System.out.println(newFee);
							
							feemaxOnScreen= phy_screen1.feemax_val_2();
							String arr[]=feemaxOnScreen.split("\\.");
							String subs=arr[1].substring(0, 1);
							String newFeemaxOnScreen=arr[0]+"."+subs;
							
							Assert.assertEquals(newFee, newFeemaxOnScreen);
							System.out.println("Feemax verified for" +act_CPT);
						}
						else if(act_CPT.endsWith("81")){
							feemax=(Actualfee*16)/100;
							fee=Double.toString(feemax);
							System.out.println(fee);
							String ele[]=fee.split("\\.");
							String sub=	ele[1].substring(0, 1);
							String newFee=ele[0]+"."+sub;
							System.out.println(newFee);
							
							feemaxOnScreen= phy_screen1.feemax_val_2();
							String arr[]=feemaxOnScreen.split("\\.");
							String subs=arr[1].substring(0, 1);
							String newFeemaxOnScreen=arr[0]+"."+subs;
							
							Assert.assertEquals(newFee, newFeemaxOnScreen);
							System.out.println("Feemax verified for" +act_CPT);
						}
						else if(act_CPT.endsWith("82")){
							feemax=(Actualfee*16)/100;
							fee=Double.toString(feemax);
							System.out.println(fee);
							String ele[]=fee.split("\\.");
							String sub=	ele[1].substring(0, 1);
							String newFee=ele[0]+"."+sub;
							System.out.println(newFee);
							
							feemaxOnScreen= phy_screen1.feemax_val_2();
							String arr[]=feemaxOnScreen.split("\\.");
							String subs=arr[1].substring(0, 1);
							String newFeemaxOnScreen=arr[0]+"."+subs;
							
							Assert.assertEquals(newFee, newFeemaxOnScreen);
							System.out.println("Feemax verified for" +act_CPT);
						}
						else if(act_CPT.endsWith("AS")){
							feemax=(Actualfee*14)/100;
							fee=Double.toString(feemax);
							System.out.println(fee);
							String ele[]=fee.split("\\.");
							String sub=	ele[1].substring(0, 1);
							String newFee=ele[0]+"."+sub;
							System.out.println(newFee);
							
							feemaxOnScreen= phy_screen1.feemax_val_2();
							String arr[]=feemaxOnScreen.split("\\.");
							String subs=arr[1].substring(0, 1);
							String newFeemaxOnScreen=arr[0]+"."+subs;
							
							Assert.assertEquals(newFee, newFeemaxOnScreen);
							System.out.println("Feemax verified for" +act_CPT);
						}
						else{
							System.out.println("No modifier is present,hence no assistance surgeon fee calculation required");
						}
						Assert.assertEquals(act_CPT, each_cpt);
						System.out.println("actual cpt is "+act_CPT);
						cpt_match = true;
					}	
				}	
			}

		}
		Reporter.addStepLog("value of CPT codes has been verified with correct feemax on associate modifier");
	}



	@Given("^The calculated feemax is present for the CPT \"([^\"]*)\" with appropriate modifier \"([^\"]*)\"  in screen \"([^\"]*)\" in division \"([^\"]*)\" and inquires for the audit number \"([^\"]*)\"$")
	public void the_calculated_feemax_is_present_for_the_CPT_with_appropriate_modifier_in_screen_in_division_and_inquires_for_the_audit_number(String cpt, String mod, String Screen, String Div, String AuditNo) throws Throwable {

		String date=null;
		String percent=null;
		String zipcode=null;
		String actual_Fee=null;
		String feemaxOnScreen=null;
		String fees=null;
		double fee=0.0;
		double feemax=0.0;
		Physician_CL201 phy_screen1 = new Physician_CL201();
		Physician_CL202 phy_screen2=new Physician_CL202();
		Physician_CL510 phy_510=new Physician_CL510();


		feemaxOnScreen=phy_screen1.feemax_val_1();


		String Actprovider_type=phy_screen1.prov_type_val_new();
		System.out.println("Act provider is "+Actprovider_type);

		date=phy_screen1.fromdate_val();
		System.out.println("from date is "+date);

		percent=phy_screen1.percent_val();
		percent=percent.substring(0, 2);
		System.out.println("percent is: "+percent);

		FunctionLibrary.navigateToDiv("CL202");	
		phy_screen2.CL202_Inquire(AuditNo,Div);

		zipcode=	phy_screen2.zip_Code();
		zipcode=zipcode.substring(0,3);
		System.out.println("zipcode is: "+zipcode);

		FunctionLibrary.navigateToDiv("CL510");


		phy_510.enter_zipcode(zipcode);
		Thread.sleep(1000);
		System.out.println("Zipcode entered");

		phy_510.enter_proc_code(cpt);
		Thread.sleep(1000);

		phy_510.enter_prov_type(Actprovider_type);
		Thread.sleep(1000);

		phy_510.enter_modifier(mod);
		Thread.sleep(1000);

		phy_510.enter_percentage(percent);
		Thread.sleep(1000);

		phy_510.enter_date(date);
		Thread.sleep(1000);

		actual_Fee=phy_510.actual_fee_val();
		System.out.println(actual_Fee);
		fee=Double.valueOf(actual_Fee);

		if(mod.equals("62")){
			feemax=(fee*63)/100;
			System.out.println(feemax);
			fees=Double.toString(feemax);
			System.out.println(fees);
			String ele[]=fees.split("\\.");
			String sub=	ele[1].substring(0, 1);
			String newFee=ele[0]+"."+sub;
			System.out.println(newFee);
			
		
			String arr[]=feemaxOnScreen.split("\\.");
			String subs=arr[1].substring(0, 1);
			String newFeemaxOnScreen=arr[0]+"."+subs;

			Assert.assertEquals(newFeemaxOnScreen, newFee);
			System.out.println("Fee max verified for the modifier: "+mod);

		}

	}






}