package stepDefinition;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.AuthNotification_TB309;
import pages.Hospital_HO400;
import pages.Hospital_HO409;
import pages.PS303;
import pages.PS330;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL209;
import pages.Physician_PS340;
import util.FunctionLibrary;

public class GlobalAutoMatchStepDefinition {


@Then("^review user code \"([^\"]*)\" is displayed in the screen \"([^\"]*)\"$")
public void review_user_code_is_displayed_in_the_screen(String rev_user, String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String rev_code=null;
	// FunctionLibrary.navigateToDiv(screen);
	// if(screen.equals("CL201")){
	Physician_CL201 phy_rev= new Physician_CL201();
	Thread.sleep(1000);
	if(screen.equals("CL201")){
	 rev_code=phy_rev.reviewUserCode();
	}
	else if(screen.equals("HO400")){
		Hospital_HO400 hos=new Hospital_HO400();
		rev_code=hos.get_rev_code();
	}
	 System.out.println("The review user code is:"+rev_code);
	 Assert.assertEquals(rev_user,rev_code);
}


@Then("^the user inquires a contract number \"([^\"]*)\" in the screen \"([^\"]*)\"$")
public void the_user_inquires_a_contract_number_in_the_screen(String exp_contract, String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String contract=null;
	 FunctionLibrary.navigateToDiv(screen);
	 Thread.sleep(1000);
	 if(screen.equals("PS340")){
		 Thread.sleep(1000);
	Physician_PS340 phy_contract= new Physician_PS340();
	phy_contract.PS340_Inquire(exp_contract, screen);
	
}
}
@Given("^the required provider number prov \"([^\"]*)\" and prov \"([^\"]*)\" is inquired in the screen  \"([^\"]*)\"$")
public void the_required_provider_number_prov_and_prov_is_inquired_in_the_screen(String prov_num1,String prov_num2, String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	Thread.sleep(1000);
	FunctionLibrary.navigateToDiv(screen);
	 if (screen.equals("PS303")){
		 PS303 ps=new PS303();
	ps.provider_inq(prov_num1, prov_num2, screen);

	}
	}



@Then("^the required caregroup \"([^\"]*)\" is displayed in screen \"([^\"]*)\"$")
public void the_required_caregroup_is_displayed_in_screen(String caregroup,String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String care_group,new_care=null;
	PS303 phy_303= new PS303();
	new_care=phy_303.caregrp_val();
	
	 System.out.println("The care group is:"+new_care);
	Assert.assertEquals(new_care, caregroup);
	 
}

@Then("^the payment type \"([^\"]*)\" is displayed in screen \"([^\"]*)\"$")
public void the_payment_type_is_displayed_in_screen(String pay_type, String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String payment_type=null;
	 //FunctionLibrary.navigateToDiv(screen);
	 Thread.sleep(1000);
	 if(screen.equals("PS340")){
	Physician_PS340 phy_pay= new Physician_PS340();
	payment_type=phy_pay.payment_val();
	Thread.sleep(1000);
	 System.out.println("The payment type is:"+payment_type);
}
}
/*@Given("^the user gets pcp from Screen \"([^\"]*)\"$")
public void the_user_gets_pcp_from_Screen(String Screen) throws Throwable {
	String pcp=null;
	if(Screen.equals("CL202")){
	Physician_CL202 phy_val1 = new Physician_CL202();
    pcp= phy_val1.get_pcp();
   System.out.println("The PCP number is:"+pcp);
	}
}*/

@When("^the user inquires logic code \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_user_inquires_logic_code_in_screen(String exp_logic, String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String logic=null;
	 FunctionLibrary.navigateToDiv(screen);
	 if(screen.equals("TB309")){
		 Thread.sleep(1000);
    AuthNotification_TB309 phy_logic = new AuthNotification_TB309();
    phy_logic.TB309_Inquire(exp_logic, screen);
    
}
}
@When("^the ancillary option \"([^\"]*)\" is displayed in screen \"([^\"]*)\"$")
public void the_ancillary_option_is_displayed_in_screen(String exp_ancillary, String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String ancillary=null;
	// FunctionLibrary.navigateToDiv(screen);
	 Thread.sleep(1000);
	 if(screen.equals("TB309")){
		 Thread.sleep(1000);
   AuthNotification_TB309 phy_logic = new AuthNotification_TB309();
    ancillary=phy_logic.ancillary_val();
    Thread.sleep(1000);
    System.out.println("The ancillary option is:"+ancillary);
}
}
@When("^the self referral \"([^\"]*)\" is checked in screen \"([^\"]*)\"$")
public void the_self_referral_is_checked_in_screen(String exp_self, String screen) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String self_refer=null;
	// FunctionLibrary.navigateToDiv(screen);
	 if(screen.equals("TB309")){
		 Thread.sleep(1000);
    AuthNotification_TB309 phy_logic = new AuthNotification_TB309();
    self_refer=phy_logic.self_referral();
    Thread.sleep(1000);
    System.out.println("The self referral is:"+self_refer);
}
}
@Then("^the claim \"([^\"]*)\" in \"([^\"]*)\" is hit with review \"([^\"]*)\" in screen \"([^\"]*)\" and is processed by RTS \"([^\"]*)\"$")
public void the_claim_in_is_hit_with_review_in_screen_and_is_processed_by_RTS(String Audit_number, String Div, String Review, String screen, String Rev_user_code) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	List act_review=null;
    List act_review_hos=null;
	FunctionLibrary.navigateToDiv(screen);
	Thread.sleep(1000);
      if(screen.equals("CL209"))
	{	
		
		Physician_CL209 phy_val = new Physician_CL209();
		phy_val.CL209_Inquire(Audit_number, Div);
		Thread.sleep(1000);
		List<String> exp_result = new ArrayList<String>();
		act_review=phy_val.review_val(Review);
		exp_result.add(Review);
        exp_result.add(Rev_user_code);
		
		Assert.assertEquals(act_review,exp_result);
		
		System.out.println("Values returned " +act_review);
		Reporter.addStepLog("Values returned " +act_review);
		System.out.println("Expected outcome " +act_review);
		Reporter.addStepLog("Expected outcome " +act_review);
}
      else if(screen.equals("HO409"))
  	{	
  		Thread.sleep(1000);
  		Hospital_HO409 hos_val = new Hospital_HO409();
  		hos_val.HO409_Inquire(Audit_number, Div);
  		Thread.sleep(1000);
  		List<String> exp_result = new ArrayList<String>();
  		act_review_hos=hos_val.review_val(Review);
  		exp_result.add(Review);
          exp_result.add(Rev_user_code);
  		
  		Assert.assertEquals(act_review_hos,exp_result);
  		
  		System.out.println("Values returned " +act_review_hos);
  		Reporter.addStepLog("Values returned " +act_review_hos);
  		System.out.println("Expected outcome " +act_review_hos);
  		Reporter.addStepLog("Expected outcome " +act_review_hos);
}
}
/*@Then("^the user enters new Screen \"([^\"]*)\" on Screen \"([^\"]*)\"$")
public void the_user_enters_new_Screen_on_Screen(String Screen1, String Screen2) throws Throwable {
if (Screen2.equalsIgnoreCase("PS303")) {
PS303 ps=new PS303();
ps.enter_NewScreen(Screen1);
Thread.sleep(500); 
}
else if (Screen2.equalsIgnoreCase("PS331")) {
PS331 ps=new PS331();
ps.enter_NewScreen(Screen1);
Thread.sleep(500); 

}
*/
@Then("^the claim \"([^\"]*)\" in \"([^\"]*)\" is hit with review \"([^\"]*)\" in screen \"([^\"]*)\" and is not processed by RTS \"([^\"]*)\"$")
public void the_claim_in_is_hit_with_review_in_screen_and_is_not_processed_by_RTS(String Audit_number, String Div, String Review, String screen, String Rev_user_code) throws Throwable {
	Thread.sleep(1000);
	FunctionLibrary.navigateToDiv(screen);

Physician_CL209 phy_val1 = new Physician_CL209();
if(screen.equals("CL209")){
phy_val1.CL209_Inquire(Audit_number,Div);
List<String> exp_result = new ArrayList<String>();
exp_result.add(Review);
exp_result.add(Rev_user_code);
List act_review_code =phy_val1.review_val(Review);
Assert.assertNotEquals(act_review_code,exp_result);
Reporter.addStepLog("Values returned " +act_review_code);
Reporter.addStepLog("Expected outcome " +act_review_code);
}
}
}