package stepDefinition;

import java.text.SimpleDateFormat;
import java.time.temporal.ChronoUnit;
import java.util.Date;

import org.testng.Assert;
import com.cucumber.listener.Reporter;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.EP400;
import pages.Hospital_HO400;
import pages.Hospital_HO410;
import pages.PS303;
import pages.PS308;
import pages.PS330;
import pages.PS331;
import pages.Physician_CL104;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL300;
import pages.Physician_CL360;
import pages.Physician_PS340;
import pages.TB_214;
import util.FunctionLibrary;

//
public class Medica {
	public static String from_date=null;
	public static String to_date=null;
	public static String group=null;
	public static String memberNo=null;
	public static String mNo=null;
	public static String PROV_NO1=null;
	public static String PROV_NO2=null;
	public static String cont_No=null;
	public static String panel_no=null;
	public static String Alt_table=null;
	public static String prov=null;


	@Then("^status \"([^\"]*)\" is present on Screen \"([^\"]*)\" for the record\\.$")
	public void status_is_present_on_Screen_for_the_record(String statusNo, String Screen) throws Throwable {

		String statusNum=null;
		if (Screen.equals("CL360")) {
			Physician_CL360 phy_screen=new Physician_CL360();
			statusNum= phy_screen.getStatusNo();
			Assert.assertEquals(statusNo, statusNum);
			System.out.println("Status no verified");
			Reporter.addStepLog("Status No verified: "+statusNum);
		}
	}


	@Then("^the status \"([^\"]*)\" should be present on Screen \"([^\"]*)\"$")
	public void the_status_should_be_present_on_Screen(String status, String Screen) throws Throwable {
		Thread.sleep(800);
		String Status=null;
		if (Screen.equals("CL104")) {
			Physician_CL104 phy_screen=new Physician_CL104();
			Status= phy_screen.getStatus();
			Assert.assertEquals(Status, status);
			System.out.println("Status  verified");
			Reporter.addStepLog("Status  verified: "+Status);
		}

		else if (Screen.equals("CL360")) {
			Physician_CL360 phy_screen=new Physician_CL360();
			Status= phy_screen.getStatus();
			Assert.assertEquals(Status, status);
			System.out.println("Status  verified");
			Reporter.addStepLog("Status  verified: "+Status);
		}
	}

	@Then("^the Temp audit number should not be all zeros on screen \"([^\"]*)\"$")
	public void the_Temp_audit_number_should_not_be_all_zeros_on_screen(String Screen) throws Throwable {
		String tempAudit=null;
		boolean flag=false;
		if (Screen.equals("CL104")) {
			Physician_CL104 phy_screen=new Physician_CL104();
			tempAudit= phy_screen.gettempAudit();
			if(!(tempAudit.equalsIgnoreCase("000000000000"))||(tempAudit.equalsIgnoreCase(null))||(tempAudit.equalsIgnoreCase(""))){
				System.out.println("Temp audit no is not all zeros");
				flag=true;
			}
			Assert.assertTrue(flag);
			Reporter.addStepLog("Temp Audit no is not all zeros :"+tempAudit);
		}
	}

	@Then("^the UFIID \"([^\"]*)\"should be present on Screen \"([^\"]*)\" in proper format$")
	public void the_UFIID_should_be_present_on_Screen_in_proper_format(String UFEID, String Screen) throws Throwable {
		String arr[]=null;
		String ufe_id=null;
		String newUFEID=null;
		String formatUFE=null;
		if (Screen.equals("CL104")) {
			Physician_CL104 phy_screen=new Physician_CL104();
			ufe_id= phy_screen.getKeyValue();
			arr= ufe_id.split(" ");
			newUFEID= arr[2].substring(0, 15);
			System.out.println("On Screen: "+newUFEID);
			formatUFE=UFEID+"00";
			System.out.println("formatted UFEID is :"+formatUFE);
			Assert.assertEquals(newUFEID, formatUFE);
			System.out.println("UFE ID verified");
			Reporter.addStepLog("UFE ID  verified: "+ufe_id);
		}
	}

	@Then("^the user fetch serial no from screen \"([^\"]*)\"$")
	public void the_user_fetch_serial_no_from_screen(String Screen) throws Throwable {


		if (Screen.equals("CL360")) {
			Physician_CL360 phy_screen=new Physician_CL360();
			String sNo= phy_screen.getSerialNo();
			System.out.println("Serial no is :"+sNo);
		}

	}

	@Then("^the user enter record number on screen \"([^\"]*)\"$")
	public void the_user_enter_record_number_on_screen(String Screen) throws Throwable {
		if (Screen.equals("CL360")) {
			Physician_CL360 phy_screen=new Physician_CL360();
			phy_screen.enter_RecordNo();
			System.out.println("Record no entered");
		}
	}

	@When("^the user gets from date from Screen \"([^\"]*)\"$")
	public void the_user_gets_from_date_from_Screen(String Screen) throws Throwable {
		Hospital_HO400 hos_400=new Hospital_HO400();
		from_date=hos_400.from_date();
		System.out.println("From date is : "+from_date);
	}

	@When("^the user gets thru date from Screen \"([^\"]*)\"$")
	public void the_user_gets_thru_date_from_Screen(String Screen) throws Throwable {
		Hospital_HO400 hos_400=new Hospital_HO400();
		to_date=hos_400.thru_date();
		System.out.println("thru date is : "+to_date);
	}

	@When("^the difference between from and thru date should be \"([^\"]*)\"$")
	public void the_difference_between_from_and_thru_date_should_be(String diff) throws Throwable {

		boolean flag=false;
		SimpleDateFormat format1 = new SimpleDateFormat("MMddyy");
		/*	String from=format1.format(from_date);	
		String thru=format1.format(to_date);	
		System.out.println(from);
		System.out.println(thru);*/
		SimpleDateFormat sdf = new SimpleDateFormat("MMddyy");
		Date date1 = sdf.parse(from_date);
		Date date2 = sdf.parse(to_date);
		System.out.println("from date is :"+ date1);
		System.out.println("thru date is :"+ date2);



		long daysBetween = ChronoUnit.DAYS.between(date1.toInstant(), date2.toInstant());
		System.out.println("Days Difference between Frm_Date and Thru_Date is" +daysBetween);

		String temp=String.valueOf(daysBetween);

		if (temp.equalsIgnoreCase(diff)) {
			System.out.println("Difference between from and thru date verified");
			flag=true;
		}
		else{
			System.out.println("diffrence not verified");
		}
		Assert.assertTrue(flag);

	}

	@When("^type of bill \"([^\"]*)\" should be present on Screen \"([^\"]*)\"$")
	public void type_of_bill_should_be_present_on_Screen(String billType, String Screen) throws Throwable {
		Hospital_HO410 hos_410=new Hospital_HO410();
		String bill_type= hos_410.bill_type_val();
		System.out.println("bill type is :"+bill_type);
		Assert.assertEquals(bill_type, billType);
		System.out.println("Value matched");
		Reporter.addStepLog("Bill type  verified: "+bill_type);
	}

	@When("^the user gets member from Screen \"([^\"]*)\"$")
	public void the_user_gets_member_from_Screen(String Screen) throws Throwable {
		String member_val=null;
		String memberArr[]=null;
		Physician_CL201 phy_cl201=new Physician_CL201();
		member_val= phy_cl201.mem_val();
		System.out.println("Member value is: "+member_val);
		memberArr=member_val.split("-");
		group=  memberArr[0];
		memberNo= memberArr[1];
		mNo=memberArr[2];
		System.out.println("group no is: "+group);
		System.out.println("member no is: "+memberNo);
		System.out.println("mNo is: "+mNo);

	}

	@When("^the user enters site \"([^\"]*)\" on Screen \"([^\"]*)\"$")
	public void the_user_enters_site_on_Screen(String Div, String Screen) throws Throwable {
		FunctionLibrary fun=new FunctionLibrary();
		fun.navigateToDiv(Screen);
		Thread.sleep(800);
		TB_214 tb_214=new TB_214();
		tb_214.enter_site(Div);
	}

	@Then("^the COB should be \"([^\"]*)\" on Screen \"([^\"]*)\"$")
	public void the_COB_should_be_on_Screen(String cob, String Screen) throws Throwable {
		String COB=null;  
		Thread.sleep(800);
		if (Screen.equalsIgnoreCase("TB214")) {
			TB_214 tb_214=new TB_214();
			COB=tb_214.get_cob();
		}
		else if (Screen.equalsIgnoreCase("EP400")) {
			EP400 ep_400=new EP400();
			COB=ep_400.get_cob();

		}
		Assert.assertEquals(cob, COB);
		System.out.println("COB Matched:Pass");
		Reporter.addStepLog("COB verified: "+COB);
	}

	@Then("^the user enter group and subscriber on Screen \"([^\"]*)\"$")
	public void the_user_enter_group_and_subscriber_on_Screen(String Screen) throws Throwable {
		FunctionLibrary fun=new FunctionLibrary();
		fun.navigateToDiv(Screen);
		Thread.sleep(800);
		EP400 ep_400=new EP400();
		ep_400.enter_group();
		ep_400.enter_subscriber();
		System.out.println("Group and subscriber entered successfully");
	}


	@When("^the user enters date \"([^\"]*)\" on Screen \"([^\"]*)\"$")
	public void the_user_enters_date_on_Screen(String Date, String Screen) throws Throwable {
		FunctionLibrary fun=new FunctionLibrary();
		fun.navigateToDiv(Screen);
		Thread.sleep(800);
		Physician_CL300 cl300=new Physician_CL300();
		cl300.enter_asOfdate(Date);
		System.out.println("Date entered");
	}

	@When("^the user enters group on Screen \"([^\"]*)\"$")
	public void the_user_enters_group_on_Screen(String arg1) throws Throwable {
		Physician_CL300 cl300=new Physician_CL300();
		cl300.enter_group();
		System.out.println("Group Entered");
	}

	@When("^the user enters member on Screen \"([^\"]*)\"$")
	public void the_user_enters_member_on_Screen(String arg1) throws Throwable {
		Physician_CL300 cl300=new Physician_CL300();
		cl300.enter_member();
		System.out.println("Member entered");
	}

	@When("^the user enters memNo on Screen \"([^\"]*)\"$")
	public void the_user_enters_memNo_on_Screen(String arg1) throws Throwable {
		Physician_CL300 cl300=new Physician_CL300();
		cl300.enter_memNo();
		System.out.println("Mem no entered");
	}

	@Then("^the Carrier field should not be zero or blank on Screen \"([^\"]*)\"$")
	public void the_Carrier_field_should_not_be_zero_or_blank_on_Screen(String Screen) throws Throwable {
		String Carrier=null;
		boolean flag=false;
		Physician_CL300 cl300=new Physician_CL300();
		Thread.sleep(800);
		Carrier=cl300.get_carrier();
		if (!(Carrier.equalsIgnoreCase("")||Carrier.equalsIgnoreCase(null)||Carrier.equalsIgnoreCase("0"))) {
			System.out.println("Carrier is not equal to zero or blank");
			flag=true;
		}
		else{
			System.out.println("Carrier is equal to zero or blank");
		}

		Assert.assertTrue(flag);
		Reporter.addStepLog("Carrier verified: "+Carrier);
	}

	@When("^the user fetch provider number from the screen \"([^\"]*)\"$")
	public void the_user_fetch_provider_number_from_the_screen(String Screen) throws Throwable {
		Thread.sleep(900);
		if (Screen.equalsIgnoreCase("CL201")) {

		String provArr[]=null;
		Physician_CL201 cl201=new Physician_CL201();
		prov= cl201.prov_val1();
		provArr=  prov.split("-");
		PROV_NO1=provArr[0];
		PROV_NO2=provArr[1];
		System.out.println("Fetced provider no is: "+PROV_NO1);
		System.out.println("Fetced provider no is: "+PROV_NO2);
		}
		else if (Screen.equalsIgnoreCase("HO400")) {
			String provArr[]=null;
			Hospital_HO400 hos_400=new Hospital_HO400();
			prov= hos_400.prov_val();
			System.out.println("prov: "+prov);
			PROV_NO1=prov.substring(0, 4);
			PROV_NO2=prov.substring(4, 11);
			System.out.println("Fetced provider no is: "+PROV_NO1);
			System.out.println("Fetced provider no is: "+PROV_NO2);
		}
	}

	@When("^the user fetch contract number from the screen \"([^\"]*)\"$")
	public void the_user_fetch_contract_number_from_the_screen(String Screen) throws Throwable {
		Thread.sleep(800);
		Physician_CL201 cl201=new Physician_CL201();
		cont_No=cl201.getContract_No();
		System.out.println("Contract NO is :"+cont_No);

	}

	@When("^the user fetch panel number from screen \"([^\"]*)\"$")
	public void the_user_fetch_panel_number_from_screen(String Screen) throws Throwable {
		
		if (Screen.equalsIgnoreCase("CL202")) {
			Physician_CL202 cl202=new Physician_CL202();
			Thread.sleep(600);
			panel_no=cl202.prov_panel_val();
			System.out.println("Panel number is: "+panel_no);	
		}
		else if (Screen.equalsIgnoreCase("HO410")) {
			Hospital_HO410 ho410=new Hospital_HO410();
			panel_no=ho410.prov_panel_val();
			System.out.println("Panel number is: "+panel_no);	
			
		}
		
	}


	@When("^the user inquires with provider no on screen \"([^\"]*)\"$")
	public void the_user_inquires_with_provider_no_on_screen(String Screen) throws Throwable {
		if (Screen.equalsIgnoreCase("PS330")) {
			FunctionLibrary fun=new FunctionLibrary();
			Thread.sleep(400);
			fun.navigateToDiv(Screen);
			Thread.sleep(900);
			PS330 ps=new PS330();
			ps.enter_providerNo1();
			Thread.sleep(400);
			ps.enter_providerNo2();
		}
		else if (Screen.equalsIgnoreCase("PS303")) {
			FunctionLibrary fun=new FunctionLibrary();
			Thread.sleep(400);
			fun.navigateToDiv(Screen);
			Thread.sleep(900);
			PS303 ps=new PS303();
			ps.enter_providerNo1();
			Thread.sleep(400);
			ps.enter_providerNo2();
		}
		
		else if(Screen.equalsIgnoreCase("PS308")){
			FunctionLibrary fun=new FunctionLibrary();
			Thread.sleep(400);
			fun.navigateToDiv(Screen);
			Thread.sleep(1000);
			PS308 ps=new PS308();
			ps.PS308_Inquire(PROV_NO1, PROV_NO2, Screen);
		}

	}



	@Then("^the contract no should match corresponding to required panel number and expiration date on screen \"([^\"]*)\" with operation \"([^\"]*)\"$")
	public void the_contract_no_should_match_corresponding_to_requied_panel_number_and_expiration_date_on_screen_with_operation(String Screen, String operation) throws Throwable {
		if (Screen.equalsIgnoreCase("PS330")) {
			PS330 ps=new PS330();
			ps.validateContractNo(operation);


		}

	}

	@Then("^the user enquires with the contract number on Screen \"([^\"]*)\"$")
	public void the_user_enquires_with_the_contract_number_on_Screen(String Screen) throws Throwable {

		if (Screen.equalsIgnoreCase("PS340")) {
			PS330 ps330=new PS330();
			ps330.enterScreen(Screen);
			Thread.sleep(500);
			Physician_PS340 ps=new Physician_PS340();
			String contNo=PS330.ContractNumber;
			ps.PS340_Inquire(contNo, Screen);
			Thread.sleep(500);
		}
	}

	@Then("^the user fetch the alt table number from Screen \"([^\"]*)\"$")
	public void the_user_fetch_the_alt_table_number_from_Screen(String Screen) throws Throwable {
		if (Screen.equalsIgnoreCase("PS340")) {
			Physician_PS340 ps=new Physician_PS340();
			Alt_table=ps.alt_table_val();
			System.out.println("ALT tble no is :"+Alt_table);
			Thread.sleep(500);
		}
	}

	@Then("^the contract number on Screen \"([^\"]*)\" should match the alt table number on Screen \"([^\"]*)\"$")
	public void the_contract_number_on_Screen_should_match_the_alt_table_number_on_Screen(String Screen1, String Screen2) throws Throwable {
		if (Screen1.equalsIgnoreCase("CL201") && Screen2.equalsIgnoreCase("PS340")) {
			String cl_cont= Medica.cont_No;
			String ps_cont=Medica.Alt_table;
			Assert.assertEquals(cl_cont, ps_cont);
			System.out.println("Contract Number verified against alt table number Successfully:pass");
			Reporter.addStepLog("Contract Number verified against alt table number Successfully :"+cl_cont);

		}
	}

}