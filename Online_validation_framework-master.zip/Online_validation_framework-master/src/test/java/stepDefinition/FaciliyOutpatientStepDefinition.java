package stepDefinition;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.testng.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.*;
import pages.Hospital_HO400;
import pages.Hospital_HO409;
import pages.Hospital_HO410;
import pages.Hospital_HO440;
import pages.Physician_CL201;
import pages.Physician_CL209;
import util.FunctionLibrary;

//
public class FaciliyOutpatientStepDefinition {
	public String link_nbr,pc_disc,Audit_number,Div,reserve_pc;
	
	@When("^claimed of the claim \"([^\"]*)\" should be more than Rate \"([^\"]*)\" defined in PS(\\d+)$")
	public void claimed_of_the_claim_should_be_more_than_Rate_defined_in_PS(String exp_claimed, String rate, int screennum) throws Throwable {
		Hospital_HO400 hos_screen = new Hospital_HO400();
		String act_claimed=null;
		String act_msg = hos_screen.hos_msg_val();
		if(act_msg.contains("NO MORE DETAILS"))
		{
			String last_rev_code = hos_screen.rev_code2_val();
			if(last_rev_code.equalsIgnoreCase("0001"))
			{
				act_claimed =hos_screen.claimed2_val();
			}
			else if(hos_screen.rev_code3_val().equalsIgnoreCase("0001"))
			{
				act_claimed =hos_screen.claimed3_val();
			}
			else
			{
				act_claimed =hos_screen.claimed4_val();
			}
		}
		else
		{
			hos_screen.hos_mainscreen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			while(!act_msg.contains("NO MORE DETAILS"))
			{
				hos_screen.hos_mainscreen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			}
			String last_rev_code = hos_screen.rev_code1_val();
			if(last_rev_code.equalsIgnoreCase("0001"))
			{
				act_claimed =hos_screen.claimed1_val();
			}
			else if(hos_screen.rev_code2_val().equalsIgnoreCase("0001"))
			{
				act_claimed =hos_screen.claimed2_val();
			}
			else if(hos_screen.rev_code3_val().equalsIgnoreCase("0001"))
			{
				act_claimed =hos_screen.claimed3_val();
			}
			else
			{
				act_claimed =hos_screen.claimed4_val();
			}
			
		}
		double amt_claimed = Double.parseDouble(act_claimed);
		double e_claimed;
		double exp_claimed_amt = Double.parseDouble(rate);
		e_claimed =exp_claimed_amt;
		if(amt_claimed>e_claimed)
		{
			Assert.assertTrue(true);
			Reporter.addStepLog("Passed: Claimed amount is greater to contract rate in PS560");
			Reporter.addStepLog("Passed: Claimed amount is " +amt_claimed);
			Reporter.addStepLog("Passed: Expected claimed amount is " +e_claimed);
		} 
		else
		{
			Reporter.addStepLog("Failed: Claimed amount is less than contract rate in PS560");
			Reporter.addStepLog("Failed: Claimed amount is " +amt_claimed);
			Reporter.addStepLog("Failed: Expected claimed amount is " +e_claimed);
		}
	}

	@When("^get the link field \"([^\"]*)\" value in dbtable \"([^\"]*)\" for region \"([^\"]*)\" based on input field \"([^\"]*)\" value as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\"$")
	public void get_the_link_field_value_in_dbtable_for_region_based_on_input_field_value_as_and_input_field_as_and_input_field_as_and_input_field_as(String link, String table, String region, String in_field1, String p_type, String in_field2, String p_nbr, String in_field3, String p_panel, String in_field4, String div) throws Throwable {
	   Thread.sleep(500);
	   Div = div;
		String link_nbr = FunctionLibrary.SingleOutputValue_DB2Validation_DivInputFour(link, region, table, in_field4, div, in_field1, p_type, in_field2, p_nbr,in_field3,p_panel);
		
	   this.link_nbr = link_nbr;
	   System.out.println("Link number is: "+link_nbr);
	   Reporter.addStepLog("Link number is " +link_nbr);
	}

	@When("^the outfield \"([^\"]*)\" value is \"([^\"]*)\" and the outfield \"([^\"]*)\" value is \"([^\"]*)\" in dbtable \"([^\"]*)\" for region \"([^\"]*)\" based on input field \"([^\"]*)\" value as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\"$")
	public void the_outfield_value_is_and_the_outfield_value_is_in_dbtable_for_region_based_on_input_field_value_as_and_input_field_as_and_input_field_as_and_input_field_as(String o_field1, String o_val1, String o_field2, String o_val2, String table, String region, String in_field1, String link, String in_field2, String p_cat, String in_field3, String p_subcat, String in_field4, String div) throws Throwable {
		link = this.link_nbr;
	    List<String> dbvalues = FunctionLibrary.Ret_TwoValues_DB2Validation_InputFour(o_field1, o_field2, region, table, in_field4, div, in_field1, link, in_field2, p_cat, in_field3, p_subcat);
	    if(dbvalues.get(0).equals(o_val1))
	    {
	    	Assert.assertEquals(dbvalues.get(0), o_val1);
	    	Reporter.addStepLog("Passed: Expected calc type is " +o_val1);
	    	Reporter.addStepLog("Passed: Actual calc type is " +dbvalues.get(0));
	    }
	    else
	    {
	    	Assert.assertEquals(dbvalues.get(0), o_val1);
	    	Reporter.addStepLog("Failed: Expected calc type is " +o_val1);
	    	Reporter.addStepLog("Failed: Actual calc type is " +dbvalues.get(0));
	    }
	    if(dbvalues.get(1).equals(o_val2))
	    {
	    	Assert.assertEquals(dbvalues.get(1), o_val2);
	    	Reporter.addStepLog("Passed: Expected calc type is " +o_val2);
	    	Reporter.addStepLog("Passed: Actual calc type is " +dbvalues.get(1));
	    }
	    else
	    {
	    	Assert.assertEquals(dbvalues.get(1), o_val2);
	    	Reporter.addStepLog("Failed: Expected calc type is " +o_val2);
	    	Reporter.addStepLog("Failed: Actual calc type is " +dbvalues.get(1));
	    }
	    
	    
	}

	@Then("^the payable amount \"([^\"]*)\" of claim \"([^\"]*)\" in screen \"([^\"]*)\" is equivalent to rate \"([^\"]*)\" defined in PS(\\d+)$")
	public void the_payable_amount_of_claim_in_screen_is_equivalent_to_rate_defined_in_PS(String exp_allowed, String Audit_number, String screen, String rate,int screenname) throws Throwable {
		Thread.sleep(500);
		FunctionLibrary.navigateToDiv(screen);
		this.Audit_number=Audit_number;
		Hospital_HO400 hos_screen = new Hospital_HO400();
		String act_allowed=null;
		String act_copay=null;
		String act_ded=null;
		String act_msg = hos_screen.hos_msg_val();
		if(act_msg.contains("NO MORE DETAILS"))
		{
			String last_rev_code = hos_screen.rev_code2_val();
			if(last_rev_code.equalsIgnoreCase("0001"))
			{
				act_allowed =hos_screen.payable2_val();
				act_copay =hos_screen.copay2_val();
				act_ded=hos_screen.ded2_val();
			}
			else if(hos_screen.rev_code3_val().equalsIgnoreCase("0001"))
			{
				act_allowed =hos_screen.payable3_val();
				act_copay =hos_screen.copay3_val();
				act_ded=hos_screen.ded3_val();
			}
			else
			{
				act_allowed =hos_screen.payable4_val();
				act_copay =hos_screen.copay4_val();
				act_ded=hos_screen.ded4_val();
			}
		}
		else
		{
			hos_screen.hos_mainscreen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			while(!act_msg.contains("NO MORE DETAILS"))
			{
				hos_screen.hos_mainscreen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
			}
			String last_rev_code = hos_screen.rev_code1_val();
			if(last_rev_code.equalsIgnoreCase("0001"))
			{
				act_allowed =hos_screen.payable1_val();
				act_copay =hos_screen.copay1_val();
				act_ded=hos_screen.ded1_val();
			}
			else if(hos_screen.rev_code2_val().equalsIgnoreCase("0001"))
			{
				act_allowed =hos_screen.payable2_val();
				act_copay =hos_screen.copay2_val();
				act_ded=hos_screen.ded2_val();
			}
			else if(hos_screen.rev_code3_val().equalsIgnoreCase("0001"))
			{
				act_allowed =hos_screen.payable3_val();
				act_copay =hos_screen.copay3_val();
				act_ded=hos_screen.ded3_val();
			}
			else
			{
				act_allowed =hos_screen.payable4_val();
				act_copay =hos_screen.copay4_val();
				act_ded=hos_screen.ded4_val();
			}
			
		}
		double amt_allowed = Double.parseDouble(act_allowed);
		double amt_copay = Double.parseDouble(act_copay);
		double amt_ded = Double.parseDouble(act_ded);
		double e_allowed;
		double exp_allowed_amt = Double.parseDouble(exp_allowed);
		e_allowed =exp_allowed_amt;
		Double tot_allowed = amt_allowed+amt_copay+amt_ded;
		System.out.println("Total allowed amt is "+tot_allowed);
		if(tot_allowed==e_allowed)
		{
			Assert.assertEquals(tot_allowed, e_allowed);
			Reporter.addStepLog("Passed: Allowed amount is equal to calc rate allowed in PS"+screenname);
			Reporter.addStepLog("Passed: Allowed amount is " +tot_allowed);
			Reporter.addStepLog("Passed: Expected allowed amount is " +e_allowed);
		} 
		else
		{
			Reporter.addStepLog("Failed: Allowed amount is not equal to calc rate allowed in PS"+screenname);
			Reporter.addStepLog("Failed: Allowed amount is " +tot_allowed);
			Reporter.addStepLog("Failed: Expected allowed amount is " +e_allowed);
		}
	}

	@Then("^the calc rate should be \"([^\"]*)\" and group should be \"([^\"]*)\" in screen \"([^\"]*)\"$")
	public void the_calc_rate_should_be_and_group_should_be_in_screen(String exp_calc_rate, String exp_grp, String screen) throws Throwable {
		
		FunctionLibrary.navigateToDiv(screen);
		Thread.sleep(500);
		if(screen.equals("HO440"))
		{
			Hospital_HO440 hos_screen = new Hospital_HO440();
			String act_calc= hos_screen.calcrate_val();
			String act_grp = hos_screen.c_grp_val();
			String act_calc1= hos_screen.calcrate1_val();
			String act_grp1 = hos_screen.c_grp1_val();
			String act_calc2= hos_screen.calcrate2_val();
			String act_grp2 = hos_screen.c_grp2_val();
			String act_calc3= hos_screen.calcrate3_val();
			String act_grp3 = hos_screen.c_grp3_val();
			if(act_calc.equalsIgnoreCase(exp_calc_rate))
			{	
				Assert.assertEquals(act_calc, exp_calc_rate);
				Reporter.addStepLog("Passed: Actal calc rate is " +act_calc);
				Reporter.addStepLog("Passed: Expected calc rate is " +exp_calc_rate);
			}
			else if(act_calc1.equalsIgnoreCase(exp_calc_rate))
			{
				Assert.assertEquals(act_calc1, exp_calc_rate);
				Reporter.addStepLog("Passed: Actal calc rate is " +act_calc1);
				Reporter.addStepLog("Passed: Expected calc rate is " +exp_calc_rate);
			}
			else if(act_calc2.equalsIgnoreCase(exp_calc_rate))
			{
				Assert.assertEquals(act_calc2, exp_calc_rate);
				Reporter.addStepLog("Passed: Actal calc rate is " +act_calc2);
				Reporter.addStepLog("Passed: Expected calc rate is " +exp_calc_rate);
			}
			else if(act_calc3.equalsIgnoreCase(exp_calc_rate))
			{
				Assert.assertEquals(act_calc3, exp_calc_rate);
				Reporter.addStepLog("Passed: Actal calc rate is " +act_calc3);
				Reporter.addStepLog("Passed: Expected calc rate is " +exp_calc_rate);
			}
			else
			{
				Assert.assertEquals(act_calc, exp_calc_rate);
				Reporter.addStepLog("Failed: Actal calc rate is " +act_calc);
				Reporter.addStepLog("Failed: Expected calc rate is " +exp_calc_rate);
			}
			if(act_grp.equals(exp_grp))
			{
				Assert.assertEquals(act_grp, exp_grp);
				Reporter.addStepLog("Passed: Actal group is " +act_grp);
				Reporter.addStepLog("Passed: Expected group is " +exp_grp);
			}
			else if(act_grp1.equals(exp_grp))
			{
				Assert.assertEquals(act_grp1, exp_grp);
				Reporter.addStepLog("Passed: Actal group is " +act_grp1);
				Reporter.addStepLog("Passed: Expected group is " +exp_grp);
			}
			else if(act_grp2.equals(exp_grp))
			{
				Assert.assertEquals(act_grp2, exp_grp);
				Reporter.addStepLog("Passed: Actal group is " +act_grp2);
				Reporter.addStepLog("Passed: Expected group is " +exp_grp);
			}
			else if(act_grp3.equals(exp_grp))
			{
				Assert.assertEquals(act_grp3, exp_grp);
				Reporter.addStepLog("Passed: Actal group is " +act_grp3);
				Reporter.addStepLog("Passed: Expected group is " +exp_grp);
			}
			else
			{
				Assert.assertEquals(act_grp3, exp_grp);
				Reporter.addStepLog("Failed: Actal group is " +act_grp);
				Reporter.addStepLog("Failed: Expected group is " +exp_grp);
			}
			
		}
	}



	@When("^for the audit number \"([^\"]*)\" type of bill \"([^\"]*)\" in screen \"([^\"]*)\"$")
	public void for_the_audit_number_type_of_bill_in_screen(String Audit_number, String exp_bill, String screen) throws Throwable {
		Thread.sleep(500);
		FunctionLibrary.navigateToDiv(screen);
		if (screen.equals("HO410"))
		{
			Hospital_HO410 hos_val = new Hospital_HO410();
			//hos_val.HO410_Inquire(Audit_number, Div);
			String act_bill_type =hos_val.bill_type_val();
			if(act_bill_type.equals(exp_bill))
			{	
				Assert.assertEquals(act_bill_type, exp_bill);
				Reporter.addStepLog("Actual bill type is " +act_bill_type);
			}	
		}
		
	}
	@Then("^the payable amount \"([^\"]*)\" of detail line \"([^\"]*)\" for claim \"([^\"]*)\" in screen \"([^\"]*)\" is at (\\d+)% of  rate \"([^\"]*)\" defined in PS(\\d+)$")
	public void the_payable_amount_of_detail_line_for_claim_in_screen_is_at_of_rate_defined_in_PS(String exp_allowed,String cpt, String Audit_number, String screen, int pc, String rate, int screennbr) throws Throwable {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		
		Hospital_HO400 hos_screen = new Hospital_HO400();
		FunctionLibrary.navigateToDiv(screen);
		Thread.sleep(500);
		if(!hos_screen.hos_msg_val().startsWith("ORIGINAL CLAIM WITH"))
		{	
			hos_screen.HO400_Inquire(Audit_number,Div);
		}
		//System.out.println(dateFormat.format(date));
		String act_allowed=null;
		String act_copay=null;
		String act_ded=null;
		if(hos_screen.cpt1_val().contains(cpt))
		{	
			System.out.println("START " +dateFormat.format(date));
			act_allowed =hos_screen.payable1_val();
			act_copay =hos_screen.copay1_val();
			act_ded=hos_screen.ded1_val();
			System.out.println("END " +dateFormat.format(date));
		}	
		else if(hos_screen.cpt2_val().contains(cpt))
		{
			System.out.println("START " +dateFormat.format(date));
			act_allowed =hos_screen.payable2_val();
			act_copay =hos_screen.copay2_val();
			act_ded=hos_screen.ded2_val();
			System.out.println("END " +dateFormat.format(date));
		}
		else if(hos_screen.cpt3_val().contains(cpt))
		{
			System.out.println("START " +dateFormat.format(date));
			act_allowed =hos_screen.payable3_val();
			act_copay =hos_screen.copay3_val();
			act_ded=hos_screen.ded3_val();
			System.out.println("END " +dateFormat.format(date));
		}
		else if(hos_screen.cpt4_val().contains(cpt))
		{
			System.out.println("START " +dateFormat.format(date));
			act_allowed =hos_screen.payable4_val();
			act_copay =hos_screen.copay4_val();
			act_ded=hos_screen.ded4_val();
			System.out.println("END " +dateFormat.format(date));
		}
		//System.out.println(dateFormat.format(new Date()));
		double amt_allowed = Double.parseDouble(act_allowed);
		double amt_copay = Double.parseDouble(act_copay);
		double amt_ded = Double.parseDouble(act_ded);
		double e_allowed,allowed_rate;
		if(!rate.equalsIgnoreCase(""))
		{	
			 allowed_rate =Double.parseDouble(rate);
		}
		else
		{
			allowed_rate = 0.0;
		}
		double exp_allowed_amt = Double.parseDouble(exp_allowed);
		e_allowed =exp_allowed_amt;
		Double tot_allowed = amt_allowed+amt_copay+amt_ded;
		System.out.println("Total allowed amt is "+tot_allowed);
		double calc = allowed_rate*pc/100;
		if(tot_allowed==calc)
		{
			Assert.assertTrue(true);
			Reporter.addStepLog("Passed: Allowed amount is at " +pc +"% of rate " +rate +" defined in PS560");
			Reporter.addStepLog("Passed: Allowed amount is " +tot_allowed);
			Reporter.addStepLog("Passed: Expected allowed amount is " +e_allowed);
		} 
		else
		{
			Reporter.addStepLog("Failed: Allowed amount is at " +pc +"% of rate " +rate +" defined in PS560");
			Reporter.addStepLog("Failed: Allowed amount is " +tot_allowed);
			Reporter.addStepLog("Failed: Expected allowed amount is " +e_allowed);
		}
		//System.out.println("time end :"+dateFormat.format(new Date()));
	}

	@Then("^the calc rate and group of detail line \"([^\"]*)\" should be equal to that of detail line \"([^\"]*)\" in screen \"([^\"]*)\"$")
	public void the_calc_rate_and_group_of_detail_line_should_be_equal_to_that_of_detail_line_in_screen(String cpt1, String cpt2, String screen) throws Throwable {
		
		FunctionLibrary.navigateToDiv(screen);
		
		if(screen.equals("HO440"))
		{
			Hospital_HO440 hos_screen = new Hospital_HO440();
			String act_calc= hos_screen.calcrate_val();
			String act_grp = hos_screen.c_grp_val();
			String act_calc1= hos_screen.calcrate1_val();
			String act_grp1 = hos_screen.c_grp1_val();
			if(act_calc.equals(act_calc1))
			{
				Assert.assertEquals(act_calc, act_calc1);
				Reporter.addStepLog("Passed: Actual calc rate for detail line with proc code " +cpt1+ " is " +act_calc);
				Reporter.addStepLog("Passed: Actual calc rate for detail line with proc code " +cpt2+ " is " +act_calc1);
			}
			else
			{
				Assert.assertEquals(act_calc, act_calc1);
				Reporter.addStepLog("Failed: Actual calc rate for detail line with proc code " +cpt1+ " is " +act_calc);
				Reporter.addStepLog("Failed: Actual calc rate for detail line with proc code " +cpt2+ " is " +act_calc1);
			}
			if(act_grp.equals(act_grp1))
			{
				Assert.assertEquals(act_grp, act_grp1);
				Reporter.addStepLog("Passed: Actual group for detail line with proc code " +cpt1+ " is " +act_grp);
				Reporter.addStepLog("Passed: Actual group for detail line with proc code " +cpt2+ " is " +act_grp1);
			}
			else
			{
				Assert.assertEquals(act_grp, act_grp1);
				Reporter.addStepLog("Failed: Actual group for detail line with proc code " +cpt1+ " is " +act_grp);
				Reporter.addStepLog("Failed: Actual group for detail line with proc code " +cpt2+ " is " +act_grp1);
			}
			
		}
		
	}
	@Then("^the calc rate and group of detail line \"([^\"]*)\" should be equal to that of detail line \"([^\"]*)\" and \"([^\"]*)\" in screen \"([^\"]*)\"$")
	public void the_calc_rate_and_group_of_detail_line_should_be_equal_to_that_of_detail_line_and_in_screen(String cpt1, String cpt2, String cpt3, String screen) throws Throwable {
		
		FunctionLibrary.navigateToDiv(screen);
		
		if(screen.equals("HO440"))
		{
			Hospital_HO440 hos_screen = new Hospital_HO440();
			String act_calc= hos_screen.calcrate_val();
			String act_grp = hos_screen.c_grp_val();
			String act_calc1= hos_screen.calcrate1_val();
			String act_grp1 = hos_screen.c_grp1_val();
			String act_calc2= hos_screen.calcrate2_val();
			String act_grp2 = hos_screen.c_grp2_val();
			if(act_calc.equals(act_calc1) && (act_calc1.equals(act_calc2)))
			{
				Assert.assertEquals(act_calc, act_calc1);
				Assert.assertEquals(act_calc1, act_calc2);
				Reporter.addStepLog("Passed: Actual calc rate for detail line with proc code " +cpt1+ " is " +act_calc);
				Reporter.addStepLog("Passed: Actual calc rate for detail line with proc code " +cpt2+ " is " +act_calc1);
				Reporter.addStepLog("Passed: Actual calc rate for detail line with proc code " +cpt3+ " is " +act_calc2);
			}
			else
			{
				Assert.assertEquals(act_calc, act_calc1);
				Assert.assertEquals(act_calc1, act_calc2);
				Reporter.addStepLog("Failed: Actual calc rate for detail line with proc code " +cpt1+ " is " +act_calc);
				Reporter.addStepLog("Failed: Actual calc rate for detail line with proc code " +cpt2+ " is " +act_calc1);
				Reporter.addStepLog("Failed: Actual calc rate for detail line with proc code " +cpt3+ " is " +act_calc2);
			}
			if(act_grp.equals(act_grp1) && (act_grp1.equals(act_grp2)))
			{
				Assert.assertEquals(act_grp, act_grp1);
				Assert.assertEquals(act_grp1, act_grp2);
				Reporter.addStepLog("Passed: Actual group for detail line with proc code " +cpt1+ " is " +act_grp);
				Reporter.addStepLog("Passed: Actual group for detail line with proc code " +cpt2+ " is " +act_grp1);
				Reporter.addStepLog("Passed: Actual group for detail line with proc code " +cpt3+ " is " +act_grp2);
			}
			else
			{
				Assert.assertEquals(act_grp, act_grp1);
				Assert.assertEquals(act_grp1, act_grp2);
				Reporter.addStepLog("Failed: Actual group for detail line with proc code " +cpt1+ " is " +act_grp);
				Reporter.addStepLog("Failed: Actual group for detail line with proc code " +cpt2+ " is " +act_grp1);
				Reporter.addStepLog("Failed: Actual group for detail line with proc code " +cpt3+ " is " +act_grp2);
			}
			
		}
		
	}	
	
	@Then("^the calc rate and group of detail line \"([^\"]*)\" should be equal to that of detail line \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" in screen \"([^\"]*)\"$")
	public void the_calc_rate_and_group_of_detail_line_should_be_equal_to_that_of_detail_line_and_and_in_screen(String cpt1, String cpt2, String cpt3, String cpt4, String screen) throws Throwable {
	
		FunctionLibrary.navigateToDiv(screen);
		
		if(screen.equals("HO440"))
		{
			Hospital_HO440 hos_screen = new Hospital_HO440();
			String act_calc= hos_screen.calcrate_val();
			String act_grp = hos_screen.c_grp_val();
			String act_calc1= hos_screen.calcrate1_val();
			String act_grp1 = hos_screen.c_grp1_val();
			String act_calc2= hos_screen.calcrate2_val();
			String act_grp2 = hos_screen.c_grp2_val();
			String act_calc3= hos_screen.calcrate3_val();
			String act_grp3 = hos_screen.c_grp3_val();
			if(act_calc.equals(act_calc1) && (act_calc1.equals(act_calc2)) && (act_calc2.equals(act_calc3)))
			{
				Assert.assertEquals(act_calc, act_calc1);
				Assert.assertEquals(act_calc1, act_calc2);
				Assert.assertEquals(act_calc2, act_calc3);
				Reporter.addStepLog("Passed: Actual calc rate for detail line with proc code " +cpt1+ " is " +act_calc);
				Reporter.addStepLog("Passed: Actual calc rate for detail line with proc code " +cpt2+ " is " +act_calc1);
				Reporter.addStepLog("Passed: Actual calc rate for detail line with proc code " +cpt3+ " is " +act_calc2);
				Reporter.addStepLog("Passed: Actual calc rate for detail line with proc code " +cpt3+ " is " +act_calc3);
			}
			else
			{
				Assert.assertEquals(act_calc, act_calc1);
				Assert.assertEquals(act_calc1, act_calc2);
				Assert.assertEquals(act_calc2, act_calc3);
				Reporter.addStepLog("Failed: Actual calc rate for detail line with proc code " +cpt1+ " is " +act_calc);
				Reporter.addStepLog("Failed: Actual calc rate for detail line with proc code " +cpt2+ " is " +act_calc1);
				Reporter.addStepLog("Failed: Actual calc rate for detail line with proc code " +cpt3+ " is " +act_calc2);
				Reporter.addStepLog("Failed: Actual calc rate for detail line with proc code "+cpt3+ " is " +act_calc3);
			}
			if(act_grp.equals(act_grp1) && (act_grp1.equals(act_grp2)) && (act_grp2.equals(act_grp3)))
			{
				Assert.assertEquals(act_grp, act_grp1);
				Assert.assertEquals(act_grp1, act_grp2);
				Assert.assertEquals(act_grp2, act_grp3);
				Reporter.addStepLog("Passed: Actual group for detail line with proc code " +cpt1+ " is " +act_grp);
				Reporter.addStepLog("Passed: Actual group for detail line with proc code " +cpt2+ " is " +act_grp1);
				Reporter.addStepLog("Passed: Actual group for detail line with proc code " +cpt3+ " is " +act_grp2);
				Reporter.addStepLog("Passed: Actual group for detail line with proc code " +cpt4+ " is " +act_grp3);
			}
			else
			{
				Assert.assertEquals(act_grp, act_grp1);
				Assert.assertEquals(act_grp1, act_grp2);
				Assert.assertEquals(act_grp2, act_grp3);
				Reporter.addStepLog("Failed: Actual group for detail line with proc code " +cpt1+ " is " +act_grp);
				Reporter.addStepLog("Failed: Actual group for detail line with proc code " +cpt2+ " is " +act_grp1);
				Reporter.addStepLog("Failed: Actual group for detail line with proc code " +cpt3+ " is " +act_grp2);
				Reporter.addStepLog("Failed: Actual group for detail line with proc code " +cpt4+ " is " +act_grp3);
			}
			
		}
	}
	@Then("^the claim \"([^\"]*)\" should not be calculated with fee schedule in screen \"([^\"]*)\"$")
	public void the_claim_should_not_be_calculated_with_fee_schedule_in_screen(String Audit_number, String screen) throws Throwable {
		FunctionLibrary.navigateToDiv(screen);
		Hospital_HO400 hos_screen = new Hospital_HO400();
		String hos_msg=hos_screen.hos_msg_val();
		if(hos_msg.contains("CLAIM NOT CALCULATED WITH FEE SCHEDULE"))
		{
			Assert.assertTrue(true);
			Reporter.addStepLog("Passed: Claim is not calculated with fee schedule");
		}
		else
		{
			Assert.assertTrue(true);
			Reporter.addStepLog("Failed: Claim is calculated with fee schedule");
		}
	}

@Then("^get the percentage discount \"([^\"]*)\" in dbtable \"([^\"]*)\" for region \"([^\"]*)\" based on input field \"([^\"]*)\" value as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\"$")
public void get_the_percentage_discount_in_dbtable_for_region_based_on_input_field_value_as_and_input_field_as_and_input_field_as_and_input_field_as(String outfield, String table, String region, String in_field1, String in_val1, String in_field2, String in_val2, String in_field3, String in_val3, String in_field4, String in_val4) throws Throwable {
	 Thread.sleep(500);
	 String link=this.link_nbr;
	 pc_disc = FunctionLibrary.SingleOutputValue_DB2Validation_DivInputFour(outfield, region, table, in_field4, in_val4, in_field1, link, in_field2, in_val2,in_field3,in_val3);
	 Reporter.addStepLog("Percentage of claimed is " +pc_disc);

 }
@Then("^the payable amount \"([^\"]*)\" of claim \"([^\"]*)\" in screen \"([^\"]*)\" is based on percentage \"([^\"]*)\" of claimed amount \"([^\"]*)\" defined in PS(\\d+)$")
public void the_payable_amount_of_claim_in_screen_is_based_on_percentage_of_claimed_amount_defined_in_PS(String exp_allowed, String Audit_number, String screen, String pc, String claimed, int arg5) throws Throwable {
	Thread.sleep(500);
	FunctionLibrary.navigateToDiv(screen);
	Hospital_HO400 hos_screen = new Hospital_HO400();
	String act_allowed=null;
	String act_copay=null;
	String act_ded=null;
	String act_msg = hos_screen.hos_msg_val();
	if(act_msg.contains("NO MORE DETAILS"))
	{
		String last_rev_code = hos_screen.rev_code2_val();
		if(last_rev_code.equalsIgnoreCase("0001"))
		{
			act_allowed =hos_screen.payable2_val();
			act_copay =hos_screen.copay2_val();
			act_ded=hos_screen.ded2_val();
		}
		else if(hos_screen.rev_code3_val().equalsIgnoreCase("0001"))
		{
			act_allowed =hos_screen.payable3_val();
			act_copay =hos_screen.copay3_val();
			act_ded=hos_screen.ded3_val();
		}
		else
		{
			act_allowed =hos_screen.payable4_val();
			act_copay =hos_screen.copay4_val();
			act_ded=hos_screen.ded4_val();
		}
	}
	else
	{
		hos_screen.hos_mainscreen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		while(!act_msg.contains("NO MORE DETAILS"))
		{
			hos_screen.hos_mainscreen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		}
		String last_rev_code = hos_screen.rev_code1_val();
		if(last_rev_code.equalsIgnoreCase("0001"))
		{
			act_allowed =hos_screen.payable1_val();
			act_copay =hos_screen.copay1_val();
			act_ded=hos_screen.ded1_val();
		}
		else if(hos_screen.rev_code2_val().equalsIgnoreCase("0001"))
		{
			act_allowed =hos_screen.payable2_val();
			act_copay =hos_screen.copay2_val();
			act_ded=hos_screen.ded2_val();
		}
		else if(hos_screen.rev_code3_val().equalsIgnoreCase("0001"))
		{
			act_allowed =hos_screen.payable3_val();
			act_copay =hos_screen.copay3_val();
			act_ded=hos_screen.ded3_val();
		}
		else
		{
			act_allowed =hos_screen.payable4_val();
			act_copay =hos_screen.copay4_val();
			act_ded=hos_screen.ded4_val();
		}
		
	}
	double amt_allowed = Double.parseDouble(act_allowed);
	double amt_copay = Double.parseDouble(act_copay);
	double amt_ded = Double.parseDouble(act_ded);
	double e_allowed;
	double exp_allowed_amt = Double.parseDouble(exp_allowed);
	double act_claimed_amt = Double.parseDouble(claimed);
	e_allowed =exp_allowed_amt;
	double pcnt = Double.parseDouble(pc);
	Double tot_allowed = amt_allowed+amt_copay+amt_ded;
	System.out.println("Total allowed amt is "+tot_allowed);
	if(tot_allowed==act_claimed_amt*pcnt)
	{
		Assert.assertEquals(tot_allowed, e_allowed);
		Reporter.addStepLog("Passed: Allowed amount is equal to calc rate allowed in PS560");
		Reporter.addStepLog("Passed: Allowed amount is " +tot_allowed);
		Reporter.addStepLog("Passed: Expected allowed amount is " +e_allowed);
	} 
	else
	{
		Reporter.addStepLog("Failed: Allowed amount is not equal to calc rate allowed in PS560");
		Reporter.addStepLog("Failed: Allowed amount is " +tot_allowed);
		Reporter.addStepLog("Failed: Expected allowed amount is " +e_allowed);
	}
}

@Then("^the payable amount \"([^\"]*)\" of claim \"([^\"]*)\" in screen \"([^\"]*)\" is based on percentage \"([^\"]*)\" of claimed amount \"([^\"]*)\" minus total reserve \"([^\"]*)\" defined in PS(\\d+)$")
public void the_payable_amount_of_claim_in_screen_is_based_on_percentage_of_claimed_amount_minus_total_reserve_defined_in_PS(String exp_allowed, String Audit_number, String screen, String pc, String claimed, String tot_reserve,int arg7) throws Throwable {
	Thread.sleep(500);
	FunctionLibrary.navigateToDiv(screen);
	Hospital_HO400 hos_screen = new Hospital_HO400();
	String act_allowed=null;
	String act_copay=null;
	String act_ded=null;
	String act_reserve = null;
	String act_msg = hos_screen.hos_msg_val();
	if(act_msg.contains("NO MORE DETAILS"))
	{
		String last_rev_code = hos_screen.rev_code2_val();
		if(last_rev_code.equalsIgnoreCase("0001"))
		{
			act_allowed =hos_screen.payable2_val();
			act_copay =hos_screen.copay2_val();
			act_ded=hos_screen.ded2_val();
			act_reserve = hos_screen.reserve2_val();
		}
		else if(hos_screen.rev_code3_val().equalsIgnoreCase("0001"))
		{
			act_allowed =hos_screen.payable3_val();
			act_copay =hos_screen.copay3_val();
			act_ded=hos_screen.ded3_val();
			act_reserve = hos_screen.reserve3_val();
		}
		else
		{
			act_allowed =hos_screen.payable4_val();
			act_copay =hos_screen.copay4_val();
			act_ded=hos_screen.ded4_val();
			act_reserve = hos_screen.reserve4_val();
		}
	}
	else
	{
		hos_screen.hos_mainscreen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		while(!act_msg.contains("NO MORE DETAILS"))
		{
			hos_screen.hos_mainscreen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		}
		String last_rev_code = hos_screen.rev_code1_val();
		if(last_rev_code.equalsIgnoreCase("0001"))
		{
			act_allowed =hos_screen.payable1_val();
			act_copay =hos_screen.copay1_val();
			act_ded=hos_screen.ded1_val();
			act_reserve = hos_screen.reserve4_val();
		}
		else if(hos_screen.rev_code2_val().equalsIgnoreCase("0001"))
		{
			act_allowed =hos_screen.payable2_val();
			act_copay =hos_screen.copay2_val();
			act_ded=hos_screen.ded2_val();
			act_reserve = hos_screen.reserve2_val();
		}
		else if(hos_screen.rev_code3_val().equalsIgnoreCase("0001"))
		{
			act_allowed =hos_screen.payable3_val();
			act_copay =hos_screen.copay3_val();
			act_ded=hos_screen.ded3_val();
			act_reserve = hos_screen.reserve3_val();
		}
		else
		{
			act_allowed =hos_screen.payable4_val();
			act_copay =hos_screen.copay4_val();
			act_ded=hos_screen.ded4_val();
			act_reserve = hos_screen.reserve4_val();
		}
		
	}
	double amt_allowed = Double.parseDouble(act_allowed);
	double amt_copay = Double.parseDouble(act_copay);
	double amt_ded = Double.parseDouble(act_ded);
	double e_allowed;
	double exp_allowed_amt = Double.parseDouble(exp_allowed);
	double act_claimed_amt = Double.parseDouble(claimed);
	e_allowed =exp_allowed_amt;
	double tot_res_amt = Double.parseDouble(act_reserve);
	double pcnt = Double.parseDouble(pc);
	Double tot_allowed = amt_allowed+amt_copay+amt_ded;
	System.out.println("Total allowed amt is "+tot_allowed);
	if(tot_allowed==(act_claimed_amt*pcnt) - tot_res_amt)
	{
		Assert.assertEquals(tot_allowed, e_allowed);
		Reporter.addStepLog("Passed: Allowed amount is equal to calc rate allowed in PS560");
		Reporter.addStepLog("Passed: Allowed amount is " +tot_allowed);
		Reporter.addStepLog("Passed: Expected allowed amount is " +e_allowed);
	} 
	else
	{
		Reporter.addStepLog("Failed: Allowed amount is not equal to calc rate allowed in PS560");
		Reporter.addStepLog("Failed: Allowed amount is " +tot_allowed);
		Reporter.addStepLog("Failed: Expected allowed amount is " +e_allowed);
	}
}
@When("^claimed of the claim \"([^\"]*)\" should be less than Rate \"([^\"]*)\" defined in PS(\\d+)$")
public void claimed_of_the_claim_should_be_less_than_Rate_defined_in_PS(String claimed, String rate, int arg3) throws Throwable {
	Hospital_HO400 hos_screen = new Hospital_HO400();
	String act_claimed=null;
	String act_msg = hos_screen.hos_msg_val();
	if(act_msg.contains("NO MORE DETAILS"))
	{
		String last_rev_code = hos_screen.rev_code2_val();
		if(last_rev_code.equalsIgnoreCase("0001"))
		{
			act_claimed =hos_screen.claimed2_val();
		}
		else if(hos_screen.rev_code3_val().equalsIgnoreCase("0001"))
		{
			act_claimed =hos_screen.claimed3_val();
		}
		else
		{
			act_claimed =hos_screen.claimed4_val();
		}
	}
	else
	{
		hos_screen.hos_mainscreen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		while(!act_msg.contains("NO MORE DETAILS"))
		{
			hos_screen.hos_mainscreen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		}
		String last_rev_code = hos_screen.rev_code1_val();
		if(last_rev_code.equalsIgnoreCase("0001"))
		{
			act_claimed =hos_screen.claimed1_val();
		}
		else if(hos_screen.rev_code2_val().equalsIgnoreCase("0001"))
		{
			act_claimed =hos_screen.claimed2_val();
		}
		else if(hos_screen.rev_code3_val().equalsIgnoreCase("0001"))
		{
			act_claimed =hos_screen.claimed3_val();
		}
		else
		{
			act_claimed =hos_screen.claimed4_val();
		}
		
	}
	double amt_claimed = Double.parseDouble(act_claimed);
	double e_claimed;
	double exp_claimed_amt = Double.parseDouble(rate);
	e_claimed =exp_claimed_amt;
	if(amt_claimed<e_claimed)
	{
		Assert.assertTrue(true);
		Reporter.addStepLog("Passed: Claimed amount is greater to contract rate in PS560");
		Reporter.addStepLog("Passed: Claimed amount is " +amt_claimed);
		Reporter.addStepLog("Passed: Expected claimed amount is " +e_claimed);
	} 
	else
	{
		Reporter.addStepLog("Failed: Claimed amount is less than contract rate in PS560");
		Reporter.addStepLog("Failed: Claimed amount is " +amt_claimed);
		Reporter.addStepLog("Failed: Expected claimed amount is " +e_claimed);
	}
}

@Then("^the category number \"([^\"]*)\" of detail line \"([^\"]*)\" should be different from either of category number \"([^\"]*)\" of detail line \"([^\"]*)\" or category number \"([^\"]*)\" of detail line \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_category_number_of_detail_line_should_be_different_from_either_of_category_number_of_detail_line_or_category_number_of_detail_line_in_screen(String catnum1, String cpt1, String catnum2, String cpt2, String catnum3, String cpt3, String screen) throws Throwable {
	Thread.sleep(500);
	FunctionLibrary.navigateToDiv(screen);
	Hospital_HO440 hos_screen = new Hospital_HO440();
	String act_catnum1= hos_screen.catnbr_val();
	String act_catnum2= hos_screen.catnbr1_val();
	String act_catnum3= hos_screen.catnbr2_val();
	boolean cond_satis = false;
	if(!act_catnum1.equals(act_catnum2) || (!act_catnum1.equals(act_catnum3)) || (!act_catnum2.equals(act_catnum3)))
	{
		if(!act_catnum1.equals(act_catnum2))
		{
			Assert.assertNotEquals(catnum1, catnum2);
			Reporter.addStepLog("Category number of detail line1 " +catnum1+ " is different from category number of detail line2 " +catnum2);
			cond_satis = true;
		}
		else
		{
			Assert.assertEquals(catnum1, catnum2);
			Reporter.addStepLog("Category number of detail line1 " +catnum1+ " is equal to category number of detail line2 " +catnum2);
		}
		if(!act_catnum2.equals(act_catnum3))
		{
			Assert.assertNotEquals(catnum2, catnum3);
			Reporter.addStepLog("Category number of detail line2 " +catnum2+ " is different from category number of detail line3 " +catnum3);
			cond_satis = true;
		}
		else
		{
			Assert.assertNotEquals(catnum2, catnum3);
			Reporter.addStepLog("Category number of detail line2 " +catnum2+ " is equal to category number of detail line3 " +catnum3);
		}
		if(!act_catnum1.equals(act_catnum3))
		{
			Assert.assertNotEquals(catnum1, catnum3);
			Reporter.addStepLog("Category number of detail line1 " +catnum1+ " is different from category number of detail line3 " +catnum3);
			cond_satis = true;
		}
		else
		{
			Assert.assertNotEquals(catnum1, catnum3);
			Reporter.addStepLog("Category number of detail line1 " +catnum1+ " is equal to category number of detail line3 " +catnum3);
		}
	}
	if(cond_satis)
	{
		Reporter.addStepLog("Passed: Category number is different " );
	}
	else
	{
		Reporter.addStepLog("Failed: Category number is same " );
	}
}
@Then("^the payable amount \"([^\"]*)\" of claim \"([^\"]*)\" in screen \"([^\"]*)\" is equivalent to fee schd rate \"([^\"]*)\" defined in PS(\\d+)$")
public void the_payable_amount_of_claim_in_screen_is_equivalent_to_fee_schd_rate_defined_in_PS(String amt, String Audit_number, String screen, String rate, int arg5) throws Throwable {
	Thread.sleep(500);
	FunctionLibrary.navigateToDiv(screen);
	Hospital_HO440 hos_screen = new Hospital_HO440();
	String act_amt= hos_screen.conamt_val();
	String act_amt1= hos_screen.conamt1_val();
	String act_amt2= hos_screen.conamt2_val();
	if(amt.equalsIgnoreCase(act_amt))
	{
		Assert.assertEquals(act_amt, amt);
		Reporter.addStepLog("Passed: Payable amount " +act_amt+ " is equal to the  Fee schedule rate " +rate );
		
	}
	
	else if(amt.equalsIgnoreCase(act_amt1))
	{
		Assert.assertEquals(act_amt1, amt);
		Reporter.addStepLog("Passed: Payable amount " +act_amt1+ " is equal to the  Fee schedule rate " +rate );
		
	}
	
	else if(amt.equalsIgnoreCase(act_amt2))
	{
		Assert.assertEquals(act_amt2, amt);
		Reporter.addStepLog("Passed: Payable amount " +act_amt2+ " is equal to the  Fee schedule rate " +rate );
		
	}
	else
	{
		
		Reporter.addStepLog("Failed: Payable amount is not equal to the  Fee schedule rate. "  );
	}
}
@Then("^the fee schedule type should be \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_fee_schedule_type_should_be_in_screen(String exp_fee_schd, String screen) throws Throwable {
	Thread.sleep(500);
	Hospital_HO440 hos_screen = new Hospital_HO440();
	String act_fee_schd = hos_screen.feeschd_val();
	if(act_fee_schd.equalsIgnoreCase(exp_fee_schd))
	{
		Assert.assertEquals(act_fee_schd, exp_fee_schd);
		Reporter.addStepLog("Passed: Expected fee schedule is " +exp_fee_schd  );
		Reporter.addStepLog("Passed: Actual fee schdule is " +act_fee_schd);
		
	}
	else
	{
		Assert.assertEquals(act_fee_schd, exp_fee_schd);
		Reporter.addStepLog("Failed: Expected fee schedule is " +exp_fee_schd  );
		Reporter.addStepLog("Failed: Actual fee schdule is " +act_fee_schd);
	}
}

@When("^get the field \"([^\"]*)\" value in dbtable \"([^\"]*)\" for region \"([^\"]*)\" based on input field \"([^\"]*)\" value as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\"$")
public void get_the_field_value_in_dbtable_for_region_based_on_input_field_value_as_and_input_field_as_and_input_field_as_and_input_field_as(String pcr, String table, String region, String in_field1, String p_type, String in_field2, String p_nbr, String in_field3, String p_panel, String in_field4, String div) throws Throwable {
	Thread.sleep(500);
	Div = div;
	String pcnt = FunctionLibrary.SingleOutputValue_DB2Validation_DivInputFour(pcr, region, table, in_field4, div, in_field1, p_type, in_field2, p_nbr,in_field3,p_panel);
	this.reserve_pc = pcnt;
	Reporter.addStepLog("Reserve percentage is " +this.reserve_pc);
}

@Then("^the reserve amount \"([^\"]*)\" of claim \"([^\"]*)\" in screen \"([^\"]*)\" is based on percentage \"([^\"]*)\" of claimed amount \"([^\"]*)\" defined in PS(\\d+)$")
public void the_reserve_amount_of_claim_in_screen_is_based_on_percentage_of_claimed_amount_defined_in_PS(String res_amt, String Audit_number,String screen, String pc, String claimed, int arg6) throws Throwable {
	Thread.sleep(500);
	FunctionLibrary.navigateToDiv(screen);
	Hospital_HO400 hos_screen = new Hospital_HO400();
	String act_reserve=null;
	String act_msg = hos_screen.hos_msg_val();
	if(act_msg.contains("NO MORE DETAILS"))
	{
		String last_rev_code = hos_screen.rev_code2_val();
		if(last_rev_code.equalsIgnoreCase("0001"))
		{
			act_reserve =hos_screen.reserve1_val();

		}
		else if(hos_screen.rev_code3_val().equalsIgnoreCase("0001"))
		{
			act_reserve =hos_screen.reserve2_val();
		}
		else
		{
			act_reserve =hos_screen.reserve3_val();
		}
	}
	else
	{
		hos_screen.hos_mainscreen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		while(!act_msg.contains("NO MORE DETAILS"))
		{
			hos_screen.hos_mainscreen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER);
		}
		String last_rev_code = hos_screen.rev_code1_val();
		if(last_rev_code.equalsIgnoreCase("0001"))
		{
			act_reserve =hos_screen.reserve4_val();
		}
		else if(hos_screen.rev_code2_val().equalsIgnoreCase("0001"))
		{
			act_reserve =hos_screen.reserve2_val();
		}
		else if(hos_screen.rev_code3_val().equalsIgnoreCase("0001"))
		{
			act_reserve =hos_screen.reserve3_val();
		}
		else
		{
			act_reserve =hos_screen.reserve4_val();
		}
		
	}
	double reser_amt = Double.parseDouble(claimed)*Double.parseDouble(this.reserve_pc);
	//double exp_allowed_amt = Double.parseDouble(res_amt);
	double act_reserve_amt = Double.parseDouble(act_reserve);
	//e_allowed =exp_allowed_amt;
	//double pcnt = Double.parseDouble(pc);
	//Double tot_allowed = amt_allowed+amt_copay+amt_ded;
	//System.out.println("Total allowed amt is "+tot_allowed);
	if(reser_amt==act_reserve_amt)
	{
		Assert.assertEquals(act_reserve_amt, reser_amt);
		Reporter.addStepLog("Passed: Percent reserve amount is equal to actual reserve eligible");
		Reporter.addStepLog("Passed: Expected reserve amount is " +reser_amt);
		Reporter.addStepLog("Passed: Actual reserve amount is " +act_reserve_amt);
	} 
	else
	{
		Reporter.addStepLog("Failed: Percent reserve amount is not equal to actual reserve eligible");
		Reporter.addStepLog("Failed: Allowed amount is " +reser_amt);
		Reporter.addStepLog("Failed: Expected allowed amount is " +act_reserve_amt);
	}
}
@Then("^the claim \"([^\"]*)\" is not hit with review \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_claim_is_not_hit_with_review_in_screen(String Audit_number, String exp_review, String screen) throws Throwable {
	Thread.sleep(1000);
	FunctionLibrary.navigateToDiv(screen);
	if(screen.equals("CL209"))
	{	
		Physician_CL209 phy_val = new Physician_CL209();
		phy_val.CL209_Inquire(Audit_number,Div);
		List<String> act_review_code=phy_val.review_val(exp_review);
		if(act_review_code.get(0).equals(exp_review))
		{	
			Assert.assertEquals(act_review_code.get(0),exp_review);
			Reporter.addStepLog("Values returned " +act_review_code.get(0));
			Reporter.addStepLog("Expected outcome " +exp_review);
		}
	}	
	else if(screen.equals("HO409"))
	{	
		Hospital_HO409 hos_val = new Hospital_HO409();
		hos_val.HO409_Inquire(Audit_number, Div);
		List<String> act_review_code=hos_val.review_val(exp_review);
		if(!act_review_code.get(0).equals(exp_review))
		{	
			Assert.assertNotEquals(act_review_code.get(0),exp_review);
			Reporter.addStepLog("Review not found " +act_review_code.get(0));
			Reporter.addStepLog("Expected review " +exp_review);
		}
		else
		{
			Reporter.addStepLog("Values returned " +act_review_code.get(0));
		}
	}
}
@When("^for the audit number \"([^\"]*)\" number of contract is more than (\\d+) in  \"([^\"]*)\"$")
public void for_the_audit_number_number_of_contract_is_more_than_in(String Audit_number, int arg2, String screen) throws Throwable {
	FunctionLibrary.navigateToDiv(screen);
	Hospital_HO410 hos_val = new Hospital_HO410();
	hos_val.HO410_Inquire(Audit_number, Div);
	String l_contract=hos_val.last_category_number_val();
	if(!l_contract.equalsIgnoreCase("000000"))
	{
		Reporter.addStepLog("Already 10 contracts applied. Review 730 should apply on claim " );
	}
	else
	{
		Reporter.addStepLog("Lesser than 10 contracts. Review 730 should not apply on claim " );
	}
}

}
