package stepDefinition;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.testng.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.*;
import pages.OutPatient_AU300;
import pages.Physician_CL140;
import pages.ConditionCode_TB223;
import pages.Hospital_HO400;
import pages.Hospital_HO409;
import pages.Hospital_HO410;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL209;
import util.FunctionLibrary;

public class HardCodedReviewStepDefinition {
	public String Audit_number,Div,to_date,act_app_val,grp_exp_date,eff_date,act_from_date,act_thru_date,act_bpl;


@When("^The provider on claim is \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
public void the_provider_on_claim_is_is_present_on_screen(String prov, String screen) throws Throwable {
	if(screen.equals("CL201"))
	{	
		Physician_CL201 phy_val = new Physician_CL201();
		String act_provider =phy_val.prov_val();
		Assert.assertEquals(act_provider,prov);
		Reporter.addStepLog("Actual provider is " +act_provider);
	}
	else if (screen.equals("HO400"))
	{
		Hospital_HO400 hos_val = new Hospital_HO400();
		String act_provider =hos_val.prov_val();
		Assert.assertEquals(act_provider,prov);
		Reporter.addStepLog("Actual provider " +act_provider);
	}
}

@Then("^the claim \"([^\"]*)\" is hit with review \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_claim_is_hit_with_review_in_screen(String Audit_number,String exp_review, String screen) throws Throwable {
	Thread.sleep(1000);
	FunctionLibrary.navigateToDiv(screen);
	if(screen.equals("CL209"))
	{	
		Physician_CL209 phy_val = new Physician_CL209();
		phy_val.CL209_Inquire(Audit_number,Div);
		List<String> act_review_code=phy_val.review_val(exp_review);
		if(act_review_code.get(0).equals(exp_review))
		{	
			Assert.assertEquals(act_review_code.get(0),exp_review);
			Reporter.addStepLog("Values returned " +act_review_code.get(0));
			Reporter.addStepLog("Expected outcome " +exp_review);
		}
	}	
	else if(screen.equals("HO409"))
	{	
		Hospital_HO409 hos_val = new Hospital_HO409();
		hos_val.HO409_Inquire(Audit_number, Div);
		List<String> act_review_code=hos_val.review_val(exp_review);
		if(act_review_code.get(0).equals(exp_review))
		{	
			Assert.assertEquals(act_review_code.get(0),exp_review);
			Reporter.addStepLog("Values returned " +act_review_code.get(0));
			Reporter.addStepLog("Expected outcome " +exp_review);
		}
		else
		{
			Reporter.addStepLog("Values returned " +act_review_code.get(0));
		}
	}
}

@When("^the \"([^\"]*)\" value is \"([^\"]*)\" and \"([^\"]*)\" is \"([^\"]*)\" and \"([^\"]*)\" is \"([^\"]*)\" from \"([^\"]*)\" in database \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\"$")
public void the_value_is_and_is_and_is_from_in_database_for_primary_key_as_and_as_and_as_and_as(String kfield1, String kvalue1, String kfield2, String kvalue2, String kfield3, String kvalue3, String tablename, String db, String i_field1, String i_value1, String i_field2, String i_value2, String i_field3, String i_value3, String i_field4, String i_value4) throws Throwable {
    
	ArrayList<String> exp_values = new ArrayList<String>();
	List<String> act_values = FunctionLibrary.DB2_return_three_values(kfield1, db, tablename, kfield2, kfield3, i_field1, i_value1, i_field2, i_value2, i_field3, i_value3, i_field4, i_value4);
	exp_values.add(kvalue1.trim());
	exp_values.add(kvalue2.trim());
	exp_values.add(kvalue3.trim());
	for(int i=0;i<exp_values.size();i++){
		if(exp_values.get(i).trim().equals(act_values.get(i).trim())){
			Reporter.addStepLog("Passed: Expected db values " +exp_values.get(i));
			Reporter.addStepLog("Passed: Actual db values " +act_values.get(i));
		}
		else{
			Reporter.addStepLog("Failed: Expected db values " +exp_values.get(i));
			Reporter.addStepLog("Failed: Actual db values " +act_values.get(i));
		}
	}	
}   

@Given("^for the audit number \"([^\"]*)\" the (\\d+)rd digit of type of bill \"([^\"]*)\" is (\\d+) in screen \"([^\"]*)\"$")
public void for_the_audit_number_the_rd_digit_of_type_of_bill_is_in_screen(String Audit_number,int index, String bill , int digit, String screen) throws Throwable {
	Thread.sleep(1000);
	FunctionLibrary.navigateToDiv(screen);
	if (screen.equals("HO410"))
	{
		Hospital_HO410 hos_val = new Hospital_HO410();
		//hos_val.HO410_Inquire(Audit_number, Div);
		String act_bill_type =hos_val.bill_type_val();
		char bill_val = act_bill_type.charAt(index-1);
		String type_bill = bill_val+"";
		int bill_freq=Integer.parseInt(type_bill);
		if(digit==bill_freq)
		{	
			Assert.assertEquals(digit, bill_freq);
			Reporter.addStepLog("Actual bill frequency " +act_bill_type);
		}	
	}
}

@Given("^the \"([^\"]*)\" value is \"([^\"]*)\" from \"([^\"]*)\" in database \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\"$")
public void the_value_is_from_in_database_for_primary_key_as_and_as_and_as_and_as_and_as(String out_field, String out_value, String tablename, String db, String inp_field1, String inp_value1, String inp_field2, String inp_value2, String inp_field3, String inp_value3, String inp_field4, String inp_value4,String inp_field5, String inp_value5) throws Throwable {
	ArrayList<String> exp_values = new ArrayList<String>();
	List<String> act_values = FunctionLibrary.DB2_return_one_value(out_field, db, tablename, inp_field1, inp_value1, inp_field2, inp_value2, inp_field3, inp_value3, inp_field4, inp_value4,inp_field5, inp_value5);
	exp_values.add(out_value.trim());
	for(int i=0;i<exp_values.size();i++){
		if(exp_values.get(i).trim().equals(act_values.get(i).trim())){
			Reporter.addStepLog("Passed: Expected db values " +exp_values.get(i));
			Reporter.addStepLog("Passed: Actual db values " +act_values.get(i));
		}
		else{
			Reporter.addStepLog("Failed: Expected db values " +exp_values.get(i));
			Reporter.addStepLog("Failed: Actual db values " +act_values.get(i));
		}
	}
}

@Given("^the providers expiry date \"([^\"]*)\" is before member's discharge date \"([^\"]*)\"$")
public void the_providers_expiry_date_is_before_member_s_discharge_date(String s_date1, String s_date2) throws Throwable {
	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	Date date1 = sdf.parse(s_date1);
	Date date2 = sdf.parse(s_date2);
	if(date1.before(date2))
	{
		Reporter.addStepLog("Provider's expiry date "+s_date1+" is before member's discharge " +s_date2);
	}
	else
	{
		Reporter.addStepLog("Provider's expiry date "+s_date1+" is after member's discharge " +s_date2);
	}
	
    
}
@When("^the comments for the claim \"([^\"]*)\" should be displayed in screen \"([^\"]*)\"$")
public void the_comments_for_the_claim_should_be_displayed_in_screen(String Audit_number,String screen) throws Throwable {
	
		FunctionLibrary.navigateToDiv(screen);
		if(screen.equals("CL202"))
		{	
			Physician_CL209 phy_val = new Physician_CL209();
			phy_val.CL209_Inquire(Audit_number,Div);
			
		}	
		else if(screen.equals("HO410"))
		{	
			Hospital_HO410 hos_val = new Hospital_HO410();
			String act_comments = hos_val.comments_val().trim();
			if(!act_comments.equals(""))
			{	
				Reporter.addStepLog("Comment on claim is  " +act_comments);
							}
			}
    
}
@When("^the remarks flag \"([^\"]*)\" value is \"([^\"]*)\" from \"([^\"]*)\" in database \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\"$")
public void the_remarks_flag_value_is_from_in_database_for_primary_key_as_and_as(String out_field1, String out_value1, String tablename, String db, String inp_field1, String inp_value1, String inp_field2, String inp_value2) throws Throwable {
	String act_remark_flag = FunctionLibrary.DB2Validation_Div(out_field1, db, tablename, inp_field1, inp_value1, inp_field2, inp_value2);
	if(out_value1.equals(act_remark_flag))
	{
		Assert.assertEquals(out_value1, act_remark_flag);
		Reporter.addStepLog("Actual remark flag is " +act_remark_flag);
	}
	else
	{
		Reporter.addStepLog("Actual remark flag is " +act_remark_flag);
	}
}

@When("^the BPL \"([^\"]*)\" value is \"([^\"]*)\" from \"([^\"]*)\" in database \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\"$")
public void the_BPL_value_is_from_in_database_for_primary_key_as_and_as(String out_field1, String out_value1, String tablename, String db, String inp_field1, String inp_value1, String inp_field2, String inp_value2) throws Throwable {
	String act_return_value = FunctionLibrary.DB2Validation_Div(out_field1, db, tablename, inp_field1, inp_value1, inp_field2, inp_value2);
	if(out_value1.equals(act_return_value))
	{
		Assert.assertEquals(out_value1, act_return_value);
		Reporter.addStepLog("No BPL record exists");
	}
	else
	{
		Reporter.addStepLog("Actual BPL is " +act_return_value);
	}
}

@When("^the category number is \"([^\"]*)\" and sub category number is \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_category_number_is_and_sub_category_number_is_in_screen(String cat_num, String sub_cat_num, String screen) throws Throwable {
	Thread.sleep(1000);
	FunctionLibrary.navigateToDiv(screen);
	Hospital_HO410 hos_val = new Hospital_HO410();
	String act_cat_num = hos_val.category_number_val();
	String exp_category_number = cat_num.concat(sub_cat_num);
	if(exp_category_number.equals(act_cat_num))
	{
		Reporter.addStepLog("Category number is missing;745 review should hit on claim" );
	}
	else
	{
		Reporter.addStepLog("Category number is " +act_cat_num);
	}
}

@When("^the number of units on claim exceeds approved LOS$")
public void the_number_of_units_on_claim_exceeds_approved_LOS() throws Throwable {
    String pac_los = FunctionLibrary.DB2Validation_Div("PAA_ORIG_LOS", "D9331COA", "PACADMIT", "PAA_HMO_ID", "MSP", "PAA_ADMIT_NBR", "84645143");
    String total_units = FunctionLibrary.Total_DB2Validation_Div("HDTL_UNIT_SVC", "D9331COA", "HDTL_DATA", "HDTL_SITE_ID", "MSP", "HDTL_AUDIT_NBR", "069255529");
    int pac_units = Integer.parseInt(pac_los);
    int claim_units = Integer.parseInt(total_units);
    if(claim_units > pac_units)
    {
    	Reporter.addStepLog("PAC_admit units " +pac_units );
    	Reporter.addStepLog("Total number units on claim" +claim_units );
    	Reporter.addStepLog("Claim should display 757 review." );
    }
    else
    {
    	Reporter.addStepLog("PAC_admit units " +pac_units );
    	Reporter.addStepLog("Total number units on claim " +claim_units );
    	Reporter.addStepLog("Claim should  not display 757 review." );
    }
}

@When("^The dates of service on the claim is within the administrative hold dates on the Member$")
public void the_dates_of_service_on_the_claim_is_within_the_administrative_hold_dates_on_the_Member() throws Throwable {
	List<String> datespan = FunctionLibrary.Ret_TwoValues_DB2Validation_Div("CLM_FROM_CYMD", "CLM_THRU_CYMD", "D9331COA", "DRCLAIMS", "CLM_HMO_ID", "MEC", "CLM_AUDNBR", "67392128");
	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	Date date1 = sdf.parse(datespan.get(0));
	Date date2 = sdf.parse(datespan.get(1));
	List<String> memadminhold = FunctionLibrary.Ret_TwoValues_DB2Validation_InputFour("MEM_AD_EFF_CYMD", "MEM_AD_EXP_CYMD", "D9331COA", "MEMMSTR", "MEM_HMO_ID", "MEC", "MEM_MEMGRP", "07592", "MEM_MEMSUB", "000093770", "MEM_MEMDEP", "00");
	Date memdate1 = sdf.parse(memadminhold.get(0));
	Date memdate2 = sdf.parse(memadminhold.get(1));
	
	if(date1.after(memdate1) || date2.before(memdate2))
	{
		Reporter.addStepLog("The dates of service on the claim "+datespan.get(0)+" - " +datespan.get(1)+ " is within member's administrative hold dates " +memadminhold.get(0)+" - " +memadminhold.get(1));
	}
	else
	{
		Reporter.addStepLog("The dates of service on the claim "+datespan.get(0)+" - " +datespan.get(1)+ " is not within member's administrative hold dates " +memadminhold.get(0)+" - " +memadminhold.get(1));
	}
}
@When("^The dates of service on the claim is within the administrative hold dates on the Provider$")
public void the_dates_of_service_on_the_claim_is_within_the_administrative_hold_dates_on_the_Provider() throws Throwable {
	List<String> datespan = FunctionLibrary.Ret_TwoValues_DB2Validation_Div("HPC_FROM_CYMD", "HPC_THRU_CYMD", "D9331COA", "HPC_DATA", "HPC_SITE_ID", "OEB", "HPC_AUDIT_NBR", "090219555");
	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	Date date1 = sdf.parse(datespan.get(0));
	Date date2 = sdf.parse(datespan.get(1));
	List<String> provadminhold = FunctionLibrary.Ret_TwoValues_DB2Validation_InputFour("PDE_AHLD_EF_CYMD2", "PDE_AHLD_EX_CYMD2", "D9331COA", "PDE_DATA", "PDE_SITE_ID", "OEB", "PDE_PROVIDER_TYPE", "0050", "PDE_PROVIDER_NBR", "0000010", "PDE_RECORD_TYPE", "1");
	Date provdate1 = sdf.parse(provadminhold.get(0));
	Date provdate2 = sdf.parse(provadminhold.get(1));
	
	if(date1.after(provdate1) || date2.before(provdate2))
	{
		Reporter.addStepLog("The dates of service on the claim "+datespan.get(0)+" - " +datespan.get(1)+ " is within provider's administrative hold dates " +provadminhold.get(0)+" - " +provadminhold.get(1));
	}
	else
	{
		Reporter.addStepLog("The dates of service on the claim "+datespan.get(0)+" - " +datespan.get(1)+ " is not within provider's administrative hold dates " +provadminhold.get(0)+" - " +provadminhold.get(1));
	} 
}

@When("^The dates of service on the claim \"([^\"]*)\" in division \"([^\"]*)\" is within the administrative hold dates on the Master Group \"([^\"]*)\" for group \"([^\"]*)\"$")
public void the_dates_of_service_on_the_claim_in_division_is_within_the_administrative_hold_dates_on_the_Master_Group_for_group(String Audit_number,String Div,String mgroup, String grp) throws Throwable {
	String main_aud = Audit_number.substring(0,8);
	List<String> datespan = FunctionLibrary.Ret_TwoValues_DB2Validation_Div("CLM_FROM_CYMD", "CLM_THRU_CYMD", "D9331COA", "DRCLAIMS", "CLM_HMO_ID", Div, "CLM_AUDNBR", main_aud);
	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	Date date1 = sdf.parse(datespan.get(0));
	Date date2 = sdf.parse(datespan.get(1));
	List<String> grpadminhold = FunctionLibrary.Ret_TwoValues_DB2Validation_InputThree("GRP_AD_EFF_CYMD", "GRP_AD_EXP_CYMD", "D9331COA", "GRPMSTR", "GRP_HMO_ID", Div, "GRP_MEMGRP", grp, "GRP_MSTR_GRP_NBR", mgroup);
	Date grpdate1 = sdf.parse(grpadminhold.get(0));
	Date grpdate2 = sdf.parse(grpadminhold.get(1));
	
	if(date1.after(grpdate1) || date2.before(grpdate2))
	{
		Reporter.addStepLog("The dates of service on the claim "+datespan.get(0)+" - " +datespan.get(1)+ " is within group's administrative hold dates " +grpadminhold.get(0)+" - " +grpadminhold.get(1));
	}
	else
	{
		Reporter.addStepLog("The dates of service on the claim "+datespan.get(0)+" - " +datespan.get(1)+ " is not within group's administrative hold dates " +grpadminhold.get(0)+" - " +grpadminhold.get(1));
	}
}

@When("^The contract setup for the claim is \"([^\"]*)\" in region \"([^\"]*)\" for table \"([^\"]*)\" in division \"([^\"]*)\" for the provider \"([^\"]*)\" with panel \"([^\"]*)\" and category number \"([^\"]*)\" and sub-category \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_contract_setup_for_the_claim_is_in_region_for_table_in_division_for_the_provider_with_panel_and_category_number_and_sub_category_in_screen(String exp_contract, String region,String dbname,String site, String prov, String prov_panel, String cat_num, String subcat_num, String screen) throws Throwable {
	Hospital_HO400 hos_val = new Hospital_HO400();
	String exp_prov_type =hos_val.prov_type_val();
	String exp_prov = hos_val.prov_num_val();
	String link_nbr = FunctionLibrary.SingleOutput_DB2Validation_DivInputFourKeyValue("PSH_LINK_NBR", region, "PSH_DATA", "PSH_SITE_ID", site, "PSH_PRV_TP", exp_prov_type, "PSH_PRV_NBR", "PSH_PANEL_NBR", exp_prov, prov_panel);
	String act_rate_type = FunctionLibrary.SingleOutput_DB2Validation_DivInputFourKeyValue("PSD_RATE_TYPE", region, dbname, "PSD_SITE_ID", site, "PSD_LINK_NBR", link_nbr, "PSD_CATEGORY", "PSD_CAT_SUBNBR", cat_num, subcat_num);
	Assert.assertEquals(act_rate_type, exp_contract);
	Reporter.addStepLog("Expected contract is " +exp_contract);
	Reporter.addStepLog("Actual contract is " +act_rate_type);
}

@When("^the number of units on claim \"([^\"]*)\" in division \"([^\"]*)\"from \"([^\"]*)\" in region \"([^\"]*)\"is more than allowed units \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_number_of_units_on_claim_in_division_from_in_region_is_more_than_allowed_units_in_screen(String audit,String site,String table,String region,String exp_units, String screen) throws Throwable {
    String act_units = FunctionLibrary.Total_DB2Validation_DivInputThree("HDTL_UNIT_SVC", region, "HDTL_DATA", "HDTL_SITE_ID", site, "HDTL_AUDIT_NBR", audit, "HDTL_FROM_CYMD", "HDTL_THRU_CYMD");
    int e_units=Integer.parseInt(exp_units);
    int a_units = Integer.parseInt(act_units);
    if(a_units > e_units)
    {
    	Reporter.addStepLog("Passed: Actual units on claim is greater than allowed, 758 review should hit on claim" );
    	Reporter.addStepLog("Passed: Actual units on claim is " +a_units);
    	Assert.assertTrue(a_units>e_units);
    }
    else if(a_units <= e_units)
    {
    	Reporter.addStepLog("Failed: Actual units on claim is lesser than allowed, 758 review should not hit on claim" +a_units);
    	Assert.assertTrue(a_units<=e_units);
    }	
    
}
@When("^the claim \"([^\"]*)\" uses a condition code \"([^\"]*)\" listed in screen \"([^\"]*)\"$")
public void the_claim_uses_a_condition_code_listed_in_screen(String audit, String exp_con_code, String screen) throws Throwable {
	Thread.sleep(2000);
	FunctionLibrary.navigateToDiv(screen);
	ConditionCode_TB223 TB223_val= new ConditionCode_TB223();
	TB223_val.TB223_Inquire(exp_con_code);
    String line1_con_code=TB223_val.cc_val();
    if(exp_con_code.equalsIgnoreCase(line1_con_code))
    {
    	Reporter.addStepLog("Condition code " +line1_con_code+ " is present in screen TB223");
    	Assert.assertTrue(true);
    }
    
}

@When("^the \"([^\"]*)\" value is \"([^\"]*)\" from \"([^\"]*)\" in database \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\"$")
public void the_value_is_from_in_database_for_primary_key_as(String output_field, String exp_cc, String tablename, String region, String prim_key, String prim_val) throws Throwable {
	String act_val= FunctionLibrary.DB2Validation(output_field, region, tablename, prim_key, prim_val);
	act_val = act_val.trim();
	if(exp_cc.equals(act_val))
	{
		Assert.assertEquals(act_val, exp_cc);
		Reporter.addStepLog("Actual value for " +output_field+ " is " +act_val);
	}
	else
	{
		Reporter.addStepLog("Step failed: Value obtained for "+output_field+ " is " +act_val);
	}

}
@When("^the recovery flag is \"([^\"]*)\" for audit number \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void the_recovery_flag_is_for_audit_number_in_screen(String exp_rec_flag, String audit, String screen) throws Throwable {
	FunctionLibrary.navigateToDiv(screen);
	if(screen.equalsIgnoreCase("CL202"))
    {
		Physician_CL202 phy_val = new Physician_CL202();
		phy_val.CL202_Inquire(audit,Div);
		String act_rec_flag = phy_val.rec_flag_val();
		if(act_rec_flag.equalsIgnoreCase(exp_rec_flag))
		{
			Assert.assertEquals(act_rec_flag, exp_rec_flag);
			Reporter.addStepLog("Passed: Value obtained for recovery flag is " +act_rec_flag);
		}
		else
		{
			Reporter.addStepLog("Failed: Value obtained for recovery flag is " +act_rec_flag);
		}
    }
}
@When("^the number of units \"([^\"]*)\" on claim \"([^\"]*)\" in screen \"([^\"]*)\" is equal to notified units \"([^\"]*)\" in screen \"([^\"]*)\" for the authorization \"([^\"]*)\"$")
public void the_number_of_units_on_claim_in_screen_is_equal_to_notified_units_in_screen_for_the_authorization(String his_exp_units, String Audit_number, String screen, String notif_units, String screen1, String auth_num) throws Throwable {
	FunctionLibrary.navigateToDiv(screen1);
	int exp_units=Integer.parseInt(his_exp_units);
	if(screen1.equalsIgnoreCase("AU300"))
    {
		OutPatient_AU300 auth_val = new OutPatient_AU300();
		auth_val.AU300_Inquire(auth_num,"AU300");
		Thread.sleep(1000);
		String auth_units=auth_val.notif_units_val();
		int a_units = Integer.parseInt(auth_units);
		if(exp_units<=a_units)
		{
			Reporter.addStepLog("Passed: For history claim, number of units should be equal to the number of units on the authorization " +exp_units);
		}
		else
		{
			Reporter.addStepLog("Failed: The history claim, number of units is not equal to the number of units on the authorization " +exp_units);
		}
    }	
}

@When("^The number of units \"([^\"]*)\" exceeds the actual authorized services on the authorization \"([^\"]*)\" in screen \"([^\"]*)\" for the authorization \"([^\"]*)\"$")
public void the_number_of_units_exceeds_the_actual_authorized_services_on_the_authorization_in_screen_for_the_authorization(String c_units, String notif_units, String screen1, String auth_num) throws Throwable {
	FunctionLibrary.navigateToDiv(screen1);
	int exp_units=Integer.parseInt(c_units);
	if(screen1.equalsIgnoreCase("AU300"))
    {
		OutPatient_AU300 auth_val = new OutPatient_AU300();
		auth_val.AU300_Inquire(auth_num,"AU300");
		Thread.sleep(1000);
		String auth_units=auth_val.notif_units_val();
		int a_units = Integer.parseInt(auth_units);
		if(exp_units>=a_units)
		{
			Reporter.addStepLog("Passed: History claim, already reached the maximum permissible RTS authorized units.Review 73 should hit. Unit on current claim is " +exp_units);
		}
		else
		{
			Reporter.addStepLog("Failed: The history claim, has not reached the number of units on the authorization. eview 73 should hit. Unit on current claim is " +exp_units);
		}
    }
}

@When("^get the outfield \"([^\"]*)\" value is \"([^\"]*)\" in dbtable \"([^\"]*)\" for region \"([^\"]*)\" based on input field \"([^\"]*)\" value as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\"$")
public void get_the_outfield_value_is_in_dbtable_for_region_based_on_input_field_value_as_and_input_field_as_and_input_field_as_and_input_field_as(String out_field1, String out_val, String table, String region, String in_field1, String in_val1, String in_field2, String in_val2, String in_field3, String in_val3, String in_field4, String div) throws Throwable {
    
	Thread.sleep(500);
	act_app_val = FunctionLibrary.SingleOutputValue_DB2Validation_DivInputFour(out_field1, region, table, in_field4, div, in_field1, in_val1, in_field2, in_val2,in_field3,in_val3);
	Reporter.addStepLog("Actual value returned from db table is " +act_app_val);
	Reporter.addStepLog("Expected value for the field is " +out_val);
	this.to_date= act_app_val;
	}
@When("^get the outfield \"([^\"]*)\" value is \"([^\"]*)\" in dbtable \"([^\"]*)\" for region \"([^\"]*)\" based on input field \"([^\"]*)\" value as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\" and input field \"([^\"]*)\" as \"([^\"]*)\"$")
public void get_the_outfield_value_is_in_dbtable_for_region_based_on_input_field_value_as_and_input_field_as_and_input_field_as(String Field, String svc_val, String Tablename, String Region, String keyfield, String keyvalue, String keyfield1, String keyvalue1,String keyfield2, String keyvalue2) throws Throwable {
   Hospital_HO400 hos_screen = new Hospital_HO400();
   String act_bpl= hos_screen.bpl_num();
   String bpl_svc_code=null;
   try
   {
	   
   bpl_svc_code = FunctionLibrary.SingleOutput_DB2Validation_DivInputThreeKeyValue(Field, Region, Tablename, keyfield1, keyvalue1, keyfield, act_bpl,keyfield2,keyvalue2);
   Reporter.addStepLog("Output of query is " +bpl_svc_code);
   }
   finally
   {
	   Assert.assertTrue(true);
	   Reporter.addStepLog("BPL used for the claim is " +act_bpl);
	   Reporter.addStepLog("Default service code 0999 is not present " +bpl_svc_code);
	   
   }
}

@When("^the service code \"([^\"]*)\" is missing in screen \"([^\"]*)\"$")
public void the_service_code_is_missing_in_screen(String svc, String screen) throws Throwable {
	Hospital_HO400 hos_screen = new Hospital_HO400();
	String act_svc= hos_screen.svc1_val();
	System.out.println(act_svc);
	if(act_svc.length()<6)
	{
		Reporter.addStepLog("Service code is missing. Claim should hit 702 review " +act_svc);
	}
}
@When("^\"([^\"]*)\" is before the audit number \"([^\"]*)\" thru date \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void is_before_the_audit_number_thru_date_in_screen(String exp_date, String Audit_number, String to_date, String screen) throws Throwable {
	Hospital_HO400 hos_screen = new Hospital_HO400();
	String act_to_date=hos_screen.thru_date();
	String new_to_date = this.to_date.substring(4, 6).concat(this.to_date.substring(6, 8)).concat(this.to_date.substring(2, 4)); 
	FunctionLibrary.DateComparision(act_to_date, new_to_date);
	Reporter.addStepLog("To date on claim " +act_to_date);
	Reporter.addStepLog("Provider contract expiry date " +new_to_date);
}

@When("^the \"([^\"]*)\" value  \"([^\"]*)\" is obtained from \"([^\"]*)\" in database \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\"$")
public void the_value_is_obtained_from_in_database_for_primary_key_as_and_as(String outfield, String outval, String table, String db, String infield1, String inval1, String infield2, String inval2) throws Throwable {
	outval= FunctionLibrary.DB2Validation_Div(outfield, db, table, infield1, inval1,infield2,inval2);
	String dd=outval.substring(6,8);
	String mm=outval.substring(4,6);
	String yy = outval.substring(2,4);
	grp_exp_date = mm.concat(dd).concat(yy);
	Reporter.addStepLog("Expiry date of group  " +grp_exp_date);
	
}

@When("^the group's expiry date \"([^\"]*)\" is before member's admit date \"([^\"]*)\"$")
public void the_group_s_expiry_date_is_before_member_s_admit_date(String grp_exp, String frm_date) throws Throwable {
	Hospital_HO400 hos_screen = new Hospital_HO400();
	String act_from_date = hos_screen.from_date();
	SimpleDateFormat sdf = new SimpleDateFormat("MMddyy");
	Date date1 = sdf.parse(grp_exp_date);
	Date date2 = sdf.parse(act_from_date);
	if(date1.before(date2))
	{
		Reporter.addStepLog("Expiry date of group  " +date1+ "is before member's admit date " +date2);
	}
	else
	{
		Reporter.addStepLog("Expiry date of group:  " +date1+ " Claim from date" +date2);
	}
	
}

@Given("^get the fromDate \"([^\"]*)\" displayed in the screen \"([^\"]*)\"$")
public void get_the_fromDate_displayed_in_the_screen(String act_from_date, String screen) throws Throwable {
	Hospital_HO400 hos_screen = new Hospital_HO400();
	act_from_date = hos_screen.from_date();
	this.act_from_date=act_from_date;
}

@Given("^get the toDate \"([^\"]*)\" displayed in the screen \"([^\"]*)\"$")
public void get_the_toDate_displayed_in_the_screen(String act_thru_date, String screen) throws Throwable {
	Hospital_HO400 hos_screen = new Hospital_HO400();
	act_thru_date = hos_screen.from_date();
	this.act_thru_date=act_thru_date;
}

@When("^get the bpl number \"([^\"]*)\" from screen \"([^\"]*)\"$")
public void get_the_bpl_number_from_screen(String act_bpl, String screen) throws Throwable {
	Hospital_HO400 hos_screen = new Hospital_HO400();
	act_bpl = hos_screen.bpl_num();
	this.act_bpl=act_bpl;
}

@When("^obtain effective date \"([^\"]*)\" for bpl \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void obtain_effective_date_for_bpl_in_screen(String eff_date, String act_bpl, String screen) throws Throwable {
	FunctionLibrary.navigateToDiv(screen);
	Physician_CL140 bpl_screen = new  Physician_CL140();
	bpl_screen.CL140_Inquire(this.act_bpl, screen);
	eff_date=bpl_screen.effectiveDateValidation();
	this.eff_date=eff_date;
}

@Then("^effective date \"([^\"]*)\" for bpl is not coinciding with fromDate \"([^\"]*)\" of claim \"([^\"]*)\" in division \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void effective_date_for_bpl_is_not_coinciding_with_fromDate_of_claim_in_division_in_screen(String eff_date, String from_date, String Audit_number, String Div, String screen) throws Throwable {
	FunctionLibrary.navigateToDiv(screen);
	Hospital_HO400 hos_screen = new Hospital_HO400();
	hos_screen.HO400_Inquire(Audit_number, Div);
	SimpleDateFormat sdf = new SimpleDateFormat("MMddyy");
	Date date1 = sdf.parse(this.eff_date);
	Date date2 = sdf.parse(this.act_from_date);
	Date date3 = sdf.parse(this.act_thru_date);
	if(date1.before(date2))
	{
		Reporter.addStepLog("Failed: Effective date of BPL " +date1+ " is not after the from date of claim " +act_from_date);
	}
	else
	{
		Reporter.addStepLog("Passed: Effective date of BPL " +date1+ " is after the from date of claim " +act_from_date);
	}
}

}




