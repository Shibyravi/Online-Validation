package stepDefinition;

import org.testng.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import driver.DriverScript;
import pages.Hospital_HO400;
import pages.Hospital_HO409;
import pages.Hospital_HO410;
import pages.Hospital_HO430;
import pages.Member_GI101;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL209;
import pages.Provider_EP120;
import util.FunctionLibrary;

public class Auto_DenyStepDefination {

	public String Audit_number,Div;
	
	
//		@Given("^User launches mainframes environment and login to KOS session with valid credentials$")
//		public void user_launches_mainframes_environment_and_login_to_KOS_session_with_valid_credentials() throws Throwable {
//			DriverScript.getInstance();
//		  
//		}
//		@Given("^The user is in division \"([^\"]*)\" and inquires for the audit number \"([^\"]*)\" in the screen \"([^\"]*)\"$")
//		public void the_user_is_in_division_and_inquires_for_the_audit_number_in_the_screen(String Div, String Audit_number, String Screen) throws Throwable {
//			this.Div = Div;
//			this.Audit_number = Audit_number;
//			FunctionLibrary.changeSite();
//			//FunctionLibrary.retScreenObject(Screen, Audit_number, Div);
//			
//			
//			//Physician_CL201 phy_screen1 = new Physician_CL201();
//			if(Screen.equals("CL201"))
//			{	
//				Physician_CL201 phy_screen1 = new Physician_CL201();
//				phy_screen1.CL201_Inquire(Audit_number,Div);
//			}
//			else if(Screen.equals("CL202"))
//			{
//				Physician_CL202 phy_screen2 = new Physician_CL202();
//				phy_screen2.CL202_Inquire(Audit_number,Div);
//			}
//			else if(Screen.equals("CL209"))
//			{
//				Physician_CL209 phy_screen3 = new Physician_CL209();
//				phy_screen3.CL209_Inquire(Audit_number,Div);
//			}
//			else if(Screen.equals("HO400"))
//			{
//				Hospital_HO400 hos_screen1 = new Hospital_HO400();
//				hos_screen1.HO400_Inquire(Audit_number,Div);
//			}
//			else if(Screen.equals("HO410"))
//			{
//				Hospital_HO410 hos_screen2 = new Hospital_HO410();
//				hos_screen2.HO410_Inquire(Audit_number,Div);
//			}
//			else if(Screen.equals("HO430"))
//			{
//				Hospital_HO430 hos_screen3 = new Hospital_HO430();
//				hos_screen3.HO430_Inquire(Audit_number,Div);
//			}
//			else if(Screen.equals("HO409"))
//			{
//				Hospital_HO409 hos_screen4 = new Hospital_HO409();
//				hos_screen4.HO409_Inquire(Audit_number,Div);
//			}
//			
			
//}
		@When("^the FromDate\"([^\"]*)\" is present on screen \"([^\"]*)\"$")
		public void the_FromDate_is_present_on_screen(String From_Date, String Screen1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    Physician_CL201 phy_screen1 = new Physician_CL201();
		    String Act_From_Date=phy_screen1.from_val();
		    Assert.assertEquals(Act_From_Date, From_Date);
		    System.out.println("From Date is" +Act_From_Date);
		    Reporter.addStepLog("From Date is" +Act_From_Date);
		}

		
	


		@When("^the MemberID used is \"([^\"]*)\" on screen\"([^\"]*)\"$")
		public void the_MemberID_used_is_on_screen(String Member_ID, String Screen2) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			//FunctionLibrary.navigateToDiv(Screen2);
			FunctionLibrary.navigateToDiv(Screen2);
			
			Member_GI101 mem_screenG1 = new Member_GI101();
			Thread.sleep(2000);
			//mem_screenG1.select.setText("Number");
			mem_screenG1.GI101_Inquire(Member_ID);
			
		}

		@When("^the EffDate\"([^\"]*)\" is present on screen \"([^\"]*)\"$")
		public void the_EffDate_is_present_on_screen(String Eff_Date, String Screen2) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			Member_GI101 mem_screenG1 = new Member_GI101();
			String Act_EffDate=mem_screenG1.EffDate_val();
			//Assert.assertEquals(Eff_Date, Act_EffDate);
			System.out.println("Eff Date is" +Act_EffDate);
			FunctionLibrary f3=new FunctionLibrary();
			//mem_screenG1.Validate_Date();
			
		}	
		
		@Then("^the claim is Denied with the denial code \"([^\"]*)\" in screen \"([^\"]*)\"$")
		public void the_claim_is_Denied_with_the_denial_code_in_screen(String Screen1, String Detail_deny_code1) throws Throwable {
			Thread.sleep(2000);
			FunctionLibrary.navigateToDiv(Screen1);
			Thread.sleep(2000);
		Physician_CL201 phy_val1 = new Physician_CL201();
		phy_val1.CL201_Inquire(Audit_number, Div);
		String act_deny_code =phy_val1.rsn_code();
		Assert.assertEquals(act_deny_code,Detail_deny_code1 );
		System.out.println("Deny code is " +act_deny_code);
		Reporter.addStepLog("Deny code is " +act_deny_code);
		}
		
		
		@When("^the From Date\"([^\"]*)\" is present on screen \"([^\"]*)\"$")
		public void the_From_Date_is_present_on_screen(String From_Date, String Screen1) throws Throwable {
			Hospital_HO400 hos_screen400 = new Hospital_HO400();
		    String Act_From_Date=hos_screen400.From_Date_val();
		    Assert.assertEquals(Act_From_Date, From_Date);
		    System.out.println("From Date is" +Act_From_Date);
		    Reporter.addStepLog("From Date is" +Act_From_Date);
		}

		@When("^The MemberNBR \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
		public void the_MemberNBR_is_present_on_screen(String Member_NBR, String Screen1) throws Throwable {
			Hospital_HO400 hos_screen400 = new Hospital_HO400();
			String Act_MemberID=hos_screen400.member_val();
			//Assert.assertEquals(Act_MemberID, Member_NBR);
		    System.out.println("Member Number is" +Act_MemberID);
		    Reporter.addStepLog("Member_NBR is" +Act_MemberID);
		}

		@When("^the MemberNBR used is \"([^\"]*)\" on screen\"([^\"]*)\"$")
		public void the_MemberNBR_used_is_on_screen(String Member_NBR, String Screen2) throws Throwable {

			FunctionLibrary.navigateToDiv(Screen2);
			Member_GI101 mem_screenG1 = new Member_GI101();
			Thread.sleep(2000);
			//mem_screenG1.select.setText("Number");
			mem_screenG1.GI101_Inquire(Member_NBR);
		}
		
		@When("^the Effective_Date\"([^\"]*)\" is present on screen \"([^\"]*)\"$")
		public void the_Effective_Date_is_present_on_screen(String arg1, String arg2) throws Throwable {
			// Write code here that turns the phrase above into concrete actions
						Member_GI101 mem_screenG1 = new Member_GI101();
						String Act_EffDate=mem_screenG1.EffDate_val();
						//Assert.assertEquals(Eff_Date, Act_EffDate);
						System.out.println("Eff Date is" +Act_EffDate);
					
						
						//mem_screenG1.Validate_Date();
		}

//		

//		@When("^the Eff_Date\"([^\"]*)\" is present on screen \"([^\"]*)\"$")
//		public void the_Eff_Date_is_present_on_screen(String Eff_Date, String From_Date) throws Throwable {
//			Member_GI101 mem_screenG1 = new Member_GI101();
//			String Act_EffDate=mem_screenG1.EffDate_val();
//		    Physician_CL201 phy_screen1 = new Physician_CL201();
//		    String Act_From_Date=phy_screen1.from_val();
//			System.out.println("Eff Date is" +Act_EffDate);
//			//Assert.assertEquals(Eff_Date, Act_EffDate);
//			System.out.println("Acc Date is" +From_Date);
//			FunctionLibrary f3=new FunctionLibrary();
//			mem_screenG1.Validate_Date();
//		}
		
		@Then("^the claim \"([^\"]*)\" is header denied with the denial code \"([^\"]*)\" in screen \"([^\"]*)\" in division \"([^\"]*)\"$")
		public void the_claim_is_header_denied_with_the_denial_code_in_screen_in_division(String Audit_number, String hdr_deny_code, String screen,String Div) throws Throwable {

			if(screen.equals("CL201"))
			{	
				Physician_CL201 phy_val = new Physician_CL201();
				if(phy_val.cur_screen.equals(2))
				{	
				String act_hdr_deny_code =phy_val.hdr_deny_val();
				Assert.assertEquals(act_hdr_deny_code,hdr_deny_code);
				Reporter.addStepLog("Header deny code is " +act_hdr_deny_code);
				}
				else
				{
					FunctionLibrary.navigateToDiv(screen);
					String act_hdr_deny_code =phy_val.hdr_deny_val();
					Assert.assertEquals(act_hdr_deny_code,hdr_deny_code);
					Reporter.addStepLog("Header deny code is " +act_hdr_deny_code);
					
				}
			}
			else if (screen.equals("HO400"))
			{
		
				Hospital_HO400 hos_val = new Hospital_HO400();
				if(hos_val.cur_screen.equals(2))
				{
				String act_hdr_deny_code =hos_val.hdr_deny_val();
				Assert.assertEquals(act_hdr_deny_code,hdr_deny_code);
				Reporter.addStepLog("Header deny code is " +act_hdr_deny_code);
				}
				else
				{
					FunctionLibrary.navigateToDiv(screen);
					Thread.sleep(1000);
					
					hos_val.HO400_Inquire(Audit_number, Div);
					Thread.sleep(2000);
					String act_hdr_deny_code =hos_val.hdr_deny_val();
					Assert.assertEquals(act_hdr_deny_code,hdr_deny_code);
					Reporter.addStepLog("Header deny code is " +act_hdr_deny_code);
					
				}
			}
		}
		
		@When("^the From_Date\"([^\"]*)\" is present on screen \"([^\"]*)\"$")
		public void the_From_Date_is_present_on_screenCL201(String From_Date, String Screen1) throws Throwable {
			 Physician_CL201 phy_screen1 = new Physician_CL201();
			    String Act_From_Date=phy_screen1.from_val();
			    Assert.assertEquals(Act_From_Date, From_Date);
			    System.out.println("From Date is" +Act_From_Date);
			    Reporter.addStepLog("From Date is" +Act_From_Date);
		   
		}

		@When("^The Member_ID \"([^\"]*)\" is present on screen \"([^\"]*)\"$")
		public void the_Member_ID_is_present_on_screen(String Member_ID, String Screen1) throws Throwable {
			Physician_CL201 phy_screen1 = new Physician_CL201();
			String Act_MemberID=phy_screen1.mem_val();
			//Assert.assertEquals(Act_MemberID, Member_ID);
		    System.out.println("Member ID is" +Act_MemberID);
		    Reporter.addStepLog("From Date is" +Act_MemberID);
		
		}

		@When("^the Group_ID used is \"([^\"]*)\" on screen\"([^\"]*)\"$")
		public void the_Group_ID_used_is_on_screen(String Group_ID, String Screen2) throws Throwable {
			FunctionLibrary.navigateToDiv(Screen2);
			Provider_EP120 prov_screenp1 = new Provider_EP120();
			Thread.sleep(2000);
			//mem_screenG1.select.setText("Number");
			prov_screenp1.EP120_Inquire(Group_ID);
		   
		}

		
		
		@When("^the Eff_Date\"([^\"]*)\" is present on screen \"([^\"]*)\"$")
		public void the_Eff_Date_is_present_on_screen(String Eff_Date, String Screen2) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			Provider_EP120 prov_screenp1 = new Provider_EP120();
			String Acct_Eff_Date=prov_screenp1.EFFective_date();
			System.out.println("Effective Date is"  + Acct_Eff_Date);
			//Assert.assertEquals(Eff_Date, Acct_Eff_Date);
		}

		@Then("^the claim is header denied with the denial_code \"([^\"]*)\" in screen \"([^\"]*)\"$")
		public void the_claim_is_header_denied_with_the_denial_code_in_screen(String deny_code, String Screen) throws Throwable {
		    Thread.sleep(2000);
			FunctionLibrary.navigateToDiv(Screen);
			Thread.sleep(2000);
		Physician_CL201 phy_val1 = new Physician_CL201();
		phy_val1.CL201_Inquire(Audit_number, Div);
		String act_deny_code =phy_val1.rsn_code();
		Assert.assertEquals(act_deny_code,deny_code );
		System.out.println("Deny code is " +act_deny_code);
		Reporter.addStepLog("Deny code is " +act_deny_code);
		    
		}
		
		@Then("^Rsn_Code(\\d+) \"([^\"]*)\" is displayed on \"([^\"]*)\"$")
		public void rsn_code_is_displayed_on(int A, String RSN_CODE2, String Screen1) throws Throwable {
			String Act_RSN__CODE2=null;
			Physician_CL201 phy_screen1 = new Physician_CL201();
			Act_RSN__CODE2 = phy_screen1.det2_deny_val();
			Assert.assertEquals(RSN_CODE2,Act_RSN__CODE2);
		}
		
		public void the_CPT_code_used_is_in_screen(int A, String CPT2, String Screen1) throws Throwable {
			String Act_CPT2__CODE=null;
			Physician_CL201 phy_screen1 = new Physician_CL201();
			Act_CPT2__CODE = phy_screen1.proc2_val();
			Assert.assertEquals(Act_CPT2__CODE,CPT2);
		}
		
		public void the_CPT_code_is_used_in_screen(int A, String CPT2, String Screen1) throws Throwable {
			String Act_CPT2__CODE=null;
			Physician_CL201 phy_screen1 = new Physician_CL201();
			Act_CPT2__CODE = phy_screen1.proc2_val();
			Assert.assertEquals(Act_CPT2__CODE,CPT2);
		}
		
		@Then("^the claim denied with the denial code \"([^\"]*)\" for detail line \"([^\"]*)\" in screen \"([^\"]*)\"$")
		public void the_claim_denied_with_the_denial_code_for_detail_line_in_screen(String Detail_deny_code2, String CPT2, String Screen1) throws Throwable {
		    String Act_DenialCode= null;
		    Hospital_HO400 HOS=new Hospital_HO400();
		    Act_DenialCode=HOS.det_deny1_val();
		    Assert.assertEquals(Act_DenialCode,Detail_deny_code2);
		}
		
		@Given("^The CPT(\\d+) code used is within the range of \"([^\"]*)\" in screen \"([^\"]*)\"$")
		public void the_CPT_code_used_is_within_the_range_of_in_screen(int B, String CPT2, String Screen1) throws Throwable {
			String Act_CPT= null;
		    Hospital_HO400 HOS=new Hospital_HO400();
		    Act_CPT=HOS.Review_Code_val();
		    Assert.assertEquals(Act_CPT,CPT2);
		}
		
//		@Then("^the claim is denied with the Header_denial code \"([^\"]*)\" in screen \"([^\"]*)\"$")
//		public void the_claim_is_denied_with_the_denial_code_in_screen(String Header_deny_code, String Screen1) throws Throwable {
//			FunctionLibrary.navigateToDiv(Screen1);
//			Physician_CL201 phy_val1 = new Physician_CL201();
//			phy_val1.CL201_Inquire(Audit_number, Div);
//			String act_deny_code =phy_val1.hdr_deny_val();
//			Assert.assertEquals(act_deny_code,Header_deny_code );
//			System.out.println("Deny code is " +act_deny_code);
//			Reporter.addStepLog("Deny code is " +act_deny_code);
//		}
		
		//det_deny1_val()
		
		
}
