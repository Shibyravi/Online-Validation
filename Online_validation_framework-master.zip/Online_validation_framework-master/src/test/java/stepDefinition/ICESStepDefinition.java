package stepDefinition;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;

import com.cucumber.listener.Reporter;

import cucumber.api.DataTable;
import cucumber.api.java.en.*;
import driver.DriverScript;
import pages.Hospital_HO400;
import pages.Hospital_HO409;
import pages.Hospital_HO410;
import pages.Hospital_HO430;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.Physician_CL209;
import util.FunctionLibrary;

public class ICESStepDefinition {
	
	public String Audit_number,Div;

public ICESStepDefinition() {
		
}


@Then("^the claim \"([^\"]*)\" in \"([^\"]*)\" is hit with review \"([^\"]*)\" in screen \"([^\"]*)\" and is processed by CES batch \"([^\"]*)\"$")
public void the_claim_in_is_hit_with_review_in_screen_and_is_processed_by_CES_batch(String Audit_number, String Div, String Review1, String Screen2, String Rev_user_code) throws Throwable {
    FunctionLibrary.navigateToDiv(Screen2);
	  Physician_CL209 phy_val1 = new Physician_CL209();
	  phy_val1.CL209_Inquire(Audit_number,Div);
	  List<String> exp_result = new ArrayList<String>();
	  exp_result.add(Review1);
	  exp_result.add(Rev_user_code);
	  List act_review_code =phy_val1.review_val(Review1);
      Assert.assertEquals(act_review_code,exp_result);
      System.out.println("Values returned " +act_review_code);
	  System.out.println("Expected outcome " +exp_result);
	  Reporter.addStepLog("Actual review code is " +act_review_code);
	}

@When("^the Primary Diagnosis code is \"([^\"]*)\" in the screen \"([^\"]*)\"$")
public void the_Primary_Diagnosis_code_is_in_the_screen(String Diag, String Screen1) throws Throwable {
  Physician_CL201 phy_val1 = new Physician_CL201();
  String act_diag1 =phy_val1.Diag1_val();
  Assert.assertEquals(act_diag1,Diag);
  System.out.println("Diagnosis code is " +act_diag1);
  Reporter.addStepLog("Diagnosis code is " +act_diag1);
}

@Then("^the \"([^\"]*)\" value is \"([^\"]*)\" from \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\"$")
public void the_value_is_from_for_primary_key_as_and_as_and_as(String column1, String Exp_Mnemonic, String tablename, String keyfield1, String keyvalue1, String keyfield2, String keyvalue2, String keyfield3, String keyvalue3) throws Throwable {
	String col = FunctionLibrary.Ret_OneValue_DB2Validation_InputThree(column1, tablename,"", keyfield1, keyvalue1, keyfield2, keyvalue2, keyfield3, keyvalue3).trim();
	Assert.assertEquals(col,Exp_Mnemonic);
	System.out.println("Mnemonic is " +col);
	Reporter.addStepLog("Mnemonic is " +col);
}

@When("^claim has one of the modifier \"([^\"]*)\" for cpt code \"([^\"]*)\" in screen \"([^\"]*)\"$")
public void claim_has_one_of_the_modifier_for_cpt_code_in_screen(String Mod, String Cpt, String Screen) throws Throwable {
	
	Physician_CL201 phy_screen = new Physician_CL201();
	String act_cpt = phy_screen.proc1_val();
	if(Cpt.contains(act_cpt))
		{
			Reporter.addStepLog("Actual CPT " + act_cpt);
			String mod1 = phy_screen.proc1_mod1_val();
			String mod2 = phy_screen.proc1_mod2_val();
			String mod3 = phy_screen.proc1_mod3_val();
			String mod4 = phy_screen.proc1_mod4_val();
			List<String> Act_Mod = new ArrayList<String>();
			Act_Mod.add(mod1);
			Act_Mod.add(mod2);
			Act_Mod.add(mod3);
			Act_Mod.add(mod4);
			System.out.println(Act_Mod);
			if (Act_Mod.contains(Mod))
			{
				Reporter.addStepLog("PROC code has expected modifier" + Act_Mod);
			}
			else
			{
				Assert.assertEquals(Act_Mod, Mod);
				Reporter.addStepLog("No modifiers on claim");
			}
		}
    
}

}
