package stepDefinition;
//
//
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.Assert;

import com.cucumber.listener.Reporter;
import com.hp.lft.common.StringUtils;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Physician_CL201;
import pages.Physician_CL202;
import pages.TB130;
import pages.TB491;
import pages.TB_470;
import pages.TB_477;
import util.FunctionLibrary;

public class NegativePayee {
	Physician_CL201 cl_201=new Physician_CL201();
	String chk=null;
	String Fin_id=null;
	String Legal_id=null; 
	public static String paid=null;
	public static String calc=null;

	@Then("^the claim type should be \"([^\"]*)\"$")
	public void the_claim_type_should_be(String val) throws Throwable {
		String claim=null;
		claim=cl_201.org_val();
		if (val.equalsIgnoreCase("ORG")) {
			Assert.assertEquals(claim, "ORG");
			System.out.println("value matched: "+claim);
		}

		Reporter.addStepLog("Claim type-verified ");

	}

	@Then("^the claim type should be ADJ \"([^\"]*)\" on Screen \"([^\"]*)\"$")
	public void the_claim_type_should_be_ADJ_on_Screen(String val,String Screen) throws Throwable {
		Physician_CL201 phy_val1 = new Physician_CL201();
		Physician_CL202 phy_val2 = new Physician_CL202();
		String claim=null;


		if (val.equalsIgnoreCase("ADJ")) {
			if (Screen.equalsIgnoreCase("CL201")) {
				claim=phy_val1.org_val();
			}
			else if (Screen.equalsIgnoreCase("CL202")) {
				claim=phy_val2.org_val();
			}

			Assert.assertEquals(claim, "ADJ");
			System.out.println("value matched: "+claim);
		}
		else{
			if (Screen.equalsIgnoreCase("CL201")) {
				phy_val1.main_screen.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER); 
			}
			else if (Screen.equalsIgnoreCase("CL202")) {
				phy_val2.SCREEN.sendTEKeys(com.hp.lft.sdk.te.Keys.ENTER); 
			}
			Thread.sleep(1000);
			if (val.equalsIgnoreCase("ADJ")) {
				Assert.assertEquals(claim, "ADJ");
				System.out.println("value matched: "+claim);
			}
		}

		Reporter.addStepLog("Claim type-verified ");
	}



	@Then("^the value of CHK should be present on \"([^\"]*)\"$")
	public void the_value_of_CHK_should_be_present_on(String Screen) throws Throwable {

		boolean flag=false;
		chk=cl_201.CHK_val();
		if (!chk.equalsIgnoreCase("")||(!chk.equalsIgnoreCase(null))) {
			System.out.println("CHK value is present");
			flag=true;
		}
		Assert.assertTrue(flag);
		Reporter.addStepLog("CHK value is present ");
	}  


	@Then("^the interest should be present on \"([^\"]*)\"$")
	public void the_interest_should_be_present_on(String Screen) throws Throwable {
		Physician_CL202 cl_202=new Physician_CL202();
		String intr=null;
		boolean flag=false;
		intr=cl_202.get_interest();
		if (!intr.equalsIgnoreCase("null")||(!intr.equalsIgnoreCase(""))) {
			System.out.println("Interest is present on screen");
			flag=true;
		}
		Assert.assertTrue(flag);
		Reporter.addStepLog("Interest present ");  
	}

	@Then("^the check returned should be \"([^\"]*)\" on \"([^\"]*)\"$")
	public void the_check_returned_should_be_on(String chk_Return, String Screen) throws Throwable {
		String  chk_return=null;
		Physician_CL202 cl_202=new Physician_CL202();
		chk_return=cl_202.get_chk_Returned_value();
		Assert.assertEquals(chk_return, chk_Return);
		System.out.println("Value of check returned matched");

		Reporter.addStepLog("chk returned verified");  
	}


	@Then("^the user gets financial id from the \"([^\"]*)\"$")
	public void the_user_gets_financial_id_from_the(String Screen) throws Throwable {
		Physician_CL202 cl_202=new Physician_CL202();

		Fin_id= cl_202.get_fin_id_value();
		System.out.println("financial id is: "+Fin_id);

	}

	@Then("^the user gets legal_id from the \"([^\"]*)\"$")
	public void the_user_gets_legal_id_from_the(String Screen) throws Throwable {
		Physician_CL202 cl_202=new Physician_CL202();

		Legal_id=cl_202.get_legal_id_value();
		System.out.println("legal id is: "+Legal_id);
	}


	@Then("^the user enter financial id on Screen \"([^\"]*)\"$")
	public void the_user_enter_financial_id_on_Screen(String Screen) throws Throwable {
		TB_470 tb470=new TB_470();
		TB_477 tb477=new TB_477();
		TB130 tb130= new TB130();
		TB491 tb491 = new TB491();
		if(Screen.equalsIgnoreCase("TB470")){
			tb470.enter_fin_id();	
		}
		else if (Screen.equalsIgnoreCase("TB477")) {
			tb477.enter_fin_id();
		}
		else if(Screen.equalsIgnoreCase("TB130")){
			tb130.enter_financial_id(Screen);
			
		}
		else if(Screen.equalsIgnoreCase("TB491")){
			tb491.enter_fin_id();
			
			
		}
	}


	@Then("^the user enter legal id on Screen \"([^\"]*)\"$")
	public void the_user_enter_legal_id_on_Screen(String Screen) throws Throwable {
		TB_470 tb470=new TB_470();
		TB_477 tb477=new TB_477();
		TB130 tb130= new TB130();
		TB491 tb491 = new TB491();
		if(Screen.equalsIgnoreCase("TB470")){
			tb470.enter_legal_id(Screen); 	
		}
		else if (Screen.equalsIgnoreCase("TB477")) {
			tb477.enter_legal_id(Screen);
		}
		else if (Screen.equalsIgnoreCase("TB130")){
			tb130.enter_legalentity();
		}
		else if (Screen.equalsIgnoreCase("TB491")){
			tb491.enter_legal_id(Screen);
			
		}
	
	}

	/*	@Then("^the eff date should be less than or equals to current date for the given legal and finanicial id on Screen \"([^\"]*)\"$")
	public void the_eff_date_should_be_less_than_or_equals_to_current_date_for_the_given_legal_and_finanicial_id_on_Screen(String ScreenName) throws Throwable {
		   FunctionLibrary f1=new FunctionLibrary();
			 f1.getLegalEntityClearDetails(ScreenName);  
	}
	 */


	@Then("^the eff date should be less than or equals to current date for the given legal and finanicial id on Screen \"([^\"]*)\" with criteria \"([^\"]*)\"$")
	public void the_eff_date_should_be_less_than_or_equals_to_current_date_for_the_given_legal_and_finanicial_id_on_Screen_with_criteria(String ScreenName, String Criteria) throws Throwable {
		FunctionLibrary f1=new FunctionLibrary();
		f1.getLegalEntityClearDetails(ScreenName, Criteria);
	}



	@Then("^the criteria should not met on Screen \"([^\"]*)\"$")
	public void the_criteria_should_not_met_on_Screen(String Screen) throws Throwable {
		FunctionLibrary f1=new FunctionLibrary();
		f1.getLegalEntityDetailsOnTB470(Screen);
	}

	@Then("^appropriate message \"([^\"]*)\" should be present on Screen \"([^\"]*)\"$")
	public void appropriate_message_should_be_present_on_Screen(String message,String Screen) throws Throwable {
		String msg=null;
		boolean flag=false;
		if (Screen.equalsIgnoreCase("CL201")) {
			Physician_CL201 phy_val1 = new Physician_CL201();
			msg=phy_val1.claim_msg();
		}
		else if (Screen.equalsIgnoreCase("CL202")) {
			Physician_CL202 phy_val2 = new Physician_CL202();
			msg=phy_val2.claim_msg();

		}

		if(message.equalsIgnoreCase("NEGATIVE PAYEE")){
			if (msg.contains("OOPS/DED PROCESSED - NEGATIVE PAYEE")) {
				System.out.println("Message verified for negative payee");
				flag=true;
			}
		}
		else if (message.equalsIgnoreCase("CHECKWRITE")) {
			if (msg.contains("CLAIM POSTED BY CHECKWRITE")) {
				System.out.println("Message verified for checkwritten");
				flag=true;
			}	
		}


		Assert.assertTrue(flag);
	}
	/*
	@Then("^appropriate message should be present on Screen \"([^\"]*)\"$")
	public void appropriate_message_should_be_present_on_Screen(String Screen,String message) throws Throwable {
		String msg=null;
		boolean flag=false;
		if (Screen.equalsIgnoreCase("CL201")) {
			Physician_CL201 phy_val1 = new Physician_CL201();
		    msg=phy_val1.claim_msg();
		}
		else if (Screen.equalsIgnoreCase("CL202")) {
			Physician_CL202 phy_val2 = new Physician_CL202();
		    msg=phy_val2.claim_msg();

		}

		if(message.equalsIgnoreCase("NEGATIVE PAYEE")){
		if (msg.contains("OOPS/DED PROCESSED - NEGATIVE PAYEE")) {
			System.out.println("Message verified for negative payee");
			flag=true;
		}
		}
		else if (message.equalsIgnoreCase("CHECKWRITE")) {
			if (msg.contains("CLAIM POSTED BY CHECKWRITE")) {
				System.out.println("Message verified for checkwritten");
				flag=true;
			}	
		}


		Assert.assertTrue(flag);
	}
	 */
	//db


	@Then("^The PRA indicator in column \"([^\"]*)\" value \"([^\"]*)\" in database \"([^\"]*)\" from Table \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\" with status \"([^\"]*)\" as \"([^\"]*)\"$")
	public void the_pra_indicator_in_column_value_in_database_from_Table_for_primary_key_as_and_as_with_status_as(String fieldname,String indicator, String db,String Table, String keyf, String Div, String keyf1, String Audit_number,String keyf2,String status) throws Throwable {

		boolean flag=false;
		// Write code here that turns the phrase above into concrete actions
		String ind_value = FunctionLibrary.DB2Validation(fieldname, db,Table, keyf, Div,keyf1,Audit_number,keyf2,status);
		Thread.sleep(1000);
		System.out.println("value from file:"+indicator);
		System.out.println("value from query:"+ind_value);
		if(indicator.equals(ind_value))
		{

			System.out.println("indicator value matched");
			flag=true;

			Reporter.addStepLog("Actual indicator value is:" +ind_value);
		}
		else
		{
			System.out.println("error");
			Reporter.addStepLog("Actual indicator value is:" +ind_value);
		}

		Assert.assertTrue(flag);
	}


	@Then("^The BAF status in column \"([^\"]*)\" value \"([^\"]*)\" in database \"([^\"]*)\" from Table \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\" with BAF notification letter \"([^\"]*)\" as \"([^\"]*)\"$")
	public void the_baf_status_in_column_value_in_database_from_Table_for_primary_key_as_and_as_with_BAF_notification_letter_as(String fieldname, String baf_status, String db, String Table, String keyf, String Div, String keyf1, String Audit_number, String keyf2, String letter) throws Throwable {

		boolean flag=false;
		// Write code here that turns the phrase above into concrete actions
		String baf_status_value = FunctionLibrary.DB2Validation(fieldname, db,Table, keyf, Div,keyf1,Audit_number,keyf2,letter);
		System.out.println("value from file:"+baf_status);
		System.out.println("value from query:"+baf_status_value);
		// boolean a= StringUtils.isNullOrEmpty(baf_status_value);
		if (baf_status_value==null) {
			System.out.println("No value present for baf status:pass");
			flag=true;
		}

		else if (baf_status_value.equalsIgnoreCase(baf_status)) {
			System.out.println("BAF status verified");
			flag=true;

		}

		Assert.assertTrue(flag);
	}




	/*	@Then("^The BAF status in column \"([^\"]*)\" value \"([^\"]*)\" in database \"([^\"]*)\" from Table \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\" with BAF notification letter \"([^\"]*)\" as \"([^\"]*)\"$")
	public void the_baf_status_in_column_value_in_database_from_Table_for_primary_key_as_and_as_with_BAF_notification_letter_as(String fieldname, String baf_status, String db, String Table, String keyf, String Div, String keyf1, String Audit_number, String keyf2, String letter) throws Throwable {

		boolean flag=false;
		// Write code here that turns the phrase above into concrete actions
		String baf_status_value = FunctionLibrary.DB2Validation(fieldname, db,Table, keyf, Div,keyf1,Audit_number,keyf2,letter);
		Thread.sleep(1000);
		System.out.println("value from file:"+baf_status);
		System.out.println("value from query:"+baf_status_value);
		if(baf_status.equals(baf_status_value))
		{

			System.out.println("matched");
			flag=true;
			Reporter.addStepLog("Actual BAF status value is:" +baf_status_value);
		}
		else
		{
			System.out.println("error");
			Reporter.addStepLog("Actual BAF status value is:" +baf_status_value);
		}
		Assert.assertTrue(flag);
	}*/

	@Then("^the user press enter on the screen \"([^\"]*)\"$")
	public void the_user_press_enter_on_the_screen(String Screen) throws Throwable {
		if (Screen.equals("TB470")) {
			TB_470 tb470=new TB_470();
			tb470.press_enter();
		}
		else if(Screen.equals("TB477")){
			TB_477 tb477=new TB_477();
			tb477.press_enter();
		}
	}

	@Then("^the user gets paid date from Sceen\"([^\"]*)\"$")
	public void the_user_gets_paid_date_from_Sceen(String Screen) throws Throwable {
		Physician_CL201 cl201=new Physician_CL201();
		FunctionLibrary fun=new FunctionLibrary();
		fun.navigateToDiv(Screen);
		paid=cl201.paid_val();
		System.out.println("Paid date: "+paid);

	}

	@Then("^the user gets calc date from Screen \"([^\"]*)\"$")
	public void the_user_gets_calc_date_from_Screen(String Screen) throws Throwable {
		Physician_CL202 cl202=new Physician_CL202();
		calc=cl202.calc_date();
		System.out.println("Calc date :"+calc);

	}
	

@Then("^the \"([^\"]*)\" value is  from \"([^\"]*)\" in database \"([^\"]*)\" for primary key \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\"$")
public void the_value_is_from_in_database_for_primary_key_as_and_as(String col_name, String table, String dbname, String field, String val, String field1, String val1) throws Throwable {
	boolean flag=false;
	String arr[]=null;
	String exp_val = FunctionLibrary.DB2ValidationForTwoString(col_name, dbname, table, field, val, field1, val1).trim();
	System.out.println(exp_val);
	
	//manipulate db date for verification
	exp_val=exp_val.substring(2,8);
	arr=exp_val.split("");
	String newDate=arr[2]+arr[3]+arr[4]+arr[5]+arr[0]+arr[1];
	System.out.println(newDate);


	if (col_name.equalsIgnoreCase("BAF_RECOV_CYMD")) {
		if(paid.equalsIgnoreCase(newDate)){
			System.out.println("Verified paid date");
			flag=true;
			Reporter.addStepLog("Paid date verified");
		}
	}
	else if (col_name.equalsIgnoreCase("BAF_NTFY_LTR_CYMD")) {
		if(calc.equalsIgnoreCase(newDate)){
			System.out.println("verified calc date");
			flag=true;
			Reporter.addStepLog("Calc date verified");
		}
	}
	
	Assert.assertTrue(flag);
}


}
